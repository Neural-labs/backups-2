import { Component } from '@angular/core';
import { ViewController, NavParams, IonicPage, Events } from 'ionic-angular';

import { AnalyticsService } from "../../../providers/analytics.service";
import { MeService } from '../../../providers/me.service';
import { QuestionsService } from '../../../providers/questions.service';
import { Agnes } from '../../../app/app.component';

import * as AWS from 'aws-sdk';
import * as S3 from 'aws-sdk/clients/s3';


@IonicPage()
@Component({
  selector: 'edit-me-popup',
  templateUrl: 'edit-me-popup.html',
  providers: [MeService, QuestionsService, AnalyticsService]

})

export class EditMePopup {
  type: string;
  edited: boolean;
  loading: boolean;
  shouldBlur: boolean;
  me: Object;
  oldPic: string;
  aboutme: string;
  fname: string;
  lname: string;
  studenttype: string;
  picurl: string;

  studentTypes: Array<string>;
  interestsAdd: string;
  skillsAdd: string;
  majorAdd: string;
  genders: Array<string>;
  gender: string;

  major: Array<string>;
  interests: Array<string>;
  skills: Array<string>;

  interestAutofillResults = [];
  skillsAutofillResults = [];

  constructor(public viewCtrl: ViewController,
              private meService: MeService,
              private events: Events,
              private questionsService: QuestionsService,
              private analyticsService: AnalyticsService,
              private navParams: NavParams) {
  }

  ngOnInit(){
    this.type = this.navParams.data.type;
    this.me = this.navParams.data.me;
    this.loading = false;
    this.shouldBlur = true;
    this.aboutme = this.me['aboutme'];
    this.fname = this.me['fname'];
    this.lname = this.me['lname'];
    this.studenttype = this.me['studenttype'];
    this.edited = false;
    this.picurl = this.me['picurl'];
    this.interestsAdd = this.skillsAdd = this.majorAdd = '';
    this.gender = this.me["gender"];
    if(this.gender == "" || this.gender == null ) {
      this.gender = "Prefer not to Answer";
    }

    this.major = this.me['major'];
    this.interests = this.me['keywords'].filter(function(a){return a.keytype == 'interest'}).map(function(a){return a.name});
    this.skills = this.me['keywords'].filter(function(a){return a.keytype == 'haveskill'}).map(function(a){return a.name});
    this.oldPic = this.me['picurl'];

    this.studentTypes = [
      "Freshman", "Sophomore", "Junior", "Senior", "Fifth year", "Masters", "PhD", "Alum", "Staff", "Other"
    ];

    this.genders = [
      "Male", "Female", "Nonbinary / Third Gender", "Prefer not to Answer"
    ];
  }

  closeEditMe(data) {
    this.viewCtrl.dismiss(data, '', {
      animate: true,
      animation: 'ios-transition',
      duration: 350,
      easing: "ease-in-out",
      direction: "back"
    });
  }

  //send edits
  submitEdits(){
    let ltype = this.type.toLowerCase();
    if(ltype == 'interests' || ltype == 'skills') {
      this.addKeyword(ltype, null, null);
    }
    if(ltype == 'basic info'){
      this.addKeyword('major', null, null);
    }

    //for interests: must have at least one interest
    //for basic info: must have first and last name and at least 1 major
    if (!((this.type == 'Interests' && this.interests.length == 0)
        || (this.type == 'General' && (this.major.length == 0 || this.fname.trim() == '' || this.lname.trim() == '')))) {
      this.loading = true;

      //submit edits
      this.me['keywords'] = this.interests.map(function(a){return {'keytype':'interest', 'name': a}})
          .concat(this.skills.map(function(a){return {'keytype':'haveskill','name':a}}));
      this.me['users_id'] = this.me['_id'];
      this.me['haveskill'] = this.skills;
      this.me['interest'] = this.interests;
      this.me['keyactive'] = [];
      this.me['postcol'] = [];
      this.me['issues'] = [];
      this.me['aboutme'] = this.aboutme;
      this.me['fname'] = this.fname;
      this.me['lname'] = this.lname;
      this.me['major'] = this.major;
      this.me['studenttype'] = this.studenttype;
      this.me['picurl'] = this.picurl;
      this.me['gender'] = this.gender;

      if (this.me['picurl'] != '' && (this.me['picurl'] != this.oldPic)){
        let creds = {
          bucket: 'agnesimages',
          access_key: 'AKIAJYQU6AUVQQKITAPQ',
          secret_key: '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'
        };

        let uniqueFilename = "";
        var possible = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
        for (var j = 0; j < 8; j++) {
          uniqueFilename += possible.charAt(Math.floor(Math.random() * possible.length));
        }

        let data = this.baseToBlob(this.me['picurl']);
        AWS.config.update({region: 'us-east-1',credentials: {
          accessKeyId: "AKIAJYQU6AUVQQKITAPQ",
          secretAccessKey:"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"
        }});

        let keyname = uniqueFilename + '.jpg';
        keyname = '_' + keyname;

        //TODO if the orientation stuff came up!
        /* if(this.orientation){
         keyname = '_' + keyname;
         }
         else{
         keyname = '_' + uniqueFilename
         }
         */

        //Bucket Parameters
        let bucketParams = {
          Key: keyname,
          ContentType: ".jpg",
          Body: data ,
          ServerSideEncryption: 'AES256',
          Bucket: creds.bucket
        };

        //bucket to define
        let bucket = new S3({ params: { Bucket: 'agnesimages' } });

        bucket.putObject(bucketParams, (err, data) => {
          if(err) {
            console.log('bucket error',err);
            return false;
          }
          else {
            // Upload Successfully Finished
            let pic = 'https://s3.amazonaws.com/agnesimages/' + keyname;

          }
        });

        this.me['picurl'] = 'https://s3.amazonaws.com/agnesimages/' + keyname;
      }


      this.meService.editMe(this.me)
          .then( data => {
            this.loading = false;
            if (data){
              let sendData = {
                data:data,
                picurl:this.picurl
              };

              this.me = data;
              localStorage.setItem('agnesUser', JSON.stringify(this.me));
              this.events.publish('updatedMe', data);
              
              this.closeEditMe(sendData);
            }
            else {
              Agnes.showError("Sorry, couldn't save your edits right now - try again!");
            }
          })
          .catch(err => {
            this.loading = false;
            Agnes.showError("Sorry, couldn't save your edits right now - try again!");
          });
    }
  }

  //autofill interests/skills
  search(type, term) {
    let matches = [];
    let data = {"searchTerm": term.trim().toLowerCase(), 'type':type};

    if (term.trim().length == 0) {
      this[type+'AutofillResults'] = [];
    }
    else {
      this.questionsService.autocomplete(data).then(value => {
        if (value) {
          matches = value;
          this[type+'AutofillResults'] = matches.map(function (a) {
            return a['keyword']
          });
        }
        else {
          this[type+'AutofillResults'] = [];
        }
      });
    }
  }

  //for adding keywords to skills or interests
  addKeyword(type, term, e){

    //for keeping keyboard up when + button is pressed
    if(e){
      e.preventDefault();
      this.shouldBlur = false;
    }

    let keyword = term ? term : this[type + 'Add'].toLowerCase();

    if(keyword.trim() != '' && this[type].indexOf(keyword) == -1) {
      this[type].push(keyword);
      this[type+'Add']='';
      setTimeout(() => {
        let elem = document.getElementById(type.toLowerCase() + 'Keywords');
        elem.scrollTop = elem.scrollHeight;
      },100);
    }

    this[type +'AutofillResults'] = [];
  }

  //clear results list if user taps off of it
  clearSearch(e){
    this.skillsAutofillResults = [];
    this.interestAutofillResults = [];
  }

  //for removing keywords from skills or interests
  removeKeyword(type,keyword){
    let ind = this[type].indexOf(keyword);
    if(ind != -1) {this[type].splice(ind,1);}
  }

  //adding keywords using the Enter key
  onEnter(ev,type){
    if(ev.keyCode == 13) {
      this.addKeyword(type, null, null);
    }
  }

  //adding/changing profile photo where type is either camera or upload
  addPhoto(type){
    let source = (type == 'camera') ? Agnes.camera.PictureSourceType.CAMERA : Agnes.camera.PictureSourceType.PHOTOLIBRARY;
    let options = {
      quality: 25,
      allowEdit: true,
      cameraDirection: Agnes.camera.Direction.FRONT,
      correctOrientation: true,
      destinationType: Agnes.camera.DestinationType.DATA_URL,
      sourceType: source
    };

    Agnes.camera.getPicture(options).then((value) => {
      if (value && typeof(value)=='string'){
        let base64Image = 'data:image/jpeg;base64,' + value;
        this.picurl = base64Image;
      }
      else {
        console.log('not base64', value);
        Agnes.showError("Couldn't process your photo - try again!");
      }
    }).catch(err => {
      console.log('camera err', err);
      if (err != 'Camera cancelled.' && err != 'no image selected') {
        Agnes.showError("Couldn't get your photos - make sure Agnes has photo access permissions and try again!");
      }
    });
  }

  //for converting uploaded/camera photo
  baseToBlob(dataURI) {
    // convert base64/URLEncoded data component to raw binary data held in a string
    var byteString;
    if (dataURI.split(',')[0].indexOf('base64') >= 0)
      byteString = atob(dataURI.split(',')[1]);
    else
      byteString = (dataURI.split(',')[1]);

    // separate out the mime component
    // var mimeString = dataURI.split(',')[0].split(':')[1].split(';')[0];

    // write the bytes of the string to a typed array
    var ia = new Uint8Array(byteString.length);
    for (var i = 0; i < byteString.length; i++) {
      ia[i] = byteString.charCodeAt(i);
    }

    return new Blob([ia.buffer], {type: "image/jpeg"});
  }

  //for keeping keyboard up when + button is pressed for keywords
  keepKeyboard(event){
    // if(!this.shouldBlur){
    //   event.target.focus();
    //   this.shouldBlur = true;
    // }
  }

}

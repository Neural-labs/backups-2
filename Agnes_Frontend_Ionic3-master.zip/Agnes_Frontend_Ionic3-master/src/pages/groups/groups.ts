import {Component, ViewChild} from '@angular/core';
import { FormControl } from '@angular/forms';
import { Content, Events, Select, IonicPage, App, ToastController, PopoverController } from 'ionic-angular';
import { AnalyticsService } from "../../providers/analytics.service";
import { GroupsService } from '../../providers/groups.service';
import { MeService } from '../../providers/me.service';
import { Agnes } from '../../app/app.component';

@IonicPage()
@Component({
  selector: 'page-groups',
  templateUrl: 'groups.html',
  providers: [ GroupsService, AnalyticsService, MeService ]
})

export class GroupsPage {

  @ViewChild('categorySelector') categorySelector: Select;
  @ViewChild('discoverGroupsContent') content: Content;

  matchedGroups: Array<Object>;
  allGroups: Array<Object>;
  adminGroups: Array<Object>;
  memberGroups: Array<Object>;
  followGroups: Array<Object>;

  recommendedGroups: Array<Object>;
  loadingRecommended: boolean;

  storedAll = [];
  searchedGroups = [];

  user: Object;
  loading: boolean;
  noInternet: boolean;
  noContent: boolean;
  refreshEnabled: boolean;

  groupSearch: string;
  isMatched: boolean;
  searching: boolean;
  initialized: boolean;
  batchNum: number;
  favoritesOn: boolean;
  canOpenFavorites: boolean;
  currentPage: number;

  searchControl: FormControl;

  groupCategories = [];
  tallCategories = ['Advocacy and Awareness', 'Greek Life',
      'Identity, Culture, and Language', 'Service', 'STEM'];

  selectedCategory = '';
  dropdownOpen = false;

  constructor(private groupsService: GroupsService,
              public appCtrl: App,
              private events: Events,
              private toastCtrl: ToastController,
              private popoverCtrl: PopoverController,
              private meService: MeService,
              private analyticsService: AnalyticsService){
    this.searchControl = new FormControl();
  }

  //initialize groups page - get and display matched groups first
  //TODO: test search term check
  ngOnInit(){

    this.refreshEnabled = true;
    this.currentPage = 1;
    this.adminGroups = [];
    this.memberGroups = [];
    this.followGroups = [];
    this.initialized = false;
    this.matchedGroups = [];
    this.allGroups = [];

    this.recommendedGroups = [];
    this.loadingRecommended = true;

    this.favoritesOn = false;
    this.canOpenFavorites = false;
    this.getMyGroups(null);
    this.getRecommended();
    this.initDiscoverGroups();

    this.events.subscribe('groupDeleted', (group) => {
      this.groupDeleted(group);
    });

    this.events.subscribe('groupSearch', term => {
      this.groupSearch = term;
      this.searchGroups(0);
    });

    //user has edited one of their groups
    this.events.subscribe('groupEdited', group => {
        this.refreshGroups(null);
    });

    this.events.subscribe('resumeApp', function() {
      console.log('resumed')
      this.initDiscoverGroups();
    })

    //user has joined a (public) group
    this.events.subscribe('addedGroup', (data) => {
      let ind = this.matchedGroups.map(a => {return a['_id']}).indexOf(data['group']['_id']);
      if(ind != -1) {
        this.matchedGroups.splice(ind,1);
      }

      this.refreshGroups(null);
    });

    //update groups list when user has left or unfollowed group
    this.events.subscribe('leftGroup', (data) => {
        this.leftGroup(data.group);
      this.refreshGroups(null);
    });

    //user shared an event to one of his/her groups, refresh group list
    this.events.subscribe('sharedEventToGroup', () => {
        this.refreshGroups(null);
    });

    //user's request to join a group has been accepted - refresh whatever list user is viewing
    this.events.subscribe('reqAcceptedNewMember', () => {
      this.refreshGroups(null);
    });

    //refresh group list when group has been deleted
    this.events.subscribe('groupDeleted',(data) => {
        this.refreshGroups(null);
    });

    //user's request to join a group has been accepted, refresh My Grousp to reflect that user is now part of new group
    this.events.subscribe('reqAcceptedNewMember', () => {
        this.refreshGroups(null);
    });

    //user has created an event hosted by one of user's groups
    this.events.subscribe('eventHosted', data => {
        this.refreshGroups(null);
    });

    //user has shared an event to one of user's groups
    this.events.subscribe('eventSharedToGroup', data => {

        let grps = data['groups'];
        let admGrps = this.adminGroups.map(a => {return a['_id']});

        let ind, eInd;
        for(let g in grps){
            ind = admGrps.indexOf(grps[g]);

            if(ind != -1){
                eInd =this.adminGroups[ind]['sharedEvents'].indexOf(data.event['_id']);
                if(eInd == -1) {
                    this.adminGroups[ind]['sharedEvents'].push(data.event['_id']);
                }
            }
        }
    });

    //user accepted join requests in notifications - update group membership
    this.events.subscribe('groupReqsResponse', data => {
        let ind = this.adminGroups.map(a => {return a['_id']}).indexOf(data['groups_id']);
        if(ind != -1){
            //add new admins
            this.adminGroups[ind]['admin'] = this.adminGroups[ind]['admin'].concat(data['newadmin'].filter(b => {
                    return this.adminGroups[ind]['admin'].indexOf(b) == -1}));

            //add new members
            this.adminGroups[ind]['members'] = this.adminGroups[ind]['members'].concat(data['newmember'].filter(b => {
                return this.adminGroups[ind]['members'].indexOf(b) == -1}));
        }
    });

    //user has been promoted to admin within group
    this.events.subscribe('adminPromotion', () => {
        this.getMyGroups(null);
    });

    this.groupSearch = '';
    //for keeping track of search batches
    this.batchNum = 0;

  }

  //save matched groups in local storage when exiting page
  ionViewWillLeave() {
    localStorage.setItem('agnesMatchedGroups', JSON.stringify(this.matchedGroups));
  }

  //disable/enable pull-to-refresh depending on whether you are currently touching the sideways scroll div
  enableRefresh(enable){
    this.refreshEnabled = enable;
  }

  getGroupCategories(){
    this.groupCategories = [];
    this.groupsService.getGroupCategories({}).then(val =>{
      this.groupCategories = val.map(x => x['category_name'][0]).sort().map(x => {
        return {
          grpname: x,
          picurl: 'assets/img/groupCategories/' + x.replace(/,*\s+/g, '_').toLowerCase() + '.jpg'
        }
      });
    }).catch(err => {
      console.log(err);
    });
  }

  getMyGroups(refresher){
      this.user = JSON.parse(localStorage.getItem('agnesUser'));

      let grps = this.user['grp'].map(function (a) {
          return a['groups_id'];
      }).concat(this.user['following'].map(a => {return a['groups_id']}));

      if(grps.length == 0){
        this.canOpenFavorites = true;
      }
      else {

        this.groupsService.getGroupsFromId({'grp':grps}).then(groups => {
          let myGroups = this.user['grp'].map(a => {return a['groups_id']});

          this.adminGroups = groups.filter(a => {
            let ind = myGroups.indexOf(a['_id']);
            return (ind != -1 ? this.user['grp'][ind]['admin'] : false);
          }).map( a => {
            a['displayURL'] = (a['thumbnail'] == '' || !a['thumbnail'] || !this.isImage(a.thumbnail)
            || a['thumbnail'].indexOf("'") != -1 ? "assets/img/pattern_" + Math.floor((Math.random() * 15) + 1) + '.png' : a['thumbnail']);
            return a;
          });

          this.memberGroups = groups.filter(a => {
            let ind = myGroups.indexOf(a['_id']);
            return (ind != -1 ? !this.user['grp'][ind]['admin'] : false);
          }).map( a => {
            a['displayURL'] = (a['thumbnail'] == '' || !a['thumbnail'] || !this.isImage(a.thumbnail)
            || a['thumbnail'].indexOf("'") != -1 ? "assets/img/pattern_" + Math.floor((Math.random() * 15) + 1) + '.png' : a['thumbnail']);
            return a;
          });

          let following = this.user['following'].map(a => {return a['groups_id']});

          this.followGroups = groups.filter(a => {
            return following.indexOf(a['_id']) != -1;
          }).map( a => {
            a['displayURL'] = (a['thumbnail'] == '' || !a['thumbnail'] || !this.isImage(a.thumbnail)
            || a['thumbnail'].indexOf("'") != -1 ? "assets/img/pattern_" + Math.floor((Math.random() * 15) + 1) + '.png' : a['thumbnail']);
            return a;
          });

          this.canOpenFavorites = true;
          if(refresher){refresher.complete();}

        }).catch(err => {
          console.log(err);
          Agnes.showError("Could not get your groups right now - try refreshing!");
          if(refresher){refresher.complete();}
        });
      }
  }

  noGroups() {
      return this.adminGroups.length == 0 && this.memberGroups.length == 0 && this.followGroups.length == 0
  }

  initDiscoverGroups(){
    this.user = JSON.parse(localStorage.getItem('agnesUser'));
    this.groupSearch = '';
    this.isMatched = true;
    this.getGroupCategories();
    // this.randomizeCategories();

    if(!Agnes.network || Agnes.network.type != 'none'){
      this.noInternet = false;

      //TODO: check if user has loaded from search term
      let searchTerm = localStorage.getItem("agnesGroupSearch");
      if (searchTerm){
        this.isMatched = false;
        this.groupSearch = searchTerm;
        this.searchGroups(0);
      }
      else {
        let timeout;
        if (localStorage.getItem('agnesGroupsTimeout')) {
          let t = new Date(JSON.parse(localStorage.getItem('agnesGroupsTimeout')));
          timeout = new Date(t.setHours(t.getHours()+ 12));
        }
        else {
          timeout = new Date()
        }

        let stored = JSON.parse(localStorage.getItem('agnesMatchedGroups'));
        if (new Date() > timeout || !stored){
          localStorage.removeItem('agnesGroupsTimeout');
          this.getMatchedGroups(null);
        }
        else {
          this.matchedGroups = stored;
        }

        this.getAllGroups(null);
        this.getFriends();
        this.initialized = true;
      }

      //update lists if group has been left/deleted from group profile
      this.events.subscribe('groupProfileData', data => {
        if (data) {
          let group = data.group;
          if(data.leftGroup && this.isMatched){
            this.leftGroup(group);
          }
          else {
            // this.updateGroup(group);
            if(data.category == 'delete') {
              this.events.publish('groupDeleted',data.group);
            }
          }
        }
      });
    }
    else {
      //lack of internet connection - show Tap to Refresh div
      this.noInternet = true;
      this.loading = false;
    }
  }

  randomizeCategories(){
    let currentIndex = this.groupCategories.length, temporaryValue, randomIndex;

    // While there remain elements to shuffle...
    while (0 !== currentIndex) {

      // Pick a remaining element...
      randomIndex = Math.floor(Math.random() * currentIndex);
      currentIndex -= 1;

      // And swap it with the current element.
      temporaryValue = this.groupCategories[currentIndex];
      this.groupCategories[currentIndex] = this.groupCategories[randomIndex];
      this.groupCategories[randomIndex] = temporaryValue;
    }
  }

  /*************************************************************************************************************/
  /*************************************** main loading functions **********************************************/
  /*************************************************************************************************************/

  //get user's matched groups
  getMatchedGroups(refresher) {

    let stored = [];
    if (localStorage.getItem('agnesMatchedGroups') != undefined &&
        localStorage.getItem('agnesMatchedGroups') != 'undefined') {
      stored = JSON.parse(localStorage.getItem('agnesMatchedGroups'))
    }

    let timeout = {};
    if (localStorage.getItem('agnesGroupsTimeout')) {
      let t = new Date(JSON.parse(localStorage.getItem('agnesGroupsTimeout')));
      timeout = new Date(t.setHours(t.getHours()+ 12));
    }
    else {
      timeout = new Date()
    }
    // t = new Date(JSON.parse(localStorage.getItem('agnesGroupsTimeout')));
    // let timeout = new Date(t.setHours(t.getHours()+ 12));
    let now = new Date();

    if(refresher != null || stored.length == 0 || now > timeout){
      let data = {'id': this.user["_id"], 'community':this.user['community']};
      this.groupsService.getMatchedGroups(data).then(value => {
        this.loading = false;

        if (value) {
          this.matchedGroups = value;

          this.displayGroups(value,false,'matched');
        }
        else {
          this.noInternet = true;
        }
        if(refresher){
          refresher.complete();
        }
      }).catch(function(error){
        this.loading = false;
        if (refresher) {
          refresher.complete();
        }
        //if timeout, show connection error screen
        if(error == 'timeout') {this.noInternet = true;}
        this.getMatchedGroups(refresher);
        console.log(error);
      });
    }
    else {
      this.matchedGroups = stored;
      this.loading = false;
    }
  }

  //get all community groups from database
  getAllGroups(refresher){

    let data = {'users_id': this.user["_id"], 'community':this.user['community']};
    this.groupsService.getAllGroups(data).then(value => {
      this.loading = false;
      if (value) {
        //filter out secret groups that user is not a member/admin of
        value = value.filter(a => {
          return a['grptype'] != 'secret' || (a['grptype'] == 'secret' &&
              (a['admin'].indexOf(this.user['_id']) != -1 ||
              a['members'].indexOf(this.user['_id']) != -1));
        });

        this.allGroups = value;
        this.displayGroups(value,false,'all');
      }
      if(refresher){
        refresher.complete();
      }
    }).catch(error => {
      this.loading = false;
      console.log(error);
      this.getAllGroups(refresher);
    });
  }

  //add events to Dates arrays and display array
  displayGroups(groups, loadingMore, ogType){

    let type = (ogType == 'search' ? 'all' : ogType);

    //filter out all null and unavilable groups, add displayURL to each group
    groups = groups.filter((a) => {return a != null}).map((a) => {

      a['displayURL'] = (a['picurl'] == '' || !a['picurl'] || !this.isImage(a.picurl) || a['picurl'].indexOf("'") != -1
          ? "assets/img/pattern_0.png" : a['picurl']);

      return a;
    });

    if(loadingMore) {
      this.allGroups = this.allGroups.concat(groups);
      this.storedAll = this.storedAll.concat(groups);
    }
    else {
      this[type+'Groups'] = groups;

      if(type == 'matched'){
        localStorage.setItem('agnesMatchedGroups', JSON.stringify(this.matchedGroups));
        localStorage.setItem('agnesGroupsTimeout', JSON.stringify(new Date()));
      }
      else if(ogType == 'all') {
        this.storedAll = this.allGroups;
      }
    }

    //show No Content div if search returns nothing
    if(this.allGroups.length == 0) {
      this.noContent = true;
    }
    else {
      this.noContent = false;
    }
  }

  sortGroups(groups) {
    return groups.sort(function(a,b){
      let aName = a['grpname']
      let bName = b['grpname']
      return aName < bName
    })
  }

  //check to see if image will load
  isImage(src) {
    let image = new Image();
    let isImage = true;
    image.src = src;
    image.onerror = function() {
      isImage = false;
    };
    image.onload = function() {
      isImage = true;
    };

    return isImage;
  }

  //refresh groups list
  refreshGroups(refresher){
    if(!Agnes.network || Agnes.network.type != 'none'){
      this.events.publish('updateUser');
      this.events.subscribe('updateDone',() => {
        this.events.unsubscribe('updateDone');
        this.user = JSON.parse(localStorage.getItem('agnesUser'));
        this.getFriends();

        this.canOpenFavorites = false;
        this.getMyGroups(null);

        if(this.isMatched){
          localStorage.removeItem('agnesMatchedGroups');
          localStorage.removeItem('agnesEventsTimeout');
          this.getMatchedGroups(refresher);
        }
        else {
          if(this.groupSearch != '') {
            this.searchGroups(0, refresher);
          }
          else {
            this.getAllGroups(refresher);
          }
        }
      });
    }
    else {
      //lack of internet connection - alert
      Agnes.showError('You are offline! Try refreshing again when you reconnect.');
      refresher.complete();
    }
  }

  //load more events for All Groups list
  loadMoreGroups(infiniteScroll){
    //load more from search term
    if(this.groupSearch != ''){
      this.batchNum += 1;
      this.searchGroups(this.batchNum,infiniteScroll);
    }
    else {
      let data = {
        "community": this.user["community"],
        "users_id": this.user["_id"],
        "page": this.currentPage + 1
      };

      this.groupsService.loadMoreGroups(data).then(moreGroups =>{
        if (moreGroups){
          if(moreGroups.length == 1){
            infiniteScroll.enable(false);
          }
          else {
            this.currentPage += 1;
            this.displayGroups(moreGroups.slice(1),true,'all');
          }
        }
        infiniteScroll.complete();
      }).catch(error => {
        infiniteScroll.complete();
        console.log(error);
      });
    }
  }

  //get user's fb friends for displaying on group cards
  getFriends(){
    let data = {
      "users_id": this.user['_id'],
      "community": this.user['community']
    };

    this.meService.getFriends(data).then(value => {
      this.loading = false;
      if(value.friends && value.friends.length > 0){
        this.user['fbfriends'] = value.friends.filter(a => {return a['_id'] != this.user['_id']}).map(b => {
          return {['_id']: b['_id'], 'thumbnail': b['thumbnail'] != '' ? b['thumbnail'] : b['picurl']};
        });
      }
      else {
        this.user['fbfriends'] = [];
      }

      this.events.publish('sendFriendsToCard', this.user['fbfriends']);

    }).catch(err => {
      this.loading = false;
      console.log(err);
    });
  }

  //get recommended groups
  getRecommended(refresh?){
    if(refresh){
      this.recommendedGroups = [];
    }

    this.loadingRecommended = true;

    this.user = JSON.parse(localStorage.getItem('agnesUser'));

    this.groupsService.getMatchedGroups({'id': this.user['_id']}).then(groups => {
      this.recommendedGroups = groups.map( a => {
        a['displayURL'] = (a['thumbnail'] == '' || !a['thumbnail'] || !this.isImage(a.thumbnail)
        || a['thumbnail'].indexOf("'") != -1 ? "assets/img/pattern_" + Math.floor((Math.random() * 15) + 1) + '.png' : a['thumbnail']);
        return a;
      });
      this.loadingRecommended = false;
    }).catch(err => {
      console.log(err);
      Agnes.showError("Could not get your groups right now - try refreshing!");
      this.loadingRecommended = false;
    });
  }

  /*************************************************************************************************************/
  /***************************************** filtering/searching ***********************************************/
  /*************************************************************************************************************/

  //toggle interested/joined groups on and off
  toggleFavorites(){
    if(this.canOpenFavorites){
      if(!this.favoritesOn) {
        if(this.adminGroups.length + this.memberGroups.length + this.followGroups.length == 0) {
          Agnes.showError("You aren't part of any groups yet - try following or joining some to get started!")
        }
        else {
          this.content.scrollToTop(0);
          this.favoritesOn = true;

          //sending My Group List analytics
          this.analyticsService.logAnalytics({community: this.user['community'], users_id: this.user['_id']}, '/groupMyList');
        }
      }
      else {
        this.favoritesOn = false;
      }
    }
  }

  //search groups by title or keywords
  searchGroups(batchNum, refresher?){
    //reset search batch number for new searches
    if(batchNum == 0) {this.batchNum = 0;}

    //exit My Groups list if on it
    this.favoritesOn = false;

    if(this.batchNum == 0) {if(this.content && this.content._scroll){this.content.scrollToTop(0);}}
    if (this.groupSearch && this.groupSearch.trim().length > 0) {

      let data = {
        "searchTerm":this.groupSearch,
        "community":this.user["community"],
        "scroll": batchNum,
        "users_id": this.user['_id']
      };

      this.loading = true;

      this.groupsService.searchGroups(data)
          .then(value => {
            this.loading = false;

            if(value){

              //filter out secret groups that user is not a member/admin of
              value = value.filter(a => {
                return a['grptype'] != 'secret' || (a['grptype'] == 'secret' &&
                    (a['admin'].indexOf(this.user['_id']) != -1 ||
                    a['members'].indexOf(this.user['_id']) != -1));
              });

              let more = batchNum != 0;
              // this.displayGroups(value,more,'search');
              this.searchedGroups = value;
              if(value.length == 0){this.batchNum = 0;}
            }
            else{
              this.allGroups = this.storedAll;
              this.batchNum = 0;
            }

            if(refresher){refresher.complete();}
          })
          .catch((error) => {
            this.loading = false;
            console.log(error);
            this.batchNum = 0;
            if(refresher){refresher.complete();}
          });
    }
    else {
      this.allGroups = this.storedAll;
      this.refreshGroups(null);
      if(this.content._scroll){this.content.scrollToTop(0);}
    }
  }

  hasNoGroups() {
    if (this.isMatched) {
      let elems = document.querySelectorAll('ion-list#groupList ion-item.hide');
      let noEvents = (elems != null ? elems.length == this.matchedGroups.length : true);
      return noEvents;
    }
    else {
      return this.allGroups.length == 0
    }
  }

  /*************************************************************************************************************/
  /********************************** handle data from profile/editing *****************************************/
  /*************************************************************************************************************/

  //user has left group - remove group from user's matched list (in display and backend)
  leftGroup(group){

    let data = {
      'groups_id': group['_id'],
      'users_id': this.user['_id']
    };

    this.groupsService.removeMatched(data).then(val => {
      if(val){
        let uInd = this.user['grp'].map(function(a){return a['groups_id']}).indexOf(group['_id']);
        let dispInd = this.matchedGroups.map(function(a){return a['_id']}).indexOf(group['_id']);

        this.user['grp'].splice(uInd,1);
        this.matchedGroups.splice(dispInd,1);

        localStorage.setItem('agnesMatchedGroups',JSON.stringify(this.matchedGroups));
        this.events.publish('updateUser');
      }
    }).catch(err =>{
      console.log('remove matched error', err);
      // Agnes.showError("Sorry, couldn't remove this group from your matched events - try again!");
    });
  }

  //group has been edited - update group object in displayed lists to reflect changes
  updateGroup(group){
    let mInd = this.matchedGroups.map(function(a){return a['_id'];}).indexOf(group['_id']);
    let aInd = this.allGroups.map(function(a){return a['_id'];}).indexOf(group['_id']);
    let sInd = this.storedAll.map(function(a){return a['_id'];}).indexOf(group['_id']);

    this.matchedGroups[mInd] = group;
    this.allGroups[aInd] = group;
    this.storedAll[sInd] = group;
  }

  //add created group to My Events list

  //delete group - remove from matched/all where applicable
  groupDeleted(group){
    let uInd = this.user['grp'].map(function(a){return a['groups_id']}).indexOf(group['_id']);
    let mInd = this.matchedGroups.map(function(a){return a['_id']}).indexOf(group['_id']);
    let aInd = this.allGroups.map(function(a){return a['_id']}).indexOf(group['_id']);

    if(uInd != -1){this.user['grp'].splice(uInd,1);}
    if(mInd != -1){this.matchedGroups.splice(mInd,1);}
    if(aInd != -1){
      this.allGroups.splice(aInd,1);
      this.storedAll = this.allGroups;
    }
  }

  imgError(group){
    group['noPic'] = true;
  }

  selectCategory(category){
    this.selectedCategory = category;
    this.toggleDropdown(false);
  }

  toggleDropdown(forceClose){
    this.dropdownOpen = forceClose ? false : !this.dropdownOpen;
  }

  openGroupProfile(group){
    this.groupsService.getGroupsFromId({'grp':[group['_id']]}).then(val =>{
      this.loading = false;
      if(val && val.length > 0){
        this.popoverCtrl.create('GroupProfile',{
          'group':val[0],
          'type': 'my'
        }, {}).present({
          animation: 'ios-transition',
          duration: 350
        });
      }
      else {
        Agnes.showError("Sorry, couldn't open this group profile!");
      }
    }).catch(err => {
      console.log(err);
      this.loading = false;
      Agnes.showError("Sorry, couldn't open this group profile!");
    });
  }

  openCategory(category){
    this.popoverCtrl.create('CategoryPage',{
      'category':category
    }, {}).present({
      animation: 'ios-transition',
      duration: 350
    });
  }

}

import main

def runTesting():
    main.runTests()

if __name__ == '__main__':
    runTesting()
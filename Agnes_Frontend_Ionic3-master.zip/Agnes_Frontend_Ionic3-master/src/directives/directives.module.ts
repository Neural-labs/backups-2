import { NgModule } from '@angular/core';
import { AgnesAutoGrowDirective } from './agnes-auto-grow/agnes-auto-grow';

@NgModule({
	declarations: [AgnesAutoGrowDirective],
	imports: [],
	exports: [AgnesAutoGrowDirective]
})
export class DirectivesModule {}

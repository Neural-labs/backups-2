from models import model_provider
from Detection_Testing.detection_testing import DetectionTester
from Detection_Training.detection_training import DetectionTrainer

DEFAULT_MODEL = 'svm'

class Detector:
    model = None
    model_type = DEFAULT_MODEL

    def __init__(self, model_type=None):

        if model_type:
            self.model_type = model_type
        # go get the model we are going to use
        self.model = model_provider.getDetectionModel(self.model_type)

    def run_training(self):
        trainer = DetectionTrainer(self.model)


    def run_testing(self):
        pass


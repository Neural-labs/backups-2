import { Component, ViewChild } from '@angular/core';
import { Events, IonicPage, App, PopoverController, Select } from 'ionic-angular';

import { AnalyticsService } from "../../../providers/analytics.service";
import { MeService } from '../../../providers/me.service';
import { GroupsService } from '../../../providers/groups.service';
import { LoginService } from '../../../providers/login.service';
import { EventsService } from '../../../providers/events.service';

import { InviteFriends } from '../../popups/invite-friends/invite-friends';
import { Agnes } from '../../../app/app.component';

import * as AWS from 'aws-sdk';
import * as S3 from 'aws-sdk/clients/s3';

@IonicPage()
@Component({
    selector: 'create-group',
    templateUrl: 'create-group.html',
    providers: [MeService, GroupsService, AnalyticsService, LoginService, EventsService]
})

export class CreateGroupPage {
    user: Object;
    group: Object;
    keywordInput: string;
    typeHelpText: string;
    localImg: string;
    loading: boolean;
    shouldBlur: boolean;
    isDefault: boolean;
    submitted: boolean;
    email: string;
    statusLimit = 200;
    descLimit = 1000;

    groupCategories: Array<string>;

    userEvents: Array<Object>;
    hostedEvents: Array<Object>;
    eventName: string;

    @ViewChild('eventSelect') eventSelect: Select;
    @ViewChild('categorySelect') categorySelect: Select;

    constructor(private groupsService: GroupsService,
                private eventsService: EventsService,
                private appCtrl: App,
                private analyticsService: AnalyticsService,
                private popoverCtrl: PopoverController,
                private loginService: LoginService,
                private events: Events){}

    //initialize Create Group page
    ngOnInit(){
        this.user = JSON.parse(localStorage.getItem('agnesUser'));
        this.keywordInput = '';
        this.loading = false;
        this.shouldBlur = true;
        this.initGroup();

    }

    //initialize group (or reset)
    initGroup(){
        this.submitted = false;

        this.group = {};
        this.group['keywords'] = [];
        this.group['status_quo'] = '';
        this.group['grpname'] = this.group['grpdesc'] = this.group['picurl'] = this.group['grpaddress'] = '';
        this.group['grptype'] = 'public';
        this.group['grpemail'] = [this.user['email']['uid']];
        this.group['weburl'] = this.group['members'] = [];
        this.group['community'] = this.user['community'];
        this.group['admin'] = [this.user['_id']];
        this.group['users_id'] = this.user['_id'];
        this.group['hostedEvents'] = [];
        this.group['topic'] = '';

        this.email = this.user['email']['uid'];

        this.userEvents = [];
        this.hostedEvents = [];
        this.eventName = '';

        this.localImg = '';
        this.isDefault = true;

        this.typeHelpText = 'Anyone can join this group';

        this.getUserEvents();
        this.getGroupCategories();
    }

    //get list of group categories
    getGroupCategories(){
        this.groupCategories = [];
        this.groupsService.getGroupCategories({}).then(val =>{
            this.groupCategories = val.map(x => x['category_name'][0]).sort();
        }).catch(err => {
            console.log(err);
        });
    }

    //get events a user is admin of
    getUserEvents(){
        this.userEvents = [];
        this.eventsService.getEventsFromId({"evt":this.user['evtrsvp'], 'community': this.user['community']}).then(value => {
            if (value && value.length > 0) {
                value = value
                    .filter(event => {
                    return event['admin'].indexOf(this.user['_id']) != -1;
                    })
                    .map(event => {
                    return {
                        evtname: event['evtname'],
                        _id: event['_id'],
                        picurl: event['picurl']
                    };
                });
                this.userEvents = value;
            }
        }).catch(err => {
        });
    }

    closeCreateGroup(backButton?) {
        if(backButton){
            //send Back Button analytics
            this.analyticsService.logAnalytics({
                backButtonName: 'createGroup',
                users_id: this.user['_id']}, '/backButton');
        }

      this.appCtrl.getRootNav().pop({
          animation: 'ios-transition',
          duration: 350,
          easing: "ease-in-out",
          direction: "back"
      });
    }

    //add keyword from keyword input field into event's keyword array
    addKeyword(e){

        //for keeping keyboard up when + button is pressed
        if(e){
            e.preventDefault();
            this.shouldBlur = false;
        }

        if(this.keywordInput.trim() != '') {
            let add = this.keywordInput.toLowerCase().trim().replace(/,\s+/,',').split(',')
                .map(a => {return a.trim()}).filter(a => {return this.group['keywords'].indexOf(a) == -1});
            this.group['keywords'] = this.group['keywords'].concat(add);
        }
        this.keywordInput = '';
    }


    //remove keyword from group
    removeKeyword(key){
        let ind = this.group['keywords'].indexOf(key);
        if(ind != -1){
            this.group['keywords'].splice(ind,1);
        }
    }

    //use return key to enter keyword
    onEnter(ev){
        if(ev.keyCode == 13) {
            this.addKeyword(null);
        }
    }

    //change help text of group type segment
    toggleType(){
        this.typeHelpText = this.group['grptype'] == 'public' ? 'Anyone can join this group'
            : (this.group['grptype'] == 'private' ? 'This group is invite-only'
                : 'Only group members can view this group');
    }

    //upload an image for this group
    addPhoto(){
        let options = {
            quality: 25,
            allowEdit: true,
            cameraDirection: Agnes.camera.Direction.FRONT,
            correctOrientation: true,
            destinationType: Agnes.camera.DestinationType.DATA_URL,
            sourceType: Agnes.camera.PictureSourceType.PHOTOLIBRARY
        };

        Agnes.camera.getPicture(options).then((value) => {
            if (value && typeof(value)=='string'){
                let base64Image = 'data:image/jpeg;base64,' + value;
                this.group['picurl'] = base64Image;
                this.localImg = base64Image;
                this.isDefault = false;
            }
            else {
                console.log('not base64', value);
                Agnes.showError("Couldn't process your photo - try again!");
            }
        }, (err) => {
            console.log(err);
        }).catch(err => {
            Agnes.showError("Couldn't get your photos - make sure Agnes has photo access permissions and try again!");
        });
    }

    // convert base64/URLEncoded data component to raw binary string
    baseToBlob(dataURI) {
        var byteString;
        if (dataURI.split(',')[0].indexOf('base64') >= 0)
            byteString = atob(dataURI.split(',')[1]);
        else
            byteString = (dataURI.split(',')[1]);

        // write the bytes of the string to a typed array
        var ia = new Uint8Array(byteString.length);
        for (var i = 0; i < byteString.length; i++) {
            ia[i] = byteString.charCodeAt(i);
        }

        return new Blob([ia.buffer], {type: "image/jpeg"});
    }

    //validate group details and submit group to database
    submitGroup(){

        this.submitted = true;
        this.addKeyword(null);

        let nameValid = this.group['grpname'] != '';
        let descValid = this.group['grpdesc'].trim() != '';
        let categoryValid = this.group['topic'].trim() != '';
        let keywordsValid = this.group['keywords'].length > 0;

        if(nameValid && keywordsValid && descValid && categoryValid){
            this.loading = true;

            if (this.group['picurl'] != ''){
                let creds = {
                    bucket: 'agnesgroupimage',
                    access_key: 'AKIAJYQU6AUVQQKITAPQ',
                    secret_key: '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'
                };
                let uniqueFilename = "";
                var possible = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";

                for (var i = 0; i < 8; i++) {
                    uniqueFilename += possible.charAt(Math.floor(Math.random() * possible.length));
                }
                this.localImg = this.group['picurl']
                let data = this.baseToBlob(this.group['picurl']);
                AWS.config.update({region: 'us-east-1',credentials: {
                    accessKeyId: "AKIAJYQU6AUVQQKITAPQ",
                    secretAccessKey:"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"
                }});

                let keyname = uniqueFilename + '.jpg';
                keyname = '_' + keyname;

                //Bucket Parameters
                let bucketParams = {
                    Key: keyname,
                    ContentType: ".jpg",
                    Body: data ,
                    ServerSideEncryption: 'AES256',
                    Bucket: creds.bucket
                };

                //bucket to define
                let bucket = new S3({ params: { Bucket: 'agnesgroupimage' } });

                bucket.putObject(bucketParams, function(err, data) {
                    if(err) {
                        console.log('bucket error',err);
                        return false;
                    }
                });

                this.group['picurl'] = 'https://s3.amazonaws.com/agnesgroupimage/' + keyname;
            }

            this.groupsService.addGroup(this.group)
                .then( data => {
                    this.loading = false;

                    if (data){
                        this.groupCreateSuccess(data, 'You\'ve successfully created ' + this.group['grpname'] + '!', false);
                    }
                    else {
                        Agnes.showError("Sorry, couldn't create your group right now - try again!");
                    }
                })
                .catch(err => {
                    this.loading = false;
                    Agnes.showError("Sorry, couldn't create your group right now - try again!");
                });
        }
        else {
            let message = "Uh oh, looks like you\'re missing at least one of the following: \n\n" +
                "name, description, category, or keywords\n\n Check again before submitting!";
            Agnes.showError(message);
        }
    }

    //for keeping keyboard up when + button is pressed for keywords
    keepKeyboard(event){
        if(!this.shouldBlur){
            event.target.focus();
            this.shouldBlur = true;
        }
    }

    //show success message w/ options to go to profile or invite members after group creation
    groupCreateSuccess(group, message, fromFB){
        if(!fromFB){
            if(this.localImg) {
                group['picurl'] = this.localImg;
            }
        }

        this.events.subscribe('agnesAlertData', ind => {
            this.events.unsubscribe('agnesAlertData');
            if (ind == 1){
                //go to invite members page
                this.popoverCtrl.create(InviteFriends,{
                    'type':'group',
                    'objectID': group['_id'],
                    'user': JSON.parse(localStorage.getItem('agnesUser')),
                    'filterIDs': [],
                    'group': group
                }, {}).present({
                    animation: 'ios-transition',
                    duration: 350
                });
            }
        });

        //auto open group profile
        this.popoverCtrl.create('GroupProfile',{
            'group':group,
            'type':'my'
        }, {}).present({
            animation: 'ios-transition',
            duration: 350
        }).then(() => {
            Agnes.showError(message,buttons);
        });

        //close create popover
        this.closeCreateGroup();

        let buttons = ['Group Profile', 'Invite Members'];



        // update host groups in create event
        this.events.publish('hostGroupCreated', group);
        this.events.publish('addedGroup', {'group': group, 'type':'admin'});
        this.user['grp'].push({'groups_id': group['_id'],'admin':true});
        localStorage.setItem('agnesUser',JSON.stringify(this.user));
    }

    //import group from facebook
    importFbGroup(){
        //user is connected to facebook, bring up list of groups to import from
        if(this.user['providerFBData']['providerId'] != '') {

            this.loading = true;

            let data = {
                'users_id':this.user['_id']
            };

            this.groupsService.getFBGroups(data).then(val => {
                this.loading = false;
                val = val.filter(a => {
                    return (typeof(a) == 'object');
                });

                if(val && val.length > 0){
                    val = val.map(a => {
                        a['_id'] = a['groups_id'];
                        a['thumbnail'] = a['picurl'];
                        return a;
                    });
                    let fbgroups = this.popoverCtrl.create(
                        'GroupListPopup',
                        {
                            'groupList': val,
                            'submitText': 'Import',
                            // 'helpText': 'Select a group to import from Facebook:',
                            'singleTap': true
                        },
                        {'enableBackdropDismiss':false});
                    fbgroups.present(
                        {
                            animate:true,
                            animation: 'md-transition',
                            duration: 200,
                            easing: "ease-in-out",
                            direction: "forward",
                        }
                    );

                    fbgroups.onDidDismiss(group => {

                        if(group){
                            let newGroup = {
                                grpname: group['grpname'],
                                grpdesc: group['grpdesc'],
                                picurl: group['picurl'],
                                thumbnail: group['thumbnail'],
                                grpaddress: [],
                                keywords: [],
                                grptype: group['grptype'].toLowerCase(),
                                grpemail: [this.email],
                                weburl: [],
                                members: [],
                                admin: this.group['admin'],
                                community: this.group['community'],
                                users_id: this.user['_id'],
                                facebookId: group['groups_id']
                            };

                            this.loading = true;

                            this.groupsService.addGroup(newGroup).then(val => {
                                if(val){
                                    val['picurl'] = group['picurl'];

                                    let grpPromise;
                                    if(group['events'].length > 0) {
                                        let data = {
                                            groupfbId: group['groups_id'],
                                            users_id: this.user['_id'],
                                            groups_id: val['_id'],
                                            community: this.user['community']
                                        };

                                        grpPromise = this.groupsService.importFbGroupEvents(data);
                                    }

                                    Promise.all([grpPromise]).then(() => {
                                        this.loading = false;
                                        this.groupCreateSuccess(val,'You\'ve successfully created "' + group['grpname'] + '"!', true);
                                    }).catch(err => {
                                        this.loading = false;
                                        this.groupCreateSuccess(val,'Your group was created but your group events couldn\'t be imported right now ' +
                                            '- try importing those events from the Create Event page!', true);
                                    });

                                }
                                else {
                                    this.loading = false;
                                    console.log('add group val err', val);
                                    Agnes.showError('Sorry, couldn\'t import your group right now - try again!');
                                }
                            }).catch(err => {
                                this.loading = false;
                                console.log('add group err', err);
                                Agnes.showError('Sorry, couldn\'t import your group right now - try again!');
                            });
                        }
                    });
                }
                else {
                    Agnes.showError('Looks like you don\'t have any Facebook groups!');
                }

            }).catch(err => {
                this.loading = false;
                console.log(err);
                Agnes.showError("Could not get your Facebook group data - try again!");
            });
        }
        //user is not connected to facebook
        else {
            this.events.subscribe('agnesAlertData', ind => {
                this.events.unsubscribe('agnesAlertData');
                if(ind == 1){
                    this.loading = true;

                    //sync user's account w facebook
                    Agnes.facebook.getLoginStatus().then(value => {

                        if(value && value.status) {

                            let upd = {
                                access_token: '',
                                users_id: this.user['_id']
                            };

                            if (value.status == 'connected') {
                                upd['access_token'] = value['authResponse']['accessToken'];

                                this.loginService.fbUpdate(upd).then(value => {

                                    this.loginService.getUser({"users_id":this.user['_id']}).then(value => {

                                        this.loading = false;
                                        if (value) {
                                            this.user = value;
                                            localStorage.setItem('agnesUser', JSON.stringify(this.user));
                                            this.importFbGroup();
                                        }
                                        else {
                                            Agnes.showError('Could not connect to Facebook - please try again!');
                                        }
                                    }).catch(err => {
                                        console.log('get user in connected err', err);
                                        this.loading = false;

                                        this.events.subscribe('updateDone', val => {
                                            this.user = value;
                                            localStorage.setItem('agnesUser', JSON.stringify(this.user));
                                            this.importFbGroup();
                                        });
                                        this.events.publish('updateUser');
                                    });

                                }).catch(err => {
                                    console.log('fb after update error',err);
                                    this.loading = false;
                                    Agnes.showError('Could not connect to Facebook - please try again!');
                                });
                            }
                            else if (value.status == 'not_authorized') {
                                this.loading = false;
                                Agnes.showError('Please allow Agnes access to your Facebook account!');
                            }
                            else {
                                let permissions = ['public_profile',
                                    'user_friends',
                                    'email',
                                    'user_birthday',
                                    'user_managed_groups',
                                    'user_likes',
                                    'pages_show_list',
                                    'user_events'];

                                Agnes.facebook.login(permissions).then(value => {

                                    if (value && value.status == 'connected') {
                                        upd['access_token'] = value['authResponse']['accessToken'];

                                        this.loginService.fbUpdate(upd).then(value => {

                                            this.loginService.getUser({"users_id":this.user['_id']}).then(value => {

                                                if (value) {
                                                    this.user = value;
                                                    localStorage.setItem('agnesUser', JSON.stringify(this.user));
                                                    this.importFbGroup();
                                                }
                                                else {
                                                    Agnes.showError('Could not connect to Facebook - please try again!');
                                                }
                                            }).catch(err => {
                                                console.log('permission get user error', err);
                                                this.loading = false;

                                                this.events.subscribe('updateDone', val => {
                                                    this.user = value;
                                                    localStorage.setItem('agnesUser', JSON.stringify(this.user));
                                                    this.importFbGroup();
                                                });
                                                this.events.publish('updateUser');
                                            });
                                        }).catch(err => {
                                            console.log('fb after update error 2',err);
                                            this.loading = false;
                                            Agnes.showError('Could not connect to Facebook - please try again!');
                                        });
                                    }
                                    else {
                                        this.loading = false;
                                        Agnes.showError('Could not connect to Facebook - please try again!');
                                    }
                                }).catch(error => {
                                    console.log('Facebook.login error', error);
                                    this.loading = false;
                                    Agnes.showError('Could not connect to Facebook - please try again!');
                                });
                            }
                        }
                        else {
                            this.loading = false;
                            Agnes.showError('Could not connect to Facebook - please try again!');
                        }
                    }).catch(error => {
                        console.log('get login status err', error);
                        this.loading = false;
                        Agnes.showError('Could not connect to Facebook - please try again!');
                    });
                }
            });

            Agnes.showError('Seems like you aren\'t connected to Facebook. Tap below to sync your accounts!',
            ['Not now', 'Sync']);
        }
    }

    //chose an event to attach
    selectEvent(event){
        if(event){
            let ind = this.hostedEvents.indexOf(event);
            if(ind == -1) {this.hostedEvents.push(event);}

            ind = this.group['hostedEvents'].indexOf(event['_id']);
            if(ind == -1) {this.group['hostedEvents'].push(event['_id']);}
        }
        this.eventSelect.close();
    }

    //remove event as hosted event
    removeEvent(event){
        let ind = this.hostedEvents.indexOf(event);
        if(ind != -1) {this.hostedEvents.splice(ind,1);}

        ind = this.group['hostedEvents'].indexOf(event['_id']);
        if(ind != -1) {this.group['hostedEvents'].splice(ind,1);}
    }

    //chose group category
    selectCategory(category){
        if(category){
            this.group['topic'] = category;
        }
        this.categorySelect.close();
    }

}

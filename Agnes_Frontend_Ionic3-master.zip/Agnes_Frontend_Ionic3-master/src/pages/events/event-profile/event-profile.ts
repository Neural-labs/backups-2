import { Component, ViewChild } from '@angular/core';
import { PopoverController, Platform, ToastController, IonicPage, ViewController,
  NavParams, Content, ActionSheetController, Events, NavController } from 'ionic-angular';

import { EventsService } from '../../../providers/events.service';
import { GroupsService } from '../../../providers/groups.service';
import { PeopleService } from '../../../providers/people.service';
import { LoginService } from '../../../providers/login.service';
import { AnalyticsService } from '../../../providers/analytics.service';

import { ReportPage } from '../../popups/report/report';
import { EventDetails } from '../../popups/event-details/event-details';
import { MapOptions } from './map-options/map-options';
import { InviteFriends } from '../../popups/invite-friends/invite-friends';
import { Agnes } from '../../../app/app.component';


@IonicPage()
@Component({
  selector: 'event-profile',
  templateUrl: 'event-profile.html',
  providers: [EventsService, GroupsService, PeopleService, AnalyticsService, LoginService]
})

export class EventProfile {
  event: Object;
  user: Object;

  startDate: string;
  timeString: string;
  evtMonth:string;
  evtDay: string;

  mapApps: Array<string>;
  loading: boolean;
  host:Object;
  isMatched: boolean;
  orientation: string;
  edited: boolean;
  menuButtons: any;
  attendees: Array<Object>;
  isGroupEvent: boolean;
  spinner = true;
  rootNavCtrl: NavController;

  textLimit = 200;

  isAdmin: boolean;
  isPrivate: boolean;
  isInterested: boolean;
  showIGYIG: boolean;
  showInvite: boolean;
  isAttending: boolean;
  inHostGroup: boolean;

  igiygFriends: Array<string>;
  sharedFriends: Array<string>;
  sharedGroups: Array<string>;


  @ViewChild('descriptionScroll') descriptionScroll: Content;
  @ViewChild('profileScroll') profileScroll: Content;

  constructor(private navParams: NavParams,
              public navCtrl: NavController,
              private platform: Platform,
              private events: Events,
              private viewCtrl: ViewController,
              private popoverCtrl: PopoverController,
              private eventsService: EventsService,
              private groupsService: GroupsService,
              private peopleService: PeopleService,
              private loginService: LoginService,
              private analyticsService: AnalyticsService,
              private toastCtrl: ToastController,
              private actionSheetCtrl: ActionSheetController) {
      this.rootNavCtrl = navParams.get('rootNavCtrl');

  }

  ngOnInit() {


    this.event = this.navParams.data.event;
    this.user = JSON.parse(localStorage.getItem('agnesUser'));

    //generate triangle image if no picurl
    this.event['displayURL'] = (this.event['picurl'] == '')
      ? "assets/img/pattern_" + Math.floor((Math.random() * 15) + 1) + '.png'
      : this.event['picurl'];

    //create month and day display and time display string
    let start = Agnes.processGMT(this.event["starttime"].replace(/[-\+]\d\d\d\d/,'Z'));
    this.evtMonth = start.date.toString().slice(5, 8);
    this.evtDay = start.date.toString().slice(9, 11);
    let end = Agnes.processGMT(this.event['endtime'].replace(/[-\+]\d\d\d\d/,'Z'));
    let endDate = (start.date == end.date) ? '' : end.date + ' ';
    this.timeString = (start.time == "12:01AM" && start.time == end.time) ? 'All Day' : start.time + ' - ' + endDate + end.time;

    //initialize other fields
    this.isMatched = (this.navParams.get('type') == 'matched');
    this.mapApps = [];
    this.loading = true;
    this.host = {'grpname':'','displayURL':''};
    this.edited = false;
    this.isAdmin = this.event['admin'].indexOf(this.user['_id']) != -1;
    this.isPrivate = this.event['evttype'] == 'private';
    this.isInterested = this.event['interested'].indexOf(this.user['_id']) != -1;
    this.isAttending = this.isAdmin || this.event['attendees'].indexOf(this.user['_id']) != -1;
    this.showIGYIG = !this.isAdmin && !this.isPrivate;
    this.showInvite = this.isAdmin;
    this.inHostGroup = this.isInHostGroup();
    this.igiygFriends = [];
    this.sharedFriends = [];
    this.sharedGroups = [];

    let userGroups = this.user['grp'].map(a => {return a['groups_id']});
    this.isGroupEvent = this.event['grps'].filter(a => {
      return userGroups.indexOf(a) != -1;
    }).length > 0;

    //get event host, if one exists
    if(this.event['grps'].length > 0) {
      let data = {"grp":[this.event['grps'][0]]};

      this.groupsService.getGroupsFromId(data).then(groups => {
        this.loading = false;
        if(groups && groups.length > 0){
          //should only return 1 group
          groups[0]['displayURL'] = 'url("' + (groups[0]['picurl'] == '' || !groups[0]['picurl']
              ? "assets/img/pattern_" + Math.floor((Math.random() * 15) + 1) + '.png' : groups[0]['picurl']) + '")';

          this.host = groups[0];
        }
        else {
          this.host = null;
          let rg = {
            'events_id': this.event['_id'],
            'groups_id': this.event['grps'][0]['_id']
          };

          this.eventsService.removeGroupFromEvent(rg).then(val =>{

          }).catch(err => {

          });
        }
      }).catch(err => {
        this.loading = false;
        this.host = null;
      });
    }
    else {
      this.loading = false;
    }

    //get event attendees
    this.getAttendees();

    this.setMenuButtons();

    //update user when user RSVPs to this event (from clicking Add to Calendar or from IGIYG accept notification)
    this.events.subscribe('goingDone', data => {
      if(data){this.user = JSON.parse(localStorage.getItem('agnesUser'));}
      this.isAttending = true;
    });

    //update user when user no longer wants to attend this event
    this.events.subscribe('notGoingDone', data => {
      this.user = JSON.parse(localStorage.getItem('agnesUser'));
      this.isAttending = false;
    });

    //watch for invite more button click in attendees list
    this.events.subscribe('inviteMore', () => {
      this.inviteFriends();
    });

    //prevent duplicate IGIYGs to the same person
    this.events.subscribe('friendsIGIYGSent', friends => {
      this.igiygFriends = this.igiygFriends.concat(friends);
    });

    //prevent duplicate IGIYGs to the same person
    this.events.subscribe('friendsShareSent', friends => {
      this.sharedFriends = this.sharedFriends.concat(friends);
    });

    //prevent dup shares to the same group
    this.events.subscribe('groupShareSent', groups => {
      this.sharedGroups = this.sharedGroups.concat(groups)
      console.log(this.sharedGroups)
  })

    //close profile when notification has been clicked so user can be directed to notification screen
    this.events.subscribe('closeProfiles', () => {
      this.closeEventProfile(null,null)
    });

    localStorage.setItem('agnesCurrentEvent', this.event['_id']);
  }

  ionViewDidEnter(){
    //send event profile analytics
    let type = this.navParams.get('type');
    let url = type == 'notification' ? '/notificationEvent' : type == 'map' ? '/clickEventMap' :
        '/' + (type == 'matched' ? 'match'
            : this.event['attendees'].indexOf(this.user['_id']) != -1 ? 'my' : 'all') + 'EventProfile';
    this.analyticsService.logAnalytics({
      users_id: this.user['_id'],
      events_id: this.event['_id']
    },url);
  }

  isInHostGroup(){
    if(this.event['grps'].length == 0) {
      return false;
    }
    else {
      let userGroups = this.user['grp'].map(a=>{return a['groups_id']});
      for(let g in this.event['grps']){
        if(userGroups.indexOf(this.event['grps'][g]) != -1){
          return true;
        }
      }
      return false;
    }
  }

  imgLoad(ev){
    let img = ev.target;
    if (img.naturalWidth > img.naturalHeight) {
      this.orientation = 'landscape';
    } else if (img.naturalWidth < img.naturalHeight) {
      this.orientation = 'portrait';
    } else {
      this.orientation = 'even';
    }
    this.spinner = false;
  }

  readMore() {
     if(this.textLimit == 200) {
       this.textLimit = 2000;
     } else {
     this.textLimit = 200;
     }
   }

  imgError(){
    this.spinner = false;
    this.event['displayURL'] = "assets/img/pattern_" + Math.floor((Math.random() * 15) + 1) + '.png';
  }

  closeEventProfile(e, data) {
    if (!e || e.direction == 4 || e == 'backButton'){

      //back button specifically has been pressed
      if(e == 'backButton'){
        //send Back Button analytics
        this.analyticsService.logAnalytics({
          backButtonName: 'eventProfile',
          users_id: this.user['_id']}, '/backButton');

      }

      // pipe edited info back to groups list
      if(this.edited){
        this.events.publish('eventProfileData',{'event':this.event,'category':'edit'});
      }
      else {
        if(data){
          data['isMatched'] = this.isMatched;
          this.events.publish('eventProfileData',data);
        }
      }

      this.events.unsubscribe('notGoingDone');

      localStorage.removeItem('agnesCurrentEvent');

      //if this is a notification, send notification closed event so notifications can be opened again
      this.events.publish('notificationClosed');

      this.viewCtrl.dismiss(this.event, '', {
        animation: 'ios-transition',
        duration: 350,
        easing: "ease-in-out",
        direction: "back"
      });
    }
  }

  //get fb friends who are attending and then show rest of attendees
  getAttendees() {
    this.event['fbfriends'] = this.event['fbfriends'] ? this.event['fbfriends'] : [];
    this.attendees = [];

    let attendProm = this.peopleService.getUsersFromIds({'users': this.event['attendees'].filter(b => {
      return b != this.user['_id'];})});
    let intProm = this.peopleService.getUsersFromIds({'users': this.event['interested'].filter(b => {
      return b != this.user['_id'];})});

    Promise.all([attendProm,intProm]).then(val =>{
      let attendees = val[0];
      let interested = val[1];

      if(attendees){
        attendees = attendees.sort(a => {return this.event['fbfriends'].indexOf(a['_id']) == -1;}).map(a => {
          a['isAttending'] = true;
          a['thumbnail'] = a['thumbnail'] != ''
              ? a['thumbnail'] : a['picurl'] != '' ? a['picurl'] : '';
          return a;
        });
        this.attendees = this.attendees.concat(attendees);
      }

      if(interested){
        interested = interested.sort(a => {return this.event['fbfriends'].indexOf(a['_id']) == -1;}).map(a => {
          a['isInterested'] = true;
          a['thumbnail'] = a['thumbnail'] != ''
              ? a['thumbnail'] : a['picurl'] != '' ? a['picurl'] : '';
          return a;
        });
        this.attendees = this.attendees.concat(interested);
      }

    }).catch(err => {
      console.log(err);
      // Agnes.showError('Sorry, could not load interested/attending users right now - exit this page and try reloading!');
      Agnes.showError("Uh oh. We lost connection.");
    });
  }

  //set up action sheet menu buttons based on user info
  setMenuButtons(){
    this.menuButtons = [];

    // add Share to Group button if user is admin of at least one group and this event is not hosted by group user is part of
    if(this.user['grp'].map(function(a){return a.admin;}).indexOf(true) != -1){
      this.menuButtons.push({
        text: 'Share to Group',
        icon: 'md-contacts',
        handler: () => {this.shareToGroup();}
      });
    }

    //add View Event Attendees button if user is admin, attending, or event is public
    if(this.isAdmin || this.isAttending ||
        (this.event['evttype'] == 'public' && (this.event['attendees'].length + this.event['interested'].length > 0))) {
      this.menuButtons.push({
        text: 'View Attendees/Interested',
        icon: 'md-person-add',
        handler: () => {this.openAttendeesList();}
      });
    }

    //add Share and Directions buttons
    this.menuButtons = this.menuButtons.concat([
      {
        text: 'Share Event',
        icon: 'md-share',
        handler: () => {this.share();}
      }]);

    //add remove event button if event is in user's RSVP list
    if(this.user['evtrsvp'].indexOf(this.event['_id']) != -1) {
      this.menuButtons.push({
          text: 'Remove Event',
          icon: 'ios-calendar',
          cssClass: 'action-sheet-report',
          handler: () => {
          Agnes.notGoing(this.event,false);
        }
      });
    }

    let lastBtn = (this.event['admin'].indexOf(this.user['_id']) != -1)
      ? {
          text: 'Delete Event',
          cssClass: 'action-sheet-report',
          icon:'md-trash',
          handler: () => {
            this.events.subscribe('agnesAlertData', (ind) => {
              this.events.unsubscribe('agnesAlertData');
              if (ind == 1) {
                this.deleteEvent();
              }
            });

            let message = "Are you sure you want to delete " + this.event['evtname'] + "?";
            Agnes.showError(message, ['Cancel', 'Yes']);
          }
      }
      : {
          text: 'Report Event',
          icon:'md-flag',
          cssClass: 'action-sheet-report',
          handler: () => {this.reportEvent();
          }};

    //add standard Report and Cancel buttons
    let stnd = [
      lastBtn,
      {
        text: 'Cancel',
        role: 'cancel',
        icon: 'md-close',
        handler: () => {}
      }
    ];

    this.menuButtons = this.menuButtons.concat(stnd);
  }

  //for menu options
  openEventMenu(){
    let actionSheet = this.actionSheetCtrl.create({
      title: '',
      buttons: this.menuButtons
    });
    actionSheet.present();
  }

  //open navigation app to direct user to event
  toLocation() {

    //send event location analytics
    this.analyticsService.logAnalytics({events_id: this.event['_id'], users_id: this.user['_id']}, '/clickEventAddress');

    let location = this.event["location"];
    if (this.platform.is('mobile') && this.platform.is('cordova')){
      if (!localStorage.getItem("agnesMaps")) {
        Agnes.launchNavigator.isAppAvailable(Agnes.launchNavigator.APP.GOOGLE_MAPS).then(isAvailable => {
          if (isAvailable){
            this.setMaps('Google Maps');
          }
          else {
            Agnes.launchNavigator.availableApps().then(results =>{
              let mapApps = [];
              for (let i in results) {
                if(results[i]){mapApps.push(i)}
              }

              this.mapApps = mapApps.filter(b => {return b.toLowerCase() != 'uber' && b.toLowerCase() != 'lyft'})
                  .map(function(a){ return Agnes.launchNavigator.getAppDisplayName(a);});

              let mapOptions = this.popoverCtrl.create(
                  MapOptions,
                  {
                    'maps':this.mapApps
                  },
                  {
                    'enableBackdropDismiss':false,
                    'cssClass': 'small'
                  });
              mapOptions.present(
                  {
                    animate: false
                  }
              );
              mapOptions.onDidDismiss(data =>{
                if (data){
                  this.setMaps(data);
                }
              });

            }).catch(err => {
              console.log('available maps err', err);
            });
          }
        });
      }
      else {
        Agnes.launchNavigator.navigate(location, {
          app: localStorage.getItem("agnesMaps")
        });
      }
    }
    else {
        window.open('https://www.google.com/maps/search/' + location);
    }
  }

  //save default navigation app in local storage
  setMaps(name) {
    if (name == "VZ Navigator"){
      name = "com.vznavigator.Generic";
    }
    else {
      name = name.toLowerCase();
      name = name.replace(' ','_');
    }
    localStorage.setItem("agnesMaps",name);

    Agnes.launchNavigator.navigate(this.event["location"], {
      app: name
    });
  }

  reportEvent(){

    let reportPage = this.popoverCtrl.create(
      ReportPage,
      {
        'entityID': this.event['_id'],
        'entityName': this.event['evtname'],
        'user':this.user,
        'type':'event',
        'platform': this.platform
      },
      {'enableBackdropDismiss':true});
    reportPage.present(
        {
          animate:true,
          animation: 'ios-transition',
          duration: 350,
          easing: "ease-in-out",
          direction: "forward",
        }
    );
    reportPage.onDidDismiss(data =>{
    });
  }

  //view fullscreen event image
  viewEvtImg(){
    Agnes.photoViewer.show(this.event['picurl']);
  }

  //open event details popup to edit event if user is event admin
  editEvent(){

    let editEvent = this.popoverCtrl.create(
      EventDetails,
      {
        'type':'Edit',
        'user':this.user,
        'platform': this.platform,
        'event': this.event
      },
      {'enableBackdropDismiss':true});
    editEvent.present(
        {
          animate:true,
          animation: 'ios-transition',
          duration: 350,
          easing: "ease-in-out",
          direction: "forward",
        }
    );
    editEvent.onDidDismiss(data => {
      if (data) {
        if(data.deleted) {
          this.deleteEvent();
        }
        else {
          this.event = data;
          this.edited = true;
        }
      }
    });
  }

  //remove event from database (only available if user is event admin)
  deleteEvent(){
    Agnes.notGoing(this.event, false);

    this.events.subscribe('notGoingDone', () => {
      this.eventsService.deleteEvent(this.event).then(value => {

        if (value) {
          let toast = this.toastCtrl.create({
            message: "You've successfully deleted " + this.event['evtname'] + ".",
            duration: 2500,
            position: 'top',
            closeButtonText: ' ',
            showCloseButton: true
          });
          toast.present();

          let ind = this.user['evtrsvp'].indexOf(this.event['_id']);
          if(ind != -1) {
            this.user['evtrsvp'].splice(ind,1);
          }

          this.events.publish('eventDeleted', this.event);
          this.events.publish('updateUser');

          this.closeEventProfile(null,{
            'category':'delete',
            'event': this.event,
            'eventFlag': -1
          });
        }
      }).catch(error => {
        console.log('delete event error', error);
        let errorMessage = "Sorry, something went wrong - try deleting " + this.event['evtname'] + "again!";
        Agnes.showError(errorMessage);
      });
    });
  }

  //user wants to attend event - call to static methods in Agnes class
  going(){
    document.querySelector('ng-component')['style']['filter'] = 'none';

    if(this.user['evtrsvp'].indexOf(this.event['_id']) == -1) {
      Agnes.going(this.event, this.isMatched);
    }
    else {
        Agnes.notGoing(this.event, this.isMatched);
        this.events.publish('eventUnattend',this.event);
    }
  }

  //open event attendees popup
  openAttendeesList(){
    if(this.isAttending){ this.user['isAttending'] = true;}
    else if(this.isInterested) {this.user['isInterested'] = true;}
    let attndList = this.popoverCtrl.create('EventAttendees', {
      'attendees':this.isAttending || this.isInterested ? [this.user].concat(this.attendees) : this.attendees,
      'canInvite': this.isAdmin || this.event['evttype'] == 'public'
    });
    attndList.present({
      animate:true,
      animation: 'ios-transition',
      duration: 350,
      easing: "ease-in-out",
      direction: "forward",
    });

    //sending Attendees Button analytics
    this.analyticsService.logAnalytics({
      events_id: this.event['_id'],
      users_id: this.user['_id']
    }, '/checkAttendeesButton');
  }

  //share event to other users
  share(){

    //send event sharing analytics
    this.analyticsService.logAnalytics({
      events_id: this.event['_id'],
      users_id: this.user['_id']
    }, '/shareEventButton');

    Agnes.shareOutside('event', this.event['_id'])

  }

  updateInterest() {
    // liking an event
      let data = {
        'users_id':this.user['_id'],
        'events_id':this.event['_id']
      };

      if(this.isInterested){
        this.eventsService.eventUninterested(data).then(value => {
          this.isInterested= false;

          let ind = this.user['evtinterest'].indexOf(this.event['_id']);
          if(ind != -1){ this.user['evtinterest'].splice(ind,1);}
          localStorage.setItem('agnesUser',JSON.stringify(this.user));

          ind = this.event['interested'].indexOf(this.user['_id']);
          if(ind != -1) {this.event['interested'].splice(ind,1);}

          this.events.publish('unlikedEvent', this.event);
        }).catch(err => {
          console.log('eBD err',err);
          // Agnes.showError('Couldn\'t like this event, please try again later!');
            Agnes.showError("Uh oh. We lost connection.");
        })
      } else {
        this.eventsService.eventInterested(data).then(value => {
          this.isInterested = true;
          this.user['evtinterest'].push(this.event['_id']);
          localStorage.setItem('agnesUser',JSON.stringify(this.user));
          this.event['interested'].push(this.user['_id']);

          this.events.publish('likedEvent',this.event);
        }).catch(err => {
          console.log('eBD err',err);
          // Agnes.showError('Couldn\'t like this event, please try again later!');
            Agnes.showError("Uh oh. We lost connection.");
        })
      }
    }

  //IGYIG
  ifYouGo(){

    if(this.user['providerFBData']['providerId'] == '') {
      Agnes.showError("We don't know who your friends are!", ['Back', 'Connect with Facebook'], true, true);

      this.events.subscribe('agnesAlertData', ind => {
        if(ind == 1){
          this.loading = true;

          //sync user's account w facebook
          Agnes.facebook.getLoginStatus().then(value => {

            if(value && value.status) {

              let upd = {
                access_token: '',
                users_id: this.user['_id']
              };

              if (value.status == 'connected') {
                upd['access_token'] = value['authResponse']['accessToken'];

                this.loginService.fbUpdate(upd).then(value => {

                  this.loginService.getUser({"users_id":this.user['_id']}).then(value => {

                    this.loading = false;
                    if (value) {
                      this.user = value;
                      localStorage.setItem('agnesUser', JSON.stringify(this.user));
                      this.ifYouGo();
                    }
                  }).catch(err => {
                    console.log('get user in connected err', err);
                    this.loading = false;

                    this.events.subscribe('updateDone', val => {
                      this.user = value;
                      localStorage.setItem('agnesUser', JSON.stringify(this.user));
                      this.ifYouGo();
                    });
                    this.events.publish('updateUser');
                  });

                }).catch(err => {
                  console.log('fb after update error',err);
                  this.loading = false;
                  // Agnes.showError('Could not connect to Facebook - please try again!');
                  Agnes.showError("Uh oh. We lost connection.");
                });
              }
              else if (value.status == 'not_authorized') {
                this.loading = false;
                Agnes.showError('Please allow Agnes access to your Facebook account!');
              }
              else {
                let permissions = ['public_profile',
                  'user_friends',
                  'email',
                  'user_birthday',
                  'user_managed_groups',
                  'user_likes',
                  'pages_show_list'];

                Agnes.facebook.login(permissions).then(value => {

                  if (value && value.status == 'connected') {
                    upd['access_token'] = value['authResponse']['accessToken'];

                    this.loginService.fbUpdate(upd).then(value => {

                      this.loginService.getUser({"users_id":this.user['_id']}).then(value => {

                        if (value) {
                          this.user = value;
                          localStorage.setItem('agnesUser', JSON.stringify(this.user));
                          this.ifYouGo();
                        }
                      }).catch(err => {
                        console.log('permission get user error', err);
                        this.loading = false;

                        this.events.subscribe('updateDone', val => {
                          this.user = value;
                          localStorage.setItem('agnesUser', JSON.stringify(this.user));
                          this.ifYouGo();
                        });
                        this.events.publish('updateUser');
                      });
                    }).catch(err => {
                      console.log('fb after update error 2',err);
                      this.loading = false;
                    });
                  }
                  else {
                    this.loading = false;
                  }
                }).catch(error => {
                  console.log('Facebook.login error', error);
                  this.loading = false;
                  // Agnes.showError('Could not connect to Facebook - please try again!');
                });
              }
            }
            else {
              this.loading = false;
              // Agnes.showError('Could not connect to Facebook - please try again!');
                Agnes.showError("Uh oh. We lost connection.");
            }
          }).catch(error => {
            console.log('get login status err', error);
            this.loading = false;
            // Agnes.showError('Could not connect to Facebook - please try again!');
              Agnes.showError("Uh oh. We lost connection.");
          });
        }
      });
    }
    else {
      this.popoverCtrl.create(InviteFriends,{
        'user':this.user,
        'objectID': this.event['_id'],
        'type': 'IGIYG',
        'event': this.event,
        'sentFriends': this.igiygFriends
      }, {}).present({
        animate:true,
        animation: 'ios-transition',
        duration: 350,
        easing: "ease-in-out",
        direction: "forward",
      });
    }
  }

  // Create inviteFriends popover
  inviteFriends(){
    this.popoverCtrl.create(
        InviteFriends,
        {
          'user':this.user,
          'objectID': this.event['_id'],
          'type': 'share_event',
          'event': this.event
        }).present({
      animate:true,
      animation: 'ios-transition',
      duration: 350,
      easing: "ease-in-out",
      direction: "forward",
    });
  }

  //share this event w/ members of a group that user is an admin of
  shareToGroup(){

    //send event sharing analytics
    this.analyticsService.logAnalytics({
      events_id: this.event['_id'],
      users_id: this.user['_id']
    }, '/shareEventButton');

    let adminGroups = this.user['grp'].filter(a => {return a['admin']}).map(a => {return a['groups_id']});

    if(adminGroups.length > 0) {

    this.loading = true;

    this.groupsService.getGroupsFromId({'grp':adminGroups}).then(groups => {
      this.loading = false;
      let shareEvent = this.popoverCtrl.create(
          'GroupListPopup',
          {
            'groupList':groups,
            'submitText': 'Share To Groups',
            'sentGroups': this.sharedGroups,
            // 'helpText': 'Select groups below to share this event with:'
          },
          {'enableBackdropDismiss':false});
      shareEvent.present(
          {
              animate:true,
              animation: 'ios-transition',
              duration: 350,
              easing: "ease-in-out",
              direction: "forward",
          }
      );
      shareEvent.onDidDismiss(groupList => {
        if(groupList && groupList.length > 0){
          let data = {
            events_id: this.event['_id'],
            shared_group: groupList,
            users_id: this.user['_id'],
            privacy: this.event['evttype']
          };

          this.groupsService.shareToGroup(data).then(val => {
            this.events.publish('sharedEventToGroup');
            let multiple = groupList.length < 2 ? '' : 's';
            let toast = this.toastCtrl.create({
              message: "You've successfully shared this event to your group" + multiple + "!",
              duration: 2500,
              position: 'top',
              closeButtonText: ' ',
              showCloseButton: true
            });
            toast.present();
          }).catch(err => {
            console.log(err);
            Agnes.showError('Sorry, couldn\'t share this event with your group' + (groupList.length > 1 ? 's' : '')
                + 'right now - try again!');
          });
        }

      });

    }).catch(error => {
      this.loading = false;
      console.log(error);
      Agnes.showError('Could not get the groups you are an admin of - try again later!');
    });

  } else {

    this.events.subscribe('agnesAlertData', (ind) => {
      this.events.unsubscribe('agnesAlertData');
      if(ind == 1){
        this.closeEventProfile(null,{
          'category':'delete',
          'event': this.event,
          'eventFlag': -1
        });
        //TODO need to direct to groups tab once this popover is closed
        this.events.publish('selectGroups');

      }
    });

    let message = "It doesn't look like you're an admin of any groups! Would you like to visit the groups page to claim or create a group?";
    Agnes.showError(message, ['Back', 'Yes']);
    }
  }

  //open profile of hosting group
  openGroupProfile(group){

    if(localStorage.getItem('agnesCurrentGroup') == group['_id']){
      this.closeEventProfile(null, null);
    }
    else {

      this.events.subscribe('groupProfileData', data => {
        if (data.category == 'edit') {this.host = data.group;}
        else if(data.category == 'delete') {this.host = null;}
        this.events.unsubscribe('groupProfileData');
      });


      if (this.navCtrl) {
        this.navCtrl.push(
            'GroupProfile',
            {
              'group':group,
              'platform': this.platform,
              'type': this.user['grp'].map(a=> {return a['groups_id']}).indexOf(group['_id']) != -1 ? 'my' : 'all'
            }, {
              animation: 'ios-transition',
              duration: 350
            });
      }
      else {
        this.rootNavCtrl.push(
            'GroupProfile',
            {
              'group':group,
              'user':this.user,
              'platform': this.platform,
              'type': this.user['grp'].map(a=> {return a['groups_id']}).indexOf(group['_id']) != -1 ? 'my' : 'all'
            }, {
              animation: 'ios-transition',
              duration: 350
            });
      }

    }
  }

  //show top bar header when user scrolls
  scrollProfile(ev){
    if(this.platform.is('android')){
      ev.domWrite(() => {
        document.querySelector('.topDivBackground')['style']['opacity'] = '' + (ev.scrollTop / (window.innerHeight / 10));
        document.querySelector('.profileType')['style']['opacity'] = '' + (1 - (ev.scrollTop / (window.innerHeight / 10)));
      });
    }
  }

  //default to initials if profile pic url is bad
  personImgError(person){
    person['noPic'] = true;
  }

}

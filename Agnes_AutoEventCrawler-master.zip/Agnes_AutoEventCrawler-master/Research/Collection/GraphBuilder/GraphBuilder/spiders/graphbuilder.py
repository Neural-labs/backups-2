# imports
import redis
import scrapy
from Utilities import DomainGraph
from Utilities.URLFilter import getPageLinks
from scrapy import signals
from scrapy.crawler import CrawlerProcess
from scrapy.spiders import BaseSpider as Spider
from scrapy.utils.project import get_project_settings
from scrapy.xlib.pydispatch import dispatcher

from config import db_config
from config.crawler import config as config

dbConn = db_config.getDBConn('dev')
Agnes = dbConn.Agnes
DB_Collection = Agnes.autocrawler_domain_pages

# File paths
# dir = os.path.dirname(__file__)
# main_dir = os.path.join(dir, '../../../../')
# redis_visited_path = main_dir+'visited.txt'
# redis_scheduled_path = main_dir+'scheduled.txt'
# urlGraph_path = main_dir+'url_Graph.P'
# clickGraph_path = main_dir+'click_Graph.P'

# Graph Object
# graph = Graph(directed=True)
url_graph = DomainGraph.DomainGraph(graph_type='url')
click_graph = DomainGraph.DomainGraph(graph_type='click')

# Redis
redis_obj = redis.Redis(host='localhost',port=6379)

# Globals
global Count
MAX_DEPTH = config.MAX_DEPTH
MAX_COUNT = config.MAX_COUNT

class GraphBuilder(Spider):
    name = "graphBuilder"

    def start_requests(self):
        print "Starting Graph Builder..."

        HomePage = config.HomePage

        initGlobals(HomePage)

        click_graph.add_root(normalizeURL(HomePage))
        url_graph.add_root(normalizeURL(HomePage))

        # do things when spider ends
        dispatcher.connect(self.spider_closed, signals.spider_closed)

        yield scrapy.Request(
                            url=HomePage,
                            callback=self.parse,
                            meta={
                                "parent":None
                            }
                            )


    def parse(self, response):
        global Count
        Domain = config.Domain

        if response.status != 200:
            print "Invalid response status: ",response.url
            return
        try:
            HTML = response.text

        except Exception as e:
            return

        if not '/html' in response.text:
            return

        currentURL = normalizeURL(response.url)
        parentURL = response.meta['parent']
        Count += 1

        _id = insertIntoMongo(currentURL, HTML, Domain)

        add_to_visited(currentURL)
        remove_from_scheduled(currentURL)

        if parentURL:
            addToURLGraph(currentURL)
            addToClickGraph(currentURL,parentURL)

        depth = nodeDepth(currentURL)


        print "STARTING Request URL=", currentURL, " Count=", Count, " Depth=", depth

        if Count > MAX_COUNT:
            print 'Reached max count. url:',currentURL, "Count: ", Count
            return
        if depth >= MAX_DEPTH:
            print "Reached max recursion depth. URL:",currentURL, " Count: ", Count
            return

        links = getPageLinks(currentURL,HTML)

        for link in links:
            if validLink(link):
                add_to_scheduled(link)

                yield scrapy.Request(link,
                                     meta={
                                         'dont_redirect': True,
                                         'parent':currentURL
                                     },
                                     callback=self.parse,
                                     errback=self.errback,
                                     )

        print "Finished Url:", currentURL, " Count=", Count, " Depth=", depth

    def errback(self, failure):
        global Count
        # log all failures
        print 'Count:',Count
        self.logger.error(repr(failure))

    def spider_closed(self,spider):
        print "Spider Finished, Writing Domain Graphs to file"
        Domain = config.Domain
        url_graph.write_to_file(Domain)
        click_graph.write_to_file(Domain)
        # writeRedisToFile()

def initGlobals(homepage):
    global Count

    # clear redis
    redis_obj.flushall()

    redis_obj.sadd('visited',homepage)
    redis_obj.sadd('scheduled',homepage)

    Count = 0

def normalizeURL(url):
    url = convertToHTTP(url)
    url = removeEndSlash(url)
    return url

def convertToHTTP(url):
    if url[:5] == 'https':
        url = 'http'+url[5:]
    if 'http:' not in url:
        url = 'http:' + url
    return url

def removeEndSlash(url):
    if url[-1] =='/':
        url = url[:-1]
    return url

def addToClickGraph(url,parentURL):
    click_graph.add_new_node(url,parentURL)

def addToURLGraph(url):
    url_graph.add_new_node(url,None)

def nodeDepth(node_url):
    return click_graph.get_depth(node_url)

def addDataToURLNode(node_url,data):
    url_graph.add_data_to_node(node_url,data)

def validLink(link):

    if visited(link) or scheduled(link):
        return False

    return True

def visited(url):
    return redis_obj.sismember('visited',url)

def scheduled(url):
    return redis_obj.sismember('scheduled',url)

def add_to_visited(url):
    return redis_obj.sadd('visited',url)

def add_to_scheduled(url):
    return redis_obj.sadd('scheduled',url)

def remove_from_scheduled(url):
    redis_obj.srem('scheduled',url)

def insertIntoMongo(url,HTML,Domain):
    try:
        _id = DB_Collection.insert_one({"url":url,"HTML":HTML,"community":Domain})
    except Exception:
        print "Already in DB:",url
        return None

    return _id

def writeRedisToFile():
    visited = redis_obj.smembers('visited')
    scheduled = redis_obj.smembers('scheduled')
    with open('visited.txt','w') as f:
        for url in visited:
            f.write(url+",")
    with open('scheduled.txt','w') as f:
        for url in scheduled:
            f.write(url+',')

def runGraphBuilder():
    process = CrawlerProcess(get_project_settings())

    process.crawl(GraphBuilder)
    process.start()  # the script will block here until the crawling is finished

import { Component, Input } from '@angular/core';
import { App, Events, PopoverController } from 'ionic-angular';

import { Agnes } from '../../app/app.component';

/**
 * card component for matched events and groups
 */

@Component({
  selector: 'agnes-card-banner',
  templateUrl: 'agnes-card-banner.html',
    providers: []
})
export class AgnesCardBannerComponent {

  @Input() object: Object;
  @Input() type: string;
  @Input() objTime: string;
  @Input() fbfriends: Array<Object>;

  objName: string;
  friendPics = [];
  objMonth: string;
  objDay: string;
  objDesc: string;

  constructor(public appCtrl: App, private events: Events, private popoverCtrl: PopoverController) {

  }

  ngOnInit(){
    this.objName = (this.type == 'group' ? this.object['grpname'] : this.object['evtname']);
    this.objDesc = (this.type == 'group' ? this.object['grpdesc'] : this.object['evtdesc']);
    this.object['peopleList'] = this.type == 'event' ? this.object['attendees']
        : this.type == 'group' ? this.object['admin'].concat(this.object['members']) : [];
    if(this.type == 'event'){
        this.object['starttime'] = this.object['starttime'].replace(/[-\+]\d\d\d\d/,'Z');
        let start = Agnes.processGMT(this.object['starttime']);
        this.objMonth = start.date.toString().slice(5, 8);
        this.objDay = start.date.toString().slice(9, 11);
    }

    this.events.subscribe('sendFriendsToCard', friends => {
        this.object['fbfriends'] = friends;
    })

    //try adding people pics to card
    if(this.fbfriends){
          this.object['fbfriends'] = this.fbfriends;
          this.addFriendPics();
      }
      else {
          this.events.subscribe('sendFriendsToCard', friends => {
              this.fbfriends = friends;
              this.object['fbfriends'] = this.fbfriends;
              this.addFriendPics();
          })
      }
  }

  //open event or group profile, depending on type of card
  openObjProfile(){
      let user = JSON.parse(localStorage.getItem('agnesUser'));

    if(this.type == 'group'){
        //open group profile

        this.popoverCtrl.create('GroupProfile',{
            'group':this.object,
            'type':'matched'
        }, {}).present({
            animation: 'ios-transition',
            duration: 350
        });

      // this.appCtrl.getRootNav().push(
      //     'GroupProfile',
      //     {
      //       'group':this.object,
      //       'type':'matched'
      //     }, {
      //       animation: 'ios-transition',
      //       duration: 350
      //     });
    }
    else {
        //open event profile (matched)
      this.appCtrl.getRootNav().push(
          'EventProfile',
          {
            'event': this.object,
            'type': 'matched'
          }, {
            animation: 'ios-transition',
            duration: 350
          });
    }
  }

  //add friends' faces to event cards
  addFriendPics(){
      this.fbfriends = this.fbfriends ? this.fbfriends : [];
      this.friendPics = this.fbfriends.filter(a => {
          return this.object['peopleList'].indexOf(a['_id']) != -1;
      }).map(b => {
          return b['thumbnail'];
      });

      if(this.friendPics.length > 3){
          this.friendPics = this.friendPics.slice(0,3);
      }
  }

}

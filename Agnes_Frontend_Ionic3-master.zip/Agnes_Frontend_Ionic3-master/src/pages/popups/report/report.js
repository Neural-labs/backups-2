"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var core_1 = require('@angular/core');
var report_service_1 = require('./report.service');
var app_component_1 = require('../../../app/app.component');
var ReportPage = (function () {
    function ReportPage(viewCtrl, navParams, alertCtrl, reportService, toastCtrl) {
        this.viewCtrl = viewCtrl;
        this.navParams = navParams;
        this.alertCtrl = alertCtrl;
        this.reportService = reportService;
        this.toastCtrl = toastCtrl;
    }
    ReportPage.prototype.ngOnInit = function () {
        this.entityID = this.navParams.data.entityID;
        this.entityName = this.navParams.data.entityName;
        this.type = this.navParams.data.type;
        this.user = this.navParams.data.user;
        this.platform = this.navParams.data.platform;
        this.shouldBlur = true;
        this.reportReason = 'Offensive';
        this.reportText = '';
    };
    ReportPage.prototype.ngAfterViewInit = function () {
        window.setTimeout(function () {
            document.getElementsByClassName('popover-content')[0]['style']['left'] = '0px';
        }, 0);
    };
    ReportPage.prototype.closeReport = function () {
        this.viewCtrl.dismiss();
    };
    ReportPage.prototype.focusOther = function (ev) {
        ev.setFocus();
    };
    ReportPage.prototype.keepKeyboard = function (event) {
        if (!this.shouldBlur || event.relatedTarget || this.reset) {
            event.target.focus();
            // Reset so other elements will blur the keyboard
            this.shouldBlur = true;
            this.reset = !this.reset;
        }
    };
    ReportPage.prototype.resetBlur = function () {
        this.reset = true;
    };
    ReportPage.prototype.flipBlur = function () {
        this.shouldBlur = false;
        this.reset = false;
    };
    ReportPage.prototype.submitReport = function () {
        var _this = this;
        if (!this.reportReason) {
            document.getElementById('reportError').classList.add('active');
        }
        else {
            this.reportReason = (this.reportReason == 'Other') ? 'Other: ' + this.reportText : this.reportReason;
            document.getElementById('reportError').classList.remove('active');
            var data = {
                "entity_type": this.type,
                "report_reason": this.reportReason,
                "email_id": this.user['email']['uid'],
                "entity_id": this.entityID,
                "user_name": this.user['fname'] + " " + this.user['lname'],
                "user_id": this.user['_id'],
                "entity_name": this.entityName
            };
            this.reportService.report(data)
                .then(function (value) {
                if (value) {
                    _this.toastCtrl.create({
                        message: 'Report successfully submitted',
                        duration: 3000,
                        position: 'bottom'
                    }).present();
                    _this.closeReport();
                }
                else {
                    app_component_1.Agnes.showError("Sorry, your report couldn't be submitted right now. Try again!");
                }
            })
                .catch(function (error) { app_component_1.Agnes.showError("Sorry, your report couldn't be submitted right now. Try again!"); });
        }
    };
    ReportPage = __decorate([
        core_1.Component({
            selector: 'report',
            templateUrl: 'report.html',
            providers: [report_service_1.ReportService]
        })
    ], ReportPage);
    return ReportPage;
}());
exports.ReportPage = ReportPage;

from NetworkxTree import NetX_Tree
import DateExtraction
from difflib import SequenceMatcher
from datetime import timedelta
from fuzzywuzzy import fuzz, process
import random
import re
import string
from nltk.corpus import stopwords
import math

stop_words = set(stopwords.words('english'))

SIM_THRESHOLD = 95
SUBSTRING_THRESHOLD = 0.85
INTERSECTION_THRESHOLD = 0.85


global random_name_words
global random_desc_words
global random_loc_words

class EventTree(NetX_Tree):

    def __init__(self, HTML=None, event=None):
        NetX_Tree.__init__(self, HTML)
        if event:
            self.complete_event_nodes = self.find_event_nodes(event)

    def find_event_nodes(self, event):
        event_parts = getEventParts(event)

        potential_event_part_nodes = initPotentialNodeParts()

        desc_found = False
        for node_id, node_data in reversed(self.get_nodes()):

            node_data['attr_dict']['totalcontent'] = cleanContent(node_data['attr_dict']['totalcontent'])
            results = nodeContainsParts(node_data, event_parts, desc_found)

            for part in results:
                if results[part]:
                    potential_event_part_nodes[part].append(node_id)

            if results['description'] and not desc_found:
                desc_found = True

        # assert we found at least 1 of each part
        for part in potential_event_part_nodes:
            if not potential_event_part_nodes[part]:
                self.complete_event_nodes = None
                return None

        event_node = findEventNode(self, potential_event_part_nodes)

        if not event_node:
            print 'Couldnt find event node'
            self.complete_event_nodes = None
            return None

        complete_event_nodes = findSubNodes(self, event_node, potential_event_part_nodes)

        complete_event_nodes['event'] = event_node

        self.complete_event_nodes = complete_event_nodes

        return complete_event_nodes

    def get_event_nodes(self):
        return self.complete_event_nodes

    def print_event(self):
        if self.complete_event_nodes:
            data = self.get_node_data(self.complete_event_nodes['event'])['attr_dict']
            # print data['totalcontent']
            print data['tag'].prettify()

    def print_event_nodes(self):
        if self.complete_event_nodes:
            for part in self.complete_event_nodes:
                print
                print part
                data = self.get_node_data(self.complete_event_nodes[part])['attr_dict']
                print data['totalcontent']
                print


def debug(tree, parts, missed_part):
    debugcontent = 'are you a creative'

    for node_id, node_data in tree.get_nodes():

        if missed_part == 'date':
            content = node_data['attr_dict']['totalcontent']
            dates = DateExtraction.getDates(content)
            if dates:
                print parts[missed_part]
                print content
                print dates
                print nodeContainsDate(node_data, parts[missed_part], debug=True)
                print
        else:
            content = cleanContent(node_data['attr_dict']['totalcontent'])
            content = removePunctuation(content)
            clean_part = removePunctuation(parts[missed_part])
            # print parts[missed_part]
            # print [content]
            # print process.extract(parts[missed_part], [content])
            _,score = process.extract(clean_part, [content])[0]
            match = SequenceMatcher(None, clean_part, content).find_longest_match(0, len(clean_part), 0,
                                                                                             len(content))

            match_threshold = int(len(clean_part) * SUBSTRING_THRESHOLD)
            if debugcontent in content:

                # print content
                print
                print clean_part
                print
                print parts[missed_part]
                print
                print content
                print
                print node_data['attr_dict']['totalcontent']
                print 'score',score
                print 'match size',match.size
                print 'match thresh',match_threshold
                # print node_data['attr_dict']['tag'].prettify()
                print nodeContainsDescription(node_data, clean_part, debug=True)
                # print nodeContainsName(node_data, clean_part, (None, None), False)
                # print nodeContainsName(node_data, clean_part, (None, None), True)
                # print nodeContainsLocation(node_data, clean_part, debug=True)
                print

    for part in parts:
        print part, parts[part]

    print 'Missed', missed_part
    print


def getEventParts(event):
    global random_name_words
    global random_desc_words
    global random_loc_words

    starttime = event['starttime']
    if starttime.minute == 1:
        starttime = starttime.replace(minute=0)

    random_desc_words = initRandomParts(event['evtdesc'])
    random_loc_words = initRandomParts(event['location'])
    random_name_words = initRandomParts(event['evtname'])

    return {
        'name':cleanContent(event['evtname']),
        'description':cleanContent(event['evtdesc']),
        'location':cleanContent(event['location']),
        'date':starttime
    }


def initRandomParts(content):

    content = cleanContent(content)
    content_sanspunc = removePunctuation(content)

    content_words = [d for d in content_sanspunc.split() if d not in stop_words]
    words_length = len(content_words)

    random_words_count = numberRandomWords(words_length)

    random_ind = sorted(random.sample(range(words_length), random_words_count))

    # random_ind = sorted([random.randint(0, words_length - 1) for i in range(words_length / 3)])

    return [content_words[rand] for rand in random_ind]


def numberRandomWords(length):
    percent = 0.03065468 + (0.8864045 - 0.03065468) / (1 + (float(length)/7.644264)**0.6408058)
    number_words = int(math.ceil(percent * length))
    return number_words

def cleanContent(content):
    content = content.replace('\n','')
    content = content.replace('\t', '')
    content = ' '.join(content.split())
    content = content.lower()
    content = convertToAscii(content)

    return content

def convertToAscii(content):
    return content.decode('utf-8').encode('ascii','ignore')

def removePunctuation(content):
    regex = re.compile('[%s]' % re.escape(string.punctuation))
    content = regex.sub(' ', content)
    return ' '.join(content.split())
    # return content.translate(string.maketrans("",""), string.punctuation).decode('utf8').encode('ascii','ignore')

def initPotentialNodeParts():
    return {
        'name':[],
        'description':[],
        'location':[],
        'date':[]
    }

def nodeContainsParts(node_data, event_parts, desc_found):
    # parts_found = {}

    description = event_parts['description']
    name = event_parts['name']
    location = event_parts['location']
    date = event_parts['date']

    description_found, (start,end) = nodeContainsDescription(node_data, description)

    name_found = nodeContainsName(node_data, name, (start,end), desc_found)

    location_found = nodeContainsLocation(node_data, location)

    date_found = nodeContainsDate(node_data, date)

    return  {
        'name':name_found,
        'description':description_found,
        'location':location_found,
        'date':date_found
    }


def naiiveStringSimilarity(a,b):
    return SequenceMatcher(None, a, b).ratio()

def nodeContainsName(node_data, name, (start,end), desc_found):
    global random_name_words

    node_data = node_data['attr_dict']
    node_totalcontent = node_data['totalcontent']
    node_totalcontent = removePunctuation(node_totalcontent)
    name = removePunctuation(name)

    regex = '.*'.join(random_name_words)
    pattern = re.compile(regex)
    re_result = re.search(pattern, node_totalcontent)

    if not start is None:# and not desc_found:

        search_content = node_totalcontent[0:start] + node_totalcontent[end:]

    else:
        search_content = node_totalcontent

    match = SequenceMatcher(None, name, search_content).find_longest_match(0, len(name), 0,
                                                                                     len(search_content))

    minimum_substring_size = int(len(name) * SUBSTRING_THRESHOLD)

    _,fuzzy_similarity = process.extract(name, [search_content])[0]

    if len(node_totalcontent) > len(name)*10:
        return False

    found = fuzzy_similarity > SIM_THRESHOLD or match.size > minimum_substring_size or not re_result is None

    return found

def nodeContainsDescription(node_data, description, debug=False):
    # split into words, sample random words, and check in node content
    global random_desc_words

    if debug:
        print 'Random words:', random_desc_words

    node_data = node_data['attr_dict']
    node_totalcontent = node_data['totalcontent']

    node_totalcontent = removePunctuation(node_totalcontent)
    description = removePunctuation(description)

    desc_words = description.split()
    node_words = node_totalcontent.split()
    intersection = int(len([w for w in desc_words if w in node_words]))
    intersection_threshold = int(len(desc_words) * INTERSECTION_THRESHOLD)

    # pattern = re.compile('.*'.join(random_desc_words))
    match = SequenceMatcher(None, description, node_totalcontent).find_longest_match(0, len(description), 0,
                                                                                     len(node_totalcontent))
    for x in range(10):
        regex = '.*'.join(random_desc_words)
        pattern = re.compile(regex)
        re_result = re.search(pattern, node_totalcontent)
        if re_result:
            break
        random_desc_words = initRandomParts(description)

    minimum_match_size = int(len(description) * SUBSTRING_THRESHOLD)

    _, fuzzy_similarity = process.extract(description, [node_totalcontent])[0]

    found = fuzzy_similarity >= SIM_THRESHOLD or match.size >= minimum_match_size or not re_result is None or \
            intersection > intersection_threshold

    if found:
        # print
        # print node_totalcontent
        # print
        # print 'fuzzy', fuzzy_similarity
        # print 'match size', match.size
        # print 'match thresh', minimum_match_size
        # print 're_result',re_result
        # print 'intersection', intersection
        # print 'inter thresh', intersection_threshold
        # print random_desc_words
        # print
        fuzzy_start = match.b
        fuzzy_end = match.b + match.size
        fuzzy_size = fuzzy_end - fuzzy_start

        if re_result:
            regex_string = re_result.group()

            regex_start = node_totalcontent.find(regex_string)
            regex_end = regex_start + len(regex_string)
            regex_size = regex_end - regex_start

            if fuzzy_size > regex_size:
                start, end = fuzzy_start, fuzzy_end
            else:
                start, end = regex_start, regex_end
        else:
            start, end = fuzzy_start, fuzzy_end
    else:
        start, end = None, None

    return found, (start,end)


def nodeContainsLocation(node_data, location, debug=False):
    global random_loc_words

    if debug:
        print random_loc_words

    node_totalcontent = node_data['attr_dict']['totalcontent']
    node_totalcontent = removePunctuation(node_totalcontent)
    location = removePunctuation(location)

    regex = '.*'.join(random_loc_words)
    pattern = re.compile(regex)
    re_result = re.search(pattern, node_totalcontent)

    match = SequenceMatcher(None, location, node_totalcontent).find_longest_match(0, len(location), 0, len(node_totalcontent))
    minimum_substring_size = int(len(location) * SUBSTRING_THRESHOLD)

    _, fuzzy_similarity = process.extract(location, [node_totalcontent])[0]

    found = fuzzy_similarity >= SIM_THRESHOLD or match.size >= minimum_substring_size or not re_result is None

    return found

def getContentWindow(content, window_size):
    length = len(content)
    offset = int(length * (window_size / 2))
    window_size = length / window_size
    start = offset
    end = offset + window_size
    window = content[start:end]
    return window

def nodeContainsDate(node_data, date, debug=False):

    node_data = node_data['attr_dict']
    node_content = node_data['content']
    node_totalcontent = node_data['totalcontent']

    node_dates = DateExtraction.getDates(node_content)
    subtree_dates = DateExtraction.getDates(node_totalcontent)

    return dateInDates(date, node_dates, debug=debug) or dateInDates(date, subtree_dates, debug=debug)

def dateInDates(date, datelist, debug=False):

    for node_date_obj in datelist:
        # for node_date_obj in node_dates:
        node_date     = node_date_obj[0]
        node_date_utc = cleanDate(convertToUTC(node_date))
        plusFour      = cleanDate(add4Hours(node_date))
        node_date     = cleanDate(node_date)

        if debug:
            print 'Attempts:'
            print node_date
            print node_date_utc
            print plusFour

        if date == node_date_utc or date == plusFour or date == node_date:
            return True
    return False


def cleanDate(date):
    if checkDateAware(date):
        return makeDateNonaware(date)
    return date

def checkDateAware(date):
    return date.tzinfo is not None and date.tzinfo.utcoffset(date) is not None

def makeDateNonaware(date):
    return date.replace(tzinfo=None)

def convertToUTC(dateobj):
    utcTime = dateobj + timedelta(hours=5)
    return utcTime

def add4Hours(dateobj):
    plusfour = dateobj + timedelta(hours=4)
    return plusfour

def deepestNodeFromList(tree, node_list):
    max_depth = 0

    for node in node_list:
        depth = tree.depth(node)
        max_depth = max(depth, max_depth)

    return max_depth


def findEventNode(tree, potential_event_part_nodes):

    # print potential_event_part_nodes

    for node_id, node_data in reversed(tree.get_nodes()):
        for part in potential_event_part_nodes:

            node_part_list = potential_event_part_nodes[part]

            if node_id in node_part_list:
                parent_list = tree.get_parent_ids(node_id)

                if parent_list:
                    node_part_list.append(parent_list[0])

    event_part_sets = [set(potential_event_part_nodes[part]) for part in potential_event_part_nodes]

    potential_event_nodes = set.intersection(*event_part_sets)

    potential_event_nodes = removeParents(tree, potential_event_nodes)

    most_dense_nodes = getMostDenseEventNodes(tree, potential_event_nodes, potential_event_part_nodes)

    if len(most_dense_nodes) > 1:

        event_node = tree.max_depth_from_list(most_dense_nodes)
    else:
        event_node = most_dense_nodes[0]

    return event_node

def removeParents(tree, node_list):
    parents = []
    for node in node_list:
        node_parents = tree.get_parent_ids(node)
        node_content_len = len(tree.get_node_data(node)['attr_dict']['totalcontent'])
        for pnode in node_parents:
            parent_content_len = len(tree.get_node_data(pnode)['attr_dict']['totalcontent'])
            if pnode in node_list and parent_content_len==node_content_len:
                parents.append(pnode)
    return [n for n in node_list if n not in parents]

def getMostDenseEventNodes(tree, potential_event_nodes, flag_dict):

    max_density = None
    event_node_densities = []

    for event_node in potential_event_nodes:

        event_density = getEventNodeDensity(tree, event_node, flag_dict)
        max_density = max(max_density, event_density)
        event_node_densities.append((event_node, event_density))

    most_dense_nodes = [node for node,density in event_node_densities if density == max_density]

    return most_dense_nodes

def getEventNodeDensity(tree, event_node, flag_dict):

    density = 0.0
    node_count = 0.0
    for node_id in tree.iterate_from_node(event_node):
        node_count += 1
        for part in flag_dict:
            if node_id in flag_dict[part]:
                density += 1
    return density / node_count

def findSubNodes(tree, event_node, flag_dict):
    max_density_parts = {
        'name': None,
        'description':None,
        'location':None,
        'date':None
    }

    # for each part
    for part in max_density_parts:
        flag_list = flag_dict[part]
        max_tuple = (None, None)

        flag_list = removeParents(tree, flag_list)

        # find the maximum density part node
        for iter_id in tree.iterate_from_node(event_node):

            iter_density = getPartialNodeDensity(tree, iter_id, flag_list)
            # iter_depth = tree.depth(iter_id)

            if iter_density > max_tuple[0]:
                max_tuple = (iter_density, iter_id)

        max_density_parts[part] = max_tuple[1]


    max_density_parts['event'] = event_node
    return max_density_parts

def getPartialNodeDensity(tree, node_id, flag_list):
    density = 0.0
    node_count = 0.0
    for iter_id in tree.iterate_from_node(node_id):
        node_count += 1
        if iter_id in flag_list:
            density += 1
    return density / node_count



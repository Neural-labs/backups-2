import { Component } from '@angular/core';
import { Platform, NavParams, PopoverController, ToastController,
  ActionSheetController, NavController, Events, IonicPage } from 'ionic-angular';

import { GroupsService } from '../../../providers/groups.service';
import { AnalyticsService } from "../../../providers/analytics.service";
import { MeService } from '../../../providers/me.service';
import {PeopleService} from '../../../providers/people.service'
import { EventsService } from '../../../providers/events.service';
import { LoginService } from '../../../providers/login.service';

import { ReportPage } from '../../popups/report/report';
import { InviteToGroup } from '../../popups/invite-to-group/invite-to-group';

import { Agnes } from '../../../app/app.component';



@IonicPage()
@Component({
  selector: 'people-profile',
  templateUrl: 'people-profile.html',
  providers: [GroupsService, AnalyticsService, MeService, EventsService, LoginService, PeopleService]

})

export class PeopleProfile {
  peopleInfoPage = 'PeopleInfo';

  user:Object;
  person:Object;
  isMe: boolean;
  spinner = true;
  userEvents : Array<Object>;
  groups : Array<Object>;
  userName: string;
  skills = [];
  interests = [];
  majorString: string;
  friends : Array<Object>;
  friendsDisplay: Array<Object>;

  orientation: string;
  fullscreen: boolean;
  menuButtons: Array<Object>;

  today: string;
  tomorrow: string;

  streak: number;
  lifetime: number;
  reward: number;
  streakGoal: number;

  noFriends: boolean;
  paused: boolean;
  daysLeft: number;
  totalDays: number;

  tappable: boolean;

  constructor(private navParams: NavParams,
              public navCtrl: NavController,
              private groupsService: GroupsService,
              private analyticsService: AnalyticsService,
              private meService: MeService,
              private peopleService: PeopleService,
              private popoverCtrl: PopoverController,
              private events: Events,
              private platform: Platform,
              private toastCtrl: ToastController,
              private actionSheetCtrl: ActionSheetController,
              private loginService: LoginService,
              private eventsService: EventsService) {
  }

  ngOnInit(){
    this.isMe = this.navParams.get('isMe');
    this.user = JSON.parse(localStorage.getItem('agnesUser'));

    this.person = this.isMe ? this.user : this.navParams.get('person');

    this.userEvents = [];
    this.groups = [];
    this.friends = [];
    this.friendsDisplay = [];
    this.noFriends = true;

    this.streak= 0;
    this.lifetime= 0;
    this.reward= 0;
    this.daysLeft = 0
    this.tappable = true;

    this.processProfile();

    let t = new Date();
    this.today = t.toDateString().match(/[a-zA-Z]{3} [a-zA-Z]{3} \d\d/)[0];
    this.today = this.today.replace(/([a-zA-Z]{3})(\s[a-zA-Z]{3}\s)(\d{2})/, "$1.$2$3");
    t.setDate(t.getDate() + 1);
    this.tomorrow = t.toDateString().match(/[a-zA-Z]{3} [a-zA-Z]{3} \d\d/)[0];
    this.tomorrow = this.tomorrow.replace(/([a-zA-Z]{3})(\s[a-zA-Z]{3}\s)(\d{2})/, "$1.$2$3");


    this.getEvents();
    this.getGroups();
    this.getFriends();

    if(!this.isMe){
      this.setMenuButtons();

    } else {

      //send Me Profile analytics
      this.analyticsService.logAnalytics({community: this.user['community'], users_id: this.user['_id']}, '/myProfile');

      this.events.subscribe('updatedMe', data => {
          this.user = JSON.parse(localStorage.getItem('agnesUser'));
          if(data['_id'] == this.person['_id']){
              this.person = JSON.parse(localStorage.getItem('agnesUser'));
              this.processProfile();
          }
      });

      this.events.subscribe('unlikedEvent', event => {
          this.user = JSON.parse(localStorage.getItem('agnesUser'));

          let ind = this.userEvents.map(a => {return a['_id']}).indexOf(event['_id']);
          if(ind != -1){this.userEvents.splice(ind,1);}
      });

        this.events.subscribe('leftGroup', data => {
            this.user = JSON.parse(localStorage.getItem('agnesUser'));

            let ind = this.groups.map(a => {return a['_id']}).indexOf(data.group);
            if(ind != -1){this.groups.splice(ind,1);}
        });

      let scheduledStop = this.twelveWeeksAhead(this.user['DOR']);
      let mostrecentDORWeek = this.mostRecentDORWeek(this.user['DOR']);
      let now = new Date();
      let nextWeek = new Date();
      nextWeek.setDate(nextWeek.getDate() + 7);
      if (now < scheduledStop) {
          let data = {
              'users_id':this.user['_id']
          };
          // let userJoin = new Date(this.user['DOR']);
          // let userLogin = new Date(this.user['lastlogin']);
          this.meService.getUserLastLogin(data).then(response => {

              let lastLogin = new Date(response['lastLogin']);
              // let weekAhead = new Date(lastLogin.setDate(lastLogin.getDate() + 7));
              if (mostrecentDORWeek > lastLogin) {
                  this.openKeywordsPopup()
              }
          })
      }
    }
    this.getPebblesData()
  }

  processProfile(){
      this.userName = this.person['fname'] + ' ' + (this.isMe ? this.person['lname'] : this.person['lname'].charAt(0).toUpperCase());

      //process edited pics
      if(this.person['localPic']){this.person['picurl'] = this.person['localPic'];}
      if(this.person['localCover']){this.person['cover'] = this.person['localCover'];}

      this.skills = this.person['keywords'].filter(function(a){return a['keytype'] == 'haveskill'}).map(function(a){return a.name;});
      this.skills = this.getUnique(this.skills);
      this.interests = this.person['keywords'].filter(function(a){return a['keytype'] != 'haveskill'}).map(function(a){return a.name;});
      this.interests = this.getUnique(this.interests);

      this.majorString = this.person['studenttype'] == 'other' ? '' :
          ((this.person['studenttype'] == 'phd' ? 'PhD' : this.person['studenttype'].charAt(0).toUpperCase()
              + this.person['studenttype'].substring(1,this.person['studenttype'].length)) + ' ') + (this.person['major'] != '' ? ' - '
          + this.person['major'].toString().replace(/,/g,', ') : '');
      let lc = this.majorString.lastIndexOf(',');
      this.majorString = (lc != -1) ? this.majorString.substring(0,lc) + ' and' + this.majorString.substring(lc + 1) : this.majorString;
  }

  mostRecentDORWeek(DOR) {
    let dor_date = new Date(DOR);
    let today = new Date();

    while (dor_date < today) {
      dor_date.setDate(dor_date.getDate() + 7);
    }
    dor_date.setDate(dor_date.getDate() - 7);
    return dor_date
  }

  goToSettings() {
    this.navCtrl.push(
    'SettingsPage',
    {}, {
      animation: 'ios-transition',
      duration: 350
    })
  }

  openEdit() {
    this.navCtrl.push(
    'EditMe', {
      'me': this.user
      }, {
      animation: 'ios-transition',
      duration: 350
    });
  }

  getEvents() {
    this.userEvents = [];

    let attendProm = this.eventsService.getEventsFromId({'evt': this.person['evtrsvp'], 'community': this.person['community']});
    let intProm = this.eventsService.getEventsFromId({'evt': this.person['evtinterest'], 'community': this.person['community']});

    Promise.all([attendProm,intProm]).then(val =>{
        let attending = !!val[0] ? val[0] : [];
        let interested = !!val[1] ? val[1] : [];
        let events = attending.concat(interested);

        if(events.length > 0){
            let today = new Date();
            events = events.filter(a => {
                return new Date(a['endtime']) >= today;
            });
            this.processEvents(events);
        }
    }).catch(err => {
        Agnes.showError("Couldn't get user events right now, sorry - try reloading the page!");
    });
  }

  processEvents(events){

    events = events.filter(a => {return (a != null && (a['evttype'] && a['evttype'] == 'public') || !a['evttype'])});
    this.userEvents = events.map(a => {
      a['displaytime'] = this.getDisplayTime(a);
      return a;
    });

    //sort events into chronological order
    this.sortEvents();

  }

  getDisplayTime(event) {
        let start = Agnes.processGMT(event["starttime"].replace(/[-\+]\d\d\d\d/,'Z'));
        let end = Agnes.processGMT(event["endtime"].replace(/[-\+]\d\d\d\d/,'Z'));
        return start.date + ' ' + (start.time == "12:01AM" ? "All Day" : start.time) + (start.time == '12:01AM' ? '' : ' - '
                + (end.date == start.date ? '' : end.date + ' ') + end.time);
    }

  sortEvents() {
      this.userEvents.sort(function(a,b){
        let aDate = +new Date(a["starttime"]);
        let bDate = +new Date(b["starttime"]);
        return aDate - bDate;
      });
  }

  getGroups() {
      this.groups = [];

      let adminGroups = this.person['grp'].filter(x => { return x['admin']})
          .map(a=>{return a['groups_id']});

      let adminProm = this.groupsService.getGroupsFromId({"grp": adminGroups});
      let memProm = this.groupsService.getGroupsFromId({"grp": this.person['grp']
          .filter(x => {
              return !x['admin'] && adminGroups.indexOf(x['groups_id']) == -1})
          .map(a=>{return a['groups_id']})});
      let intProm = this.groupsService.getGroupsFromId({'grp': this.person['following'].map(a=>{return a['groups_id']})});

      Promise.all([adminProm, memProm, intProm]).then(val => {
          let admin = !!val[0] ? val[0] : [];
          let member = !!val[1] ? val[1] : [];
          let following = !!val[2] ? val[2] : [];

          let groups = admin.concat(member.concat(following));
          if (groups.length > 0) {
              this.groups = groups.filter(a => {
                  return this.isMe || a['grptype'].toLowerCase() != 'secret';
              }).map(function(a){
                  a['displayURL'] = ((a['thumbnail'] == '' || !a['thumbnail'])
                      ? "assets/img/pattern_" + Math.floor((Math.random() * 15) + 1) + '.png' : a['thumbnail']);
                  return a;
              });
          }
      }).catch(err => {
          console.log(err);
          Agnes.showError("Couldn't get user groups right now, sorry - try reloading the page!");
      });

  }

  getFriends() {
    let data = {
        "users_id": this.person['_id'],
        "community": this.person['community']
    };

    this.meService.getFriends(data).then(value => {
      if(!value.Nofriends) {
        this.noFriends = false;
        this.friends = value['friends'].filter(x => x['display']);
        if(this.friends.length > 3) {
          this.friendsDisplay = [this.friends[0], this.friends[1], this.friends[2]]
        } else {
          this.friendsDisplay = this.friends;
        }
      } else {
        this.noFriends = true;
      }
      })
      .catch(err => {
          if(this.person['_id'] == this.user['_id']){Agnes.showError("Sorry, we couldn't retrieve your friends right now.");}
      });
  }

  openProfile(id) {
    this.peopleService.getUsersFromIds({'users' : [id]}).then(value => {
        if(value && value[0]){
            this.popoverCtrl.create('PeopleProfile', {
                person: value[0],
                isMe: false
            }).present({
                animate:true,
                animation: 'ios-transition',
                duration: 350,
                easing: "ease-in-out",
                direction: "forward",
            });
        }
        else {
            Agnes.showError('Can\'t load this person\'s profile right now - try again!');
        }
    }).catch(err => {
        Agnes.showError('Can\'t load this person\'s profile right now - try again!');
    });
  }

  openFriendList() {

    //prevent opening multiple popovers

    if(this.tappable) {
      this.tappable = !this.tappable;

      let friendIds = this.friends.map(f => f['_id']);

      this.peopleService.getUsersFromIds({'users': friendIds}).then(value => {
        this.popoverCtrl.create('FriendList', {
          friends: value
        }).present({
          animate:true,
          animation: 'ios-transition',
          duration: 350,
          easing: "ease-in-out",
          direction: "forward"
        })
      });
      this.tappable = !this.tappable;
    }
  }


  twelveWeeksAhead(dateStr) {
    let weeks = new Date(dateStr);
    weeks.setDate(weeks.getDate() + 84);
    return weeks
  }

  imgLoad(ev){
    let img = ev.target;
    if (img.naturalWidth > img.naturalHeight) {
      this.orientation = 'landscape';
    } else if (img.naturalWidth < img.naturalHeight) {
      this.orientation = 'portrait';
    } else {
      this.orientation = 'even';
    }
    this.fullscreen = true;
    this.spinner = false;
  }

  coverImgError(ev) {
    this.person['cover'] = '';
  }

  imgError(ev){
    this.fullscreen = false;
    this.spinner = false;
  }

  setMenuButtons(){
    this.menuButtons = [];

    //TODO: add chat w user and invite user to group

    let snd = [{
      text: 'Report User',
      icon:'md-flag',
      cssClass:'action-sheet-report',
      handler: () => {this.reportEntity();}
    },{
      text: 'Cancel',
      role: 'cancel',
      cssClass:'',
      icon: 'md-close',
      handler: () => {}
    }];

    this.menuButtons = this.menuButtons.concat(snd);
  }

  openPeopleMenu(){
    let actionSheet = this.actionSheetCtrl.create({
      title: '',
      buttons: this.menuButtons
    });
    actionSheet.present();
  }

  openKeywordsPopup(){

    let data = {'users_id':this.user['_id']};
    this.meService.getProposedGeneralWords(data).then( keywords => {
      if (keywords && keywords.length != 0) {
          Agnes.showError("Tap on keywords that resonate with you", ["Add to Interests"], true, false, false, keywords);
          this.events.subscribe('agnesAlertData', selectedWords => {
            if (selectedWords) {
              let data = {
                'users_id':this.user['_id'],
                'interest':selectedWords
              };
              this.meService.addKeyWords(data).then(success => {
                if (success =='success') {
                  this.addNewKeywords(selectedWords);
                }
              });
            }

          });
      }
    });
  }

  addNewKeywords(keywords) {
    for (let keyword of keywords) {
      let keywordObj = {
          'keytype':'interest',
          'name':keyword
      };
      this.user['keywords'].push(keywordObj);
    }
    this.events.publish('userEdited',this.user)
  }

  closePeopleProfile(e) {
    if (!e || e.direction == 4){

        if(this.isMe){
            //send Back Button analytics
            this.analyticsService.logAnalytics({
                backButtonName: 'myProfile',
                users_id: this.user['_id']}, '/backButton');
        }

      this.navCtrl.pop({
          animation: 'ios-transition',
          duration: 350,
          easing: "ease-in-out",
          direction: "back"
      })
    }
  }

  //show person's initials if they have no pic or pic URL returns error
  profilePicError(ev, person){
      person['picError'] = true;
  }

  inviteToGroup(){

    let data = {"grp": this.user['grp'].filter(function(b){return b['admin'];}).map(function (a) {return a['groups_id']})};

    if(data['grp'].length == 0){
      Agnes.showError('You have to be an admin of at least one group to invite someone to join a group!');
    }
    else {
      this.groupsService.getGroupsFromId(data).then(value => {
        if (value) {

          value = value.filter( a => {
            return a['members'].indexOf(this.person['_id']) == -1 && a['admin'].indexOf(this.person['_id']) == -1;
          });

          if(value.length == 0){
            Agnes.showError('Looks like ' + this.person['fname']
              + ' is already part of all of that groups that you\'re an admin of!');
          }
          else {
            this.popoverCtrl.create(
              InviteToGroup,
              {
                'user':this.user,
                'person': this.person,
                'groups': value,
                'platform': this.platform
              },
              {
                  'enableBackdropDismiss':true
              }).present({
                animate:true,
                animation: 'ios-transition',
                duration: 350,
                easing: "ease-in-out",
                direction: "forward",
            });
          }
        }
        else {
          Agnes.showError("Sorry, couldn't get your groups right now - try again!");
        }
      }).catch(function(){Agnes.showError("Sorry, couldn't get your groups right now - try again!")});
    }
  }

  reportEntity(){

    let reportPage = this.popoverCtrl.create(
      ReportPage,
      {
        'entityID': this.person['_id'],
        'entityName': this.person['fname'] + ' ' + this.person['lname'],
        'user':this.user,
        'type':'people',
        'platform': this.platform
      },
      {'enableBackdropDismiss':true});
    reportPage.present(
      {
        animate: false
      }
    );
  }

  viewPic(type){
    if(type == 'cover' && this.person['cover'] != ''){
        Agnes.photoViewer.show(this.person['cover']);
    }
    else if(type == 'profile' && this.fullscreen){
        Agnes.photoViewer.show(this.person['picurl']);
    }
  }

  getUnique(arr){
    let u = {}, a = [];
    for(var i = 0, l = arr.length; i < l; ++i){
      if(u.hasOwnProperty(arr[i])) {
        continue;
      }
      a.push(arr[i]);
      u[arr[i]] = 1;
    }
    return a;
  }

  //log out of profile
  logout(){
    this.events.publish('logout');
  }

  connectFB(){

        Agnes.facebook.getLoginStatus().then(value => {

            if(value && value.status) {

                let upd = {
                    access_token: '',
                    users_id: this.user['_id']
                };

                if (value.status == 'connected') {
                    upd['access_token'] = value['authResponse']['accessToken'];

                    this.loginService.fbUpdate(upd).then(value => {

                        this.loginService.getUser({"users_id":this.user['_id']}).then(value => {
                            if (value) {
                                this.user = value;
                                localStorage.setItem('agnesUser', JSON.stringify(this.user));
                            }
                        }).catch(err => {
                            console.log(err);
                            this.events.publish('updateUser');
                        });
                        let fbToast = this.toastCtrl.create({
                            message: 'Successfully connected with Facebook!',
                            position:'top',
                            duration: 2500,
                            showCloseButton: true,
                            closeButtonText: ' '
                        });
                        fbToast.present();

                    }).catch(err => {
                        console.log('fb after update error',err);
                        Agnes.showError('Could not connect to Facebook - please try again!');
                    });
                }
                else if (value.status == 'not_authorized') {
                    Agnes.showError('Please allow Agnes access to your Facebook account!');
                }
                else {
                    let permissions = ['public_profile',
                        'user_friends',
                        'email',
                        'user_birthday',
                        'user_managed_groups',
                        'user_likes',
                        'pages_show_list',
                        'user_events'];

                    Agnes.facebook.login(permissions).then(value => {

                        if (value && value.status == 'connected') {
                            upd['access_token'] = value['authResponse']['accessToken'];

                            this.loginService.fbUpdate(upd).then(value => {
                                let fbToast = this.toastCtrl.create({
                                    message: 'Successfully connected with Facebook!',
                                    position:'top',
                                    duration: 2500,
                                    closeButtonText: ' ',
                                    showCloseButton: true
                                });
                                fbToast.present();

                                this.loginService.getUser({"users_id":this.user['_id']}).then(value => {
                                    if (value) {
                                        this.user = value;
                                        localStorage.setItem('agnesUser', JSON.stringify(this.user));
                                    }
                                }).catch(err => {
                                    console.log(err);
                                    this.events.publish('updateUser');
                                });
                            }).catch(err => {
                                console.log('fb after update error 2',err);
                                Agnes.showError('Could not connect to Facebook - please try again!');
                            });
                        }
                        else {
                            Agnes.showError('Could not connect to Facebook - please try again!');
                        }
                    }).catch(error => {
                        console.log('Facebook.login error', error);
                        Agnes.showError('Could not connect to Facebook - please try again!');
                    });
                }
            }
        }).catch(error => {Agnes.showError('Could not connect to Facebook - please try again!')});
    }

    getPebblesData() {
        let data = {"users_id":this.person['_id'], "community":this.person['community']}
        this.peopleService.getUserStreak(data).then(val =>{
          this.streak = val['dayStreak']
        }).catch(error => {
          console.log(error)
        })
        this.peopleService.getUserRewardCountdown(data).then(val => {
          this.reward = val['untilReward']
        }).catch(error=> {
          console.log(error)
        })
        this.peopleService.getUserLifetimePebbles(data).then(val => {
          this.lifetime = val['lifeTimePebble']
        }).catch(error=> {
          console.log(error)
        })

        //determine if pebbles are active now
        this.peopleService.communityPebblesStatus({'community' : this.person['community']}).then(val => {
          this.paused = !val['pebbleStatus']
          const start = new Date(val['startDate'])
          const end = new Date(val['endDate'])
          const now = new Date()
          this.totalDays = Math.round(Math.abs((start.getTime() - end.getTime())/(86400000)))
          this.daysLeft = Math.round(Math.abs((start.getTime() - now.getTime())/(86400000)))
      }).catch(error => {
        console.log(error)
      })

        let goalsArray = [7, 14, 21, 30, 45, 60, 75, 100]

        for(let g in goalsArray) {
          if(this.streak < goalsArray[g]) {
            this.streakGoal = goalsArray[g];
            break;
          }
        }
    }

    openPebblePage(pageIndex) {

      //define and pass all progress data so that slides can work correctly
      if(!this.paused) {
        this.popoverCtrl.create('PebbleProfile',
        {page : pageIndex,
        person: this.person,
        streak: this.streak,
        streakGoal: this.streakGoal,
        lifetime: this.lifetime,
        reward: this.reward,
        noFriends: this.noFriends,
        isMe: this.isMe
        }, {}).present({
          animate:true,
          animation: 'ios-transition',
          duration: 350,
          easing: "ease-in-out",
          direction: "forward",
        })
    } else {
      this.popoverCtrl.create('PebblePaused',
      {person: this.person,
      isMe: this.isMe,
      daysLeft: this.daysLeft,
      totalDays: this.totalDays
    }, {}).present({
        animate: true,
        animation: 'ios-transition',
        duration: 350,
        easing: "ease-in-out",
        direction: "forward",
      })
    }
  }

}

"""
This is the meat of the repo

Here be happenin' all the proprietary things

Inputs:
user huddle object

Outputs:
1. Ranking of items to show in the huddle

"""
import logging
import random
import time
from datetime import datetime

default_thumbnail = 'https://s3.amazonaws.com/agnesimages/Agnes-Logo-128px.png'

HUDDLE_SIZE_THRESHOLD = 25

obj_mappings = {
    'news': {
        'type':'News',
        'label':'News',
        'thumbnail':'picurl',
        'action':'Share To Contacts',
        'timestamp':''

    },
    'recentlyAddedEvent': {
        'type': 'Events',
        'label':'Recently Added',
        'thumbnail':'thumbnail',
        'action':'Share to Contacts',
        'timestamp':''
    },
    'eventTrending': {
        'type': 'Events',
        'label':'Recently Added',
        'thumbnail':'thumbnail',
        'action':'Share to Contacts',
        'timestamp':''
    },
    'eventsFriends':{
        'type':'Events',
        'label':'Event Update',
        'thumbnail':'thumbnail',
        'action':'Interested',
        'timestamp':''
    },
    'eventFeatured':{
        'type':'Events',
        'label':'Featured',
        'thumbnail':'thumbnail',
        'action':'Interested',
        'timestamp':''
    },
    'recommendedEvent':{
        'type':'Events',
        'label':'Recommended',
        'thumbnail':'thumbnail',
        'action':'Interested',
        'timestamp':''
    },
    'recommendedGroup': {
        'type':'Groups',
        'label':'Recommended',
        'thumbnail':'thumbnail',
        'action':'Interested',
        'timestamp':''
    },
    'groupUpdate': {
        'type':'Groups',
        'label':'Group Update',
        'thumbnail':'thumbnail',
        'action':'Interested',
        'timestamp':''
    },
    'featured_groups':{
        'type':'Groups',
        'label':'Featured',
        'thumbnail':'thumbnail',
        'action':'Interested',
        'timestamp':''
    },
    'discoverGroup': {
        'type':'Groups',
        'label':'Discover',
        'thumbnail':'thumbnail',
        'action':'Interested',
        'timestamp':''
    },
    'discoverEvent': {
        'type':'Events',
        'label':'Discover',
        'thumbnail':'thumbnail',
        'action':'Interested',
        'timestamp':''
    }
}

def updateItems(user_huddle):

    update_items = user_huddle['updateFeed']


def rankItemsA(user_huddle):
    # result = [dict(tupleized) for tupleized in set(tuple(item.items()) for item in l)]

    # todo: Add ads
    # try:
    allItems = {}
    allItems['news'] = removeDuplicateDicts(user_huddle['news'])
    allItems['recentlyAddedEvent'] = removeDuplicateDicts(user_huddle['recentlyAddedEvent']) # 0 is most recent
    allItems['eventTrending'] = removeDuplicateDicts(user_huddle['eventTrending']) # 0 is most trending
    allItems['eventsFriends'] = removeDuplicateDicts(user_huddle['eventsFriends']) # 0 is most friends
    allItems['eventFeatured'] = removeDuplicateDicts(user_huddle['eventFeatured']) # no ordering
    allItems['recommendedEvent'] = removeDuplicateDicts(user_huddle['recommendedEvent']) # 0 is most recommended
    allItems['groupUpdate'] = removeDuplicateDicts(user_huddle['groupUpdate']) # 0 is oldest 1 is newest
    allItems['featured_groups'] = removeDuplicateDicts(user_huddle['featuredGroup'])  # no ordering
    allItems['discoverEvent'] = removeDuplicateDicts(user_huddle['discoverEvent']) # 0 is soonest


    # except TypeError as e:
    #     print e
    #     print user_huddle['_id']
    #     print 'what ahat'

    # Removed at Kai's request
    # allItems['recommendedGroup'] = user_huddle['recommendedGroup'][:5] # 0 is most recommended
    # allItems['discoverGroup'] = user_huddle['recommendedGroup'][5:] # 0 most recommended

    allItems = cleanItems(allItems)
    allItems = removeEmptyKeys(allItems)

    ranking = getRanking(allItems)

    return ranking

def removeDuplicateDicts(dict_list):
    unique_list = []
    seen = []
    for item in dict_list:
        if item['_id'] not in seen:
            unique_list.append(item)
            seen.append(item['_id'])
    return unique_list

def cleanItems(allItems):

    # TODO: only put recommended groups that are above the threshold = 0.98

    # TODO: remove duplicates across types
    # for key in allItems:
    #     item_list = allItems[key]
    #     for item in item_list:
    #         for iter_key in allItems:
    #             if item in

    return allItems

def getRanking(allItems):

    ranking = []

    while hasItems(allItems):
        random_keys = allItems.keys()
        random.shuffle(random_keys)

        while len(random_keys) > 0:
            key = random_keys.pop(0)
            entity_list = allItems[key]

            entity = entity_list.pop(0)
            ranking.append(buildRankingItem(key, entity))

            if len(ranking) >= HUDDLE_SIZE_THRESHOLD:
                return ranking

        allItems = removeEmptyKeys(allItems)

    # logging.info('Community:')
    # logging.info('Ranking Types:')
    # for item in ranking:
    #     logging.info('%s %s' % (item['label'], item['type']))
    # logging.info('\n')
    # logging.info('new ranking len %d ' % len(ranking))
    return ranking

def hasItems(allItems):
    for key in allItems.keys():
        if allItems[key]:
            return True
    return False

def removeEmptyKeys(allItems):
    for key in allItems.keys():
        if not allItems[key]:
            del allItems[key]
    return allItems

def buildRankingItem(key, entity):

    new_item = {}
    for mapping_key in obj_mappings[key].keys():
        new_item[mapping_key] = obj_mappings[key][mapping_key]

    new_item['entity'] = entity

    new_item['thumbnail'] = getThumbnail(key, entity)

    return new_item

def getThumbnail(key, entity):

    if 'thumbnail' in entity:
        if entity['thumbnail']:
            return entity['thumbnail']

    return default_thumbnail

def rankCategoryItems(key, items):

    rankings = []

    for item in items:

        ranking = rankItem(key, item)
        rankings.append((item, ranking))

    sorted_rankings = sorted(rankings, key=lambda x: x[1])
    return [x[0] for x in sorted_rankings]


def rankItem(key, item):

    function_mapping = {
        'news':rankNewsItem,

    }

    return function_mapping[key](item)

def rankNewsItem(item):

    news_date = item['date_published']

def rankRecentlyAddedEvent(item):

    event_createtime = item['createtime']


def rankTrending(item):

    event_starttime = item['starttime']


def rankEventFriends(item):

    pass


def rankFeaturedEvent(item):
    pass

def rankRecommendedEvent(item):
    pass

def rankRecommendedGroup(item):
    pass

def rankDiscoverEvents(item):
    pass

def rankAd(item):
    pass

def rankDiscoverGroups(item):
    pass

def rankGroupUpdate(item):
    pass

def rankFeaturedGroup(item):
    pass

def rankRecentlyAddedGroup(item):
    pass

def rankNewFriendJoin(item):
    pass

def rankGroupFollow(item):
    pass

def rankGroupJoin(item):
    pass

def rankGroupFriends(item):
    pass

def rankPebbleClaim(item):
    pass




'''
News
Recently Added Events
Trending
Event Friends
Featured Events
Recommended
Recommended
Discover Events
Ad
Discover Groups
All Group Update
Featured Groups
Recently Added Groups
New Friend Joins
Group Follows
Group Joins
Group Friends
Pebble Daily Claim
'''
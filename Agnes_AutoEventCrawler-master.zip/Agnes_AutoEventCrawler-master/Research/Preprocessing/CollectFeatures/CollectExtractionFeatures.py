'''
Module for extracting features from a event page sample (could be a single node or subtree)

Types of Features:
1. Manual Features (keywords, length, avg sentence length, locations, dates etc.)
2. HTML Embedding (Locally trained W2V Embedding of html content words)
3. Structural Features (height, depth, position,

'''

from config import db_config
from collections import Counter
from gensim.models import Word2Vec
from gensim.models import keyedvectors
import numpy as np
import re
import string
import pickle
from bson import Binary
from Utilities import DateExtraction, LocationExtraction, DataFilter
from EmbeddingTrainer import tokenizeW2V, tokenizeC2V, tokenizeH2V_W

dbConn = db_config.getDBConn('dev')
Agnes = dbConn.Agnes
Data_Collection = Agnes.autocrawler_ext_data

def getCharEmbeddingModel():
    model = {}
    with open('glove.840B.300d-char.txt', 'r') as f:
        data = f.readlines()
        for line in data:
            char = line[0]
            char_data = line[1:]
            char_data = np.array([float(item) for item in char_data.split() if item]).astype(np.float16)
            model[char] = char_data

    return model

def getContentEmbeddingModel():
    model = keyedvectors.KeyedVectors().load_word2vec_format('GoogleNews-vectors-negative300.bin', binary=True)
    return model

def getHTMLEmbeddingModel():
    return Word2Vec.load('gensim_html2vec_model')

def extractFeaturesManual(text):

    features = []

    features += manualGeneral(text)

    features += manualLocation(text)

    features += manualDate(text)

    return features

def manualGeneral(text):
    html_text = DataFilter.removeContentInHTML(text)
    content_text = DataFilter.removeHTML(text)

    lower_html = html_text.lower()
    lower_html_nohref = DataFilter.removeHref(lower_html)
    lower_content = content_text.lower()

    keywords = ['title', 'description', 'desc', 'location', 'locat','name', 'date', 'summary', 'event', 'content', 'field', 'address',
                'venue', 'time', 'when', 'where', 'start', 'end', 'map', 'calendar', 'cal', 'from', 'to', 'building', 'hall', 'auditorium',
                'room', 'clock', 'street', 'locality', 'theatre', 'theater']

    content_length = len(content_text)  # int
    html_length = len(lower_html_nohref)  # int
    content_words = [w for w in DataFilter.removePunctuation(content_text).split() if w] # list
    num_content_words = len(content_words)  # int
    num_html_words = len(DataFilter.removePunctuation(lower_html_nohref).split())  # int

    if num_content_words == 0:
        capital_ratio = 0
    else:
        capital_ratio = len([1 for w in content_words if w[0].isupper()]) / float(num_content_words)  # float

    avg_content_word_len = getAvgWordLength(lower_content)  # float
    avg_content_sen_len = getAvgSentenceLength(lower_content)  # float

    punc_counts = getKeywordCount(string.punctuation, lower_content)  # list
    content_keywords = getKeywordCount(keywords, lower_content)  # list
    html_keywords = getKeywordCount(keywords, lower_html_nohref)  # list
    tag_counts = getTagCount(lower_html) # list

    features = [content_length, html_length, num_content_words, num_html_words, capital_ratio, avg_content_word_len,
                avg_content_sen_len]

    features += punc_counts
    features += content_keywords
    features += html_keywords
    features += tag_counts

    # if 'Chicano' in content_text:
    #     print text
    #     print 'content_len',content_length
    #     print 'html_len',html_length
    #     print 'num_content_words',num_content_words
    #     print 'num_html_words',num_html_words
    #     print 'capital ratio',capital_ratio
    #     print 'avg_content_word_len',avg_content_word_len
    #     print 'avg_content_sen_len',avg_content_sen_len
    #     print 'punc counts', zip(string.punctuation, punc_counts)
    #     print 'content keywords',zip(keywords, content_keywords)
    #     print 'html_keywords',zip(keywords, html_keywords)
    #     print 'tag_counts',zip(DataFilter.ValidTags, tag_counts)

    return features

def manualLocation(text):

    text = DataFilter.removeHTML(text)
    text = DataFilter.cleanString(text)

    usaddr_location_fields = LocationExtraction.getUSAddressFields()
    postal_location_fields = LocationExtraction.getPostalFields()
    features = []

    us_addr = LocationExtraction.getRawUSAddress(text)
    postal_addr = LocationExtraction.getRawPostalAddress(text)

    for field in usaddr_location_fields:
        features.append(len([item for item in us_addr if item[1] == field]))

    for field in postal_location_fields:
        features.append(len([item for item in postal_addr if item[1]==field]))
    # locations = len(LocationExtraction.getLocations(text))

    return features

def manualDate(text):
    text = DataFilter.removeHTML(text)
    dates = len(DateExtraction.getDates(text))

    return [dates]

def extractFeaturesContent(embedding_model, text):
    tokens = tokenizeW2V(text)

    vectors = [embedding_model.wv[token] for token in tokens if token in embedding_model.wv]

    if not vectors:
        return None

    feature_vector = np.mean(np.vstack(vectors).astype(np.float16), axis=0)

    feature_vector = Binary(pickle.dumps(feature_vector))

    return feature_vector

def extractFeaturesHTML(embedding_model, text):
    tokens = tokenizeH2V_W(text)

    if not tokens:
        return None

    # print [(token, token in embedding_model.wv) for token in tokens]

    vectors = [embedding_model.wv[token] for token in tokens if token in embedding_model.wv]

    if not vectors:
        return None

    feature_vector = np.mean(np.vstack(vectors).astype(np.float16), axis=0)

    feature_vector = Binary(pickle.dumps(feature_vector))

    return feature_vector

def extractFeaturesStructure(tree, node_id):

    height = tree.height(node_id)
    depth = tree.depth(node_id)
    num_first_children = tree.num_immediate_children(node_id)
    num_total_children = len(list(tree.iterate_from_node(node_id))) - 1
    position = tree.get_position(node_id)

    features = [height, depth, num_first_children, num_total_children, position]

    # print 'Height:', height
    # print 'Depth:', depth
    # print 'First Children',num_first_children
    # print 'Total Children',num_total_children
    # print 'Position', position

    return features

def extractFeaturesChar(embedding_models, text):
    tokens = tokenizeC2V(text)
    return embedding_models['char'].infer_vector(tokens).tolist()

def getTagCount(html):
    html = DataFilter.cleanString(html)

    pattern = re.compile('(<)([\w]*?)[ >]')
    tags = Counter([item[1] for item in re.findall(pattern, html)])

    valid_tags = DataFilter.ValidTags

    if not tags:
        return [0]*len(valid_tags)

    tag_counts = []
    for tag in valid_tags:
        if tag in tags:
            tag_counts.append(tags[tag])
        else:
            tag_counts.append(0)

    return tag_counts

def getKeywordCount(keyword_list, content):
    counts = []
    for item in keyword_list:
        counts.append(content.count(item))
    return counts

def getAvgWordLength(content):
    content = DataFilter.removePunctuation(content)
    avg_word_len = np.mean([len(word) for word in content.split()])
    if np.isnan(avg_word_len):
        return 0
    return avg_word_len

def getAvgSentenceLength(content):
    avg_sen_len = np.mean([len(sen) for sen in content.split('.')])
    if np.isnan(avg_sen_len):
        return 0
    return avg_sen_len

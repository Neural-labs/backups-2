DATA_SEARCH = [
    'evt',
    'event'
]

MAX_DEPTH = 6
MAX_COUNT = 3000

HomePage = 'http://www.mit.edu'
Domain = 'mit'


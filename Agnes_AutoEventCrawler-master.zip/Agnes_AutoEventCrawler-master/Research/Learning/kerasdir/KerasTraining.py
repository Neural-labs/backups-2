from gensim.models import Doc2Vec
from config import db_config
from keras.models import Sequential, model_from_json
from keras.layers import Conv1D, MaxPooling1D, LSTM, Dense, Activation, Flatten, GlobalMaxPool1D, Dropout
from keras.callbacks import ModelCheckpoint
import multiprocessing
from sklearn.metrics import recall_score, f1_score, roc_auc_score
import re
import math
from imblearn.combine import SMOTEENN
from keras.optimizers import SGD
import numpy as np
import pickle
import logging
from bson.objectid import ObjectId
from kerasTesting import testModel


cores = multiprocessing.cpu_count()

dbConn = db_config.getDBConn('dev')
Agnes = dbConn.Agnes
Data_Collection = Agnes.autocrawler_ext_data

total_samples = 5000000
batch_size = 10000
epochs = 5

RANDOM_SEED = 42

INPUT_DIM = 314

def runClassificationTraining(sample_part):

    # print 'Initializing Global Variables...'
    # initGlobals()

    print 'Building Model...'
    model = getModel()

    # epochs = total_samples / batch_size
    steps_per_epoch = total_samples / batch_size

    print 'Epochs',epochs
    print 'Steps per epoch', steps_per_epoch

    print 'Generating Training Samples...'
    sample_generator = getSampleGenerator(sample_part)

    print 'Generating Validation Samples...'
    validation_data = validationBatch(sample_part)

    # for X,y in sample_generator:
    #     X.reshape(X.shape[0], 1, X.shape[1])
    #     print 'Training Shape:',X.shape
    #
    #     # print
    #     break

    # counter = 1

    # print 'Fitting model...'
    # for X,y in sample_generator:
    #     counter += 1
    #     model.train_on_batch(X, y, class_weight={0: 1, 1: 500})
    #     if counter % 10 == 0:
    #         print
    #         print 'Epoch',counter
    #         test_X, test_y, samples = validationBatch(sample_part)
    #         if test_X is None:
    #             print 'validation batch collection failed'
    #             continue
    #         # model.test_on_batch(test_X, test_y)
    #         preds = model.predict_on_batch(test_X)
    #         runStats(preds, test_y, samples)
    #         print 'Save Model...'
    #         # serialize model to JSON
    #         # model_json = model.to_json()
    #         # with open("model.json", "w") as json_file:
    #         #     json_file.write(model_json)
    #         #
    #         #     # serialize weights to HDF5
    #         # model.save_weights("model.h5")
    #         # print("Saved model to disk")
    #         with open('extraction_classification_model_' + sample_part + '_'+str(counter)+'.h5', 'w') as f:
    #             model.save('extraction_classification_model_' + sample_part+ '_'+str(counter)+'.h5', overwrite=True)

    # raise ValueError('stop')

    print 'Fitting model...'
    filepath = 'keras_classifier_'+ sample_part +'.hdf5'
    checkpoint = ModelCheckpoint(filepath, verbose=1, save_best_only=True)
    callbacks_list = [checkpoint]
    model.fit_generator(generator=sample_generator, epochs=epochs,  steps_per_epoch=steps_per_epoch,
                         validation_data= validation_data,class_weight={0:1,1:500}, callbacks=callbacks_list)#, workers=cores)

    # testModel(model)


def runStats(predictions, actual_values, samples):

    preds = []
    for row in range(len(predictions)):
        for col in range(len(predictions[0])):
            preds.append(predictions[row][col])

    actual_values = list(np.array(actual_values).astype(np.float16))
    # print 'Validation Recall:', recall_score(actual_values, preds)
    # print 'Validation F1:', f1_score(actual_values, preds)

    if not 1 in actual_values:
        return
    print 'ROC AUC Score:', roc_auc_score(actual_values, preds)

    avg_pos = 0.0
    count_pos = 0.0
    avg_neg = 0.0
    count_neg = 0.0
    for index in range(len(predictions)):
        if actual_values[index]:
            avg_pos += preds[index]
            count_pos += 1
            print
            print 'SAMPLE:'
            print samples[index]['text']
            print samples[index]['event_id']
            print preds[index]
            print

        else:
            avg_neg += preds[index]
            count_neg += 1

    print 'Pos Val Samples', count_pos
    if count_pos:
        print 'Avg Pos Score:', avg_pos / count_pos
    print 'Neg Val Samples', count_neg
    if count_neg:
        print 'Avg Neg Score:', avg_neg / count_neg
    print

def getModel():
    kernel_size = 5
    pool_size = 4
    filters = 64
    lstm_output_size = 64
    input_dim = INPUT_DIM
    consume_less = 1  # 1 for cpu, 2 for gpu

    model = Sequential()
    model.add(Conv1D(filters,
                     kernel_size,
                     padding='same',
                     strides=1,
                     kernel_initializer='uniform',
                     input_shape=(None, input_dim),
                     batch_input_shape=(None, 1,input_dim)
                     ))
    model.add(Activation('relu'))
    # model.add(Flatten())
    # model.add(GlobalMaxPool1D())
    # model.add(Flatten())
    model.add(MaxPooling1D(padding='same'))
    model.add(LSTM(lstm_output_size))

    model.add(Dense(64, activation='relu'))
    model.add(Dense(64, activation='relu'))
    model.add(Dense(1, activation='sigmoid'))
    sgd = SGD(lr=0.01, momentum=0.0, decay=0.0, nesterov=False)
    model.compile(loss='binary_crossentropy',
                  optimizer='adam',
                  metrics=['accuracy'])
    model.summary()
    return model

def getSimpleModel():
    pass

def getSampleGenerator(sample_part):

    for epoch in range(epochs):
        batch_index = 0
        last_id = None
        X = []
        y = []

        while batch_index < total_samples:
            # logging.info('Fetching batch index: %d' % batch_index)

            samplebatch = getSampleBatchCursor(last_id)

            # logging.info('Retrieved %d samples' % samplebatch.count(with_limit_and_skip=True))

            for index, sample in enumerate(samplebatch):
                if invalidSample(sample):
                    continue

                label = checkLabel(sample, sample_part)

                features = getFeatures(sample)
                if len(features) != INPUT_DIM:
                    continue

                X.append(features)
                y.append(label)

                last_id = sample['_id']

            X = np.array(X)
            # logging.info(('X_train_shape',X.shape))
            X = X.reshape(X.shape[0], 1, X.shape[1])
            y = np.array(y)
            yield X, y
            X = []
            y = []
            del samplebatch
            batch_index += batch_size

def getFeatures(sample):
    features = []

    features += list(pickle.loads(sample['features_h2v_w']))
    # features += list(pickle.loads(sample['features_w2v_pretrained']))
    features += sample['manual_v2']
    return features

def validationBatch(sample_part):

    val_samples = None
    X = []
    y = []
    while val_samples is None or len(X) == 0:
        try:
            val_samples = getRandomBatch()
            for sample in val_samples:
                if invalidSample(sample):
                    continue
                label = checkLabel(sample, sample_part)
                features = getFeatures(sample)
                if len(features) != INPUT_DIM:
                    continue
                X.append(features)
                y.append(label)
        except Exception as e:
            print 'Failed to get validation collection, trying again...'

    # print 'Fetching positives'
    # pos_val_samples = getPosBatch()
    # print 'Fetching negatives'
    # neg_val_samples = getNegBatch()

    # for sample in pos_val_samples:
    #     if invalidSample(sample):
    #         continue
    #
    #     label = checkLabel(sample, sample_part)
    #     features = sample[sample_part+'_features']
    #
    #     X.append(features)
    #     y.append(label)
    #
    # for sample in neg_val_samples:
    #     if invalidSample(sample):
    #         continue
    #
    #     label = checkLabel(sample, sample_part)
    #     features = sample[sample_part + '_features']
    #
    #     X.append(features)
    #     y.append(label)

    # print X
    # print len(X)
    X = np.array(X)
    print X.shape
    X = X.reshape(X.shape[0], 1, X.shape[1])
    y = np.array(y)

    return X,y#,samples

def invalidSample(sample):
    if not 'manual' in sample or not 'features_h2v_w' in sample or not 'features_w2v_pretrained' in sample:
        return True
    return False

def checkLabel(sample, part):

    if not sample['label']:
        return False

    sample_part = sample['part']
    if sample_part == part:
        return True

    return False

def getSampleBatchCursor(last_id):
    # db.students.find({'_id': {'$gt': last_id}}).limit(10)
    if not last_id:
        return Data_Collection.find({"features_h2v_w": { '$exists': True },"features_w2v_pretrained": { '$exists': True }}, no_cursor_timeout=True).limit(batch_size)
    return Data_Collection.find({'_id': {'$gt': last_id}, "features_h2v_w": { '$exists': True },"features_w2v_pretrained": { '$exists': True }}, no_cursor_timeout=True).limit(batch_size)

def getRandomBatch():
    val_batch_size = 10000
    validation_index = ObjectId('5a913f4355c857433e80fea2')
    return Data_Collection.aggregate([{"$sample": {'size': val_batch_size}}, {"$match": {"features_h2v_w": { '$exists': True }, '_id': {'$gt': validation_index}}}])

def getPosBatch():
    return Data_Collection.find({'label':1, "features_h2v_w": { '$exists': True }}, no_cursor_timeout=True).limit(batch_size/2)

def getNegBatch():
    return Data_Collection.find({'label':0, "features_h2v_w": { '$exists': True }}, no_cursor_timeout=True).limit(batch_size/2)

def getValBatch():
    val_batch_size = 10000
    validation_index = ObjectId('5a91294a55c857431b804747')
    return Data_Collection.find({'_id': {'$gt': validation_index}, "features_h2v_w": { '$exists': True },"features_w2v_pretrained": { '$exists': True }}, no_cursor_timeout=True).limit(val_batch_size)
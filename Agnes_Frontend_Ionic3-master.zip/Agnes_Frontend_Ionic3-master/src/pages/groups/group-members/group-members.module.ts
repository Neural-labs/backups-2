import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';


import { GroupMembers } from './group-members';
import { ComponentsModule } from '../../../components/components.module';

@NgModule({
    declarations: [
        GroupMembers
    ],
    imports: [
        IonicPageModule.forChild(GroupMembers),
        ComponentsModule
    ],
    exports: [
        GroupMembers
    ]
})

export class GroupMembersModule { }

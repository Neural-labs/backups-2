import {Component} from '@angular/core';
import { NavParams, IonicPage, Events, ViewController } from 'ionic-angular';

@IonicPage()
@Component({
    selector: 'event-attendees',
    templateUrl: 'event-attendees.html',
    providers: []
})

export class EventAttendees {

    user:Object;
    attendees: Array<Object>;
    peopleSearch: string;
    canInvite: string;

    constructor(private viewCtrl: ViewController,
                private events: Events,
                private navParams: NavParams) {
    }

    //initialize attendees page
    ngOnInit() {
        this.user = JSON.parse(localStorage.getItem("agnesUser"));
        this.attendees = this.navParams.get('attendees');
        this.peopleSearch = '';
        this.canInvite = this.navParams.get('canInvite');
    }

    //filter attendees by name
    matchesSearch(person){
        let term = this.peopleSearch.trim().toLowerCase();
        let len = term.length;
        if(len > 0){
            let fname = person['fname'].toLowerCase().substring(0,len) == term;
            let lname = person['lname'].toLowerCase().substring(0,len) == term;
            let fullname = (person['fname'] + ' ' + person['lname']).toLowerCase() == term;

            return (fname || lname || fullname);
        }
        else {
            return true;
        }
    }

    //close attendees popup page
    closeEventAttendees(inviteMore){
        if(inviteMore){
            this.events.publish('inviteMore');
        }
        this.viewCtrl.dismiss(null,null,{
            animation: 'ios-transition',
            duration: 350,
            easing: "ease-in-out",
            direction: "back"
        });
    }
}

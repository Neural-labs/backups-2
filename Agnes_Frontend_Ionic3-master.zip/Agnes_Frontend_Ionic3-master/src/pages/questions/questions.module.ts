import { NgModule } from '@angular/core';
import { QuestionsPage } from './questions';
import { IonicPageModule } from 'ionic-angular';
import { ComponentsModule } from '../../components/components.module';

@NgModule({
  declarations: [
    QuestionsPage
  ],
  imports: [
    IonicPageModule.forChild(QuestionsPage),
    ComponentsModule
  ],
  exports: [
    QuestionsPage
  ]
})

export class QuestionsPageModule { }

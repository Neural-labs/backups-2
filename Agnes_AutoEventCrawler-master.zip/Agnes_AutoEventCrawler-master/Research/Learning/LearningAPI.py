from KazemWork import kazem_work
from Preprocessing.CollectFeatures.EmbeddingTrainer import runEmbeddingTrainer
from io import ioLearning
from kerasdir.KerasTraining import runClassificationTraining
from kerasdir.emptyWord2Vec import runTraining
from kerasdir.imdb_cnn_lstm import runKerasIMBD
from kerasdir.kerasLearning import runKeras
from kerasdir.kerasTesting import testModel
from networkx import networkx_learning


def IoLearning():
    ioLearning.main()

def RunKerasLearning():
    runKeras()

def RunKerasIMBD():
    runKerasIMBD()

def runWord2VecTrain():
    runTraining()

def runGensim(model):
    runEmbeddingTrainer(model_type=model)

def runClassifierTraining(part):
    runClassificationTraining(part)

def runClassifierTesting():
    testModel()

def runKazem():
    kazem_work.runKazemWork()

def runNetworkx():
    networkx_learning.runNXLearning()
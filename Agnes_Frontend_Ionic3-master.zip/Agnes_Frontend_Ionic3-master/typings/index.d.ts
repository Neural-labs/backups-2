/// <reference path="globals/aws-sdk/index.d.ts" />

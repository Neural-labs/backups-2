from config import db_config
import random
import logging

Agnes = db_config.getDBConn('dev').Agnes
Events_Collection = Agnes.autocrawler_events
Id_Data_Collection = Agnes.autocrawler_id_data
Id_ValData_Collection = Agnes.autocrawler_id_data_val

train_sources = ['busboysandpoets.com', 'caps.gov.harvard.edu', 'marymount.edu', 'atlanticcouncil.org', 'ces.fas.harvard.edu', 'newamerica.org', 'history.fas.harvard.edu', 'law.columbia.edu', 'guevents.georgetown.edu', 'chem.columbia.edu', 'jtsa.edu', '37', 'calendar.colgate.edu', 'humanrightscolumbia.org', 'dspshows.com', 'gsas.harvard.edu', 'events.williams.edu', 'memorialchurch.harvard.edu', 'edportal.harvard.edu', 'calendar.northeastern.edu', 'capitalfringe.org', 'eventbrite.com(ithaca)', 'chemistry.harvard.edu', 'engineering.cornell.edu', 'cfa.gmu.edu', 'calendar.howard.edu', 'brookings.edu', 'artgallery.yale.edu', 'events.temple.edu', 'earth.columbia.edu', 'artsinitiative.columbia.edu', 'nyu.edu', 'belfercenter.org', 'heymancenter.org', 'aei.org', 'barnard.edu', 'green.harvard.edu', 'washingtondc.eventful.com', 'washington.org', 'politics-prose.com', 'gradschool.cornell.edu', 'environment.harvard.edu', 'events.newschool.edu', 'anthropology.fas.harvard.edu', 'events.ithaca.edu', 'calendar.oberlin.edu', 'news.dartmouth.edu', 'weai.columbia.edu', 'events.towson.edu', 'ofa.fas.harvard.edu', 'cato.org', 'georgetowndc.com', 'econ.columbia.edu', 'harvard-yenching.org', 'shakespearetheatre.org', 'csis.org', 'dcsbdc.org', 'slavic.fas.harvard.edu', 'my.arboretum.harvard.edu', 'economics.harvard.edu', 'events.cornell.edu', 'events.visitithaca.com', 'cellbio.med.harvard.edu', 'eventbrite.com', 'histsci.fas.harvard.edu', 'mailman.columbia.edu', 'harvardartmuseums.org', 'sociology.fas.harvard.edu', 'peabody.harvard.edu', 'american.edu', 'events.goucher.edu', 'usgbc.org', 'eli.org', 'energypolicy.columbia.edu', 'philly.com', 'astro.columbia.edu', 'runwashington.com', 'hls.harvard.edu', 'eventbrite.com(washington)', 'gsd.harvard.edu', 'arch.columbia.edu', 'bu.edu', 'socialwork.columbia.edu', 'events.citypaper.com', 'iijs.columbia.edu', 'ves.fas.harvard.edu', 'events.udel.edu']

test_sources = ['930.com', 'ticketmaster', 'thebostoncalendar.com', 'thephillycalendar.com', 'events.uri.edu', 'math.cornell.edu', 'physics.columbia.edu', 'meetup.com', 'english.columbia.edu', 'radcliffe.harvard.edu','browse.calendar.gwu.edu']

def shuffle_all_events():

    print 'Shuffling?'
    counter = 0
    cursor = Id_Data_Collection.find({}, no_cursor_timeout=True)
    for item in cursor:
        counter += 1
        if counter % 1000 == 0:
            print 'Progress:',counter
        if item['evtsource'] in test_sources:

            Id_ValData_Collection.insert_one(item)


    # events = getEvents()
    # counter = 0
    # for event in events:
    #     counter += 1
    #     if counter % 100 == 0:
    #         logging.info('Counter %d of %d' % (counter, events.count()))
    #     updateSample(event['_id'],generateRandom())


def generateRandom():
    return int(abs(random.getrandbits(62)))  # 2^128 possible ids

def getEvents():
    return Events_Collection.find({},no_cursor_timeout=True)

def getRandomBatch():
    batch_size = 1000
    return Events_Collection.aggregate([{"$sample": {'size': batch_size}}])

def updateSample(_id, random_id):
    # Events_Collection.insert_one(updated_event)
    # Events_Collection.remove_one({'_id':old_id})

    Events_Collection.update_one({
        '_id': _id
    }, {
        '$set': {
            'random_id': random_id
        }
    }, upsert=False)

def getIdData():
    return Id_Data_Collection.find({},no_cursor_timeout=True)
from CollectEventTrees import collecteventtrees
from CleanData import RemoveDuplicates, CleanData, PermShuffleEvents
from CollectFeatures import EmbeddingTrainer, Page_EmbeddingTrainer
from CollectSamples import CollectIdentificationSamples, CollectExtractionSamples, CollectUniquePages
from ExamineData import examineData, ExtractionExamination, SinglePage


def cleanDataWrapper():
    CleanData.cleanData()

def removeDuplicates(Key):
    RemoveDuplicates.removeDuplicates(key=Key)

def examineAllData():
    examineData.examineData()

def extractionExamination():
    ExtractionExamination.ExamineSamples()

def examineSinglePage():
    SinglePage.runSinglePage()

def runTreeCollection():
    collecteventtrees.EventTreeCollection()

def runExtractionSampleCollection():
    CollectExtractionSamples.RunExtractionSampleCollection()

def runIdentificationSampleCollection():
    CollectIdentificationSamples.RunIdentificationSampleCollection()

def trainEventEmbedding(model_type):
    EmbeddingTrainer.runEmbeddingTrainer(model_type)

def trainPageEmbedding():
    Page_EmbeddingTrainer.runEmbeddingTrainer()

def collect_unique_events():
    CollectUniquePages.CollectUniqueSources()

def parse_unique_events():
    CollectUniquePages.ParseUniqueSources()

def shuffleEvents():
    PermShuffleEvents.shuffle_all_events()


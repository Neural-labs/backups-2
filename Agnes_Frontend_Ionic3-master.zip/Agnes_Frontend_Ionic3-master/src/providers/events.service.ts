import { Injectable } from '@angular/core';
import { Headers, Http, RequestOptions } from '@angular/http';
import { Agnes } from '../app/app.component';
import 'rxjs/add/operator/toPromise';
import 'rxjs/add/operator/timeout';

@Injectable()
export class EventsService {
  private headers = new Headers({'Content-Type': 'application/json'});

  constructor(private http: Http) {
  }

  getTrendingEvents(uid): Promise<Object[]> {
    let data = {users_id:uid, token: localStorage.getItem('agnesToken')};
    data["timestamp"] = new Date()
    let addUrl = Agnes.API_URL + '/trending_events';
    let options = new RequestOptions({ headers: this.headers });

    return this.http.post(addUrl, data, options)
      .timeout(10000)
      .toPromise()
      .then(response => response.json() as Object[])
      .catch(this.handleError);
  }

  getMatchedEvents(data): Promise<Object[]> {
      data["token"] = localStorage.getItem('agnesToken')
      data["timestamp"] = new Date()
    let addUrl = Agnes.API_URL + '/user_match_event_2';
    let options = new RequestOptions({ headers: this.headers });
    return this.http.post(addUrl, data, options)
      .timeout(10000)
      .toPromise()
      .then(response => response.json() as Object[])
      .catch(this.handleError);
  }

  loadAllEvents(uid,comm): Promise<Object[]> {
    let data = {"users_id": uid, "community": comm, "token": localStorage.getItem('agnesToken')};
    data["timestamp"] = new Date()
    let addUrl = Agnes.API_URL + '/events';
    let options = new RequestOptions({ headers: this.headers });
    return this.http.post(addUrl, data, options)
      .timeout(10000)
      .toPromise()
      .then(response => response.json() as Object[])
      .catch(this.handleError);
  }

  onCampusEvents(uid,comm): Promise<Object[]> {
    let data = {"users_id": uid, "community": comm, "token": localStorage.getItem('agnesToken')};
    data["timestamp"] = new Date()
    let addUrl = Agnes.API_URL + '/onCampusEvents';
    let options = new RequestOptions({ headers: this.headers });
    return this.http.post(addUrl, data, options)
      .timeout(10000)
      .toPromise()
      .then(response => response.json() as Object[])
      .catch(this.handleError);
  }

  offCampusEvents(uid,comm): Promise<Object[]> {
    let data = {"users_id": uid, "community": comm, "token": localStorage.getItem('agnesToken')};
    data["timestamp"] = new Date()
    let addUrl = Agnes.API_URL + '/offCampusEvents';
    let options = new RequestOptions({ headers: this.headers });
    return this.http.post(addUrl, data, options)
      .timeout(10000)
      .toPromise()
      .then(response => response.json() as Object[])
      .catch(this.handleError);
  }

  loadMoreOnCampusEvents(data): Promise<Object[]>{
    data["token"] = localStorage.getItem('agnesToken');
    data["timestamp"] = new Date()
    let addUrl = Agnes.API_URL + '/load_more_onCampusEvents';
    let options = new RequestOptions({ headers: this.headers });

    return this.http.post(addUrl, data, options)
      .timeout(5000)
      .toPromise()
      .then(response => response.json() as Object[])
      .catch(this.handleError);
  }

  loadMoreOffCampusEvents(data): Promise<Object[]>{
    data["token"] = localStorage.getItem('agnesToken');
    data["timestamp"] = new Date()
    let addUrl = Agnes.API_URL + '/load_more_offCampusEvents';
    let options = new RequestOptions({ headers: this.headers });

    return this.http.post(addUrl, data, options)
      .timeout(5000)
      .toPromise()
      .then(response => response.json() as Object[])
      .catch(this.handleError);
  }

  sendFlag(flaginfo): Promise<Object[]>{
    flaginfo["token"] = localStorage.getItem('agnesToken');
    flaginfo["timestamp"] = new Date()
    let addUrl = Agnes.API_URL + '/swipe_left_users_events';
    let options = new RequestOptions({ headers: this.headers });

    return this.http.post(addUrl, flaginfo, options)
      .timeout(5000)
      .toPromise()
      .then(response => response.json() as Object[])
      .catch(this.handleError);
  }

  attendEvent(flaginfo): Promise<Object[]>{
    flaginfo["token"] = localStorage.getItem('agnesToken');
    flaginfo["timestamp"] = new Date()
    let addUrl = Agnes.API_URL + '/event_attendee';
    let options = new RequestOptions({ headers: this.headers });

    return this.http.post(addUrl, flaginfo, options)
      .timeout(5000)
      .toPromise()
      .then(response => response.json() as Object[])
      .catch(this.handleError);
  }

  unattendEvent(flaginfo): Promise<Object[]>{
    flaginfo["token"] = localStorage.getItem('agnesToken');
    flaginfo["timestamp"] = new Date()
    let addUrl = Agnes.API_URL + '/event_unattend';
    let options = new RequestOptions({ headers: this.headers });

    return this.http.post(addUrl, flaginfo, options)
      .timeout(5000)
      .toPromise()
      .then(response => response.json() as Object[])
      .catch(this.handleError);
  }

  getMoreEvents(data): Promise<Object[]>{
    data["token"] = localStorage.getItem('agnesToken');
    data["timestamp"] = new Date()
    let addUrl = Agnes.API_URL + '/load_more_events';
    let options = new RequestOptions({ headers: this.headers });

    return this.http.post(addUrl, data, options)
      .timeout(5000)
      .toPromise()
      .then(response => response.json() as Object[])
      .catch(this.handleError);
  }

  searchEvents(data): Promise<Object[]>{
    data["token"] = localStorage.getItem('agnesToken');
    data["timestamp"] = new Date()
    let addUrl = Agnes.API_URL + '/searchEvent_v2';
    let options = new RequestOptions({ headers: this.headers });

    return this.http.post(addUrl, data, options)
      .timeout(5000)
      .toPromise()
      .then(response => response.json() as Object[])
      .catch(this.handleError);
  }

  editEvent(data): Promise<Object[]>{
    data["token"] = localStorage.getItem('agnesToken');
    data["timestamp"] = new Date()
    let addUrl = Agnes.API_URL + '/edit_event';
    let options = new RequestOptions({ headers: this.headers });

    return this.http.post(addUrl, data, options)
      .timeout(10000)
      .toPromise()
      .then(response => response.json() as Object[])
      .catch(this.handleError);
  }

  deleteEvent(data): Promise<Object[]>{
    data["token"] = localStorage.getItem('agnesToken');
    data["timestamp"] = new Date()
    let addUrl = Agnes.API_URL + '/deleteEvent';
    let options = new RequestOptions({ headers: this.headers });

    return this.http.post(addUrl, data, options)
      .timeout(5000)
      .toPromise()
      .then(response => response.json() as Object[])
      .catch(this.handleError);
  }

  addEvent(data): Promise<Object[]>{
    data["token"] = localStorage.getItem('agnesToken');
    data["timestamp"] = new Date()
    let addUrl = Agnes.API_URL + '/recur_create_event';
    // let addUrl = Agnes.API_URL + '/create_event';
    let options = new RequestOptions({ headers: this.headers });

    return this.http.post(addUrl, data, options)
      .timeout(10000)
      .toPromise()
      .then(response => response.json() as Object[])
      .catch(this.handleError);
  }

  getEventsFromId(data): Promise<Object[]>{
    data["token"] = localStorage.getItem('agnesToken');
    data["timestamp"] = new Date()
    let addUrl = Agnes.API_URL + '/event_object_2';
    let options = new RequestOptions({ headers: this.headers });

    return this.http.post(addUrl, data, options)
      .timeout(5000)
      .toPromise()
      .then(response => response.json() as Object[])
      .catch(this.handleError);
  }

  eventsByDate(data): Promise<Object[]>{
    data["token"] = localStorage.getItem('agnesToken');
    data["timestamp"] = new Date()
    let addUrl = Agnes.API_URL + '/eventsByDate';
    let options = new RequestOptions({ headers: this.headers });

    return this.http.post(addUrl, data, options)
      .timeout(5000)
      .toPromise()
      .then(response => response.json() as Object[])
      .catch(this.handleError);
  }

  sendIYG(data): Promise<any>{
    data["token"] = localStorage.getItem('agnesToken');
    data["timestamp"] = new Date()
    let addUrl = Agnes.API_URL + '/iGIYG_event_sender';
    let options = new RequestOptions({ headers: this.headers });

    return this.http.post(addUrl, data, options)
      .timeout(5000)
      .toPromise()
      .then(response => response.json() as Object[])
      .catch(this.handleError);
  }

  acceptIYG(data): Promise<any>{
    data["token"] = localStorage.getItem('agnesToken');
    data["timestamp"] = new Date()
    let addUrl = Agnes.API_URL + '/iGIYG_event_accept';
    let options = new RequestOptions({ headers: this.headers });

    return this.http.post(addUrl, data, options)
      .timeout(5000)
      .toPromise()
      .then(response => response.json() as Object[])
      .catch(this.handleError);
  }

  rejectIYG(data): Promise<any>{
    data["token"] = localStorage.getItem('agnesToken');
    data["timestamp"] = new Date()
    let addUrl = Agnes.API_URL + '/iGIYG_event_reject';
    let options = new RequestOptions({ headers: this.headers });

    return this.http.post(addUrl, data, options)
      .timeout(5000)
      .toPromise()
      .then(response => response.json() as Object[])
      .catch(this.handleError);
  }

  removeGroupFromEvent(data): Promise<any>{
    data["token"] = localStorage.getItem('agnesToken');
    data["timestamp"] = new Date()
    let addUrl = Agnes.API_URL + '/remove_group_from_event';
    let options = new RequestOptions({ headers: this.headers });

    return this.http.post(addUrl, data, options)
      .timeout(5000)
      .toPromise()
      .then(response => response.json() as Object[])
      .catch(this.handleError);
  }

  eventInterested(data): Promise<any>{
      data["token"] = localStorage.getItem('agnesToken');
      data["timestamp"] = new Date()
      let addUrl = Agnes.API_URL + '/event_interested';
      let options = new RequestOptions({ headers: this.headers });
      return this.http.post(addUrl, data, options)
        .timeout(5000)
        .toPromise()
        .then(response => response.json() as Object[])
        .catch(this.handleError);
  }

  eventUninterested(data): Promise<any>{
      data["token"] = localStorage.getItem('agnesToken');
      data["timestamp"] = new Date()
      let addUrl = Agnes.API_URL + '/event_uninterested';
      let options = new RequestOptions({ headers: this.headers });
      return this.http.post(addUrl, data, options)
        .timeout(5000)
        .toPromise()
        .then(response => response.json() as Object[])
        .catch(this.handleError);
  }

  shareEvent(data): Promise<any>{
    data["token"] = localStorage.getItem('agnesToken');
    data["timestamp"] = new Date()
    let addUrl = Agnes.API_URL + '/share_event';
    let options = new RequestOptions({ headers: this.headers });

    return this.http.post(addUrl, data, options)
      .timeout(5000)
      .toPromise()
      .then(response => response.json() as Object[])
      .catch(this.handleError);
  }

  private handleError(error: any): Promise<any> {
    console.error('An error occurred', error);
    return Promise.reject(error.message || error);
  }
}

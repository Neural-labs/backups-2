import {Component} from '@angular/core';
import { NavParams, IonicPage, Events, ViewController } from 'ionic-angular';

@IonicPage()
@Component({
    selector: 'friend-list',
    templateUrl: 'friend-list.html',
    providers: []
})

export class FriendList {

    user:Object;
    friends: Array<Object>;
    peopleSearch: string;

    constructor(private viewCtrl: ViewController,
                private navParams: NavParams) {
    }

    //initialize friends page
    ngOnInit() {
        this.user = JSON.parse(localStorage.getItem("agnesUser"));
        this.friends = this.navParams.get('friends');
        this.peopleSearch = '';
    }

    //filter friends by name
    matchesSearch(person){
        let term = this.peopleSearch.trim().toLowerCase();
        let len = term.length;
        if(len > 0){
            let fname = person['fname'].toLowerCase().substring(0,len) == term;
            let lname = person['lname'].toLowerCase().substring(0,len) == term;
            let fullname = (person['fname'] + ' ' + person['lname']).toLowerCase() == term;

            return (fname || lname || fullname);
        }
        else {
            return true;
        }
    }

    //close popup page
    closeFriendList(inviteMore){
        this.viewCtrl.dismiss(null,null,{
            animation: 'ios-transition',
            duration: 350,
            easing: "ease-in-out",
            direction: "back"
        });
    }
}

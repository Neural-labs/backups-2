"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var core_1 = require('@angular/core');
var ionic_angular_1 = require('ionic-angular');
var chat_1 = require('../pages/chat/chat');
var events_1 = require('../pages/events/events');
var groups_1 = require('../pages/groups/groups');
var people_1 = require('../pages/people/people');
var me_1 = require('../pages/me/me');
var settings_1 = require('../pages/settings/settings');
var group_requests_1 = require('../pages/group-requests/group-requests');
var groups_service_1 = require('../pages/groups/groups.service');
var login_service_1 = require('../pages/login/login.service');
var events_service_1 = require('../pages/events/events.service');
var event_profile_1 = require('../pages/events/event-profile/event-profile');
var group_profile_1 = require('../pages/groups/group-profile/group-profile');
var chat_profile_1 = require('../pages/chat/chat-profile/chat-profile');
var Agnes = (function () {
    function Agnes(platform, alertCtrl, events, groupsService, loginService, eventsService, config, deploy, toastCtrl, popoverCtrl, backgroundMode, badge, deeplinks, keyboard, push, splashScreen, statusBar) {
        var _this = this;
        this.platform = platform;
        this.events = events;
        this.groupsService = groupsService;
        this.loginService = loginService;
        this.eventsService = eventsService;
        this.config = config;
        this.deploy = deploy;
        this.toastCtrl = toastCtrl;
        this.popoverCtrl = popoverCtrl;
        this.backgroundMode = backgroundMode;
        this.badge = badge;
        this.deeplinks = deeplinks;
        this.keyboard = keyboard;
        this.push = push;
        this.splashScreen = splashScreen;
        this.statusBar = statusBar;
        this.rootPage = 'LoginPage';
        //get user info to load into Menu
        this.user = JSON.parse(localStorage.getItem("agnesUser"));
        this.deviceToken = null;
        this.floatTo = 'chat';
        this.floatSrc = 'assets/img/icons/chatIcon.png';
        this.activePage = 'Events';
        this.newChats = [];
        this.loading = false;
        Agnes.loading = this.loading;
        Agnes.version = '2.4.5';
        Agnes.alertCtrl = alertCtrl;
        Agnes.API_URL = 'https://meetagnes.com/application';
        Agnes.eventsService = this.eventsService;
        Agnes.plt = this.platform;
        Agnes.evts = this.events;
        Agnes.toastCtrl = this.toastCtrl;
        if (this.user) {
            this.events.publish('updateUser', { 'user': this.user, 'showChat': true });
        }
        else {
            this.user = { 'fname': '', 'lname': '' };
            this.image = '';
        }
        this.groupRequestsNum = 0;
        this.listenForUserUpdate();
        this.events.subscribe('refreshThumb', function () {
            var img = _this.image;
            _this.image = '';
            setTimeout(function () {
                _this.image = img;
            }, 10);
        });
        this.events.subscribe('pagePushed', function () {
            var x = _this.nav.getActive();
            _this.showChatButton = x.isFirst();
        });
        this.events.subscribe('showChat', function (showChat) {
            _this.showChatButton = showChat;
        });
        this.events.subscribe('refreshRequests', function () {
            _this.getGroupRequests();
        });
        this.events.subscribe('logout', function () {
            var devID = localStorage.getItem('agnesDevice');
            localStorage.clear();
            localStorage.setItem('agnesDevice', devID);
            localStorage.removeItem('agnesMatchedEvents');
            _this.events.publish('showChat', false);
            _this.events.publish('resetActive');
            _this.nav.setRoot('LoginPage');
        });
        this.events.subscribe('resetActive', function () {
            _this.activePage = 'Events';
        });
        this.events.subscribe('readChat', function (id) {
            var ind = _this.newChats.indexOf(id);
            if (ind != -1) {
                _this.newChats.splice(ind, 1);
            }
        });
        this.events.subscribe('loggedIn', function () {
            var extEvent = localStorage.getItem('agnesSharedevent');
            if (extEvent) {
                _this.eventsService.getEventsFromId({ 'evt': [extEvent] }).then(function (value) {
                    if (value && value['length'] > 0) {
                        var event_1 = { 'event': value[0] };
                        var current = localStorage.getItem('agnesCurrentEvent');
                        if (!current || (current && (current != event_1['event']['_id']))) {
                            _this.openEventProfile(event_1);
                        }
                    }
                    else {
                        Agnes.showError('Sorry, the event that was shared with you already happened!');
                    }
                }).catch(function (err) {
                    console.log(err);
                    Agnes.showError('Sorry, could\'t retrieve the shared event. Try quitting the app and clicking the link again!');
                });
            }
            var extGroup = localStorage.getItem('agnesSharedgroup');
            if (extGroup) {
                _this.groupsService.getGroupsFromId({ 'grp': [extGroup] }).then(function (value) {
                    if (value && value['length'] > 0) {
                        var group = value[0];
                        var current = localStorage.getItem('agnesCurrentGroup');
                        if (!current || (current && (current != group['_id']))) {
                            _this.openGroupProfile(group);
                        }
                    }
                    else {
                        Agnes.showError('Sorry, the group that was shared with you is not in Agnes\' database!');
                    }
                }).catch(function (err) {
                    console.log(err);
                    Agnes.showError('Sorry, could\'t retrieve the shared group. Try quitting the app and clicking the link again!');
                });
            }
        });
        this.events.subscribe('updateDeviceId', function (uid) {
            var dev = localStorage.getItem('agnesDevice');
            dev = dev ? dev : '';
            var dName = _this.platform.is('android') ? 'android' : (_this.platform.is('ios') ? 'ios' : 'wp');
            var userId = uid.id;
            var deviceData = {
                "deviceId": dev,
                "deviceName": dName,
                "users_id": userId
            };
            _this.loginService.updateDeviceId(deviceData).then(function (value) {
            }).catch(function (err) {
                console.log(err);
            });
        });
        this.events.subscribe('goToPage', function (type) {
            var data = type == 'events' ? { title: 'Events', component: events_1.EventsPage } : { title: 'Groups', component: groups_1.GroupsPage };
            _this.openPage(data);
        });
        this.initializeApp();
        // used for navigation
        this.pages = [
            { title: 'Events', component: events_1.EventsPage },
            { title: 'Groups', component: groups_1.GroupsPage },
            { title: 'People', component: people_1.PeoplePage },
            { title: 'Chat', component: chat_1.ChatList }
        ];
        this.lower = [
            { title: 'Group Requests', component: group_requests_1.GroupRequests },
            { title: 'Settings', component: settings_1.SettingsPage }
        ];
        document.addEventListener('resume', function ($event) {
            _this.events.publish('resumeApp')
            var nts = JSON.parse(localStorage.getItem('agnesNotifications'));
            if (nts) {
                //process most recent notification (i.e. notification that was clicked on in background)
                _this.processNotifications(nts[nts.length - 1]);
            }
            _this.isPaused = false;
            var user = JSON.parse(localStorage.getItem('agnesUser'));
            if (user) {
                _this.loginService.getUser({ "users_id": user['_id'] }).then(function (value) {
                    _this.events.publish('userUpdated', { 'user': value, 'showChat': value['canChat'] });
                }).catch(function (error) {
                    console.log('resume error', error);
                });
            }
            if (_this.activePage == 'Events') {
                _this.events.publish('resumeApp');
            }
        });
        document.addEventListener('pause', function ($event) {
            _this.isPaused = true;
        });
    }
    Agnes.prototype.listenForUserUpdate = function () {
        var _this = this;
        this.events.subscribe('updateUser', function (data) {
            _this.loginService.getUser({ "users_id": data.user['_id'] }).then(function (value) {
                if (value) {
                    _this.user = value;
                    localStorage.setItem('agnesUser', JSON.stringify(_this.user));
                    _this.image = 'url("' + _this.user['thumbnail'] + '")';
                    //check number of new chats
                    if (_this.user['channels']) {
                        _this.newChats = _this.user['channels'].filter(function (a) { return !a['status']; }).map(function (a) { return a['receiverId']; });
                    }
                    //get number of requests
                    _this.getGroupRequests();
                    //get people limit, show/hide elements based on this
                    _this.getPeopleLimit(data.showChat);
                    //update crash analytics
                    if (window['fabric']) {
                        window['fabric'].Crashlytics.setUserIdentifier(_this.user['_id']);
                        window['fabric'].Crashlytics.setUserName(_this.user['fname'] + ' ' + _this.user['lname']);
                        window['fabric'].Crashlytics.setUserEmail(_this.user['email']['uid']);
                    }
                    _this.events.publish('updateDone');
                }
            }).catch(function (err) {
                _this.events.publish('updateUser', data);
            });
        });
    };
    Agnes.prototype.getGroupRequests = function () {
        var _this = this;
        //get number of requests
        this.groupRequestsNum = 0;
        var groups = this.user['grp'].filter(function (a) { return a['admin']; });
        var data = { "grp": groups.map(function (a) { return a['groups_id']; }) };
        this.groupsService.getGroupsFromId(data).then(function (groups) {
            if (groups) {
                for (var g in groups) {
                    _this.groupRequestsNum += groups[g]['pendingreq'].length;
                }
                _this.groupRequestsNum += _this.user['invites'].length;
            }
            else {
                _this.groupRequestsNum = _this.user['invites'].length;
            }
        }).catch(function (err) { _this.groupRequestsNum = _this.user['invites'].length; });
    };
    // processDeepLinks(){
    //   this.deeplinks.routeWithNavController(this.nav, {
    //     'event/': EventsPage,
    //     'group/': GroupsPage,
    //   }).subscribe((match) => {
    //
    //     console.log(match);
    //
    //     //oops, this isn't a deep link, just a website link - redirect to website!
    //     if (match.$link.url.indexOf('event') == -1 && match.$link.url.indexOf('group') == -1) {
    //       if(match.$link.url.indexOf('fb') == -1 && match.$link.url.indexOf('authorize') == -1) {
    //         window.open(match.$link.url, '_system', 'location=yes');
    //       }
    //     }
    //     else {
    //       let type = match.$link.url.indexOf('event') != -1 ? 'event' : 'group';
    //
    //       if(match.$link.url.indexOf('fb') == -1 && match.$link.url.indexOf('authorize') == -1) {
    //         if(!localStorage.getItem('agnesUser')) {
    //           Agnes.showError('Please sign up for or log in to view the shared ' + type + '!');
    //           localStorage.setItem('agnesShared'+type,match.$link.path.replace('/',''));
    //         }
    //         else {
    //           let id = (match.$link.url.indexOf('agnes://') != -1)
    //             ? match.$link.url.replace('agnes://' + type + '/','')
    //             : match.$link.path.replace('/share/' + type + '/','');
    //
    //           if(type == 'event'){
    //             this.eventsService.getEventsFromId({'evt':[id]}).then(value => {
    //               if (value && value['length'] > 0){
    //                 let event = {'event':value[0]};
    //                 let current = localStorage.getItem('agnesCurrentEvent');
    //                 if(!current || (current && (current != event['event']['_id']))){
    //                   this.openEventProfile(event);
    //                 }
    //               }
    //               else {
    //                 Agnes.showError('Sorry, the event that was shared with you already happened!');
    //               }
    //             }).catch(err => {
    //               console.log(err);
    //               Agnes.showError('Sorry, could\'t retrieve the shared event. Try quitting the app and clicking the link again!');
    //             });
    //           }
    //           else {
    //             this.groupsService.getGroupsFromId({'grp':[id]}).then(value => {
    //               if (value && value['length'] > 0){
    //                 let group = value[0];
    //                 let current = localStorage.getItem('agnesCurrentGroup');
    //                 if(!current || (current && (current != group['_id']))){
    //                   this.openGroupProfile(group);
    //                 }
    //               }
    //               else {
    //                 Agnes.showError('Sorry, the group that was shared with you is not in Agnes\' database!');
    //               }
    //             }).catch(err => {
    //               console.log(err);
    //               Agnes.showError('Sorry, could\'t retrieve the shared group. Try quitting the app and clicking the link again!');
    //             });
    //           }
    //         }
    //       }
    //     }
    //   }, (nomatch) => {
    //     // nomatch.$link - the full link data
    //     console.error('Got a deeplink that didn\'t match', nomatch);
    //   });
    // }
    Agnes.prototype.initializeApp = function () {
        var _this = this;
        this.platform.ready().then(function () {
            // Okay, so the platform is ready and our plugins are available.
            // Here you can do any higher level native things you might need.
            _this.statusBar.hide();
            _this.splashScreen.hide();
            _this.keyboard.hideKeyboardAccessoryBar(false);
            _this.config.set('ios', 'statusbarPadding', false);
            _this.backgroundMode.enable();
            // BackgroundMode.onactivate().subscribe(data => {
            //   console.log('background mode activated');
            // });
            //android keyboard push up
            if (_this.platform.is('android')) {
                _this.keyboard.disableScroll(true);
                var y_1;
                var h_1;
                var offsetY_1;
                var tapCoordinates = function (e) {
                    y_1 = e.touches[0].clientY;
                    h_1 = window.innerHeight;
                    offsetY_1 = (h_1 - y_1);
                };
                var keyboardShowHandler = function (e) {
                    var kH = e.keyboardHeight;
                    var bodyMove = document.querySelector("ion-app");
                    console.log(bodyMove);
                    //let bodyMoveStyle = bodyMove.style;
                    // if (offsetY < kH + 40) {
                    //   bodyMoveStyle.bottom = (kH - offsetY + 40) + "px";
                    //   bodyMoveStyle.top = "initial";
                    // }
                };
                var keyboardHideHandler = function () {
                    var removeStyles = document.querySelector("ion-app");
                    console.log(removeStyles);
                    //removeStyles.removeAttribute("style");
                };
                window.addEventListener('native.keyboardshow', keyboardShowHandler);
                window.addEventListener('native.keyboardhide', keyboardHideHandler);
                window.addEventListener('touchstart', tapCoordinates);
            }
            // //watch for internet disconnect
            // let disconnectSubscription = Network.onDisconnect().subscribe(() => {
            //   Agnes.showError('Lost connection!')
            // });
            //Google analytics
            // GoogleAnalytics.debugMode()
            // GoogleAnalytics.startTrackerWithId("UA-83217625-1");
            //
            // GoogleAnalytics.enableUncaughtExceptionReporting(true)
            //   .then(value => {
            //   }).catch(err => {
            //   console.log("analytics error", err);
            // });
            if (_this.platform.is('cordova')) {
                //initialize push notification plugin
                var pushObject = _this.push.init({
                    android: {
                        //icon: TODO get icon
                        senderID: '327356857183',
                        sound: true,
                        vibrate: true
                    },
                    ios: {
                        alert: 'true',
                        badge: true,
                        sound: 'true'
                    },
                    windows: {}
                });
                pushObject.on('registration').subscribe(function (data) {
                    console.log('push register', data);
                    localStorage.setItem('agnesDevice', data['registrationId']);
                });
                pushObject.on('notification').subscribe(function (data) {
                    console.log('notification', data);
                    //background notification - increase badge and store in local storage
                    if (!data['additionalData'].foreground && _this.isPaused) {
                        var nts = JSON.parse(localStorage.getItem('agnesNotifications'));
                        if (nts) {
                            var sameSender = nts.map(function (a) {
                                return a.additionalData.sender['_id'];
                            }).indexOf(data['additionalData'].sender['_id']) != -1;
                            if ((data['additionalData'].category != 'chat' && data['additionalData'].category != 'IYGIG_sent')
                                || ((data['additionalData'].category == 'chat' || data['additionalData'].category == 'IYGIG_sent')
                                    && !sameSender)) {
                                nts.push(data);
                                _this.badge.increase(1);
                            }
                        }
                        else {
                            nts = [data];
                            _this.badge.increase(1);
                        }
                        localStorage.setItem('agnesNotifications', JSON.stringify(nts));
                    }
                    else {
                        _this.processNotifications(data);
                    }
                });
                pushObject.on('error').subscribe(function (e) {
                    console.log(e['message']);
                });
                //register device for push notifications only is user is logged in
                if (_this.user['_id']) {
                    _this.events.publish('updateDeviceId', { 'id': _this.user['_id'] });
                }
            }
            //crash reporting
            if (window['fabric']) {
                window['fabric'].Crashlytics.setUserIdentifier(_this.user['_id']);
                window['fabric'].Crashlytics.setUserName(_this.user['fname'] + ' ' + _this.user['lname']);
                window['fabric'].Crashlytics.setUserEmail(_this.user['email']['uid']);
            }
            //check for updates
            if (_this.platform.is('cordova') && _this.platform.is('mobile')
                && (_this.platform.is('ios') || _this.platform.is('android')) && !_this.platform.is('mobileweb')) {
                _this.deploy.check().then(function (snapshotAvailable) {
                    if (snapshotAvailable) {
                        // let updatePopup = this.popoverCtrl.create(
                        //   UpdatePopup,
                        //   {},
                        //   {});
                        // updatePopup.present({
                        //   animate: true,
                        //   animation: 'ios-transition',
                        //   duration: 350,
                        //   easing: "ease-in-out",
                        //   direction: 'forward'
                        // });
                        _this.deploy.download({}).then(function () {
                            _this.deploy.extract({}).then(function () {
                                var alert = Agnes.alertCtrl.create({
                                    title: 'Update Available',
                                    message: "An update is available and will be applied once Agnes restarts. " +
                                        "Tap 'Restart' to restart now or 'Cancel' to get the update later",
                                    buttons: [
                                        {
                                            text: 'Cancel',
                                            handler: function () {
                                                Agnes.removeFilter();
                                            },
                                            role: 'cancel'
                                        },
                                        {
                                            text: 'Yes',
                                            handler: function () {
                                                _this.deploy.load();
                                            }
                                        }]
                                });
                                for (var e = 0; e < document.getElementsByTagName("ion-popover").length; e++) {
                                    document.getElementsByTagName("ion-popover")[e]["style"]["filter"] = "blur(3vw)";
                                }
                                document.getElementsByTagName("ng-component")[0]["style"]["filter"] = "blur(3vw)";
                                alert.present();
                            });
                        });
                    }
                });
            }
            //handle deeplinking
            //this.processDeepLinks();
        });
    };
    Agnes.prototype.openPage = function (page) {
        // Reset the content nav to have just this page
        // we wouldn't want the back button to show in this scenario
        if (page.title == 'Chat') {
            this.floatTo = 'events';
            this.floatSrc = 'assets/img/icons/eventsIcon.png';
            this.newChats = [];
        }
        else {
            this.floatTo = 'chat';
            this.floatSrc = 'assets/img/icons/chatIcon.png';
        }
        this.activePage = page.title;
        this.nav.setRoot(page.component);
    };
    Agnes.prototype.pushPage = function (page) {
        //for Settings and Group Requests
        //almost acts as popover
        this.showChatButton = false;
        var params = {};
        var opts = {
            animate: true,
            animation: 'ios-transition',
            duration: 350,
            easing: "ease-in-out",
            direction: "forward"
        };
        if (page.title == 'Settings') {
            params = {
                user: this.user,
                fromFB: (this.user['email']['fbid'] != '')
            };
        }
        else {
            //send group requests to Group Requests page
            params = {
                user: this.user,
                toInvites: localStorage.getItem('toInvites')
            };
            localStorage.removeItem('toInvites');
        }
        this.nav.push(page.component, params, opts);
    };
    Agnes.prototype.openMeProfile = function () {
        this.nav.setRoot(me_1.MePage);
        this.menu.close();
        this.activePage = 'Me';
    };
    Agnes.prototype.floatButton = function () {
        //on any page except for Chat, go to chat page
        if (this.floatTo == 'chat') {
            //tracking
            if (window['fabric']) {
                window['fabric'].Answers.sendCustomEvent('Floating Button', { type: 'to chat' });
            }
            this.floatTo = 'events';
            this.floatSrc = 'assets/img/icons/eventsIcon.png';
            this.activePage = 'Chat';
            this.nav.setRoot(chat_1.ChatList);
        }
        else {
            this.floatTo = 'chat';
            this.floatSrc = 'assets/img/icons/chatIcon.png';
            this.activePage = 'Events';
            this.nav.setRoot(events_1.EventsPage);
        }
    };
    Agnes.prototype.getPeopleLimit = function (showChat) {
        var _this = this;
        var data = { "users_id": this.user['_id'] };
        this.loginService.chatAllowCheck(data).then(function (data) {
            if (data['chat'] || _this.user['community'] == 'groupten') {
                _this.pages = [
                    { title: 'Events', component: events_1.EventsPage },
                    { title: 'Groups', component: groups_1.GroupsPage },
                    { title: 'People', component: people_1.PeoplePage },
                    { title: 'Chat', component: chat_1.ChatList }
                ];
                _this.showChatButton = showChat;
                _this.user['canChat'] = true;
            }
            else {
                _this.pages = [
                    { title: 'Events', component: events_1.EventsPage },
                    { title: 'Groups', component: groups_1.GroupsPage }
                ];
                _this.showChatButton = false;
                _this.user['canChat'] = false;
            }
            localStorage.setItem('agnesUser', JSON.stringify(_this.user));
        }).catch(function () {
            _this.pages = [
                { title: 'Events', component: events_1.EventsPage },
                { title: 'Groups', component: groups_1.GroupsPage },
                { title: 'People', component: people_1.PeoplePage },
                { title: 'Chat', component: chat_1.ChatList }
            ];
            _this.showChatButton = showChat;
            _this.user['canChat'] = true;
            localStorage.setItem('agnesUser', JSON.stringify(_this.user));
        });
    };
    Agnes.prototype.processNotifications = function (data) {
        var _this = this;
        var type = data.additionalData['category'];
        var btns = [{
                text: 'OK',
                role: 'cancel',
                handler: function () {
                    //if request or invite, update group req badge number in side bar
                    if (data.additionalData['category'] == 'request' || data.additionalData['category'] == 'invite') {
                        _this.events.publish('updateUser', { 'user': _this.user, 'showChat': _this.user['canChat'] });
                    }
                }
            }];
        //add second button for action if notification is not for accepted invite or accepted admin request
        if (data.additionalData['category'] != 'acceptInvite' && data.additionalData['category'] != 'admin') {
            btns.push({
                text: 'View',
                role: '',
                handler: function () {
                    _this.notificationHandler(data.additionalData['category'], data.additionalData['sender']);
                }
            });
        }
        //
        if (data.additionalData['category'] == 'chat') {
            this.processChatNotification(data);
        }
        else if (data.additionalData['category'] == 'IYGIG_sent' || data.additionalData['category'] == 'IYGIG_accept') {
            this.processIYGIG(data);
        }
        else if ((data.additionalData['category'] == 'request' || data.additionalData['category'] == 'invite')
            && (localStorage.getItem('inRequests') == 'true')) {
            this.events.publish('reqNotification');
        }
        else if ((data.additionalData['category'] == 'acceptInvite')) {
            var toast = this.toastCtrl.create({
                message: data.message,
                position: 'top',
                duration: 7000,
                cssClass: 'chat',
                showCloseButton: false });
            toast.present();
        }
        else {
            var confirmAlert = Agnes.alertCtrl.create({
                title: data.title,
                message: data.message,
                buttons: btns
            });
            confirmAlert.present();
        }
    };
    Agnes.prototype.notificationHandler = function (type, data) {
        var _this = this;
        //refresh user
        this.loginService.getUser({ "users_id": this.user['_id'] })
            .then(function (value) {
            if (value) {
                _this.events.publish('updateUser', { 'user': value, 'showChat': value['canChat'] });
                //group request
                if (type == 'request' || type == 'invite') {
                    _this.events.subscribe('updateDone', function () {
                        if (type == 'invite') {
                            localStorage.setItem('toInvites', 'true');
                        }
                        _this.pushPage({ component: group_requests_1.GroupRequests });
                        _this.events.unsubscribe('updateDone');
                    });
                }
                //event shared
                if (type == 'shareEvent') {
                    _this.openEventProfile(data);
                }
                //group request accepted or claim approved
                if (type == 'accept' || type == 'claim') {
                    localStorage.removeItem('agnesMatchedGroups');
                    localStorage.removeItem('agnesGroupsTimeout');
                    _this.openGroupProfile(data);
                }
            }
        })
            .catch(function (err) {
            console.log(err);
            _this.notificationHandler(type, data);
        });
    };
    Agnes.prototype.processChatNotification = function (data) {
        var _this = this;
        var currentChat = localStorage.getItem('agnesChat');
        //user is currently chatting w/ person who just sent message
        if (currentChat == data.additionalData['sender']['_id']) {
            //data is igiyg - get event info from event id
            if (data.additionalData['event']) {
                this.eventsService.getEventsFromId({ 'evt': data.additionalData['event']['id'] }).then(function (val) {
                    if (val && val['length'] > 0) {
                        data.additionalData['event'] = val[0];
                        _this.events.publish('messageReceived', data.additionalData);
                    }
                }).catch(function (err) {
                });
            }
            else {
                this.events.publish('messageReceived', data.additionalData);
            }
        }
        else {
            if (this.newChats.indexOf(data.additionalData['sender']['_id']) == -1) {
                this.newChats.push(data.additionalData['sender']['_id']);
            }
            //user clicks notification outside of app - go to chat w/ sender
            if (!data.additionalData.foreground) {
                //increase badge count
                //Badge.increase(1);
                //user is chatting w/ someone else - close that chat first
                if (currentChat) {
                    this.events.publish('closeCurrentChat', currentChat);
                }
                this.goToChat(data.additionalData['sender']);
            }
            else {
                //user is on chat list page
                if (this.activePage == 'Chat') {
                    this.events.publish('updateChatList', data);
                }
                else {
                    var chatToast = this.toastCtrl.create({
                        message: '',
                        position: 'top',
                        duration: 4000,
                        cssClass: 'chat',
                        showCloseButton: true,
                        closeButtonText: data.additionalData['sender']['fname'] + ' ' + data.additionalData['sender']['lname'] + '\n' + data.message
                    });
                    chatToast.present();
                    chatToast.onDidDismiss(function (event, role) {
                        if (role == 'close') {
                            if (currentChat) {
                                _this.events.publish('closeCurrentChat', currentChat);
                            }
                            _this.goToChat(data.additionalData['sender']);
                        }
                    });
                }
            }
        }
    };
    Agnes.prototype.processIYGIG = function (data) {
        var _this = this;
        if (data.additionalData['category'] == 'IYGIG_accept') {
            Agnes.alertCtrl.create({
                title: 'I\'m in!',
                message: data.message,
                cssClass: "error",
                enableBackdropDismiss: false,
                buttons: [
                    {
                        text: 'OK',
                        handler: function () {
                            Agnes.removeFilter();
                            var event = data.additionalData['event'];
                            _this.eventsService.getEventsFromId({ 'evt': [event['id']] }).then(function (val) {
                                if (val && val['length'] > 0) {
                                    Agnes.going(val[0], false);
                                }
                                else {
                                    Agnes.showError('Sorry, tried adding ' + event['evtname'] + ' to your calendar but it looks like ' +
                                        'it no longer exists or already happened!');
                                }
                            }).catch(function (err) {
                                console.log(err);
                                Agnes.showError('Sorry, could\'t add this event to your calendar - try searching ' +
                                    'and adding it manually!');
                            });
                        }
                    }
                ]
            }).present();
        }
        else {
            console.log(data);
            this.processChatNotification(data);
        }
    };
    Agnes.prototype.openEventProfile = function (event) {
        if (event.event['_id'] != localStorage.getItem('agnesCurrentEvent')) {
            this.nav.push(event_profile_1.EventProfile, {
                'event': event.event,
                'user': this.user,
                'type': 'all'
            }, {
                animation: 'ios-transition',
                duration: 350
            });
        }
    };
    Agnes.prototype.openGroupProfile = function (group) {
        if (group['_id'] != localStorage.getItem('agnesCurrentGroup')) {
            this.nav.push(group_profile_1.GroupProfile, {
                'group': group,
                'user': this.user,
                'platform': this.platform
            }, {
                animation: 'ios-transition',
                duration: 350
            });
        }
    };
    Agnes.prototype.goToChat = function (user) {
        var chatProfilePage = this.popoverCtrl.create(chat_profile_1.ChatProfile, {
            channel: {
                '_id': user['_id'],
                'fname': user['fname'],
                'lname': user['lname'],
                'picurl': user['picurl']
            }
        }, {
            'enableBackdropDismiss': false,
            'showBackdrop': false
        });
        chatProfilePage.present({
            animate: true,
            animation: 'ios-transition',
            duration: 350,
            easing: "ease-in-out",
            direction: "forward"
        });
    };
    /**************************************************************************************************************/
    /**************************************************************************************************************/
    /*************************************************STATIC METHODS***********************************************/
    /**************************************************************************************************************/
    /**************************************************************************************************************/
    Agnes.processGMT = function (date) {
        var x = new Date(date);
        var d = new Date(x.toLocaleDateString()).toDateString().match(/[a-zA-Z]{3} [a-zA-Z]{3} \d\d/)[0];
        d = d.replace(/([a-zA-Z]{3})(\s[a-zA-Z]{3}\s)(\d{2})/, "$1,$2$3");
        d = d.replace(',', '.');
        var t = x.toLocaleTimeString().replace(/:\d\d\s/, '').replace(/\s[a-zA-Z]{3}/, '');
        return { 'date': d, 'time': t };
    };
    Agnes.showError = function (message) {
        var _this = this;
        var alert = this.alertCtrl.create({
            title: "Error",
            message: message,
            cssClass: "error",
            enableBackdropDismiss: false,
            buttons: [
                {
                    text: 'OK',
                    handler: function () {
                        _this.removeFilter();
                    }
                }
            ]
        });
        for (var e = 0; e < document.getElementsByTagName("ion-popover").length; e++) {
            document.getElementsByTagName("ion-popover")[e]["style"]["filter"] = "blur(3vw)";
        }
        document.getElementsByTagName("ng-component")[0]["style"]["filter"] = "blur(3vw)";
        alert.present();
    };
    Agnes.removeFilter = function () {
        for (var e = 0; e < document.getElementsByTagName("ion-popover").length; e++) {
            document.getElementsByTagName("ion-popover")[e]["style"]["filter"] = "none";
        }
        document.getElementsByTagName("ng-component")[0]["style"]["filter"] = "none";
    };
    /**************************** ATTEND EVENT FUNCTIONS ****************************************/
    Agnes.going = function (event, matched) {
        var _this = this;
        var user = JSON.parse(localStorage.getItem('agnesUser'));
        var flaginfo = {
            "users_id": user['_id'],
            "events_id": event['_id'],
            "flag": 1,
            "matched": matched
        };
        this.loading = true;
        this.eventsService.sendFlag(flaginfo)
            .then(function (value) { return _this.setAttendance(event, value, flaginfo, matched); })
            .catch(function (error) {
            _this.loading = false;
            _this.showError("Sorry, could not add " + event['evtname'] + " to your attended events list right now - try again later!");
        });
    };
    Agnes.setAttendance = function (event, value, flaginfo, matched) {
        var _this = this;
        if (value == 0) {
            this.eventsService.attendEvent(flaginfo)
                .then(function (attendResult) { return _this.goingResponse(attendResult, event, matched); })
                .catch(function (error) { console.log(error); });
        }
        else {
            this.loading = false;
            var template = "Sorry, could not add " + event['evtname'] + " to your attended events list right now - try again later!";
            this.showError(template);
        }
    };
    Agnes.goingResponse = function (attendResult, event, matched) {
        var _this = this;
        var user = JSON.parse(localStorage.getItem('agnesUser'));
        this.evts.publish('updateUser', { 'user': user, 'showChat': user['canChat'] });
        if (attendResult.indexOf('SUCCESS') != -1) {
            user['evtrsvp'].push(event['_id']);
            localStorage.removeItem('agnesMatchedEvents');
            localStorage.removeItem('agnesEventsTimeout');
            if (this.plt.is('cordova')) {
                this.addToCalendar(event, matched);
            }
            else {
                this.loading = false;
                var toast = this.toastCtrl.create({
                    message: event['evtname'] + ' was successfully added to your events',
                    position: 'bottom',
                    showCloseButton: true,
                    closeButtonText: 'Undo',
                    duration: 5000
                });
                toast.present();
                toast.onDidDismiss(function (e, role) {
                    if (role == 'close') {
                        _this.notGoing(event, matched);
                    }
                });
                this.evts.publish('goingDone', event);
            }
        }
        else {
            this.loading = false;
            var message = "Sorry, could not add " + event['evtname'] + " to your attended events list right now - please try again!";
            this.showError(message);
        }
    };
    Agnes.addToCalendar = function (event, matched) {
        var _this = this;
        var t = event['evtname'];
        var title = t.replace(/\s+/g, ' ');
        var eventloc = event['location'];
        var eventLocation = eventloc.replace(/\s+/g, ' ');
        var n = event['evtdesc'];
        var notes = n.replace(/\s+/g, ' ').substring(0, 2000);
        var startDate = new Date(event['starttime'].replace(/[-\+]\d\d\d\d/, 'Z'));
        var endDate = new Date(event['endtime'].replace(/[-\+]\d\d\d\d/, 'Z'));
        this.calendar.findEvent(title, '', '', startDate, endDate).then(function (message) {
            if (message['length'] == 0) {
                //event is not in calendar - add
                _this.calendar.createEvent(title, eventLocation, notes, startDate, endDate).then(function (msg) {
                    _this.loading = false;
                    _this.evts.publish('goingDone', event);
                    var toast = _this.toastCtrl.create({
                        message: event['evtname'] + ' was successfully added to your calendar',
                        position: 'bottom',
                        showCloseButton: true,
                        closeButtonText: 'Undo',
                        duration: 4000
                    });
                    toast.present();
                    toast.onDidDismiss(function (e, role) {
                        if (role == 'close') {
                            _this.notGoing(event, matched);
                        }
                    });
                }).catch(function (err) {
                    _this.loading = false;
                    Agnes.showError("This event was successfully added to your list of events but there was a problem adding " +
                        "it to your calendar - please try again!");
                });
            }
            else {
                //event is already in calendar - just show event add success message
                _this.loading = false;
                var toast = _this.toastCtrl.create({
                    message: event['evtname'] + ' was successfully added to your events',
                    position: 'bottom',
                    showCloseButton: true,
                    closeButtonText: 'Undo',
                    duration: 5000
                });
                toast.present();
                //make sure user is updated
                var user = JSON.parse(localStorage.getItem('agnesUser'));
                if (user['evtrsvp'].indexOf(event['_id']) == -1) {
                    user['evtrsvp'].push(event['_id']);
                    localStorage.setItem('agnesUser', JSON.stringify(user));
                }
                _this.evts.publish('goingDone', event);
            }
        }).catch(function (ferr) {
            Agnes.showError("This event was successfully added to your list of events but " +
                "there was a problem adding it to your calendar - make sure Agnes has calendar access and try again!");
            _this.loading = false;
        });
    };
    /**************************** UNATTEND/REMOVE EVENT FUNCTIONS ****************************************/
    Agnes.notGoing = function (event, matched) {
        var _this = this;
        var user = JSON.parse(localStorage.getItem('agnesUser'));
        var eventFlag = (user["evtrsvp"].indexOf(event['_id']) != -1) ? 0 : -1;
        //send flag that user is not attending
        //flag is -1 if user has not indicated he/she wants to attend (delete event from events list)
        //flag is 0 if user did want to attend but has changed his/her mind (leave event in events list, remove 'going' indicator)
        var flagInfo = {
            "users_id": user["_id"],
            "events_id": event['_id'],
            "flag": eventFlag,
            "matched": matched
        };
        this.eventsService.sendFlag(flagInfo)
            .then(function (value) {
            //user was previously going to attend event, so set unattendance
            if (flagInfo.flag == 0) {
                _this.setUnattend(value, flagInfo, event, matched);
            }
            else {
                _this.nopeResponse('SUCCESS', flagInfo.flag, event, matched);
            }
        })
            .catch(function (error) {
            console.log(error);
            Agnes.showError("Sorry, could not remove " + event['evtname'] + " from your attended events list right now " +
                "- try again later!");
        });
    };
    Agnes.setUnattend = function (value, flagInfo, event, matched) {
        var _this = this;
        if (value == 0) {
            this.eventsService.unattendEvent(flagInfo)
                .then(function (attendResult) { return _this.nopeResponse(attendResult, flagInfo['flag'], event, matched); })
                .catch(function (error) {
                console.log(error);
            });
        }
        else {
            var template = "There was a problem removing this event, so you may still see it on your events list in the " +
                "future. Try removing it later if you do!";
            Agnes.showError(template);
        }
    };
    Agnes.nopeResponse = function (attendResult, eventFlag, event, matched) {
        var _this = this;
        var user = JSON.parse(localStorage.getItem('agnesUser'));
        if (attendResult.indexOf('SUCCESS') != -1) {
            var ind = user['evtrsvp'].indexOf(event["_id"]);
            //remove event from user's evtrsvp if user was previously going to attend event
            if (ind != -1) {
                user['evtrsvp'].splice(ind, 1);
                localStorage.setItem('agnesUser', JSON.stringify(user));
                this.evts.publish('updateUser', { 'user': user, 'showChat': user['canChat'] });
            }
            else {
                //remove event from user's displayed matched events
                this.evts.publish('eventDeleted', { 'event': event, 'flag': eventFlag });
            }
            if (this.plt.is('cordova') && eventFlag == 0) {
                this.removeFromCalendar(event, eventFlag, matched);
            }
            else {
                this.evts.publish('notGoingDone', event);
                var toast = this.toastCtrl.create({
                    message: event['evtname'] + ' was successfully removed from your events',
                    position: 'bottom',
                    showCloseButton: true,
                    closeButtonText: 'Undo',
                    cssClass: 'delete',
                    duration: 4000
                });
                toast.present();
                toast.onDidDismiss(function (e, role) {
                    //user has clicked Undo
                    if (role == 'close') {
                        _this.undoNope(event, eventFlag, matched);
                    }
                });
            }
        }
        else {
            var template = "There was a problem removing this event, so you may still see it on your events list in the " +
                "future. Try removing it later if you do!";
            Agnes.showError(template);
        }
    };
    Agnes.removeFromCalendar = function (event, eventFlag, matched) {
        var _this = this;
        var title = event.evtname.replace(/\s+/g, ' ');
        var startDate = new Date(event['starttime'].replace(/[-\+]\d\d\d\d/, 'Z'));
        var endDate = new Date(event['endtime'].replace(/[-\+]\d\d\d\d/, 'Z'));
        endDate.setDate(endDate.getDate() + 1);
        this.calendar.deleteEvent(title, '', '', startDate, endDate).then(function (message) {
            var popupMessage = event.evtname + " was removed from your " + (message ? "calendar" : "event list") + "!";
            _this.evts.publish('notGoingDone', event);
            var toast = _this.toastCtrl.create({
                message: popupMessage,
                position: 'bottom',
                showCloseButton: true,
                closeButtonText: 'Undo',
                duration: 4000,
                cssClass: 'delete'
            });
            toast.present();
            toast.onDidDismiss(function (e, role) {
                if (role == 'close') {
                    _this.undoNope(event, eventFlag, matched);
                }
            });
        }).catch(function (err) {
            Agnes.showError(event['evtname'] + " was removed from your event list but there was a problem deleting it from your calendar.");
        });
    };
    Agnes.undoNope = function (event, eventFlag, matched) {
        var _this = this;
        var user = JSON.parse(localStorage.getItem('agnesUser'));
        //user was undecided about event, reset event flag to 0
        if (eventFlag == -1) {
            var flaginfo = {
                "users_id": user['_id'],
                "events_id": event['_id'],
                "flag": 0,
                "matched": true
            };
            this.eventsService.sendFlag(flaginfo)
                .then(function (value) {
                _this.evts.publish('pushEvent', event);
            })
                .catch(function (error) {
                console.log(error);
                Agnes.showError("Sorry, could not add " + event['evtname'] + " back into your events list right now - please try again!");
            });
        }
        else {
            this.going(event, matched);
        }
    };
    __decorate([
        core_1.ViewChild(ionic_angular_1.Nav)
    ], Agnes.prototype, "nav", void 0);
    __decorate([
        core_1.ViewChild(ionic_angular_1.Menu)
    ], Agnes.prototype, "menu", void 0);
    Agnes = __decorate([
        core_1.Component({
            templateUrl: 'app.html',
            providers: [groups_service_1.GroupsService, login_service_1.LoginService, events_service_1.EventsService]
        })
    ], Agnes);
    return Agnes;
}());
exports.Agnes = Agnes;

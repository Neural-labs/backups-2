import { Component } from '@angular/core';
import { Events, IonicPage } from 'ionic-angular';
import { ChatService } from '../../providers/chat.service';

@IonicPage()
@Component({
  selector: 'page-chat',
  providers: [ChatService],
  templateUrl: 'chat.html',
})


export class ChatList {

  myChatsPage = 'MyChatsPage';
  newChatPage = 'NewChatPage';

  constructor(private events: Events) {
  }

}

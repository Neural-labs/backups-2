import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';

import { MyChatsPage } from './my-chats';

@NgModule({
    declarations: [
        MyChatsPage
    ],
    imports: [
        IonicPageModule.forChild(MyChatsPage)
    ],
    exports: [
        MyChatsPage
    ],
})

export class MyChatsPageModule { }

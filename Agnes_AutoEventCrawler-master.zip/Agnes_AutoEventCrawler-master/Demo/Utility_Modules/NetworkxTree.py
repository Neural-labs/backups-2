import networkx as nx
import random
import DataFilter
import bs4
from node2vec import Node2Vec

class NetX_Tree:

    def __init__(self, HTML=None):
        self.Graph = nx.DiGraph()
        if HTML:
            self.html_to_tree(HTML)

    def __str__(self):
        print 'Graph:'
        print 'Nodes:',len(self.Graph.nodes())
        # print self.Graph.nodes()
        print 'Edges:',len(self.Graph.edges())
        # print self.Graph.edges()
        return ''

    def html_to_tree(self, HTML):
        assert HTML is not None

        soup = DataFilter.removeBadThings(HTML)

        for tag_obj in BFS_TagObjGenerator(soup):
            tag = tag_obj['tag']
            nodeID = tag_obj['tagID']
            parentID = tag_obj['parentID']
            nodeData = getTagData(tag)
            self.add_node(nodeID, parentID, nodeData)

        self.clean_tree()

        return self

    def clean_tree(self):
        removed_count = 0
        for node_id, node_data in self.get_nodes():
            parent_ids = self.get_parent_ids(node_id)

            child_ids = self.get_children_ids(node_id)

            # only consider nodes with 1 child and a parent
            if parent_ids and len(child_ids) is 1:

                assert len(parent_ids) is 1, 'Something is terribly wrong'

                parent_id = parent_ids[0]
                child_id = child_ids[0]

                child_data = self.get_node_data(child_id)
                child_content = child_data['attr_dict']['totalcontent']
                node_content = node_data['attr_dict']['totalcontent']

                if child_content == node_content or child_content.strip() == node_content.strip():

                    # child_tag = child_data['attr_dict']['tag']
                    # node_tag = node_data['attr_dict']['tag']
                    # child_tag = combineTags(node_tag, child_tag)

                    # remove current node
                    self.Graph.remove_node(node_id)
                    # add edge between parent and child
                    self.Graph.add_edge(u=parent_id, v=child_id)

                    removed_count += 1

    def is_leaf(self, node_id):
        return len(list(self.Graph.successors(node_id))) == 0

    def add_node(self, nodeID, parentID, nodeData):
        self.Graph.add_node(nodeID, attr_dict=nodeData)
        if not parentID is None:
            assert parentID is not None
            self.Graph.add_edge(u=parentID, v=nodeID)

    def get_nodes(self):
        return [(n,d) for n,d in self.Graph.nodes(data=True)]

    def get_node_data(self, node_id):
        return self.Graph.nodes(data=True)[node_id]

    def get_edges(self):
        return self.Graph.edges()

    def get_graph(self):
        return self.Graph

    def get_root(self):
        return list(self.Graph.nodes())[0]

    def depth(self, node):
        return len(nx.shortest_path(self.Graph, source=self.get_root(), target=node))

    def node_path(self, node1, node2):
        return nx.shortest_path(self.Graph, source=node1, target=node2)

    def get_children_ids(self, node_id):
        return list(self.Graph.successors(node_id))

    def get_parent_ids(self, node_id):
        return list(self.Graph.predecessors(node_id))

    def iterate_from_node(self, node_id):
        stack = [node_id]
        while len(stack) > 0:
            current_node_id = stack.pop(0)
            yield current_node_id

            for child_id in self.get_children_ids(current_node_id):
                stack.append(child_id)

    def max_depth_from_list(self, node_list):
        maxdepth = 0
        maxdepth_node = None
        for node_id in node_list:
            depth = self.depth(node_id)
            if depth > maxdepth:
                maxdepth = depth
                maxdepth_node = node_id
        return maxdepth_node

    def write_as_edgelist(self):
        nx.write_edgelist(self.Graph, "single_page_test.edgelist")

    def get_n2v_embedding(self):
        n2v = Node2Vec(self.Graph, dimensions=64, walk_length=30, num_walks=200)

        print n2v.__dict__.keys()

        # model = n2v.fit(window=10, min_count=1, batch_words=4)

        # print model.wv.most_similar('2')

        print 'done?'
        # model = n2v.fit(window=10, min_count=1, batch_words=4)


# Iterate BFS through BeautifulSoup Tags
def BFS_TagObjGenerator(soup):
    counter = 0
    root_tag = getRootFromSoup(soup)
    root = {
        'tag': root_tag,
        'tagID': counter,
        'parentID': None,
    }
    stack = [root]
    while len(stack) > 0:
        tag_obj = stack.pop(0)
        tag = tag_obj['tag']

        if validTag(tag_obj):
            yield tag_obj

        if hasattr(tag, 'children'):
            for child in tag.children:
                if validTag(child):
                    counter += 1
                    stack.append({
                        'tag': child,
                        'tagID': counter,
                        'parentID' : tag_obj['tagID']
                    })

# some pages have multiple trees
# returns largest tree
def getRootFromSoup(soup):
    maxChildren = 0
    maxChild = None
    for tag in soup.children:
        if hasattr(tag,'children'):
            temp = len(list(tag.children))
            if temp > maxChildren:
                maxChildren = temp
                maxChild = tag
    return maxChild

def combineTags(node_tag, child_tag):

    for attr in node_tag.attrs:

        value = node_tag[attr]

        if attr in child_tag.attrs:
            if type(node_tag[attr]) is list:
                child_tag[attr] += value
        else:
            child_tag[attr] = value

    return child_tag

def generateID():
    return int(abs(random.getrandbits(24)))

def validTag(tagObj):

    if type(tagObj) == dict:
        tag = tagObj['tag']
    else:
        tag = tagObj

    return type(tag) == bs4.element.Tag

def hasContent(content):
    content = ' '.join(content.split())
    content = content.strip()
    content = content.replace('\n','')
    content = content.replace('\t','')
    return content != ''

def isImg(tag):
    if 'name' in tag and tag.name == 'img':
        return True
    return False

def getTagData(tag):
    return {
        'tag-str': clean(str(tag)),
        'tag': tag,
        'content': getTagContent(tag),
        'totalcontent': getTagTotalContent(tag)
    }

def clean(content):
    content = content.strip()
    content = content.replace('\t','')
    content = content.replace('\n','')
    content = ' '.join(content.split())
    return content

def getTagContent(tag):
    content = tag.find(text=True, recursive=False)
    if content:
        return clean(content)
    else:
        return ''

def getTagTotalContent(root_tag):
    content = ''
    if hasattr(root_tag, 'text'):
        content = root_tag.text

    return clean(content)





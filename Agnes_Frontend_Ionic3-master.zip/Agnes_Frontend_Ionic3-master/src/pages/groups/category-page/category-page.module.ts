import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { ComponentsModule } from '../../../components/components.module';
import { CategoryPage } from './category-page';

@NgModule({
    declarations: [
        CategoryPage
    ],
    imports: [
        IonicPageModule.forChild(CategoryPage),
        ComponentsModule
    ],
    exports: [
        CategoryPage
    ],
})

export class CategoryPageModule { }

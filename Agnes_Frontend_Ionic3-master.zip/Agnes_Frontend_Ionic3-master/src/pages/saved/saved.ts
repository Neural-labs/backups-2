import { Component, ViewChild } from '@angular/core';
import { Content, Events, Select, IonicPage, App, PopoverController, Slides } from 'ionic-angular';
import { AnalyticsService } from "../../providers/analytics.service";
import { GroupsService } from '../../providers/groups.service';
import { EventsService } from '../../providers/events.service';
import { MeService } from '../../providers/me.service';
import { Agnes } from '../../app/app.component';

@IonicPage()
@Component({
    selector: 'saved-page',
    templateUrl: 'saved.html',
    providers: [ GroupsService, AnalyticsService, MeService, EventsService ]
})

export class SavedPage {

    @ViewChild('categorySelector') categorySelector: Select;

    user: Object;
    loading: boolean;
    noInternet: boolean;
    noContent: boolean;
    refreshEnabled: boolean;

    adminGroups: Array<Object>;
    memberGroups: Array<Object>;
    followGroups: Array<Object>;
    savedEvents: Array<Object>;

    gotEvents: boolean;
    gotGroups: boolean;

    groupsError: boolean;
    eventsError: boolean;

    selectedDate: string;

    timeout: Date;

    @ViewChild('eventSlides') slides: Slides;

    constructor(private groupsService: GroupsService,
                public appCtrl: App,
                private eventsService: EventsService,
                private events: Events,
                private popoverCtrl: PopoverController,
                private meService: MeService,
                private analyticsService: AnalyticsService){
    }

    //initialize saved page
    ngOnInit(){

        this.adminGroups = [];
        this.memberGroups = [];
        this.followGroups = [];
        this.savedEvents = [];

        this.gotEvents = false;
        this.gotGroups = false;

        this.groupsError = false;
        this.eventsError = false;

        this.loading = true;
        this.refreshEnabled = true;

        //getMyGroups has been completed
        this.events.subscribe('gotSavedGroups', data => {
            this.gotGroups = true;
            this.groupsError = !data.success;

            if(this.gotEvents){
                if(data.refresher) {data.refresher.complete();}
                this.loading = false;

                if(this.groupsError){
                    if(this.eventsError){
                        this.noContent = true;
                    }
                    else {
                        Agnes.showError("Sorry, could not get your saved groups right now, try refreshing!");
                        this.noContent = false;
                    }
                }
            }
        });

        //getMyGroups has been completed
        this.events.subscribe('gotSavedEvents', data => {
            this.gotEvents = true;
            this.eventsError = !data.success;

            if(this.gotGroups){
                if(data.refresher) {data.refresher.complete();}
                this.loading = false;

                if(this.eventsError){
                    if(this.groupsError){
                        this.noContent = true;
                    }
                    else {
                        Agnes.showError("Sorry, could not get your saved events right now, try refreshing!");
                        this.noContent = false;
                    }
                }
            }
        });

        //user has deleted a group
        this.events.subscribe('groupDeleted', (group) => {
            this.getMyGroups(null);
        });

        //user has edited one of their groups
        this.events.subscribe('groupEdited', group => {
            this.getMyGroups(null);
        });

        //user has joined a (public) group
        this.events.subscribe('addedGroup', (data) => {
            this.getMyGroups(null);
        });

        //remove followed group from matched events list
        this.events.subscribe('followGroup', (group) => {
            this.user = JSON.parse(localStorage.getItem('agnesUser'));
            this.getMyGroups(null);
        });

        //update groups list when user has left or unfollowed group
        this.events.subscribe('leftGroup', (group) => {
            this.user = JSON.parse(localStorage.getItem('agnesUser'));
            this.getMyGroups(null);
        });

        //user shared an event to one of his/her groups, refresh group list
        this.events.subscribe('sharedEventToGroup', () => {
            this.getMyGroups(null);
        });

        //user's request to join a group has been accepted - refresh whatever list user is viewing
        this.events.subscribe('reqAcceptedNewMember', () => {
            this.getMyGroups(null);
        });

        //refresh group list when group has been deleted
        this.events.subscribe('groupDeleted',(data) => {
            this.getMyGroups(null);
        });

        //user's request to join a group has been accepted, refresh My Grousp to reflect that user is now part of new group
        this.events.subscribe('reqAcceptedNewMember', () => {
            this.getMyGroups(null);
        });

        //user has created an event hosted by one of user's groups
        this.events.subscribe('eventHosted', data => {
            this.getMyGroups(null);
        });

        //user has shared an event to one of user's groups
        this.events.subscribe('eventSharedToGroup', data => {
            this.getMyGroups(null);
        });

        //user accepted join requests in notifications - update group membership
        this.events.subscribe('groupReqsResponse', data => {
            this.getMyGroups(null);
        });

        //user has been promoted to admin within group
        this.events.subscribe('adminPromotion', () => {
            this.getMyGroups(null);
        });

        this.events.subscribe('likedEvent', (event) => {
            this.user = JSON.parse(localStorage.getItem('agnesUser'));
            this.getMyEvents(null, true);
        });

        this.events.subscribe('unlikedEvent', (event) => {
            this.user = JSON.parse(localStorage.getItem('agnesUser'));
            this.getMyEvents(null, true);
        });

        this.timeout = new Date();
        this.initSaved();
    }

    ionViewWillEnter() {
        if(this.timeout){
            let now = new Date();

            //update if user last looked at this 10+ minutes ago
            if(now.getTime() > this.timeout.getTime() + 60000){
                this.timeout = new Date();
                this.initSaved();
            }
        }
    }

    initSaved(){
        this.user = JSON.parse(localStorage.getItem('agnesUser'));

        if(!Agnes.network || Agnes.network.type != 'none'){
            this.noInternet = false;

            this.getMyGroups(null);
            this.getMyEvents(null);
        }
        else {
            //lack of internet connection - show Tap to Refresh div
            this.noInternet = true;
            this.loading = false;
        }
    }

    //disable/enable pull-to-refresh depending on whether you are currently touching the sideways scroll div
    enableRefresh(enable){
        this.refreshEnabled = enable;
    }

    //get list of groups that user is a part of/has saved
    getMyGroups(refresher?){
        this.user = JSON.parse(localStorage.getItem('agnesUser'));

        let grps = this.user['grp'].map(function (a) {
            return a['groups_id'];
        }).concat(this.user['following'].map(a => {return a['groups_id']}));


        this.groupsService.getGroupsFromId({'grp':grps}).then(groups => {
            let myGroups = this.user['grp'].map(a => {return a['groups_id']});

            this.adminGroups = groups.filter(a => {
                let ind = myGroups.indexOf(a['_id']);
                return (ind != -1 ? this.user['grp'][ind]['admin'] : false);
            }).map( a => {
                a['displayURL'] = (a['thumbnail'] == '' || !a['thumbnail'] || !this.isImage(a.thumbnail)
                || a['thumbnail'].indexOf("'") != -1 ? "assets/img/pattern_" + Math.floor((Math.random() * 15) + 1) + '.png' : a['thumbnail']);
                return a;
            });

            this.memberGroups = groups.filter(a => {
                let ind = myGroups.indexOf(a['_id']);
                return (ind != -1 ? !this.user['grp'][ind]['admin'] : false);
            }).map( a => {
                a['displayURL'] = (a['thumbnail'] == '' || !a['thumbnail'] || !this.isImage(a.thumbnail)
                || a['thumbnail'].indexOf("'") != -1 ? "assets/img/pattern_" + Math.floor((Math.random() * 15) + 1) + '.png' : a['thumbnail']);
                return a;
            });

            let following = this.user['following'].map(a => {return a['groups_id']});

            this.followGroups = groups.filter(a => {
                return following.indexOf(a['_id']) != -1;
            }).map( a => {
                a['displayURL'] = (a['thumbnail'] == '' || !a['thumbnail'] || !this.isImage(a.thumbnail)
                || a['thumbnail'].indexOf("'") != -1 ? "assets/img/pattern_" + Math.floor((Math.random() * 15) + 1) + '.png' : a['thumbnail']);
                return a;
            });

            this.events.publish('gotSavedGroups', {refresher: refresher, success: true});

        }).catch(err => {
            console.log(err);
            this.events.publish('gotSavedGroups', {refresher: refresher, success: false});
        });
    }

    //get list of events that user is going to and is interested in/has saved
    getMyEvents(refresher?, keepDate?){
        this.savedEvents = [];

        let goingProm = this.eventsService.getEventsFromId({"evt": this.user['evtrsvp'], 'community': this.user['community']});
        let intProm = this.eventsService.getEventsFromId({"evt": this.user['evtinterest'], 'community': this.user['community']});

        Promise.all([goingProm, intProm]).then(val => {
            let going = val[0];
            let interested = val[1];

            this.processMyEvents(going.concat(interested), keepDate);

            this.events.publish('gotSavedEvents', {refresher: refresher, success: true});

        }).catch(err => {
            console.log(err);
            this.events.publish('gotSavedEvents', {refresher: refresher, success: false});
        });
    }

    //refresh saved events and groups
    refreshSaved(refresher){
        this.gotEvents = false;
        this.gotGroups = false;
        this.eventsError = false;
        this.groupsError = false;
        this.noContent = false;

        this.getMyGroups(refresher);
        this.getMyEvents(refresher);
    }

    /*************************************************************************************************************/
    /***************************************** secondary functions ***********************************************/
    /*************************************************************************************************************/

    //check to see if image will load
    isImage(src) {
        let image = new Image();
        let isImage = true;
        image.src = src;
        image.onerror = function() {
            isImage = false;
        };
        image.onload = function() {
            isImage = true;
        };

        return isImage;
    }

    //go to default image if image will not load
    imgError(group){
        group['noPic'] = true;
    }

    //sort user events into date slides
    processMyEvents(events, keepDate?){
        if(events.length > 0){
            let today = new Date();

            events = events.filter(a => {
                return new Date(a['endtime']) >= today;
            }).sort(function(a,b){
                let aDate = +new Date(a['starttime']);
                let bDate = +new Date(b['starttime']);
                return aDate - bDate;
            }).map(a => {
                a["starttime"] = a["starttime"].replace(/[-\+]\d\d\d\d/,'Z');
                let start = Agnes.processGMT(a['starttime']);
                let time = (start.time == "12:01AM") ? "All Day" : start.time;

                let end = Agnes.processGMT(a['endtime']);
                let endtime = ' - ' + ((end.date == start.date) ? '' : end.date.substring(5,start.date.length) + ' ') +
                    end.time;

                a['dispTime'] = time + endtime;
                a['dispDate'] = start.date.substring(5,start.date.length);

                return a;
            });

            for(let e in events){
                this.addToDate(events[e]);
            }

            if(!keepDate){this.selectedDate = this.savedEvents[0]['date'];}
        }
    }

    addToDate(event){
        let dates = this.savedEvents.map(x => x['date']);
        let ind = dates.indexOf(event['dispDate']);

        //add date to saved events if it does not already exist
        if(ind == -1){
            this.savedEvents.push({
                date: event['dispDate'],
                events: [event]
            });
        }
        else {
            this.savedEvents[ind]['events'].push(event);
        }
    }

    //change slides by selecting from the scrolling date list
    selectDate(date){
        this.selectedDate = date;
        let ind = this.savedEvents.map(x => x['date']).indexOf(date);
        if(ind != -1){
            this.slides.slideTo(ind);

            //make sure date box is scrolled into view
            let el = document.querySelector('#' + this.selectedDate .replace(' ', '') + '.dateItem');
            if (!this.isElementInViewport(el)){
                let scrolling = el.parentElement.parentElement;
                let rect = el.getBoundingClientRect();
                let width = window.innerWidth;
                scrolling.scrollLeft = scrolling.scrollLeft + (rect.right - width) + (width/100*4)
            }
        }
    }

    //change active date in date list when slides have been swiped
    eventsSwiped(){
        let ind = this.slides.getActiveIndex();
        if(ind != -1 && this.savedEvents[ind] && this.selectedDate != this.savedEvents[ind]['date']) {

            this.selectedDate = this.savedEvents[ind]['date'];

            //make sure date box is scrolled into view
            let el = document.querySelector('#' + this.selectedDate .replace(' ', '') + '.dateItem');
            if (!this.isElementInViewport(el)){
                let scrolling = el.parentElement.parentElement;
                let rect = el.getBoundingClientRect();
                let width = window.innerWidth;
                scrolling.scrollLeft = scrolling.scrollLeft + (rect.right - width) + (width/100*4)
            }
        }
    }

    //check if date box is in view
    isElementInViewport (el) {
        let rect = el.getBoundingClientRect();
        return (
            rect.top >= 0 &&
            rect.left >= 0 &&
            rect.bottom <= (window.innerHeight || document.documentElement.clientHeight) && /*or $(window).height() */
            rect.right <= (window.innerWidth || document.documentElement.clientWidth) /*or $(window).width() */
        );
    }

    openGroupProfile(group){
        this.groupsService.getGroupsFromId({'grp':[group['_id']]}).then(val =>{
            this.loading = false;
            if(val && val.length > 0){
                this.popoverCtrl.create('GroupProfile',{
                    'group':val[0],
                    'type': 'my'
                }, {}).present({
                    animation: 'ios-transition',
                    duration: 350
                });
            }
            else {
                Agnes.showError("Sorry, couldn't open this group profile!");
            }
        }).catch(err => {
            console.log(err);
            this.loading = false;
            Agnes.showError("Sorry, couldn't open this group profile!");
        });
    }

}

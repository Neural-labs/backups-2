import os
from Utilities import EventTree, DataFilter
from config import db_config
import argparse
import networkx as nx
import time
from node2vec import Node2Vec
from bson.binary import Binary
import pickle
# from node2vec.src import main
import sys
import requests
from Preprocessing.CollectFeatures import CollectExtractionFeatures


dbConn = db_config.getDBConn('dev')
Agnes = dbConn.Agnes
AutoCrawler_Events = Agnes.autocrawler_events
Data_Collection = Agnes.autocrawler_ext_data
Autocrawler_Unique = Agnes.autocrawler_unique_sources

# current_filepath = os.path.abspath(__file__)
# pos_csv = os.path.abspath(os.path.join(__file__ ,"../../../Data/csv/PositiveFeatureSelection.csv"))
missed_events_filepath = os.path.abspath(os.path.join(__file__,"../../../Data/txt/missed_events.txt"))

def runSinglePage():

    '''
    https://www.dcsbdc.org/workshop.aspx?ekey=600370005
    http://energypolicy.columbia.edu/events-calendar/women-energy-networking-event-w-greater-nyc-chapter-wen
    http://www.ustreetmusichall.com/event/1410053-dj-sega-washington/
    http://www.930.com/event/1356031-phox-washington/
    http://www.upenn.edu/calendar/?page=1&month=9&day=6&oldview=day&event=92881953&year=2017
    http://events.cornell.edu/event/how_do_i_know_my_students_are_learning_before_the_semester_ends
    http://events.cornell.edu/event/asking_good_in-class_questions
    http://www.eventbrite.com/e/fias-fill-a-bag-for-2500-basement-sale-friday-august-12-from-12pm-7pm-tickets-26608243974?aff=ebapi
    '''

    # page_url = 'https://calendar.oberlin.edu/event/public_observing_3791'
    # page_url = 'http://www.upenn.edu/calendar/?page=1&month=9&day=6&oldview=day&event=92881953&year=2017'
    # page_url = 'http://energypolicy.columbia.edu/events-calendar/women-energy-networking-event-w-greater-nyc-chapter-wen'
    page_url = 'http://events.cornell.edu/event/2015_conservation_education_days'
    # page_url = 'http://browse.calendar.gwu.edu/EventList.aspx?display=Month&eventidn=14590&fromdate=07%2F08%2F2017&information_id=27258&todate=09%2F02%2F2017&type=public&view=EventDetails'
    # html = fetchPage(page_url)
    # examineHTML(html)
    event0 = getEventByUrl(page_url)

    examinePage(event0)

    page_url = 'http://events.cornell.edu/event/1_greek_experience_1gxp'
    # html = fetchPage(page_url)
    # examineHTML(html)
    event1 = getEventByUrl(page_url)

    # examinePage(event1)

    # compareTrees(event0, event1)

    # cursor = getRandomEvent()

    # for event in cursor:
    #     examinePage(event)

    #
    # page_urls = getMissedPageUrls()
    #
    # for page_url in page_urls:
    #     print('url:',page_url)
    #     event = getEventByUrl(page_url)
    #     examinePage(event)

def fetchPage(url):
    try:
        html = requests.get(url).text
    except Exception as e:
        print 'failed'
        return None
    return html

def getEventByUrl(page_url):
    return AutoCrawler_Events.find_one({'url':page_url})

def getRandomEvent():
    return AutoCrawler_Events.aggregate([{"$sample": {'size': 1}}])

def getData():
    return Data_Collection.find({})

def examineHTML(html):

    html = '<div class="field field-name-field-address"><div class="label-above">Location</div><div class="addressfield-container-inline organisation-block"><span class="organisation-name">Dudley House Graduate Student Lounge</span></div><div class="addressfield-container-inline locality-block country-US"><span class="locality">Cambridge</span>, <span class="state">MA</span> <span class="postal-code">02138</span></div><span class="country">United States</span></div>'

    

    # event_tree = EventTree.EventTree(HTML=html)
    # data = event_tree.get_node_data(event_tree.get_root())['attr_dict']
    # print data['tag'].prettify()

    # print 'Nodes:',len(event_tree.get_nodes())

    # for node_id, node_data in event_tree.get_nodes():
    #     if 'img' in str(node_data['attr_dict']['tag']):
    #         print node_data['attr_dict']['tag'].prettify()


def compareTrees(evt0, evt1):

    tree0 = pickle.loads(evt0['netx_tree_pkl'])
    tree1 = pickle.loads(evt1['netx_tree_pkl'])

    len0 = len(tree0.get_nodes())
    len1 = len(tree1.get_nodes())

    found0in1 = 0
    found1in0 = 0

    for index in range(max(len0, len1)):

        if index < len0:
            id0, data0 = tree0.get_nodes()[index]
        if index < len1:
            id1, data1 = tree1.get_nodes()[index]

        html0 = DataFilter.removeHref(DataFilter.removeContentInHTML(str(data0['attr_dict']['tag'])))
        html1 = DataFilter.removeHref(DataFilter.removeContentInHTML(str(data1['attr_dict']['tag'])))

        if html0 != html1:

            other_html1,other_id1 = checkInOtherTree(html0, tree1)

            other_html0, other_id0 = checkInOtherTree(html1, tree0)

            if other_html1:
                # print 'html0 is in tree1:'
                # print 'html0', html0
                # print 'id0', id0
                # print 'other html',other_html1
                # print 'other id', other_id1
                found0in1 += 1
            else:
                print 'html0 is not in tree1'
                print html0

            print

            if other_html0:
                # print 'html1 is in tree0:'
                # print 'html1',html1
                # print 'id1',id1
                # print 'other html', other_html0
                # print 'other id', other_id0
                found1in0 += 1

            else:
                print 'html1 is not in tree0'
                print html1

            print

            print '\n ----- \n'

        else:
            found1in0 += 1
            found0in1 += 1

        print 'len1', len1
        print 'Found 0 in 1:', found0in1
        print 'len0', len0
        print 'Found 1 in 0:', found1in0

def checkInOtherTree(html, otherTree):

    for node_id, node_data in otherTree.get_nodes():

        other_html = DataFilter.removeHref(DataFilter.removeContentInHTML(str(node_data['attr_dict']['tag'])))

        if html == other_html:
            return other_html, node_id

    return None, None

def examinePage(event):

    HTML = event['HTML']

    event_tree = pickle.loads(event['netx_tree_pkl'])
    event_nodes = event_tree.get_event_nodes()
    parts = ['name', 'description', 'location', 'date', 'other']

    for part in event_nodes:
        print part
        data = event_tree.get_node_data(event_nodes[part])
        tag = data['attr_dict']['tag']
        text = str(tag)
        print text
        general_features = CollectExtractionFeatures.extractFeaturesManual(text)
        structure_features = CollectExtractionFeatures.extractFeaturesStructure(event_tree, event_nodes[part])

        print

    raise ValueError('stap')



    # for node_id, node_data in event_tree.get_nodes():
    #
    #     sample = {}
    #
    #     position = event_tree.get_position(node_id)
    #     print 'node',node_id,'position',position,'depth',event_tree.depth(node_id)

        # text = convertTagToStr(node_data['attr_dict']['tag'])

    #     subtree_labels = node_data['attr_dict']['subtree_label']
    #     node_labels = node_data['attr_dict']['node_label']
    #
    #     subtree_labels = [subtree_labels[part] for part in parts]
    #     node_labels = [node_labels[part] for part in parts]
    #
    #     # html_features = extractFeaturesHTML(html_embedding_model, text)
    #     # manual_features = extractFeaturesManual(text)
    #
    #     sample['subtree_label'] = subtree_labels
    #     sample['node_label'] = node_labels
    #     # sample['html_embedding'] = html_features
    #     # sample['manual_features'] = manual_features
    #
    #     # samples.append(sample)
    # event_tree.print_labels()
    #
    # event_tree = EventTree.EventTree(HTML, event)
    # event_nodes = event_tree.get_event_nodes()
    # print event['evtsource']
    # event_tree.print_labels()
    #
    # print sys.getsizeof(Binary(pickle.dumps(event_tree)))

    # print event_nodes
    # print event['url']
    #
    # event_paths = {}
    # for part in event_nodes:
    #     if part =='event':
    #         continue
    #     print sys.getsizeof(event_tree.get_node_data(event_nodes[part])['attr_dict']['tag'])
    #     print part, event_tree.get_node_data(event_nodes[part])['attr_dict']['tag'].prettify
    #     print
    #     # print part, event_tree.node_path(event_nodes['event'], event_nodes[part])
    #     event_paths[part] = event_tree.node_path(event_nodes['event'], event_nodes[part])

    # print
    # counter = 0
    # for node in event_tree.iterate_from_node(event_nodes['event']):
    #     counter += 1
    #     path = event_tree.node_path(event_nodes['event'], node)
    #     level = len(path)
    #     parts = ''
    #     for part in event_paths:
    #         if node in event_paths[part] or len([x for x in path if x in event_paths[part]]) == len(event_paths[part]):
    #             parts += part + ' '
    #     # print
    #     # print '========================================'
    #     # for part in event_nodes:
    #     #     if part == 'event':
    #     #         continue
    #     #     print part, event_tree.node_path(event_nodes['event'], event_nodes[part])
    #     print
    #     print path[max(-len(path), -2)]
    #     print '(',node,')', parts#,'path',event_tree.node_path(event_nodes['event'], node)
    #     print
    #     # if not parts:
    #     # print event_tree.get_node_data(node)['attr_dict']['totalcontent']
    #     # print
    # print counter
    # print event['url']
    # #
    #
    # # for i in range(10):
    # #     event_tree = EventTree.EventTree(HTML, event)
    # #     event_nodes = event_tree.get_event_nodes()
    # #
    # #     print event_nodes
    # #     print event['url']
    # #
    # #     if not event_nodes:
    # #         break
    #
    # # event_binary = Binary(pickle.dumps(event_tree))
    # #
    #
    # print sys.getsizeof(makeBinary(event_tree))

    # data = getData()

    # for dataitem in data:
    #     print 'size:',sys.getsizeof(dataitem)

    # test_tag = Binary(pickle.dumps(event_tree.get_node_data(event_nodes['event'])['attr_dict']['tag']))
    #
    # writeBinaryTreeToEvent(event, test_tag)
    # print event['url']
    #
    # print event_nodes
    # print event['url']

def makeBinary(item):
    return Binary(pickle.dumps(item))

def writeBinaryTreeToEvent(event, binary):

    AutoCrawler_Events.update_one({
        '_id': event['_id']
    }, {
        '$set': {
            'event_tree_pkl': binary
        }
    }, upsert=False)


def initializeNode2VecArgs(input_path, output_path):
    dict_args = {'directed': False, 'walk_length': 80, 'num_walks': 10, 'window_size': 10, 'dimensions': 128, 'unweighted': True, 'workers': 8, 'iter': 1, 'q': 1, 'p': 1, 'weighted': False, 'output': output_path, 'input': input_path, 'undirected': True}

    namespace = argparse.Namespace()

    for key in dict_args.keys():
        namespace.key = dict_args[key]

    return namespace


def getMissedPageUrls():
    missed_urls = []
    with open(missed_events_filepath, 'r') as f:
        data = f.readlines()
        for url in data:
            missed_urls.append(url.replace('\n',''))

        return missed_urls

def removeURL(url):
    missed_urls = getMissedPageUrls()

    with open(missed_events_filepath, 'w') as f:
        for item in missed_urls:
            if item != url:
                f.write(item+'\n')

'''
first 100
http://events.ithaca.edu/event/junior_recital_erin_dowler_clarinet
https://www.eventbrite.com/e/igniting-transformation-for-america-transformative-justice-coalition-fundraiser-and-reception-tickets-29452290594?aff=ebapi
https://www.google.com/calendar/event?eid=N2FrYzdqMWhqdGRnMjlnNDVwaWdrc2U0OTggY29ybmVsbGNpbmVtYWNhbGVuZGFyQG0&ctz=America/New_York

2nd 100
https://www.eventbrite.com/e/making-amas-collection-public-tickets-32825025535?aff=ebapi
https://calendar.oberlin.edu/event/oberlin_chamber_orchestra_raphael_jimenez_conductor_4110


3rd 100
https://www.eventbrite.com/e/2017-nshss-scholars-day-registration-35414302131?aff=ebapi
https://www.eventbrite.com/e/fit-celebrating-men-who-support-women-dc-tickets-37881154553?aff=ebapi
https://www.eventbrite.com/e/young-women-run-tickets-33232042935?aff=ebapi
https://www.meetup.com/dccapitalstriders/events/240167319/
http://calendar.colgate.edu/event/colgate_university_mens_soccer_vs_bucknell
https://www.eventbrite.com/e/3rd-annual-dc-growers-cup-tickets-34451253627?aff=ebapi

1st 1000: 895/946
bad data:
https://www.eventbrite.com/e/2nd-annual-brunch-fit-for-a-queen-celebration-of-womens-history-month-tickets-31219257640?aff=ebapi
http://events.cornell.edu/event/cu_music_pianist_malcolm_bilson
https://www.eventbrite.com/e/the-business-of-design-contracts-and-negotiations-tickets-32448805250?aff=ebapi

bad crawler:
http://events.cornell.edu/event/nbb_seminar_speaker_michael_n_nitabach_yale_school_of_medicine
https://www.eventbrite.com/e/unpacking-the-standards-for-mathematical-practice-tickets-31494120763?aff=ebapi
http://events.ithaca.edu/event/junior_recital_seamus_buxton_tenor

fixed:
https://news.dartmouth.edu/events/event?event=46021&listing=1
http://calendar.colgate.edu/event/biology_honor_presentations_3110




https://www.eventbrite.com/e/gain-mentors-dc-decorum-crafting-communications-tickets-33282220016?aff=ebapi
https://www.capitalfringe.org/events/1004-marian-mclaughlin-progressive-folk-string-trio
http://www.harvardartmuseums.org/visit/calendar/arts-first-at-the-harvard-art-museums-performance-fair-in-adolphus-busch-hall-2
http://www.930.com/event/1419945-nancy-beth-megan-mullally-washington/
https://www.eventbrite.com/e/drink-ink-valentines-day-edition-joseph-magnus-distillery-tickets-30342578469?aff=ebapi
http://events.newschool.edu/event/student_recital__1354
http://events.ithaca.edu/event/junior_recital_mckinny_danger-james_mezzo-soprano
https://www.eventbrite.com/e/art-cruise-tickets-33952475769?aff=ebapi
https://www.eventbrite.com/e/bachelor-in-paradise-premiere-blowout-tickets-36502709587?aff=ebapi
http://browse.calendar.gwu.edu/EventList.aspx?display=Month&eventidn=13756&fromdate=12%2F19%2F2016&information_id=25521&todate=02%2F13%2F2017&type=public&view=EventDetails
http://calendar.colgate.edu/event/colgate_university_womens_tennis_vs_rochester
https://news.dartmouth.edu/events/event?event=44559&listing=1
https://www.eventbrite.com/e/brunch-all-you-can-eat-bottomless-mimosa-tickets-23897417820?aff=ebapi
http://events.cornell.edu/event/316_maple_tubing_workshop_installation_benefits
http://events.cornell.edu/event/before_sexual_and_normal_shifting_categories_of_sexual_anomalies_from_ancient_to_fourteenth-century_china
http://www.eventbrite.com/e/the-midnight-mansion-pool-party-tickets-26902801002?aff=ebapi
http://events.cornell.edu/event/staphylococcus_aureus_leukocidins_from_receptor_identification_to_unraveling_their_role_in_pathogenesis
http://events.ithaca.edu/event/elective_recital_marshall_pokrentowski_baritone
http://events.cornell.edu/event/ms_petra_deane-coe_dissertation_seminar_title_tba
http://browse.calendar.gwu.edu/EventList.aspx?display=Month&eventidn=13459&fromdate=10%2F04%2F2016&information_id=24897&todate=11%2F29%2F2016&type=public&view=EventDetails
https://www.eventbrite.com/e/pulselocal-dc-kick-off-event-tickets-38793538518?aff=ebapi
https://www.eventbrite.com/e/rosebarmondays-hosted-by-dave-east-tickets-37000160476?aff=ebapi
http://events.cornell.edu/event/aasp_and_a3c_praxis_lunch_series_5941
https://www.meetup.com/dccapitalstriders/events/239289913/
http://www.eventbrite.com/e/small-business-brief-advice-legal-clinic-impact-hub-tickets-26956966011?aff=ebapi
https://www.eventbrite.com/e/destination-cuba-new-years-eve-party-tickets-29838218916?aff=ebapi
http://guevents.georgetown.edu/event/performance_review_seminar_for_staff
https://www.eventbrite.com/e/report-launch-global-health-and-the-future-role-of-the-united-states-tickets-34426896775?aff=ebapi
https://www.eventbrite.com/e/havana-photo-exhibit-feat-elliott-odonovan-tickets-34021058903?aff=ebapi
http://events.cornell.edu/event/ivermectin_drug_discovery_one_mouse_at_a_time
https://events.temple.edu/ctmpharmacology-seminar-bradford-g-hill-phd
https://events.temple.edu/field-hockey-vs-uconn-alumni-day
https://www.eventbrite.com/e/weed-dating-tickets-33594755819?aff=ebapi
https://www.capitalfringe.org/events/1027-beach-haus
https://www.eventbrite.com/e/bud-appetit-presents-high-on-the-hill-a-cannabis-infused-dinner-series-tickets-33034391755?aff=ebapi
http://guevents.georgetown.edu/event/jumpstart_january_refugees_and_humanitarian_affairs
https://www.eventbrite.com/e/one-night-only-ucb-tob-another-surprise-band-tickets-38532293126?aff=ebapi
http://events.cornell.edu/event/reuben_a_and_cheryl_casselberry_munday_distinguished_lecture
https://www.eventbrite.com/e/helping-professions-mixer-tickets-36593185202?aff=ebapi
https://www.eventbrite.com/e/generation-x-seated-speed-dating-for-people-born-between-1965-and-1982-tickets-32273981347?aff=ebapi
https://www.eventbrite.com/e/post-march-college-reception-tickets-31085389236?aff=ebapi
http://www.ustreetmusichall.com/event/1459666-zebbler-encanti-experience-washington/
http://events.cornell.edu/event/microeconomic_theory_workshop_kota_saito

'''

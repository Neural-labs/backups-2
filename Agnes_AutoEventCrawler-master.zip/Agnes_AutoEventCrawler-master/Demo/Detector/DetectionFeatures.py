import numpy as np
import pickle
import logging
import string
import re
from bson.binary import Binary
from Utility_Modules import DataFilter
from gensim.models import keyedvectors, Word2Vec

def getFeatures(sample):
    word2vec_embedding = keyedvectors.KeyedVectors().load_word2vec_format('GoogleNews-vectors-negative300.bin',
                                                                          binary=True)
    h2v_w_embedding = Word2Vec.load('gensim_model_w2v_hw')
    c2v_embedding = getCharEmbeddingModel()

    features = []

    manual_features = extractFeaturesManual(sample)

    html_features = extractHTMLFeaturesEmbedding(h2v_w_embedding, sample)

    content_features = extractContentFeaturesEmbedding(word2vec_embedding, sample)

    url_features = extractURLFeaturesEmbedding(c2v_embedding, sample)

    for features in [html_features, content_features, url_features]:
        if not features:
            return None

    features += manual_features
    features += html_features
    features += content_features
    features += url_features

    return features

def getCharEmbeddingModel():
    model = {}
    with open('glove.840B.300d-char.txt', 'r') as f:
        data = f.readlines()
        for line in data:
            char = line[0]
            char_data = line[1:]
            char_data = np.array([float(item) for item in char_data.split() if item]).astype(np.float16)
            model[char] = char_data
    return model


def extractFeaturesManual(sample):

    content = removeHref(sample['HTML'])
    content = content.lower()

    keywords = ['title', 'description', 'desc', 'location', 'locat', 'name', 'date', 'summary', 'event', 'content',
                'field', 'address','venue', 'time', 'when', 'where', 'start', 'end', 'map', 'calendar', 'cal', 'from', 'to', 'building',
                'hall', 'auditorium', 'room', 'clock', 'street', 'locality', 'theatre', 'theater']

    content_keywords = getKeywordCount(keywords, content)

    return content_keywords

def extractHTMLFeaturesEmbedding(embedding_model, sample):
    HTML = sample['HTML']
    HTML = removeHref(HTML)
    # html_content = removeRealContent(HTML)

    tokens = tokenizeH2V_W(HTML)

    feature_vector = getAvgEmbedding(embedding_model, tokens)

    return feature_vector

def extractContentFeaturesEmbedding(embedding_model, sample):

    tokens = tokenizeW2V(sample['HTML'])

    feature_vector = getAvgEmbedding(embedding_model, tokens)

    return feature_vector

def extractURLFeaturesEmbedding(embedding_model, sample):
    url = sample['url']

    tokens = tokenizeC2V(url)

    vectors = [embedding_model[char] for char in tokens if char in embedding_model]

    if not vectors:
        return None

    feature_vector = np.mean(np.vstack(vectors).astype(np.float16), axis=0)

    feature_vector = Binary(pickle.dumps(feature_vector))

    return feature_vector

def getAvgEmbedding(embedding_model, tokens):
    if not tokens:
        return None

    vectors = [embedding_model.wv[token] for token in tokens if token in embedding_model.wv]

    if not vectors:
        return None

    feature_vector = np.mean(np.vstack(vectors).astype(np.float16), axis=0)

    feature_vector = Binary(pickle.dumps(feature_vector))

    return feature_vector

def tokenizeC2V(content):
    filters = ''  # if we want to remove some symbols
    for c in filters:
        content = content.replace(c, '')
    return [char for char in content if char]

def tokenizeH2V_W(content):
    content = content.replace('\n','')
    content = removeHref(content)
    # html_soup = DataFilter.removeBadThings(content)
    html_soup = DataFilter.simpleGetSoup(content)
    # html_soup = BeautifulSoup(content,'lxml')
    max_head = html_soup.find('html')
    if not max_head:
        logging.info('Sample has wrong html')
        print html_soup
        return None
    h2v_string = ''
    for tag in max_head.findChildren():
        if hasattr(tag,'attrs') and hasattr(tag,'name'):
            h2v_string += tag.name + ' '
            for attr in tag.attrs:
                value = tag[attr]
                if isinstance(value, list):
                    for val in value:
                        h2v_string += removePunctuation(val)+' '
                else:
                    h2v_string += removePunctuation(value)+' '
    return [word for word in ' '.join(h2v_string.split()).split() if word]

def tokenizeW2V(content):
    content = cleanhtml(content)
    content = removePunctuation(content)
    return [word for word in content.split() if word]

def getKeywordCount(keyword_list, content):
    counts = []
    for item in keyword_list:
        counts.append(content.count(item))
    return counts

def getAvgWordLength(content):
    content = removePunctuation(content)
    avg_word_len = np.mean([len(word) for word in content.split()])
    return avg_word_len

def getAvgSentenceLength(content):
    avg_sen_len = np.mean([len(sen) for sen in content.split('.')])
    return avg_sen_len

def cleanString(content):
    content = content.replace('\n','')
    content = content.replace('\t','')
    content = ' '.join(content.split())
    return content

def removePunctuation(content):
    for char in string.punctuation:
        content = content.replace(char, ' ')
    return ' '.join(content.split())

def removeHref(raw_html):
    pattern = re.compile('href=".*?"')
    html_sans_href = re.sub(pattern, '', raw_html)
    return html_sans_href

def cleanhtml(raw_html):
    cleanr = re.compile('<[^<]+?>')
    cleantext = re.sub(cleanr, '', raw_html)
    return cleantext

def removeRealContent(content):
    pattern = re.compile('>.+?<')
    cleancontent = re.sub(pattern, '><', content)
    return cleancontent
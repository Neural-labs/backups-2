import { Component, ViewChild } from '@angular/core';
import { FormControl } from '@angular/forms';
import { IonicPage, NavParams, Events, ViewController, Content } from 'ionic-angular';
import { GroupsService } from '../../../providers/groups.service';

@IonicPage()
@Component({
    selector: 'group-list-popup',
    templateUrl: 'group-list-popup.html',
    providers: [GroupsService]
})

export class GroupListPopup {

    user: Object;
    groupList: Array<Object>;
    originalList: Array<Object>;
    submitText: string;
    backText: string;
    helpText: string;
    groupSearch: string;
    invited: Array<any>;
    singleTap: boolean;
    searchControl: FormControl;
    batchNum: number;
    hasInfinite: boolean;
    canToggle: boolean;
    sentGroups: Array<string>;


    @ViewChild('') content: Content;

    constructor(public navParams: NavParams,
                private viewCtrl: ViewController,
                private groupsService: GroupsService,
                public events: Events) {
        this.searchControl = new FormControl();
    }

    ngOnInit() {
        this.user = JSON.parse(localStorage.getItem('agnesUser'));
        this.groupList = this.navParams.get('groupList');
        this.originalList = JSON.parse(JSON.stringify(this.groupList));
        this.hasInfinite = this.navParams.get('hasInfinite');
        this.canToggle = true;
        this.sentGroups = this.navParams.get('sentGroups')
        for(let g in this.groupList){
            this.groupList[g]['displayURL'] =
                this.groupList[g]['thumbnail'] != '' ? this.groupList[g]['thumbnail'] : 'assets/img/icons/defaultGroup.png';
            this.groupList[g]['invited'] = this.sentGroups.indexOf(this.groupList[g]['_id']) != -1;
        }

        this.submitText = this.navParams.get('submitText');
        this.backText = this.navParams.get('backText') ? this.navParams.get('backText') : 'Back';
        this.helpText = this.navParams.get('helpText');
        this.singleTap = this.navParams.get('singleTap');
        this.groupSearch = '';
        this.invited = [];
        this.batchNum = 0;
    }

    ionViewDidLoad() {
        // Handle Search
        this.searchControl.valueChanges.debounceTime(350).subscribe(search => {

            if (search == '') {
                this.groupList = JSON.parse(JSON.stringify(this.originalList));
                // this.content.scrollToTop(0);
                let elem = document.getElementById('groupList');
                elem.scrollTop = 0;
            }
            else {
                this.searchGroups(0);
            }
        });
    }

    //add or remove group from invite list
    toggleGroup(group){
      if(group['invited'] == false) {
        if(this.singleTap){
            this.closeGroupListPopup(group);
        }
        else {
            let invInd = this.invited.indexOf(group['_id']);
            if(invInd == -1){
                if(!this.hasInfinite || (this.hasInfinite && this.canToggle)) {
                    this.invited.push(group['_id']);
                }
            }
            else{this.invited.splice(invInd,1);}
        }
      }
    }

    //close group list popup
    closeGroupListPopup(data){
        this.events.publish('groupShareSent', data);
        this.events.publish('groupListPopupData', data);
        this.viewCtrl.dismiss(data,'',{
            animation: 'ios-transition',
            duration: 350,
            easing: "ease-in-out",
            direction: "back"
        });
    }

    //load more groups
    loadMoreGroups(infiniteScroll){
        if(this.groupSearch != ''){
            this.batchNum += 1;
            this.searchGroups(this.batchNum,infiniteScroll);
        }
        else {
            let data = {
                "community": this.user["community"],
                "users_id": this.user["_id"],
                "_id": this.groupList[this.groupList.length - 1]["_id"]
            };

            this.groupsService.loadMoreGroups(data).then(moreGroups =>{
                if (moreGroups){
                    if(moreGroups.length == 1){
                        infiniteScroll.enable(false);
                    }
                    else {
                        moreGroups = moreGroups.filter((a) => {return a != null});
                        moreGroups.slice(1);
                        this.groupList = this.groupList.concat(moreGroups);
                    }
                }
                infiniteScroll.complete();
            }).catch(error => {
                infiniteScroll.complete();
                console.log(error);
            });
        }
    }

    //search groups
    searchGroups(batchNum, infiniteScroll?){
        //reset search batch number for new searches
        if(batchNum == 0) {this.batchNum = 0;}

        if (this.helpText) {

            if(this.batchNum == 0) {
                // this.content.scrollToTop(0);
                let elem = document.getElementById('groupList');
                elem.scrollTop = 0;
                this.groupList = [];
            }
            if (this.groupSearch && this.groupSearch.trim().length > 0) {

                let data = {"searchTerm":this.groupSearch, "community":this.user['community'], "scroll": batchNum};
                this.groupsService.searchGroups(data)
                    .then(value => {
                        if(value){
                            //filter out secret groups that user is not a member/admin of
                            value = value.filter(a => {
                                return a['grptype'] != 'secret' || (a['grptype'] == 'secret' &&
                                    (a['admin'].indexOf(this.user['_id']) != -1 ||
                                    a['members'].indexOf(this.user['_id']) != -1));
                            });

                            this.groupList = this.groupList.concat(value);
                            if(value.length == 0){this.batchNum = 0;}
                        }
                        else{
                            this.groupList = JSON.parse(JSON.stringify(this.originalList));
                            this.batchNum = 0;
                        }

                        if(infiniteScroll){infiniteScroll.complete();}
                    })
                    .catch(function(error){
                        if(infiniteScroll){infiniteScroll.complete();}
                        console.log(error);
                        this.batchNum = 0;
                    });
            }
            else {
                this.groupList = JSON.parse(JSON.stringify(this.originalList));
            }
        }
    }
}

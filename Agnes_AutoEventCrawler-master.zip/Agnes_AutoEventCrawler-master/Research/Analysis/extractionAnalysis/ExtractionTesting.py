from ExtractionTraining import getModel
from Utilities import EventTree
from gensim.models import Word2Vec
import requests
from Preprocessing.CollectFeatures import CollectExtractionFeatures
import logging
import pickle
import numpy as np
from config import db_config
from sklearn.preprocessing import scale
import math
import ExtractionTraining

Agnes = db_config.getDBConn('dev').Agnes
Events_Collection = Agnes.autocrawler_events
Data_Collection = Agnes.autocrawler_ext_data

split_index = 4424651130935301185

real_page_urls = [
    # 'https://www.usgbc.org/event/designing-human-health-and-wellbeing',
    # 'http://browse.calendar.gwu.edu/EventList.aspx?fromdate=4/5/2018&todate=5/4/2018&display=&type=public&eventidn=16032&view=EventDetails&information_id=30331',
    # 'http://browse.calendar.gwu.edu/EventList.aspx?fromdate=4/6/2018&todate=5/5/2018&display=&type=public&eventidn=15818&view=EventDetails&information_id=29900'
    # 'https://www.umass.edu/events/scary-movie-night-blob',
    'http://www.calstatela.edu/event/2018-conference-chicano-history-historiography-and-historical-novel-out-many-one'
]

single_models = ['name', 'description', 'location', 'date','other']

global html_embedding_model

def testExtraction():

    name_weights_fpath = 'extraction_classifier_singlelabel_name.hdf5'
    name_model = getModel('name')
    name_model.load_weights(name_weights_fpath)

    multilabel_weights_fpath = 'extraction_classifier_multilabel_subtree.hdf5'
    subtree_model = getModel('subtree')
    subtree_model.load_weights(multilabel_weights_fpath)

    global html_embedding_model
    html_embedding_model = Word2Vec.load('gensim_model_w2v_hw')

    logging.info('Loading Model...')

    models = {
        'subtree':subtree_model,
        'name':name_model
    }

    runRealData(models)

def runMongoData(model, model_type):

    val_data_generator = getValidationGenerator(model_type)

def getValidationGenerator(model_type):

    id_index = split_index
    batch_num = 0
    while True:

        validation_batch = getValidationBatch(id_index)
        batch_count = validation_batch.count(with_limit_and_skip=True)

        if not validation_batch or not batch_count:
            break

        batch_num += 1
        # logging.info('Fetched Validation Batch %d\n' % batch_num)

        id_index = validation_batch[batch_count-1]['random_id']

        X = []
        y = []

        for sample in validation_batch:

            features = getFeatures(model_type, sample)
            labels = getLabels(model_type, sample)

            if not features:
                continue

            features = ExtractionTraining.scaleFeatures(features)
            X.append(features)
            y.append(labels)

        X = np.array(X)
        # X = ExtractionTraining.scaleFeatures(features)
        X = X.reshape(X.shape[0], 1, X.shape[1])
        y = np.array(y)

        yield X, y

def getLabels(model_type, sample):
    if model_type == 'subtree':
        return sample['subtree_label']
    elif model_type == 'node':
        return sample['node_label']
    elif isSingleModel(model_type):
        return getPartLabel(model_type, sample)
    else:
        print 'model type not specified correctly'


def isSingleModel(model_type):
    return model_type in single_models

def getPartLabel(model_type, sample):
    index = single_models.index(model_type)
    return [math.ceil(sample['subtree_label'][index])]

def getValidationBatch(index_id):
    return Data_Collection.find({'random_id': {'$gt': index_id}}, no_cursor_timeout=True).limit(batch_size).sort(
        'random_id', 1)

def runRealData(models):

    logging.info('Fetching real data...')
    dataGenerator = getData()

    logging.info('testing models')
    testModel(models, dataGenerator)

def getData():

    for page_url in real_page_urls:
        print 'Page Url', page_url,'\n'
        html = getHTML(page_url)

        data, samples, tree = getDataSamples(html)
        # all_data += data
        # all_samples += samples
        # all_data = np.array(all_data)
        # all_data = all_data.reshape(all_data.shape[0], 1, all_data.shape[1])
        yield data, samples, tree


def testModel(models, dataGenerator):
    subtree_model = models['subtree']
    # name_model = models['name']
    for data, samples, tree in dataGenerator:

        subtree_predictions = subtree_model.predict(data)

        # top_predictions = subtree_predictions[:5]
        printResults(subtree_predictions, samples, models, tree)
        # printStats(samples, subtree_predictions)

def getHTML(url):
    try:
        html = requests.get(url).text
    except Exception as e:
        print 'Failed to get html',url
        return ''
    return html

def getDataSamples(html):
    data = []
    samples = []
    event_tree = EventTree.EventTree(html)

    for node_id, node_data in event_tree.get_nodes():
        subtree_html = str(node_data['attr_dict']['tag'])
        features = getFeatures(subtree_html, node_id, event_tree)

        if features:
            features = ExtractionTraining.scaleFeatures(features)
            data.append(features)
            samples.append({'text':subtree_html,
                            'node_id':node_id})


    # raise ValueError('stap')
    data = np.array(data)
    data = data.reshape(data.shape[0], 1, data.shape[1])

    return data, samples, event_tree


def getFeatures(subtree_html, node_id, event_tree):

    global html_embedding_model

    html_features = CollectExtractionFeatures.extractFeaturesHTML(html_embedding_model, subtree_html)
    manual_features = CollectExtractionFeatures.extractFeaturesManual(subtree_html)
    structure_features = CollectExtractionFeatures.extractFeaturesStructure(event_tree, node_id)

    if not html_features:
        return None

    return list(pickle.loads(html_features)) + manual_features + structure_features


def printResults(subtree_predictions, samples, models, tree):

    name_model = models['name']

    combined_subtree = zip(samples, subtree_predictions)

    sorted_subtree_items = sorted(combined_subtree, key=lambda x: np.mean(x[1]))

    top_5 = sorted_subtree_items[:]

    max_name_predictions = []

    for sample, prediction in top_5:
        if 'Chicano' in sample['text']:
            print '\nSubtree:'
            print sample['text']
            print prediction
            print

            node_id = sample['node_id']
            child_data = []
            child_samples = []
            for iter_id in tree.iterate_from_node(node_id):
                iter_data = tree.get_node_data(iter_id)
                iter_html = str(iter_data['attr_dict']['tag'])
                iter_features = getFeatures(iter_html, iter_id, tree)
                if not iter_features is None:
                    child_data.append(ExtractionTraining.scaleFeatures(iter_features))
                    child_samples.append({'text': iter_html,'node_id': node_id})

            child_data = np.array(child_data)
            child_data = child_data.reshape(child_data.shape[0], 1, child_data.shape[1])

            name_preds = name_model.predict(child_data)

            sorted_child_data = sorted(zip(child_samples, name_preds), key=lambda x: x[1])

            for child_sample, child_prediction in sorted_child_data:
                print '\nChild:'
                print child_sample['text']
                print child_prediction
                print
                # print
                # max_name_predictions.append()
                # if child_prediction > max_name_prediction:
                #     max_name_prediction = child_prediction
                #     max_sample = child_sample
            # print 'Max Name:'
            # print max_sample['text']
            # print max_name_prediction
            # print
            print '----------------------------------'

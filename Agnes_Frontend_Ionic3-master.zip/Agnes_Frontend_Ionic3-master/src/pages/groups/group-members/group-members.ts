import { Component } from '@angular/core';
import { NavController, NavParams, IonicPage, ViewController, Events, Select, ToastController } from 'ionic-angular';

import { GroupsService } from '../../../providers/groups.service';
import { PeopleService } from '../../../providers/people.service';

import { Agnes } from '../../../app/app.component';

@IonicPage()
@Component({
    selector: 'group-members',
    templateUrl: 'group-members.html',
    providers: [GroupsService, PeopleService]
})
export class GroupMembers {

    group: Object;
    user: Object;
    loading: boolean;
    canToggle: boolean;
    type: string;

    userSearch: string;
    memberList: Array<Object>;
    selectedPerson = null;
    edited: boolean;

    rvadmin = [];
    newadmin = [];
    rvmember = [];
    newmember = [];

    oldMembers: Array<Object>;
    oldAdmins: Array<Object>;

    buttonText: string;

    constructor(public navCtrl: NavController,
                public viewCtrl: ViewController,
                public events: Events,
                private toastCtrl: ToastController,
                private groupsService: GroupsService,
                private peopleService: PeopleService,
                private navParams: NavParams) {
    }

    ngOnInit(){

        this.user = JSON.parse(localStorage.getItem('agnesUser'));
        this.group = JSON.parse(JSON.stringify(this.navParams.get('group')));
        this.type = this.navParams.get('type');
        this.memberList = this.navParams.get('memberList');

        this.canToggle = this.type == 'edit';
        this.buttonText = 'Select a member to edit';

        this.userSearch = '';
        this.edited = false;

        this.sortMemberList();

        if(this.type == 'edit') {
            this.oldMembers = [...this.memberList.filter(x => x['isMember']).map(x => x['_id'])];
            this.oldAdmins = [...this.memberList.filter(x => x['isAdmin']).map(x => x['_id'])];
        }
    }

    closeGroupMembers(fromBackButton){
        this.loading = false;
        if(this.type == 'edit'){
            if(this.edited){
                if(fromBackButton){
                    Agnes.showError('Do you want to save your changes?', ['Not now', 'Save']);
                    this.events.subscribe('agnesAlertData', ind => {
                        if(ind == 1){
                            this.submitEditMembers();
                        }
                        else {
                            this.viewCtrl.dismiss(null,'',{
                                animate: true,
                                animation: 'ios-transition',
                                duration: 350,
                                easing: "ease-in-out",
                                direction: "back"
                            });
                        }
                    });
                }
                else {
                    this.submitEditMembers();
                }
            }
            else {
                this.viewCtrl.dismiss(null,'',{
                    animate: true,
                    animation: 'ios-transition',
                    duration: 350,
                    easing: "ease-in-out",
                    direction: "back"
                });
            }
        }
        else {
            this.viewCtrl.dismiss(null,'',{
                animate: true,
                animation: 'ios-transition',
                duration: 350,
                easing: "ease-in-out",
                direction: "back"
            });
        }
    }

    submitEditMembers(){

        if(this.type == 'edit') {
            if(this.edited){
                this.loading = true;

                if(this.group['admin'].filter(a => {
                        return this.rvadmin.indexOf(a) == -1 && this.newmember.indexOf(a) == -1;
                    }).length == 0) {
                }
                let data = {
                    'users_id': this.user['_id'],
                    'groups_id': this.group['_id'],
                    'newmember': this.memberList.filter(x => x['isMember'] && this.oldMembers.indexOf(x['_id']) == -1)
                        .map(x => x['_id']),
                    'newadmin': this.memberList.filter(x => x['isAdmin'] && this.oldAdmins.indexOf(x['_id']) == -1)
                        .map(x => x['_id']),
                    'rvmember': this.memberList.filter(x => x['isAdmin'] && this.oldMembers.indexOf(x['_id']) != -1)
                        .map(x => x['_id']),
                    'rvadmin': this.memberList.filter(x => x['isMember'] && this.oldAdmins.indexOf(x['_id']) != -1)
                        .map(x => x['_id']),
                    'community': this.user['community']
                };

                this.groupsService.editGroupMembers(data).then(val => {

                    this.loading = false;

                    if(val){
                        this.toastCtrl.create({
                            message: "You've successfully edited your group members!",
                            position:'top',
                            showCloseButton: true,
                            closeButtonText: ' ',
                            duration: 2500
                        }).present();

                        this.events.publish('groupMembersEdited', val);

                        this.viewCtrl.dismiss(val,null,{
                            animation: 'ios-transition',
                            duration: 350,
                            easing: "ease-in-out",
                            direction: "back"
                        });
                    }
                    else {
                        Agnes.showError('Could not edit your group right now - try again!');
                    }
                }).catch(err => {
                    Agnes.showError('Could not edit your group right now - try again!');
                    this.loading = false;
                    console.log('error on edit', err);
                });
            }
        }
    }

    /************************************************************************************************************/
    /************************************************************************************************************/
    /*************************************** MEMBER STUFF ***********************************************/
    /************************************************************************************************************/
    /************************************************************************************************************/


    //user name matches user search input
    matchesSearch(person){
        let term = this.userSearch.trim().toLowerCase();
        let len = term.length;
        if(len > 0){
            if (term.indexOf(' ') != -1){
                //user has searched a first and last name
                let ts = term.replace(/\s+/g,' ').split(' ');
                let fname = person['fname'].toLowerCase().substring(0,ts[0].length) == ts[0];
                let lname = person['lname'].toLowerCase().substring(0,ts[1].length) == ts[1];
                return (fname && lname);
            }
            let fname = person['fname'].toLowerCase().substring(0,len) == term;
            let lname = person['lname'].toLowerCase().substring(0,len) == term;
            return (fname || lname);
        }
        else {
            return true;
        }
    }

    selectPerson(person){
        if(this.selectedPerson && this.selectedPerson == person){
            if(this.selectedPerson == person) {
                this.selectedPerson = null;
                this.buttonText = this.edited ? 'Save' : 'Select a member to edit';
            }
        }
        else {
            this.buttonText = person['isAdmin'] ? 'Make this admin a member'
                : person['isMember'] ? 'Make this member an admin' : 'Can\'t edit follower status!';
            this.selectedPerson = person['isAdmin'] || person['isMember'] ? person : null;
        }
    }

    //sort member list by admins first alphabetically and then members alphabetically
    sortMemberList(){
        //sort admins alphabetically above members
        let admins = this.memberList.filter(a => {return this.group['admin'].indexOf(a['_id']) != -1});
        admins = admins.sort((a,b) => {
            return (b['fname'] < a['fname'] ? 1 : -1);
        });

        let mems = this.memberList.filter(a => {
            return this.group['members'].indexOf(a['_id']) != -1 && this.group['admin'].indexOf(a['_id']) == -1;
        });
        mems = mems.sort((a,b) => {
            return (b['fname'] < a['fname'] ? 1 : -1);
        });

        this.memberList = admins.concat(mems);
    }

    viewMembers() {

    }

    changeMemberStatus(){
        if(this.type == 'edit' && this.selectedPerson){
            if(this.selectedPerson['_id'] == this.user['_id'] && this.group['admin'].length == 1){
                Agnes.showError('Groups need at least one admin and you\'re the only one right now! ' +
                    'Promote someone in your group before giving up your admin status :)');
            }
            else {
                this.selectedPerson['isMember'] = !this.selectedPerson['isMember'];
                this.selectedPerson['isAdmin'] = !this.selectedPerson['isAdmin'];
                this.edited = true;
                this.selectedPerson = null;
                this.buttonText = 'Save';
            }
        }
    }
}

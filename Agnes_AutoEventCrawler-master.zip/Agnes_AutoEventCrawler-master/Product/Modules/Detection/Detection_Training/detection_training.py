from utilities import DetectionModel

DEFAULT_MODEL_TYPE = 'SVM'

class DetectionTrainer:
    model = None
    train_index = 0

    def __init__(self, model):
        if not model:
            raise ValueError('No model provided to Detection Trainer')
        self.model = model['model']
        self.train_index = model['train_index']

    def doTraining(self):

        if not self.model:
            raise ValueError('No model to train!')

        trained_model = runTraining(self.model)


def runTraining(model):
    train_index = model['train_index']



'''
import os

import numpy as np
from sklearn import svm
from sklearn.externals import joblib
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.naive_bayes import GaussianNB
from sklearn.neighbors import KNeighborsClassifier

from Research.config.initConfig import getDBConn

fileDir = os.path.dirname(os.path.realpath('__file__'))
filename = os.path.join(fileDir, 'Data/Features/features.txt')

dbConn = getDBConn('dev')
Agnes = dbConn.Agnes
data_collection = Agnes.autocrawler_data
# test_collection = Agnes.autocrawler_test
# ext_collection = Agnes.autocrawler_ext_data

global testCommunities
global doTrain

Debug = True

def debug(string, **kwargs):
    if Debug:
        print string
        for arg in kwargs:
            print arg

def RunClassification(classifierType, do_train, test_communities):

    global testCommunities
    global doTrain
    testCommunities = test_communities
    doTrain = do_train

    if doTrain:

        accuracies = []
        predictionData = []

        trueNegative = 0.0
        falseNegative = 0.0
        truePositive = 0.0
        falsePositive = 0.0
        totalPredictions = 0

        accuracy, predictions, model = RunClassifier(classifierType)
        accuracies.append(accuracy)
        predictionData = set(predictionData + predictions)

        for item in predictionData:
            predictedValue = item[1]
            actualValue = item[2]

            totalPredictions += 1
            if predictedValue != actualValue:
                if actualValue:
                    # print 'FN - Community:', test_communities, 'url:', item[0]
                    falseNegative += 1
                else:
                    # print 'FP - Community:', test_communities, 'url:', item[0]
                    falsePositive += 1
            else:
                if actualValue:
                    truePositive += 1
                else:
                    trueNegative += 1

        writeModelToFile(model, classifierType)

        return {
            'accuracy': accuracy,
            'FP': falsePositive,
            'FN': falseNegative,
            'TP': truePositive,
            'TN': trueNegative
        }

    else:
        scores = RunClassifier(classifierType)

        print("Accuracy: %0.2f (+/- %0.2f)" % (scores.mean(), scores.std() * 2))

def RunClassifier(classifierType):

    global testCommunities
    global doTrain

    data, urls = getData()
    if doTrain:
        debug('Starting Training')
        if classifierType == 'svm':

            accuracy, predictions, model = runSVM(data, urls)

        elif classifierType == 'knn':

            accuracy, predictions, model = runKNN(data, urls)

        elif classifierType == 'bayes':

            accuracy, predictions, model = runBayes(data, urls)

        else:
            raise ValueError('No Type Given to RunClassifier')

        return accuracy, predictions, model

    else:
        scores = runCrossVal(classifierType, data)
        return scores


def doCommunityTest(communities):
    return len(communities) > 0

def getData():
    allData = getDataFromMongo()
    data, urls = splitAllData(allData)
    return data,urls

def getDataFromMongo():
    return data_collection.find({})

def getFeatures():
    with open(filename, 'r') as f:
        rawFeatures = f.read()
        features = rawFeatures.split(';')
        return features

def splitAllData(allData):

    global testCommunities
    global doTrain

    X, y, urls, communities = splitData(allData)

    if doTrain:

        if testCommunities:
            data, urls = communityTestTrainSplit(X, y, communities, urls)

        else:
            X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2)

            data = {
                'x_train': X_train,
                'x_test': X_test,
                'y_train': y_train,
                'y_test': y_test
            }

        return data, urls

    else:

        return {
            'X': X,
            'y': y
        }, urls

def splitData(allData):
    X = []
    y = []
    urls = []
    communities = []

    for dataSample in allData:
        if dataSample['label'] == True:
            y.append(1)
        else:
            y.append(0)

        # community = dataSample['community']
        data = dataSample['data']
        url = dataSample['url']

        X.append(data)
        urls.append(url)
        # communities.append(community)

    X = np.array(X)
    y = np.array(y)

    return X, y, urls ,communities

def communityTestTrainSplit(X, y, communities, urls):

    global testCommunities

    X_train = []
    X_test = []
    test_urls = []
    y_train = []
    y_test = []
    train_urls = []

    for index in range(len(y)):
        community = communities[index]
        data = X[index]
        label = y[index]
        url = urls[index]

        if community in testCommunities:
            X_test.append(data)
            y_test.append(label)
            test_urls.append(url)
        else:
            X_train.append(data)
            y_train.append(label)
            train_urls.append(url)

    return{
            'x_train':X_train,
            'x_test':X_test,
            'y_train':y_train,
            'y_test':y_test
        }, {
        'train_urls':train_urls,
        'test_urls':test_urls
    }


'''
# As other classifiers, SVC, NuSVC and LinearSVC take as input two arrays: an array X of size [n_samples, n_features] holding the training samples, and an array y of class labels (strings or integers), size [n_samples]:
'''
def runSVM(data, urls):

    X_train = data['x_train']
    y_train = data['y_train']
    clf = svm.SVC()
    clf.fit(X_train, y_train)

    accuracy, predictions = runTesting(clf, data, urls)

    return accuracy, predictions, clf

def runKNN(data, urls):

    X_train = data['x_train']
    y_train = data['y_train']
    clf = KNeighborsClassifier(n_neighbors=5)
    clf.fit(X_train, y_train)

    accuracy, predictions = runTesting(clf, data, urls)

    return accuracy, predictions, clf

def runBayes(data, urls):
    X_train = data['x_train']
    y_train = data['y_train']
    clf = GaussianNB()
    clf.fit(X_train, y_train)

    accuracy, predictions = runTesting(clf, data, urls)

    return accuracy, predictions, clf

def runCrossVal(classifierType, data):
    model = getModel(classifierType)

    scores = cross_val_score(model, data['X'], data['y'], cv=5)

    return scores

def runTesting(model, data, urls):
    X_test = data['x_test']
    y_test = data['y_test']

    y_predictions = model.predict(X_test)

    accuracy, predictions = runAccuracy(y_test, y_predictions, urls)

    return accuracy, predictions

def runAccuracy(y_test, y_predictions, urls):

    global testCommunities

    totalSamples = len(y_test)
    errors = 0.0

    predictions = []
    for index in range(len(y_predictions)):
        model_prediction = y_predictions[index]
        actual_value     = y_test[index]

        if model_prediction != actual_value:
            errors += 1.0

        if testCommunities:
            predictions.append((urls['test_urls'][index], model_prediction, actual_value))
        else:
            predictions.append((urls[index], model_prediction, actual_value))

    errorRate = errors / totalSamples
    accuracyRate = 1 - errorRate
    return accuracyRate, predictions

def writeModelToFile(model, classifierType):
    joblib.dump(model, classifierType+'_model.pkl')

def getModel(classifierType):
    return joblib.load('model.pkl')


'''


import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';

import { EventRepeat } from './event-repeat';

@NgModule({
    declarations: [
        EventRepeat
    ],
    imports: [
        IonicPageModule.forChild(EventRepeat)
    ],
    exports: [
        EventRepeat
    ]
})

export class EventRepeatModule { }

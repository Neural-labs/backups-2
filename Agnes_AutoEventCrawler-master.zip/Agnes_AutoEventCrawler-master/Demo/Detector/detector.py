from DetectionFeatures import getFeatures

def clusterPages(pages):
    pass


def classifyPage(sample):

    features = getFeatures(sample)
    if not features:
        return None


    # get model

    # classify sample

    # return classification and url


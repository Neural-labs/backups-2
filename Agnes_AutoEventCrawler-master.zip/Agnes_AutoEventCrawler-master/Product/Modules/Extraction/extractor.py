from Extraction_Testing import extraction_tester
from Extraction_Training import extraction_trainer

class Extractor:

    def __init__(self):
        pass


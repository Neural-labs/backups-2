import pandas as pd

def main():

    series = pd.Series([1,2,3,4])
    print series
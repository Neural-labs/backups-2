import redis


def checkFriendship(user_0, user_1):

    pass


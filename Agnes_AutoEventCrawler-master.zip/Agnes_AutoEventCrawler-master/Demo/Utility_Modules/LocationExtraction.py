# Extracts the location from a string
import usaddress
from postal.parser import parse_address

def getLocations(content):

    locations = runExtraction(content)
    return locations

def runExtraction(content):

    usaddr_parsed = usaddress.parse(content)

    postal_parsed = parse_address(content)

    usaddr_locations = getUSAddress(usaddr_parsed)

    postal_locations = getPyPostal(postal_parsed)

    us_address = ''
    if len(usaddr_locations) > 0:
        us_address = ' '.join(usaddr_locations)

    postal_address = ''
    if len(postal_locations) > 0:
        postal_address = ' '.join(postal_locations)

    if us_address or postal_address:
        print content
    if us_address:
        print usaddr_parsed
    if postal_address:
        print postal_parsed

    locations = [us_address, postal_address]

    return [item for item in locations if item]

def getUSAddress(addr):
    return [item[0] for item in addr if item[1] != 'Recipient']

def getPyPostal(addr):
    return [item[0] for item in addr if item[1] != 'house']

def validUSAddress(address_obj):
    strong_item_fields = {
        'Recipient':False,
        'AddressNumber':False,
        'StreetName':False,
        'StreetNamePostType':False,
        'StreetNamePostDirectional':False,
        'PlaceName':False,
        'StateName':False,
        'ZipCode':False
    }

    for item in address_obj:
        partial_content = item[0]
        content_type = item[1]
        if content_type in strong_item_fields.keys():
            strong_item_fields[content_type] = True

    # print item_fields
    # return strong_item_fields['AddressNumber'] and item_fields['StreetName'] and item_fields['PlaceName'] \
    #             and item_fields['StateName'] and item_fields['ZipCode']

def getUSAddressFields():
    fields = ['AddressNumber','AddressNumberPrefix','AddressNumberSuffix','BuildingName','CornerOf','IntersectionSeparator','LandmarkName',
              'NotAddress','OccupancyType','OccupancyIdentifier','PlaceName','Recipient','StateName','StreetName','StreetNamePreDirectional',
              'StreetNamePreModifier','StreetNamePreType','StreetNamePostDirectional','StreetNamePostModifier','StreetNamePostType',
              'SubaddressIdentifier','SubaddressType','USPSBoxGroupID','USPSBoxGroupType','USPSBoxID','USPSBoxType','ZipCode']
    return fields

def getRawUSAddress(content):
    return usaddress.parse(content)

def getPostalFields():
    fields = ['house','category','near','house_number','road','unit','level','staircase','entrance','po_box','postcode','suburb',
              'city_district','city','island','state_district','state','country_region','country','world_region']
    return fields

def getRawPostalAddress(content):
    return parse_address(content, language='en', country='us')

def getAllFields():
    return getUSAddressFields() + getPostalFields()


import { Component, ViewChild } from '@angular/core';
import { Content, Platform, Events, IonicPage, App, Slides, ViewController } from 'ionic-angular';
import { AnalyticsService} from "../../providers/analytics.service";
import { EventsService } from '../../providers/events.service';
import { MeService } from '../../providers/me.service';

import { Agnes } from '../../app/app.component';

declare var google: any;

@IonicPage()
@Component({
    selector: 'map',
    templateUrl: 'map.html',
    providers: [EventsService, MeService, AnalyticsService]
})

export class MapPage {

    allEvents: Array<Object>;
    storedAll: Array<Object>;
    mapAllEvents: Array<any>;

    user: Object;
    loading: boolean;
    noInternet: boolean;
    map: any;
    mapInitialized: boolean;
    markers: Array<any>;
    theme: boolean;
    noContent: boolean;

    today: string;
    tomorrow: string;

    haveAll: boolean;

    @ViewChild('discoverEventsContent') content: Content;
    @ViewChild('mapEventSlides') slides:Slides;

    constructor(private eventsService: EventsService,
                private analyticsService: AnalyticsService,
                private meService: MeService,
                public appCtrl: App,
                private viewCtrl: ViewController,
                private events: Events,
                private platform: Platform){
    }

    ngOnInit(){
        this.mapAllEvents = [];
        this.markers = [];
        this.user = JSON.parse(localStorage.getItem('agnesUser'));

        this.mapInitialized = false;
        this.loading = true;

        this.noContent = false;

        let t = new Date();
        this.today = t.toDateString().match(/[a-zA-Z]{3} [a-zA-Z]{3} \d\d/)[0];
        this.today = this.today.replace(/([a-zA-Z]{3})(\s[a-zA-Z]{3}\s)(\d{2})/, "$1.$2$3");
        t.setDate(t.getDate() + 1);
        this.tomorrow = t.toDateString().match(/[a-zA-Z]{3} [a-zA-Z]{3} \d\d/)[0];
        this.tomorrow = this.tomorrow.replace(/([a-zA-Z]{3})(\s[a-zA-Z]{3}\s)(\d{2})/, "$1.$2$3");

        //refresh Discover if user goes to, edits, or deletes an event after opening event profile
        this.events.subscribe('eventProfileData', (data) => {
            this.refreshEvents(null);
        });

        this.initEvents();

        //send map button analytics if maps tab has been selected
        this.analyticsService.logAnalytics({community: this.user['community'], users_id: this.user['_id']}, '/mapTab');

        this.events.subscribe('gotMapEvents_all', () => {
            this.haveAll = true;
            this.getMap();
        });

    }

    //save matched events in local storage when exiting page
    //in case something was changed (i.e. event attended, deleted, created, edited, etc.)
    ionViewWillLeave() {
        localStorage.setItem('agnesMapEvents', JSON.stringify(this.mapAllEvents));
    }

    // ionViewWillEnter(){
    //     this.initEvents();
    // }

    initEvents(){
        if(!Agnes.network || Agnes.network.type != 'none'){
            this.loading = true;
            this.noInternet = false;
            this.mapInitialized = false;
            this.getAllEvents(null);
        }
        else {
            //lack of internet connection - show Tap to Refresh div
            this.noInternet = true;
            let mapEvents = JSON.parse(localStorage.getItem('agnesMapEvents'));
            this.mapAllEvents = mapEvents ? mapEvents : [];
        }
    }

    /*************************************************************************************************************/
    /*************************************** main loading functions **********************************************/
    /*************************************************************************************************************/


    //get all community events from database
    getAllEvents(refresher){
        this.eventsService.loadAllEvents(this.user['_id'], this.user['community'])
            .then(allEvents => {
                if(refresher){
                    refresher.complete();
                }
                this.processEvents(allEvents, false, 'all');
            })
            .catch(error => {
                this.loading = false;
                this.noInternet = true;
                console.log(error);
                Agnes.showError('Could not get events - refreshing now!');
                this.getAllEvents(refresher);
            });
    }

    //process events for display
    processEvents(events, loadingMore, type){
        events = events.filter(a => {return (a != null && (a['evttype'] && a['evttype'] == 'public') || !a['evttype'])});

        if(!loadingMore){
            this[type+'Events'] = [];
        }

        for (let v in events){
            if (events[v] && typeof(events[v])=='object'){
                if (this[type+'Events'].map(function (a) {return a["_id"];}).indexOf(events[v]["_id"]) == -1){
                    this[type+'Events'].push(events[v]);
                }
            }
        }

        this.events.publish('gotMapEvents_' + type);
    }

    //refresh events ist
    refreshEvents(refresher) {
        if(!Agnes.network || Agnes.network.type != 'none'){
            this.initEvents();
        } else {
            //lack of internet connection - alert
            Agnes.showError('You are offline! Try refreshing again when you reconnect.');
            refresher.complete();
        }
    }

    //show map of events
    getMap(){
                if(!this.mapInitialized){
                    this.loading = true;
                    if(!this.platform.is('cordova')) {
                        navigator.geolocation.getCurrentPosition((pos) => {
                            this.initMap(pos['coords']);
                        });
                    }
                    else {
                        //get user's location
                        Agnes.geolocation.getCurrentPosition().then(pos => {
                            localStorage.setItem('agnesPosition', JSON.stringify(pos['coords']));
                            this.initMap(pos['coords']);
                        }).catch(err => {
                            let coords = JSON.parse(localStorage.getItem('agnesPos'));
                            if(coords) {
                                this.initMap(coords)
                            } else {
                                let evtCoords = this.findEvtCoords();
                                this.initMap(evtCoords);
                            }

                        });
                    }
                }
    }

    // Find coordinates for one event
    findEvtCoords() {
      this.initMarkers('all');
        for (let i = 0; i < this.mapAllEvents.length; i++) {
            if (this.mapAllEvents[i]['geo']) {
                let coords = this.mapAllEvents[i]['geo'].split(',')
                return {
                    'latitude':coords[0],
                    'longitude':coords[1],
                    "accuracy":5,
                    "altitude":0,
                    "heading":-1,
                    "speed":-1,
                    "altitudeAccuracy":-1
                }
            }
        }
    }

    //initialize map of All Events
    initMap(coords){
        //create map
        let latLng = new google.maps.LatLng(coords['latitude'], coords['longitude']);
        console.log(latLng);
        let mapOptions = {
            center: latLng,
            zoom: 14,
            mapTypeId: google.maps.MapTypeId.ROADMAP,
            clickableIcons: false,
            disableDefaultUI: true,
            styles: [
                {
                    "elementType": "geometry",
                    "stylers": [
                        {
                            "color": "#f5f5f5"
                        }
                    ]
                },
                {
                    "elementType": "labels.text.fill",
                    "stylers": [
                        {
                            "color": "#325861"
                        }
                    ]
                },
                {
                    "elementType": "labels.text.stroke",
                    "stylers": [
                        {
                            "color": "#ffffff"
                        }
                    ]
                },
                {
                    "featureType": "administrative.country",
                    "elementType": "geometry.stroke",
                    "stylers": [
                        {
                            "color": "#ffffff"
                        }
                    ]
                },
                {
                    "featureType": "administrative.land_parcel",
                    "elementType": "labels.text.fill",
                    "stylers": [
                        {
                            "color": "#bdbdbd"
                        }
                    ]
                },
                {
                    "featureType": "administrative.province",
                    "elementType": "geometry.stroke",
                    "stylers": [
                        {
                            "color": "#ffffff"
                        }
                    ]
                },
                {
                    "featureType": "landscape.man_made",
                    "elementType": "geometry.stroke",
                    "stylers": [
                        {
                            "color": "#ffffff"
                        }
                    ]
                },
                {
                    "featureType": "landscape.natural",
                    "elementType": "geometry",
                    "stylers": [
                        {
                            "color": "#ffffff"
                        }
                    ]
                },
                {
                    "featureType": "poi",
                    "elementType": "geometry",
                    "stylers": [
                        {
                            "color": "#eeeeee"
                        }
                    ]
                },
                {
                    "featureType": "poi",
                    "elementType": "labels.text.fill",
                    "stylers": [
                        {
                            "color": "#757575"
                        }
                    ]
                },
                {
                    "featureType": "poi",
                    "elementType": "labels.text.stroke",
                    "stylers": [
                        {
                            "color": "#ffffff"
                        }
                    ]
                },
                {
                    "featureType": "poi.park",
                    "elementType": "geometry.fill",
                    "stylers": [
                        {
                            "color": "#e5e5e5"
                        }
                    ]
                },
                {
                    "featureType": "poi.park",
                    "elementType": "labels.text.fill",
                    "stylers": [
                        {
                            "color": "#9e9e9e"
                        }
                    ]
                },
                {
                    "featureType": "road",
                    "elementType": "geometry",
                    "stylers": [
                        {
                            "color": "#ffffff"
                        }
                    ]
                },
                {
                    "featureType": "road",
                    "elementType": "labels.text.fill",
                    "stylers": [
                        {
                            "color": "#43656d"
                        }
                    ]
                },
                {
                    "featureType": "road",
                    "elementType": "labels.text.stroke",
                    "stylers": [
                        {
                            "color": "#ffffff"
                        }
                    ]
                },
                {
                    "featureType": "road.highway",
                    "elementType": "geometry",
                    "stylers": [
                        {
                            "color": "#dadada"
                        }
                    ]
                },
                {
                    "featureType": "road.highway",
                    "elementType": "geometry.stroke",
                    "stylers": [
                        {
                            "color": "#ffffff"
                        }
                    ]
                },
                {
                    "featureType": "road.highway",
                    "elementType": "labels.text.fill",
                    "stylers": [
                        {
                            "color": "#43656d"
                        }
                    ]
                },
                {
                    "featureType": "road.highway",
                    "elementType": "labels.text.stroke",
                    "stylers": [
                        {
                            "color": "#ffffff"
                        }
                    ]
                },
                {
                    "featureType": "transit",
                    "elementType": "labels.text.fill",
                    "stylers": [
                        {
                            "color": "#43656d"
                        }
                    ]
                },
                {
                    "featureType": "transit",
                    "elementType": "labels.text.stroke",
                    "stylers": [
                        {
                            "color": "#ffffff"
                        }
                    ]
                },
                {
                    "featureType": "transit.line",
                    "elementType": "geometry.fill",
                    "stylers": [
                        {
                            "color": "#8ec3b9"
                        }
                    ]
                },
                {
                    "featureType": "transit.station",
                    "elementType": "geometry",
                    "stylers": [
                        {
                            "color": "#eeeeee"
                        }
                    ]
                },
                {
                    "featureType": "water",
                    "elementType": "geometry",
                    "stylers": [
                        {
                            "color": "#4dbcea"
                        }
                    ]
                },
                {
                    "featureType": "water",
                    "elementType": "labels.text.fill",
                    "stylers": [
                        {
                            "color": "#43656d"
                        }
                    ]
                }
            ]
        };

        this.map = new google.maps.Map(document.getElementById('eventsMap'), mapOptions);

        let markers = this.initMarkers('all');

        //add event listeners to markers
        for(let x in markers){
            this.markers.push(markers[x]);
            markers[x].setMap(this.map);
            markers[x] = this.addListenerToMarker(markers[x])
            google.maps.event.trigger(this.map, "resize");
        }

        this.mapInitialized = true;
        this.loading = false;
    }

    initMarkers(type:string) {

        //create marker image for Agnes Icon
        let image = {
            url: 'assets/img/Loading-Agnes-Smaller.gif',
            scaledSize: new google.maps.Size(20, 20),
            origin: new google.maps.Point(0, 0),
            anchor: new google.maps.Point(15, 30),
            optimized: false
        };

        let markers = [];

        let mappingArray = this.allEvents;

        // for (let i = 0; i < array.length; i++) {
        for(let i = 0; i < mappingArray.length; i++) {
            let event = mappingArray[i];
            event["starttime"] = event["starttime"].replace(/[-\+]\d\d\d\d/,'Z');
            let start = Agnes.processGMT(event['starttime']);
            let date = (start.date == this.today) ? "Today" : (start.date == this.tomorrow) ? "Tomorrow" : start.date;
            let time = (start.time == "12:01AM") ? "All Day" : start.time;
            event["displaytime"] = date + " : " + time;
            if((event['geo']) && (date == "Today")){
                this.mapAllEvents.push(event);
                let coords = event['geo'].split(',');
                let ll = new google.maps.LatLng(parseFloat(coords[0]), parseFloat(coords[1]));

                // Shapes define the clickable region of the icon. The type defines an HTML
                // <area> element 'poly' which traces out a polygon as a series of X,Y points.
                // The final coordinate closes the poly by connecting to the first coordinate.
                let shape = {
                    coords: [1, 1, 1, 20, 18, 20, 18, 1],
                    type: 'poly'
                };


                let marker = new google.maps.Marker({
                    position: ll,
                    title: event['_id'],
                    animation: google.maps.Animation.DROP,
                    clickable: true,
                    icon: image,
                    shape: shape,
                    zIndex: 1,
                    type:type,
                    name:event['evtname'],
                    optimized: false
                });
                markers.push(marker);
            }
        }
        if(this.mapAllEvents.length == 0) {
          this.noContent = true;
        }
        return markers
    }

    mapSlideChanged() {
        let curr = this.slides.getActiveIndex();
        let title = this.mapAllEvents[curr]["_id"];
        for(let m in this.markers) {
            if(this.markers[m]['title'] == title) {
                google.maps.event.trigger(this.markers[m], 'click');
            }
        }
    }

    addListenerToMarker(marker) {
        let icon = {
            url: 'assets/img/Loading-Agnes-Smaller.gif',
            scaledSize: new google.maps.Size(20, 20),
            origin: new google.maps.Point(0, 0),
            anchor: new google.maps.Point(15, 30)
        };
        let largeIcon = {
            url: 'assets/img/Loading-Agnes-Smaller.gif',
            scaledSize: new google.maps.Size(50, 50),
            origin: new google.maps.Point(0, 0),
            anchor: new google.maps.Point(15, 30)
        };
        marker.addListener('click', () => {
            for(let m in this.markers){
                this.markers[m].setIcon(icon);
                this.markers[m].setZIndex(1);
            }
            google.maps.event.trigger(this.map, "resize");
            let eID = marker.getTitle();
            let ind = this.mapAllEvents.map(a => {
                return a['_id']
            }).indexOf(eID);
            this.slides.slideTo(ind);
            event = this.mapAllEvents[ind];
            marker.setIcon(largeIcon);
            marker.setZIndex(10)
            if (!event) {
                return;
            }
            this.map.setCenter(marker.getPosition());
        });
    }


    closeMap() {
      this.viewCtrl.dismiss('MapPage', '', {
        animation: 'ios-transition',
        duration: 350,
        easing: "ease-in-out",
        direction: "back"
      });
    }

}

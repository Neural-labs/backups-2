"""
Module for training the classification model for extraction

Types of models:
Subtree Multilabel - categorical output of 5 classes
Node Multilabel - categorial output of 5 classes
Subtree Single Label - binary classifier for a single part of the event tree

"""
from config import db_config
from keras.models import Sequential
from keras.layers import Conv1D, Activation, MaxPooling1D, LSTM, Dense, BatchNormalization
from keras.optimizers import SGD
from keras.callbacks import ModelCheckpoint
import numpy as np
import gc
import logging
import pickle
import math

Agnes = db_config.getDBConn('dev').Agnes
Events_Collection = Agnes.autocrawler_events
Data_Collection = Agnes.autocrawler_ext_data
Eval_Data_Collection = Agnes.autocrawler_ext_data_val

# total_samples = 100000 # for testing
# validation_size = 10000 # for testing
last_random_id = 4611685969403546753
total_samples = Data_Collection.count()
validation_size = 50000
batch_size = 32
INPUT_DIM_SUBTREE = 319
INPUT_DIM_SINGLE = 319
epochs = 5
split_index = 4424651130935301185

single_models = ['name', 'description', 'location', 'date','other']


train_sources = ['busboysandpoets.com', 'caps.gov.harvard.edu', 'marymount.edu', 'atlanticcouncil.org', 'ces.fas.harvard.edu', 'newamerica.org', 'history.fas.harvard.edu', 'law.columbia.edu', 'guevents.georgetown.edu', 'chem.columbia.edu', 'jtsa.edu', '37', 'calendar.colgate.edu', 'humanrightscolumbia.org', 'dspshows.com', 'gsas.harvard.edu', 'events.williams.edu', 'memorialchurch.harvard.edu', 'edportal.harvard.edu', 'calendar.northeastern.edu', 'capitalfringe.org', 'eventbrite.com(ithaca)', 'chemistry.harvard.edu', 'engineering.cornell.edu', 'cfa.gmu.edu', 'calendar.howard.edu', 'brookings.edu', 'artgallery.yale.edu', 'events.temple.edu', 'earth.columbia.edu', 'artsinitiative.columbia.edu', 'nyu.edu', 'belfercenter.org', 'heymancenter.org', 'aei.org', 'barnard.edu', 'green.harvard.edu', 'washingtondc.eventful.com', 'washington.org', 'politics-prose.com', 'gradschool.cornell.edu', 'environment.harvard.edu', 'events.newschool.edu', 'anthropology.fas.harvard.edu', 'events.ithaca.edu', 'calendar.oberlin.edu', 'news.dartmouth.edu', 'weai.columbia.edu', 'events.towson.edu', 'ofa.fas.harvard.edu', 'cato.org', 'georgetowndc.com', 'econ.columbia.edu', 'harvard-yenching.org', 'shakespearetheatre.org', 'csis.org', 'dcsbdc.org', 'slavic.fas.harvard.edu', 'my.arboretum.harvard.edu', 'economics.harvard.edu', 'events.cornell.edu', 'events.visitithaca.com', 'cellbio.med.harvard.edu', 'eventbrite.com', 'histsci.fas.harvard.edu', 'mailman.columbia.edu', 'harvardartmuseums.org', 'sociology.fas.harvard.edu', 'peabody.harvard.edu', 'browse.calendar.gwu.edu', 'american.edu', 'events.goucher.edu', 'usgbc.org', 'eli.org', 'energypolicy.columbia.edu', 'philly.com', 'astro.columbia.edu', 'runwashington.com', 'hls.harvard.edu', 'eventbrite.com(washington)', 'gsd.harvard.edu', 'arch.columbia.edu', 'bu.edu', 'socialwork.columbia.edu', 'events.citypaper.com', 'iijs.columbia.edu', 'ves.fas.harvard.edu', 'events.udel.edu']

test_sources = ['930.com', 'ticketmaster', 'thebostoncalendar.com', 'thephillycalendar.com', 'events.uri.edu', 'math.cornell.edu', 'physics.columbia.edu', 'meetup.com', 'english.columbia.edu', 'radcliffe.harvard.edu']

useHTML = True
useContent = True
useManual = True
useStructure = True

def runExtractionTraining(model_type):
    logging.info('Training %s model' % model_type)
    if model_type == 'subtree':
        runSubtreeTraining(model_type)
    elif model_type == 'node':
        runNodeTraining(model_type)
    elif model_type in single_models:
        runSingleTraining(model_type)
    else:
        print 'model_type incorrectly specified'


def runSubtreeTraining(model_type):
    model = getModel(model_type)

    logging.info('Starting sample generator')
    sample_generator = getSampleGenerator(model_type)

    logging.info('Starting validation generator')
    validation_generator = getValidationGenerator(model_type)

    steps_per_epoch = total_samples / batch_size
    validation_steps = validation_size / batch_size

    logging.info('Fitting model...')
    logging.info('Total Samples: %d, Batch Size: %d, Steps per epoch %d, Validation Steps: %d' %
                 (total_samples, batch_size, steps_per_epoch, validation_steps))
    filepath = 'extraction_classifier_multilabel_'+ model_type +'.hdf5'
    checkpoint = ModelCheckpoint(filepath, verbose=1, save_best_only=True)
    callbacks_list = [checkpoint]
    model.fit_generator(generator=sample_generator, epochs=epochs, steps_per_epoch=steps_per_epoch,
                        validation_data=validation_generator, validation_steps=validation_steps, callbacks=callbacks_list, verbose=1)



def runNodeTraining(model_type):
    pass


def runSingleTraining(model_type):

    model = getModel(model_type)
    logging.info('Training extraction classifier')

    logging.info('Starting sample generator')
    # sample_generator = getSampleGenerator(model_type)
    sample_generator = getSampleGeneratorV2(model_type, training=True)

    logging.info('Starting validation generator')
    # validation_generator = getValidationGenerator(model_type)
    validation_generator = getSampleGeneratorV2(model_type, training=False)

    steps_per_epoch = total_samples / batch_size
    validation_steps = validation_size / batch_size

    logging.info('Fitting model...')
    logging.info('Total Samples: %d, Batch Size: %d, Steps per epoch %d, Validation Steps: %d' %
                 (total_samples, batch_size, steps_per_epoch, validation_steps))
    filepath = 'extraction_classifier_singlelabelv2_' + model_type + '.hdf5'
    checkpoint = ModelCheckpoint(filepath, verbose=1, save_best_only=True)
    callbacks_list = [checkpoint]
    model.fit_generator(generator=sample_generator, epochs=epochs, steps_per_epoch=steps_per_epoch,
                        validation_data=validation_generator, validation_steps=validation_steps,
                        callbacks=callbacks_list, verbose=1, class_weight={0:1, 1:100})


def evaluateModel(model_type, model):

    evaluationData = getEvaluationData()


def getModel(model_type):
    if model_type == 'subtree':
        return getSubtreeModel()
    elif model_type in single_models:
        return getSingleModel()
    else:
        raise ValueError('model_type incorrectly specified')

def getSubtreeModel():
    kernel_size = 5
    filters = 64
    lstm_output_size = 64
    input_dim = INPUT_DIM_SUBTREE

    model = Sequential()
    model.add(Conv1D(filters,
                     kernel_size,
                     padding='same',
                     strides=1,
                     kernel_initializer='uniform',
                     input_shape=(None, input_dim),
                     batch_input_shape=(None, 1, input_dim)
                     ))
    model.add(Activation('relu'))
    model.add(MaxPooling1D(padding='same'))
    model.add(LSTM(lstm_output_size))
    model.add(Dense(64, activation='relu'))
    model.add(Dense(64, activation='relu'))
    model.add(Dense(5, activation='sigmoid'))
    sgd = SGD(lr=0.01, decay=1e-6, momentum=0.9, nesterov=True)
    model.compile(loss='binary_crossentropy',
                  optimizer=sgd,
                  metrics=['accuracy'])
    model.summary()
    return model

def getSingleModel():
    kernel_size = 5
    filters = 64
    lstm_output_size = 64
    input_dim = INPUT_DIM_SINGLE

    model = Sequential()
    model.add(Conv1D(filters,
                     kernel_size,
                     padding='same',
                     strides=1,
                     kernel_initializer='uniform',
                     input_shape=(None, input_dim),
                     batch_input_shape=(None, 1, input_dim)
                     ))
    model.add(Activation('relu'))
    model.add(MaxPooling1D(padding='same'))
    model.add(LSTM(lstm_output_size))
    model.add(BatchNormalization())
    model.add(Dense(64, activation='relu'))
    model.add(BatchNormalization())
    model.add(Dense(64, activation='relu'))
    model.add(BatchNormalization())
    model.add(Dense(1, activation='sigmoid'))
    model.compile(loss='binary_crossentropy',
                  optimizer='adam',
                  metrics=['accuracy'])
    model.summary()
    return model


def getSampleGenerator(model_type):

    for epoch in range(epochs):
        logging.info('Sample Generator starting epoch %d\n' % epoch)
        # last_id = split_index
        last_id = None
        batch_num = 0
        while True:

            sample_batch = getSampleBatchCursor(last_id)
            batch_count = sample_batch.count(with_limit_and_skip=True)

            if not sample_batch or not batch_count:
                logging.info('sample batch or batch count is 0')
                break

            batch_num += 1
            last_id = sample_batch[batch_count-1]['random_id']

            shuffle_array = []
            for sample in sample_batch:
                if not validSample(sample, training=True):
                    continue

                features = getFeatures(model_type, sample)

                labels = getLabels(model_type, sample)

                if not features:
                    continue

                features = scaleFeatures(features)
                shuffle_array.append(features+labels)

            if shuffle_array:
                shuffle_array = np.array(shuffle_array)
                np.random.shuffle(shuffle_array)

                X,y = retrieveFromShuffle(model_type, shuffle_array)
                yield X, y
                del sample_batch
                gc.collect()

def getSampleGeneratorV2(model_type, training):
    for epoch in range(epochs):
        logging.info('Sample Generator starting epoch %d, Training=%r\n' % (epoch, training))
        last_id = 0
        batch_num = 0

        while last_id < last_random_id:

            sample_batch = getSampleBatchCursor(last_id)
            batch_count = sample_batch.count(with_limit_and_skip=True)

            if not sample_batch or not batch_count:
                continue # no items returned

            batch_num += 1
            # logging.info('Fetched Sample Batch %d\n' % batch_num)
            last_id = sample_batch[batch_count-1]['random_id']

            shuffle_array = []

            for sample in sample_batch:
                # logging.info('evtsource valid %r' % validSample(sample, training=True))
                # logging.info(sample)
                # raise ValueError('stop')
                if not validSample(sample, training=training):
                    continue

                features = getFeatures(model_type, sample)

                label = getLabels(model_type, sample)

                if not features:
                    continue

                features = scaleFeatures(features)

                shuffle_array.append(features+label)

            if shuffle_array:
                shuffle_array = np.array(shuffle_array)
                np.random.shuffle(shuffle_array)

                X,y = retrieveFromShuffle(model_type, shuffle_array)
                yield X, y
                del sample_batch
                gc.collect()

def validSample(sample, training):
    if not sample['evtsource']:
        return False
    if training:
        return sample['evtsource'] in train_sources
    else:
        return not sample['evtsource'] in train_sources


def retrieveFromShuffle(model_type, shuffle_array):
    if model_type == 'subtree':
        X = [a[:-5] for a in shuffle_array]
        y = [a[-5:] for a in shuffle_array]
    elif isSingleModel(model_type):
        X = [a[:-1] for a in shuffle_array]
        y = [a[-1] for a in shuffle_array]
    else:
        raise ValueError('model_type incorrectly specified')

    X = np.array(X)
    X = X.reshape(X.shape[0], 1, X.shape[1])
    y = np.array(y)
    return X,y


def getValidationGenerator(model_type):

    for epoch in range(epochs):
        logging.info('Validation Generator starting epoch %d\n' % epoch)
        # id_index = split_index
        id_index = None
        batch_num = 0
        while True:

            validation_batch = getValidationBatch(id_index)
            batch_count = validation_batch.count(with_limit_and_skip=True)

            if not validation_batch or not batch_count:
                break

            batch_num += 1

            id_index = validation_batch[batch_count-1]['random_id']

            X = []
            y = []

            for sample in validation_batch:

                if not validSample(sample, training=False):
                    continue
                features = getFeatures(model_type, sample)
                labels = getLabels(model_type, sample)

                if not features:
                    continue

                features = scaleFeatures(features)

                X.append(features)
                y.append(labels)
            if X:
                X = np.array(X)
                X = X.reshape(X.shape[0], 1, X.shape[1])
                y = np.array(y)

                yield X, y

def getEvaluationData():

    eval_cursor = getEvalCursor()

def getLabels(model_type, sample):
    if model_type == 'subtree':
        return sample['subtree_label']
    elif model_type == 'node':
        return sample['node_label']
    elif isSingleModel(model_type):
        return getPartLabel(model_type, sample)
    else:
        print 'model type not specified correctly'

def getFeatures(model_type, sample):
    content_embedding = sample['content_embedding']
    html_embedding = sample['html_embedding']
    manual_features = sample['manual_features']
    structure_features = sample['structure_features']
    if not html_embedding or not content_embedding or np.isnan(np.sum(manual_features)):
        return None

    features = []
    if useContent:
        features += list(pickle.loads(content_embedding))
    if useHTML:
        features += list(pickle.loads(html_embedding))
    if useManual:
        features += manual_features
    if useStructure:
        features += structure_features

    return features

def getSampleBatchCursor(index_id):
    if not index_id:
        return Data_Collection.find({}, no_cursor_timeout=True).limit(batch_size).sort('random_id',1)
    query = {
        'random_id': {
            '$gt': index_id
        }
    }

    # return Data_Collection.find({'random_id': {'$lt': last_id}}, no_cursor_timeout=True).limit(batch_size).sort('random_id',-1)
    return Data_Collection.find(query, no_cursor_timeout=True).limit(batch_size).sort('random_id', 1)

def getValidationBatch(index_id):
    if not index_id:
        return Data_Collection.find({}, no_cursor_timeout=True).limit(batch_size).sort('random_id',1)
    query = {
        'random_id': {
            '$gt': index_id
        }
    }
    return Data_Collection.find(query, no_cursor_timeout=True).limit(batch_size).sort('random_id',1)

def getEvalCursor():
    return Eval_Data_Collection.find({}, no_cursor_timeout=True)

def isSingleModel(model_type):
    return model_type in single_models

def getPartLabel(model_type, sample):
    index = single_models.index(model_type)
    subtree_label = math.ceil(sample['subtree_label'][index])

    if sample['single_label'] == model_type:
        return [1]

    if 1.0 > subtree_label > 0.0:
        return [1]

    return [0]

def scaleFeatures(features):
    minScalingFeatures = []
    maxScalingFeatures = []

    if useHTML:
        minScalingFeatures += minFeatures[:100]
        maxScalingFeatures += maxFeatures[:100]

    if useManual:
        minScalingFeatures += minFeatures[100:314]
        maxScalingFeatures += maxFeatures[100:314]

    if useStructure:
        minScalingFeatures += minFeatures[314:]
        maxScalingFeatures += maxFeatures[314:]

    features = list(features)
    for index in range(len(features)):
        denominator = float(maxScalingFeatures[index] - minScalingFeatures[index])
        if not denominator:
            continue
        features[index] = features[index] / denominator
    return features


minFeatures = [-26.86, -25.7, -32.2, -20.78, -25.55, -27.25, -24.75, -28.95, -21.55, -23.33, -34.66, -24.69, -24.3, -42.03, -33.47, -20.84, -25.02, -24.44, -22.7, -32.44, -21.31, -26.64, -21.64, -22.08, -24.94, -41.5, -24.02, -38.22, -27.8, -21.44, -24.11, -15.914, -24.42, -26.47, -20.92, -41.94, -21.42, -19.55, -29.8, -14.01, -21.92, -19.28, -22.8, -15.68, -30.5, -18.77, -19.23, -20.62, -18.84, -26.2, -21.66, -32.47, -20.55, -18.81, -17.0, -20.64, -27.6, -14.9, -21.66, -21.84, -26.14, -13.6, -22.75, -16.06, -21.14, -16.8, -24.81, -18.95, -21.86, -18.8, -13.33, -41.03, -22.97, -23.5, -22.31, -16.86, -21.52, -29.25, -12.73, -20.47, -26.4, -24.94, -26.94, -18.81, -26.23, -20.84, -23.94, -27.9, -18.31, -19.92, -19.94, -17.83, -18.77, -20.94, -17.17, -24.39, -19.66, -22.23, -14.555, -24.62, 0, 7, 0, 2, 0, 0, 0.0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0.0]

maxFeatures = [22.62, 19.2, 13.75, 26.08, 28.25, 18.75, 27.67, 18.33, 23.83, 16.14, 23.81, 21.05, 18.36, 18.67, 24.95, 19.72, 20.98, 19.8, 21.56, 19.67, 24.16, 20.27, 20.66, 24.77, 23.4, 24.89, 50.12, 23.47, 25.89, 25.06, 28.83, 26.39, 24.9, 16.03, 14.8, 41.53, 15.234, 32.28, 23.25, 21.64, 27.0, 21.02, 23.02, 20.19, 20.4, 30.64, 18.33, 19.88, 23.05, 13.66, 26.11, 23.9, 27.31, 23.34, 15.875, 15.45, 27.06, 35.3, 24.23, 16.52, 20.19, 34.56, 22.73, 18.3, 18.69, 20.44, 25.08, 21.16, 20.78, 23.55, 30.75, 19.44, 25.7, 20.36, 15.09, 25.73, 17.8, 23.75, 21.14, 28.9, 16.38, 18.11, 20.1, 29.9, 23.3, 26.86, 17.98, 16.66, 28.78, 23.94, 23.97, 18.72, 31.53, 21.33, 26.06, 19.39, 18.11, 22.84, 30.6, 21.58, 89625, 91593, 16079, 15645, 1, 71.6, 5826.0, 90, 70, 75, 111, 50, 79, 164, 86, 88, 553, 67, 1163, 330, 975, 271, 318, 79, 0, 100, 0, 70, 28, 36, 22, 37, 19, 278, 16, 119, 73, 119, 197, 14, 11, 11, 25, 25, 19, 25, 9, 107, 16, 22, 25, 28, 38, 51, 37, 49, 113, 44, 11, 71, 99, 694, 30, 21, 6, 31, 15, 34, 1, 34, 23, 317, 31, 31, 55, 55, 115, 76, 40, 223, 764, 1383, 22, 47, 160, 9, 6, 120, 113, 45, 112, 112, 25, 335, 8, 52, 2, 10, 5, 5, 3, 39, 24, 269, 2, 50, 5, 0, 0, 18, 1, 3, 0, 16, 0, 0, 506, 10, 155, 0, 0, 13, 2, 15, 14, 0, 11, 50, 57, 34, 58, 13, 0, 15, 1, 69, 87, 0, 26, 1, 542, 2, 0, 0, 0, 0, 8, 0, 324, 197, 1, 5, 38, 240, 0, 13, 0, 8, 25, 24, 154, 25, 82, 93, 0, 50, 72, 1, 4, 191, 6, 13, 105, 110, 20, 90, 72, 15808, 71, 80, 16, 2, 19, 37, 1, 38, 917, 686, 3, 5, 39, 11, 35, 124, 1, 5, 465, 423, 28, 7, 1, 3, 4, 37, 9, 3, 41, 1, 5, 37, 1, 9, 1, 140093, 23, 23, 324, 825, 0.9987893462469734]


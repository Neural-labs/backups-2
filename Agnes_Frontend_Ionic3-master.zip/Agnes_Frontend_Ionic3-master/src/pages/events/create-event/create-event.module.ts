import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { DirectivesModule } from '../../../directives/directives.module';

import { CreateEventPage } from './create-event';

@NgModule({
    declarations: [
        CreateEventPage
    ],
    imports: [
        IonicPageModule.forChild(CreateEventPage),
        DirectivesModule
    ],
    exports: [
        CreateEventPage
    ],
})

export class CreateEventPageModule { }

import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { ComponentsModule } from '../../components/components.module';

import { MapPage } from './map';
import { SuperTabsModule } from 'ionic2-super-tabs';

@NgModule({
  declarations: [
    MapPage
  ],
  imports: [
    IonicPageModule.forChild(MapPage),
    SuperTabsModule,
    ComponentsModule
  ],
  exports: [
    MapPage
  ],
})

export class MapPageModule { }

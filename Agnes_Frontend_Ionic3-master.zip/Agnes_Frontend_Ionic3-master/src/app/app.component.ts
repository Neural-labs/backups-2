import { Component, ViewChild } from '@angular/core';
import { Nav, Platform, AlertController, Events, ModalController, ToastController } from 'ionic-angular';
import { Deploy } from '@ionic/cloud-angular';

import { GroupsService } from '../providers/groups.service';
import { LoginService } from '../providers/login.service';
import { EventsService } from '../providers/events.service';
import { AnalyticsService} from "../providers/analytics.service";
import { PeopleService } from '../providers/people.service';
import { MeService } from '../providers/me.service'
/* native plugins */
import { ActionSheet } from '@ionic-native/action-sheet';
import { Badge } from '@ionic-native/badge';
import { Calendar } from '@ionic-native/calendar';
import { Camera } from '@ionic-native/camera';
import { DatePicker } from '@ionic-native/date-picker';
import { Device } from '@ionic-native/device';
import { Facebook } from '@ionic-native/facebook';
import { Geolocation } from '@ionic-native/geolocation';
import { Keyboard } from '@ionic-native/keyboard';
import { LaunchNavigator } from '@ionic-native/launch-navigator';
import { LocalNotifications } from '@ionic-native/local-notifications';
import { Network } from '@ionic-native/network';
import { PhotoViewer } from '@ionic-native/photo-viewer';
import { Push } from '@ionic-native/push';
import { SocialSharing } from '@ionic-native/social-sharing';
import { SplashScreen } from '@ionic-native/splash-screen';
import { StatusBar } from '@ionic-native/status-bar';
import event = google.maps.event;

declare var cordova: any;

@Component({
  templateUrl: 'app.html',
  providers: [GroupsService, LoginService, EventsService, AnalyticsService, PeopleService, MeService]
})

export class Agnes {
  @ViewChild(Nav) nav: Nav;


  rootPage: any = 'LoginPage';

  user: Object;
  loading: boolean;
  isPaused: boolean;
  deviceToken: any;

  static referralCode: any;
  static alertCtrl: AlertController;
  static API_URL: string;
  static loading: boolean;
  static version: string;
  static eventsService: any;
  static peopleService: any;
  static meService: any;
  static plt: Platform;
  static evts: Events;
  static toastCtrl: ToastController;
  static newChats: Array<any>;


  //natives
  static actionSheet: ActionSheet;
  static badge: Badge;
  static calendar: Calendar;
  static camera: Camera;
  static datePicker: DatePicker;
  static device: Device;
  static facebook: Facebook;
  static geolocation: Geolocation;
  static keyboard: Keyboard;
  static launchNavigator: LaunchNavigator;
  static localNotifications: LocalNotifications;
  static network: Network;
  static photoViewer: PhotoViewer;
  static socialSharing: SocialSharing;
  static splashScreen: SplashScreen;
  static statusBar: StatusBar;
  static modalCtrl: ModalController;



  constructor(public platform: Platform,
              alertCtrl: AlertController,
              public modalCtrl: ModalController,
              public events: Events,
              private groupsService: GroupsService,
              private loginService: LoginService,
              public eventsService: EventsService,
              private analyticsService: AnalyticsService,
              public meService : MeService,
              public peopleService : PeopleService,
              public deploy: Deploy,
              private toastCtrl: ToastController,
              private actionSheet: ActionSheet,
              private badge: Badge,
              private calendar: Calendar,
              private camera: Camera,
              private datePicker: DatePicker,
              private device: Device,
              private facebook: Facebook,
              private geolocation: Geolocation,
              private keyboard: Keyboard,
              private launchNavigator: LaunchNavigator,
              private localNotifications: LocalNotifications,
              private network: Network,
              private photoViewer: PhotoViewer,
              private push: Push,
              private socialSharing: SocialSharing,
              private splashScreen: SplashScreen,
              private statusBar: StatusBar) {

    this.user = JSON.parse(localStorage.getItem("agnesUser"));
    this.loading = false;

    Agnes.newChats = [];
    Agnes.loading = this.loading;
    Agnes.version = '2.6.4';
    Agnes.alertCtrl = alertCtrl;
    Agnes.API_URL = 'https://meetagnes.com/application';
    Agnes.eventsService = this.eventsService;
    Agnes.peopleService = this.peopleService;
    Agnes.meService = this.meService;
    Agnes.plt = this.platform;
    Agnes.evts = this.events;
    Agnes.toastCtrl = this.toastCtrl;
    Agnes.modalCtrl = this.modalCtrl;

    Agnes.actionSheet = this.actionSheet;
    Agnes.badge = this.badge;
    Agnes.calendar = this.calendar;
    Agnes.camera = this.camera;
    Agnes.datePicker = this.datePicker;
    Agnes.device = this.device;
    Agnes.facebook = this.facebook;
    Agnes.geolocation = this.geolocation;
    Agnes.keyboard = this.keyboard;
    Agnes.launchNavigator = this.launchNavigator;
    Agnes.localNotifications = this.localNotifications;
    Agnes.network = this.network;
    Agnes.photoViewer = this.photoViewer;
    Agnes.socialSharing = this.socialSharing;
    Agnes.splashScreen = this.splashScreen;
    Agnes.statusBar = this.statusBar;

    if(this.user){
      this.events.publish('updateUser');
    }

    this.listenForUserUpdate();

    //logout of account
    this.events.subscribe('logout', () => {

      let user = JSON.parse(localStorage.getItem('agnesUser'));
      if(user){
        //send logout analytics
        this.analyticsService.logAnalytics({community: user['community'], users_id: user['_id']}, '/signOut');
      }

      this.resetData();
      this.nav.setRoot('LoginPage');
    });

    //decrease chat badge and remove id from unread chats when chat has been opened
    this.events.subscribe('readChat', (id) => {
      let ind = Agnes.newChats.indexOf(id);
      if (ind != -1) {
        Agnes.newChats.splice(ind,1);
        this.events.publish('updateChatBadge',false);
      }
    });

    this.events.subscribe('loggedIn', () => {
      let extEvent = localStorage.getItem('agnesSharedevent');
      if(extEvent) {
        this.eventsService.getEventsFromId({'evt':[extEvent], 'community': this.user['community']}).then(value => {
          if (value && value['length'] > 0){
            let event = {'event':value[0]};
            let current = localStorage.getItem('agnesCurrentEvent');
            if(!current || (current && (current != event['event']['_id']))){
              this.openEventProfile(event);
            }
          }
          else {
            Agnes.showError('Sorry, the event that was shared with you already happened!');
          }
        }).catch(err => {
          console.log(err);
          Agnes.showError('Sorry, could\'t retrieve the shared event. ' +
              'Try quitting the app and clicking the link again!');
        });
      }

      let extGroup = localStorage.getItem('agnesSharedgroup');
      if(extGroup) {
        this.groupsService.getGroupsFromId({'grp':[extGroup]}).then(value => {
          if (value && value['length'] > 0){
            let group = value[0];
            let current = localStorage.getItem('agnesCurrentGroup');
            if(!current || (current && (current != group['_id']))){
              this.openGroupProfile(group);
            }
          }
          else {
            Agnes.showError('Sorry, the group that was shared with you is not in Agnes\' database!');
          }
        }).catch(err => {
          console.log(err);
          Agnes.showError('Sorry, could\'t retrieve the shared group. Try quitting the app ' +
              'and clicking the link again!');
        });
      }
    });

    this.events.subscribe('updateDeviceId', (uid) => {
      let dev = localStorage.getItem('agnesDevice');
      dev = dev ? dev : '';
      let dName = this.platform.is('android') ? 'android' : (this.platform.is('ios') ? 'ios' : 'wp');
      let userId = uid.id;
      let deviceData = {
        "deviceId": dev,
        "deviceName": dName,
        "users_id": userId
      };

      console.log('device id', deviceData);
      console.log('dev name', dName);

      this.loginService.updateDeviceId(deviceData).then(value => {
      }).catch(err => {
        console.log(err);
      });
    });

    //update home screen icon badge
    this.events.subscribe('changeInNotifCount', (unread) => {
      this.badge.set(unread);
    });

    //listen for scheduled local notifications
    // this.localNotifications.on('trigger',(notification, state) => {
    //   console.log('triggered');
    //   let rating = this.modalCtrl.create(
    //     'AgnesRating',
    //   {
    //     'event': notification.data
    //   });
    //
    //   rating.onDidDismiss(() => {
    //     Agnes.removeFilter();
    //   });
    //
    //   for (var e = 0; e < document.getElementsByTagName("ion-popover").length; e++){
    //     document.getElementsByTagName("ion-popover")[e]["style"]["filter"]="blur(3vw)";
    //   }
    //   document.getElementsByTagName("ng-component")[0]["style"]["filter"]="blur(3vw)";
    //   rating.present();
    //
    // });

    this.initializeApp();

    document.addEventListener('resume', (e) => {
      // let nts = JSON.parse(localStorage.getItem('agnesNotifications'));
      // if(nts){
      //   //process most recent notification (i.e. notification that was clicked on in background)
      //   this.processNotifications(nts[nts.length - 1]);
      // }

      console.log('resume', e);
      this.events.publish('resumeApp')

      this.isPaused = false;

      let user = JSON.parse(localStorage.getItem('agnesUser'));
      if(user) {
        //send Resumed App analytics
        this.analyticsService.logAnalytics({community: this.user['community'], users_id: this.user['_id']},
            '/resumeApp');

          this.loginService.getUser({"users_id":user['_id']}).then(value => {
            this.events.publish('userUpdated',{'user':value});
        }).catch(error =>{
          console.log('resume error',error);
        });
      }
    });

    document.addEventListener('pause', ($event) => {
      this.isPaused = true;

      let user = JSON.parse(localStorage.getItem('agnesUser'));
      if(user) {
        //send Backgrounded App analytics
        this.analyticsService.logAnalytics({community: this.user['community'], users_id: this.user['_id']},
            '/backgroundAppRun');
      }
    });
  }

  listenForUserUpdate(){
    this.events.subscribe('updateUser', () => {
      let user = JSON.parse(localStorage.getItem('agnesUser'));
      this.loginService.getUser({"users_id":user['_id']}).then(value => {
        if(value){
          this.user = value;
          localStorage.setItem('agnesUser',JSON.stringify(this.user));
          this.events.publish('updateDone');
        }
      }).catch(err => {
        this.events.publish('updateUser');
      });
    });
  }

  // Reset User and Device Data
  resetData() {

      this.resetDeviceData();
      this.badge.set(0);
  }

  resetDeviceData() {
      // get variables
      let dName = this.getDeviceName();
      let userId = this.getUserID();
      let deviceData = {
          "deviceId": '',
          "deviceName": dName,
          "users_id": userId
      };

      // update device ID
      this.loginService.updateDeviceId(deviceData)
          .then(value => {

          }).catch(err => {
              console.log(err);
          });
      this.resetLocalStorage()
  }

  getDeviceName(){
      return this.platform.is('android') ? 'android' : (this.platform.is('ios') ? 'ios' : 'wp');
  }

  getUserID(){
      return JSON.parse(localStorage.getItem('agnesUser'))['_id']
  }


  resetLocalStorage() {
      let devID = localStorage.getItem('agnesDevice');
      localStorage.clear()
      localStorage.setItem('agnesDevice',devID);
  }

  initializeApp() {
    this.platform.ready().then(() => {

      //TODO: remove
      this.badge.set(0);


      this.keyboard.hideKeyboardAccessoryBar(false);
      this.keyboard.disableScroll(false);
      this.statusBar.hide();
      // this.statusBar.backgroundColorByHexString('#153A42');
      // this.config.set('ios', 'statusbarPadding', true);

      // android keyboard push up
      this.androidKeyboardPushUp()

      // //watch for internet disconnect
      // let disconnectSubscription = Network.onDisconnect().subscribe(() => {
      //   Agnes.showError('Lost connection!')
      // });



      if(this.platform.is('cordova')){

        this.branchInit()
        //initialize push notification plugin

        let pushObject = this.initPushObject();

        pushObject.on('registration').subscribe(data => {
          console.log('push registration', JSON.stringify(data));
          localStorage.setItem('agnesDevice',data['registrationId']);
          this.deviceToken = data['registrationId'];
        });

        pushObject.on('notification').subscribe(data => {
          console.log('notification log', JSON.stringify(data));

          //increase badge if new non-chat notification or if chat notification from new user (i.e.
          let nts = JSON.parse(localStorage.getItem('agnesNotifications'));
          nts = nts ? nts : [];
          let type = data.additionalData.category == 'IYGIG_sent' ? 'igiyg' : data.additionalData.category;
          let sid = type == 'request' ? 'pending' : type == 'chat' ? 'from' : '_id';

          if (type != 'announcement' && type != 'acceptInvite' && type != 'IYGIG_accept' && type != 'hostedEvent'
              && type != 'admin' && (type != 'chat' || (type == 'chat' &&
              nts.map(a => {return a['from'];}).indexOf(data.additionalData.sender[sid]) == -1))){

            let objID =
                (type == 'request' ? data.additionalData['sender']['_id'] :
                  (type == 'chat' ? data.additionalData['sender']['_id'] :
                    (type == 'invite' ? data.additionalData['sender']['_id'] :
                      (type == 'claim' ? data.additionalData['sender']['_id'] :
                        ((type == 'admin' || type == 'member') ? data.additionalData['sender']['_id'] :
                          data.additionalData['event'] ? data.additionalData['event']['_id'] : '')))));

            if(objID != ''){
              let item = {
                'from': data.additionalData['sender'][sid],
                'obj_id': objID,
                'type': type
              };

              nts.push(item);
              localStorage.setItem('agnesNotifications',JSON.stringify(nts));
              this.badge.increase(1);
            }
          }

          //increase notification count on tabs header
          this.events.publish('gotNewNotif');

          // background notification - increase badge and store in local storage
          if(!data['additionalData'].foreground) {

            //send Pressed Notification analytics
            this.analyticsService.logAnalytics({
              notification_type: data['additionalData']['category'],
              users_id: this.user['_id']}, '/pressedNotificationByUser');


            //open notifications page bc person clicked from background
            if(!localStorage.getItem('notificationsPageOpen')){
              this.nav.push(
                  'NotificationsPage',
                  {}, {
                    animation: 'ios-transition',
                    duration: 350
                  });
            }
          }
          else {
            this.loginService.getUser({"users_id":this.user['_id']}).then(value => {
              if (value) {
                this.user = value;
                localStorage.setItem('agnesUser',JSON.stringify(this.user));
              }
              this.processNotifications(data);
            }).catch(err => {
              console.log('refresh user from notif error',err);
              this.processNotifications(data);
            });
          }

        });
        pushObject.on('error').subscribe(e => {
          console.log('push notification error',e['message']);
        });


        //register device for push notifications only is user is logged in
        if (this.user['_id']) {
          this.events.publish('updateDeviceId',{'id':this.user['_id']});
        }
      }

      //check for updates
      if (this.platform.is('cordova') && this.platform.is('mobile')
        && (this.platform.is('ios') || this.platform.is('android')) && !this.platform.is('mobileweb')){
        this.deploy.check().then((snapshotAvailable: boolean) => {
          console.log('deploy available', snapshotAvailable);
          if (snapshotAvailable) {
            // let updatePopup = this.popoverCtrl.create(
            //   UpdatePopup,
            //   {},
            //   {});
            // updatePopup.present({
            //   animate: true,
            //   animation: 'ios-transition',
            //   duration: 350,
            //   easing: "ease-in-out",
            //   direction: 'forward'
            // });
            this.deploy.download({
            }).then(() => {
              this.deploy.extract({
              }).then(() => {
                let alert = Agnes.alertCtrl.create({
                  title: 'Update Available',
                  message: "An update is available and will be applied once Agnes restarts. " +
                  "Tap 'Restart' to restart now or 'Cancel' to get the update later",
                  buttons: [
                    {
                      text: 'Cancel',
                      handler: () => {
                        Agnes.removeFilter();
                      },
                      role: 'cancel'
                    },
                    {
                      text: 'Restart',
                      handler: () => {
                        this.deploy.load();
                      }
                    }],
                  cssClass: 'deploy'
                });
                for (var e = 0; e < document.getElementsByTagName("ion-popover").length; e++){
                  document.getElementsByTagName("ion-popover")[e]["style"]["filter"]="blur(3vw)";
                }
                document.getElementsByTagName("ng-component")[0]["style"]["filter"]="blur(3vw)";
                alert.present();
              })
            });
          }
        });
      }

      //handle deeplinking
      //this.processDeepLinks();
    });
  }

  branchInit() {
    const Branch = window['Branch'];
    Branch.initSession(data => {
      if (data['+clicked_branch_link']) {
        console.log(data)
        if(data['referralCode']) {
          // read deep link data on click
          Agnes.referralCode = data['referralCode'];
        } else if (data['_id']) {
          if(data['pageNav'] == 'news'){
            this.openNewsProfile(data['object'])
          }
        }
      }
    })
  }

  static getReferalCode() {
    if(Agnes.referralCode) {
      this.evts.publish('referralExists', Agnes.referralCode)
    }
  }


  androidKeyboardPushUp() {
      if(this.platform.is('android')) {

          let y;
          let h;
          let offsetY;

          let tapCoordinates = function(e) {
              y = e.touches[0].clientY;
              h = window.innerHeight;
              offsetY = (h - y);
          };

          let keyboardShowHandler = function(e) {
              let kH = e.keyboardHeight;
              let bodyMove = document.querySelector("ion-app");
              let bodyMoveStyle = bodyMove['style'];

              if (offsetY < kH + 40) {
                  bodyMoveStyle.bottom = (kH - offsetY + 40) + "px";
                  bodyMoveStyle.top = "initial";
              }
          };

          let keyboardHideHandler = function() {
              let removeStyles = document.querySelector("ion-app");
              removeStyles.removeAttribute("style");
          };

          window.addEventListener('native.keyboardshow', keyboardShowHandler);
          window.addEventListener('native.keyboardhide', keyboardHideHandler);
          window.addEventListener('touchstart', tapCoordinates);

      }
  }

  initPushObject() {
      return this.push.init({
          android: {
              icon: 'icon',
              senderID: '327356857183',
              sound: true,
              vibrate: true
          },
          ios: {
              alert: 'true',
              badge: true,
              sound: 'true'
          },
          windows: {}
      });
  }

  processNotifications(data){
    let type = data.additionalData['category'];

    if(type == 'chat') {
      this.processChatNotification(data);
    }
    else {
      //update notification badge on me tab
      if(type != 'admin' && type != 'member'){
        this.events.publish('updateMeBadge', true);
      }

      //update group profile if notification is accept group invite
      if(type == 'acceptInvite'){
        this.events.publish('newMemberAccept',[data.additionalData['accept']]);
      }

      //update group profile if notification is admin promotion
      if(type == 'admin'){
        this.events.publish('adminPromotion', data['additionalData']['sender']['_id']);
      }

      if(type == 'member') {
        this.events.publish('reqAcceptedNewMember', data['additionalData']['sender']['_id']);
      }

      //update notifications
      this.events.publish('refreshNotifications');

      let message = data.title + '\n' + data.message;
      let notifToast = this.toastCtrl.create({
        message: '',
        position:'top',
        cssClass: 'notification',
        duration: 2500,
        showCloseButton: true,
        closeButtonText: message
      });

      notifToast.present();
      notifToast.onDidDismiss((event,role)=>{
        //add event to calendar if message if IGIYG accept
        if(type == 'IYGIG_accept' || type == 'hostedEvent') {

          this.eventsService.getEventsFromId({
            'evt':[data.additionalData['event']['_id']],
            'community': this.user['community']
          }).then(val => {
            if(val){
              let event = val[0];
              Agnes.going(event,false);

              if(type == 'hostedEvent'){
                //refresh groups
                let eData = {
                  eventID: data.additionalData['event']['_id'],
                  groupID: data.additionalData['group']['_id']
                };
                this.events.publish('eventHosted', eData);
              }

              if(role == 'close') {
                this.openEventProfile(event);
              }
            }
          }).catch(err => {
            console.log('get event from igiyg accept err', err);
          });
        }
        else {
          if(role == 'close'){

            if (type == 'announcement' || type == 'acceptInvite' || type == 'admin' || type == 'member'){
              let grp = (type == 'announcement' ? data.additionalData['group'] : data.additionalData['sender']);

              let grpPromise = null;
              if(type == 'announcement') {
                grpPromise = this.groupsService.getGroupsFromId({'grp':[grp['_id']]});
              }

              Promise.all([grpPromise]).then(val => {
                let canOpen = true;
                if(grpPromise && val) {

                  if(val[0] && val[0][0]) {
                    grp = val[0][0];
                  }
                  else {
                    canOpen = false;
                    Agnes.showError('Could not open this group profile - try checking it out in My Groups');
                  }
                }

                //open group profile
                if(canOpen){
                  this.openGroupProfile(grp);
                }

              }).catch(err => {
                console.log(err);
                Agnes.showError('Could not open this group profile - try checking it out in My Groups');
              });
            }
            else {
              //go to notification tab
              this.events.publish('closeProfiles');
              this.events.publish('toMeTab', {'toNotifs':true,'notification':data});
            }
          }
        }
      });
    }
  }

  processChatNotification(data){

    let currentChat = localStorage.getItem('agnesChat');

    //user is currently chatting w/ person who just sent message
    if (currentChat == data.additionalData['sender']['_id']) {
      this.events.publish('messageReceived',data.additionalData);
    }
    else {

      if(Agnes.newChats.indexOf(data.additionalData['sender']['_id']) == -1){
        Agnes.newChats.push(data.additionalData['sender']['_id']);
      }
      this.events.publish('updateChatBadge', true);

      //user clicks notification outside of app - go to chat w/ sender
      if (!data.additionalData.foreground) {

        //increase badge count
        //Badge.increase(1);

        //user is chatting w/ someone else - close that chat first
        if (currentChat) {
          this.events.publish('closeCurrentChat',currentChat);
        }
        this.goToChat(data.additionalData['sender']);
      }

      else {

        //user is on chat list page (and not in a chat profile from that page) - update chat list
        if(localStorage.getItem('inChat') == 'true' && !currentChat) {
          this.events.publish('updateChatList',data);
        }

        let chatToast = this.toastCtrl.create({
          message: '',
          position:'top',
          cssClass: 'notification',
          duration: 2500,
          showCloseButton: true,
          closeButtonText: data.additionalData['sender']['fname'] + ' ' + data.additionalData['sender']['lname'] + '\n' + data.message
        });
        chatToast.present();
        chatToast.onDidDismiss((event,role)=>{
          if(role == 'close'){
            if (currentChat) {
              this.events.publish('closeCurrentChat',currentChat);
            }
            this.goToChat(data.additionalData['sender']);
          }
        });
      }
    }

  }

  processIYGIG(data){
    if(data.additionalData['category'] == 'IYGIG_accept') {
      Agnes.alertCtrl.create({
        title: 'I\'m in!',
        message:  data.message,
        cssClass: "error",
        enableBackdropDismiss: false,
        buttons: [
          {
            text: 'OK',
            handler: () => {
              Agnes.removeFilter();
              let event = data.additionalData['event'];
              this.eventsService.getEventsFromId({
                'evt':[event['id']],
                'community': this.user['community']
              }).then(val => {
                if (val && val['length'] > 0) {
                  Agnes.going(val[0],false);
                }
                else {
                  Agnes.showError('Sorry, tried adding ' + event['evtname'] + ' to your calendar but it looks like ' +
                    'it no longer exists or already happened!');
                }
              }).catch(err => {
                console.log(err);
                Agnes.showError('Sorry, could\'t add this event to your calendar - try searching ' +
                  'and adding it manually!');
              });
            }
          }
        ]
      }).present();
    }
    //no IGIYG popup anymore, now handled in chat
    else {
      this.processChatNotification(data);
    }
  }

  //open event profile from notification click / deep link
  openEventProfile(event) {
    if (event['_id'] != localStorage.getItem('agnesCurrentEvent')){
      this.nav.push(
        'EventProfile',
        {
          'event':event,
          'user':this.user,
          'type':'notification'
        }, {
          animation: 'ios-transition',
          duration: 350
        });
    }
  }

  //open news article from notification click / deep link
  openNewsProfile(article) {
    if (article['_id'] != localStorage.getItem('agnesCurrentEvent')){
      this.nav.push(
        'NewsProfile',
        {
          'newsItem':article,
          'user':this.user,
        }, {
          animation: 'ios-transition',
          duration: 350
        });
    }
  }



  //open group profile from notification click / deep link
  openGroupProfile(group){

    if(group['_id'] != localStorage.getItem('agnesCurrentGroup')){
      this.loading = true;
      this.groupsService.getGroupsFromId({'grp':[group['_id']]}).then(val =>{
        this.loading = false;
        if(val && val.length > 0){
          this.nav.push(
              'GroupProfile',
              {
                'group':val[0],
                'user':this.user,
                'type': 'notification'
              }, {
                animation: 'ios-transition',
                duration: 350
              });
        }
        else {
          Agnes.showError("Sorry, couldn't open this group profile!");
        }
      }).catch(err => {
        console.log(err);
        this.loading = false;
        Agnes.showError("Sorry, couldn't open this group profile!");
      });
    }
  }

  //open chat profile from notification click
  goToChat(user) {

    this.nav.push(
      'ChatProfile',
      {
        'channel': user,
        'newChat': true
      }, {
        animation: 'ios-transition',
        duration: 350
      });
  }

  /**************************************************************************************************************/
  /**************************************************************************************************************/
  /*************************************************STATIC METHODS***********************************************/
  /**************************************************************************************************************/
  /**************************************************************************************************************/

  static processGMT(date){
    let x = new Date(date);
    let d = new Date(x.toLocaleDateString()).toDateString().match(/[a-zA-Z]{3} [a-zA-Z]{3} \d\d/)[0];
    d = d.replace(/([a-zA-Z]{3})(\s[a-zA-Z]{3}\s)(\d{2})/, "$1,$2$3");
    d = d.replace(',','.');
    let t = x.toLocaleTimeString().replace(/:\d\d\s/,'').replace(/\s[a-zA-Z]{3}/,'');
    return {'date':d, 'time': t};
  }

  static showError(message, buttons?, full?, fb?, hasIcons?, keywordsList?, selectedKeywords?){
    let agnesAlert = this.modalCtrl.create('AgnesAlert',
        {
          alertMessage: message,
          alertButtons: buttons,
          fullButtons: full,
          keywordsList: keywordsList,
          hasFbButton: fb,
          hasIcons: hasIcons,
          selectedKeywords: selectedKeywords
        });
    agnesAlert.onDidDismiss(() => {
      Agnes.removeFilter();
    });

    for (var e = 0; e < document.getElementsByTagName("ion-popover").length; e++){
      document.getElementsByTagName("ion-popover")[e]["style"]["filter"]="blur(3vw)";
    }
    document.getElementsByTagName("ng-component")[0]["style"]["filter"]="blur(3vw)";
    agnesAlert.present();
  }

  static removeFilter(){
    for (var e = 0; e < document.getElementsByTagName("ion-popover").length; e++){
      document.getElementsByTagName("ion-popover")[e]["style"]["filter"]="none";
    }
    document.getElementsByTagName("ng-component")[0]["style"]["filter"]="none";
  }

  static hasPlugins() {
    return this.plt.is('cordova');
  }

  static getNewChats(){
    return this.newChats;
  }

  static shareOutside(type, id) {
    if (this.plt.is('cordova')) {
      this.meService.createDeepLink({'entityType' : type, 'entityId': id}).then(val => {
        let link = val['deepLinkUrl']['url']
        let message = "Check out this " + (type == 'news' ? "news article" : (type == 'event' ?  "event" : "group"))
            + " from the new Agnes app!\n\n" + link;
        let subj = type + " on Agnes: A New Campus App!";

        Agnes.socialSharing.share(message, subj, '', '')
            .then((val) => {
            })
            .catch((err) => {
                Agnes.showError("Couldn't share right now, try again!");
            });
      }).catch(err => {
        console.log(err)
      })
    }
    else {
        Agnes.showError("Please install Agnes from the App Store or Google Play store to share this item.");
    }
  }

  /********************************************************************************************/
  /**************************** ATTEND EVENT FUNCTIONS ****************************************/
  /********************************************************************************************/

  static going(event, matched, additionalUser?){

    let user = JSON.parse(localStorage.getItem('agnesUser'));
    let flaginfo = {
      "users_id": user['_id'],
      "events_id": event['_id'],
      "flag": 1,
      "matched": matched
    };

    this.loading = true;

    this.eventsService.sendFlag(flaginfo)
      .then(value => this.setAttendance(event, value, flaginfo, matched))
      .catch( error => {
        this.loading = false;
        this.showError("Sorry, could not add " + event['evtname'] + " to your attended events list right now - try again later!");
        if(!additionalUser) {
          this.loading = false;
          this.evts.publish('goingDone',false);
        }
      });

    if(additionalUser){
      let addFlagInfo= {
        "users_id": additionalUser,
        "events_id": event['_id'],
        "flag": 1,
        "matched": matched
      };
      this.eventsService.sendFlag(addFlagInfo)
      .then(value => this.setAttendance(event, value, addFlagInfo,matched))
      .catch( error => {
        this.loading = false;
        this.evts.publish('goingDone',false);
      });
    }
  }

  static setAttendance(event, value, flaginfo, matched){

    let currUser = JSON.parse(localStorage.getItem('agnesUser'));

    if (value==0){
      this.eventsService.attendEvent(flaginfo)
        .then(attendResult => {
            if(currUser['_id'] != flaginfo['users_id']) {
              this.peopleService.getUsersFromIds({'users': flaginfo['users_id']}).then(u => {
                let user = u[0];
                this.goingResponse(attendResult,event,matched,user,false)
              })
            } else {
              this.goingResponse(attendResult,event,matched,currUser,true);
            }
        })
        .catch(error => {
          console.log(error);
          this.evts.publish('goingDone',false);});
    }
    else {
      this.loading = false;
      let template = "Sorry, could not add " + event['evtname'] + " to your attended events list right now - try again later!";
      this.showError(template);
      this.evts.publish('goingDone',false);
    }
  }

  static goingResponse(attendResult,event,matched, user?, me?){


    if(!user){
      user = JSON.parse(localStorage.getItem('agnesUser'));
    }

    this.evts.publish('updateUser');

    if (attendResult.indexOf('SUCCESS')!=-1) {
      user['evtrsvp'].push(event['_id']);

      localStorage.removeItem('agnesMatchedEvents');
      localStorage.removeItem('agnesEventsTimeout');

      if (this.plt.is('cordova')) {
        this.addToCalendar(event, matched);
        console.log("cordova");
      }
      else if(me == true) {
        this.loading = false;
        let toast = this.toastCtrl.create({
          message: event['evtname'] + ' was successfully added to your events',
          position:'top',
          showCloseButton: true,
          closeButtonText: ' ',
          duration: 2500
        });
        toast.present();
        console.log("presenting going toast");
        this.evts.publish('goingDone',event);
      }
    }
    else {
      this.loading = false;
      let message = "Sorry, could not add " + event['evtname'] + " to your attended events list right now - please try again!";
      this.showError(message);
      this.evts.publish('goingDone',false);
    }
  }

  static addToCalendar(event, matched){
    let t = event['evtname'];
    let title = t.replace(/\s+/g, ' ');
    let eventloc = event['location'];
    let eventLocation = eventloc.replace(/\s+/g, ' ');
    let n = event['evtdesc'];
    let notes = n.replace(/\s+/g, ' ').substring(0,2000);

    let startDate = new Date(event['starttime'].replace(/[-\+]\d\d\d\d/,'Z'));
    let endDate = new Date(event['endtime'].replace(/[-\+]\d\d\d\d/,'Z'));

    this.calendar.findEvent(title,'','',startDate,endDate).then(message => {
      if (message['length'] == 0){
        //event is not in calendar - add
        this.calendar.createEvent(title,eventLocation,notes,startDate,endDate).then(msg => {
          this.loading = false;

          //make sure user is updated
          let user = JSON.parse(localStorage.getItem('agnesUser'));
          if(user['evtrsvp'].indexOf(event['_id']) == -1) {
            user['evtrsvp'].push(event['_id']);
            localStorage.setItem('agnesUser',JSON.stringify(user));
          }

          this.evts.publish('goingDone',event);

          let toast = this.toastCtrl.create({
            message: event['evtname'] + ' was successfully added to your calendar',
            position:'top',
            showCloseButton: true,
            closeButtonText: ' ',
            duration: 2500
          });
          toast.present();
          console.log("presenting calendar toast");

          let inFive = new Date(new Date().getTime() + 5000);

          // Schedule local notification for rating
          // this.localNotifications.schedule({
          //   text: '',
          //   at: inFive,
          //   data: event
          // });

        }).catch(err => {
          this.loading = false;
          Agnes.showError("This event was successfully added to your list of events but there was a problem adding " +
            "it to your calendar - please try again!");
        });
      }
      else {
        //event is already in calendar - just show event add success message
        this.loading = false;
        let toast = this.toastCtrl.create({
          message: event['evtname'] + ' was successfully added to your events',
          position:'top',
          showCloseButton: true,
          closeButtonText: ' ',
          duration: 2500
        });
        toast.present();

        //make sure user is updated
        let user = JSON.parse(localStorage.getItem('agnesUser'));
        if(user['evtrsvp'].indexOf(event['_id']) == -1) {
          user['evtrsvp'].push(event['_id']);
          localStorage.setItem('agnesUser',JSON.stringify(user));
        }

        this.evts.publish('goingDone',event);
      }
    }).catch(err => {
      Agnes.showError("This event was successfully added to your list of events but " +
        "there was a problem adding it to your calendar - make sure Agnes has calendar access and try again!");
      this.loading = false;
      this.evts.publish('goingDone',event);
    });
  }

  /*****************************************************************************************************/
  /**************************** UNATTEND/REMOVE EVENT FUNCTIONS ****************************************/
  /*****************************************************************************************************/

  static notGoing(event, matched){
    let user = JSON.parse(localStorage.getItem('agnesUser'));
    let eventFlag = (user["evtrsvp"].indexOf(event['_id']) != -1) ? 0 : -1;

    //send flag that user is not attending
    //flag is -1 if user has not indicated he/she wants to attend (delete event from events list)
    //flag is 0 if user did want to attend but has changed his/her mind (leave event in events list, remove 'going' indicator)
    let flagInfo = {
      "users_id": user["_id"],
      "events_id": event['_id'],
      "flag": eventFlag,
      "matched": matched
    };

    this.eventsService.sendFlag(flagInfo)
      .then(value => {
        //user was previously going to attend event, so set unattendance
        if (flagInfo.flag == 0) {
          this.setUnattend(value, flagInfo,event, matched);
        }
        //user was never going to attend, skip setting unattendance
        else {
          this.nopeResponse('SUCCESS', flagInfo.flag, event, matched);
        }
      })
      .catch(error => {
        console.log(error);
        Agnes.showError("Sorry, could not remove " + event['evtname'] + " from your attended events list right now " +
          "- try again later!");
      });
  }

  static setUnattend(value, flagInfo, event, matched) {
    if (value == 0) {
      this.eventsService.unattendEvent(flagInfo)
        .then(attendResult => this.nopeResponse(attendResult, flagInfo['flag'], event, matched))
        .catch(error => {
          console.log(error)
        });
    }
    else {
      let template = "There was a problem removing this event, so you may still see it on your events list in the " +
        "future. Try removing it later if you do!";
      Agnes.showError(template);
    }
  }

  static nopeResponse(attendResult, eventFlag, event, matched) {
    let user = JSON.parse(localStorage.getItem('agnesUser'));

    if (attendResult.indexOf('SUCCESS') != -1) {

      let ind = user['evtrsvp'].indexOf(event["_id"]);

      //remove event from user's evtrsvp if user was previously going to attend event
      if (ind != -1) {
        user['evtrsvp'].splice(ind, 1);
        localStorage.setItem('agnesUser',JSON.stringify(user));
        this.evts.publish('updateUser');
      }

        //remove event from user's displayed matched events
        this.evts.publish('removeFromMatched', event);

      if (this.plt.is('cordova') && eventFlag == 0) {
        this.removeFromCalendar(event, eventFlag, matched);
      }
      else {
        this.evts.publish('notGoingDone',event);
        let toast = this.toastCtrl.create({
          message: event['evtname'] + ' was successfully removed from your events',
          position: 'top',
          showCloseButton: true,
          closeButtonText: ' ',
          duration: 2500
        });
        toast.present();
      }
    }
    else {
      let template = "There was a problem removing this event, so you may still see it on your events list in the " +
        "future. Try removing it later if you do!";
      Agnes.showError(template);
    }
  }

  static removeFromCalendar(event, eventFlag, matched) {

    let title = event.evtname.replace(/\s+/g, ' ');

    let startDate = new Date(event['starttime'].replace(/[-\+]\d\d\d\d/, 'Z'));
    let endDate = new Date(event['endtime'].replace(/[-\+]\d\d\d\d/, 'Z'));
    endDate.setDate(endDate.getDate() + 1);

    this.calendar.deleteEvent(title, '', '', startDate, endDate).then(message => {
      let popupMessage = event.evtname + " was removed from your " + (message ? "calendar" : "event list") + "!";

      this.evts.publish('notGoingDone',event);

      let toast = this.toastCtrl.create({
        message: popupMessage,
        position: 'top',
        showCloseButton: true,
        closeButtonText: ' ',
        duration: 2500
      });
      toast.present();
    }).catch(err => {
      Agnes.showError(event['evtname'] +
          " was removed from your event list but there was a problem deleting it from your calendar.");
      this.evts.publish('notGoingDone', event);
    });
  }

  static undoNope(event, eventFlag, matched) {
    let user = JSON.parse(localStorage.getItem('agnesUser'));

    //user was undecided about event, reset event flag to 0
    if (eventFlag == -1) {
      let flaginfo = {
        "users_id": user['_id'],
        "events_id": event['_id'],
        "flag": 0,
        "matched": true
      };

      this.eventsService.sendFlag(flaginfo)
        .then(value => {
          this.evts.publish('pushEvent', event);
        })
        .catch(error => {
          console.log(error);
          Agnes.showError("Sorry, could not add " + event['evtname'] +
              " back into your events list right now - please try again!");
        });
    }
    //user was going to attend event, add event back into user's rsvp list and update event attendance count
    else {
      this.going(event, matched);
    }
  }
}

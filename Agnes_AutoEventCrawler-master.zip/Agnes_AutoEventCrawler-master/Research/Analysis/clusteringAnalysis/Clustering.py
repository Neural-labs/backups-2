from Analysis.detectionAnalysis import DetectionTesting, DetectionTraining
from sklearn.cluster import DBSCAN
from sklearn.neighbors import DistanceMetric
from sklearn.metrics.pairwise import euclidean_distances
from config import db_config
import logging
import pickle
import gc
from collections import Counter
import random
import numpy as np
from sklearn.metrics import log_loss, mean_squared_error, roc_auc_score, r2_score


Agnes = db_config.getDBConn('dev').Agnes
Events_Collection = Agnes.autocrawler_events
Domain_Collection = Agnes.autocrawler_domain_pages
Data_Collection = Agnes.autocrawler_id_data

batch_size = 100

# community = 'gwu'
# evtsources = ['browse.calendar.gwu.edu']

community = 'cornell'
evtsources = ['events.cornell.edu', 'cinema.cornell.edu']

# community = 'american'
# evtsources = ['american.edu']

# community = 'bu'
# evtsources = ['bu.edu']

# community = 'harvard'
# evtsources = ['harvardartmuseums.org', 'history.fas.harvard.edu', 'peabody.harvard.edu', 'edportal.harvard.edu', 'gsas.harvard.edu', 'daviscenter.fas.harvard.edu', 'cellbio.med.harvard.edu', 'my.arboretum.harvard.edu', 'memorialchurch.harvard.edu', 'ves.fas.harvard.edu', 'philosophy.fas.harvard.edu', 'economics.harvard.edu', 'linguistics.fas.harvard.edu', 'ces.fas.harvard.edu', 'ofa.fas.harvard.edu', 'green.harvard.edu', 'radcliffe.harvard.edu', 'hls.harvard.edu', 'gsd.harvard.edu', 'slavic.fas.harvard.edu', 'histsci.fas.harvard.edu', 'psychology.fas.harvard.edu', 'environment.harvard.edu', 'caps.gov.harvard.edu', 'statistics.fas.harvard.edu', 'sociology.fas.harvard.edu', 'anthropology.fas.harvard.edu', 'harvard-yenching.org', 'chemistry.harvard.edu']

def runClustering(detect):
    print 'Running Clustering on mongodb data using community = ',community
    cluster_data, id_data, samples = getData(detect)

    # metric = DistanceMetric.get_metric('mahalanobis', V=np.cov(X))
    # metric = DistanceMetric.get_metric('euclidean')
    metric = 'euclidean'

    algorithm = 'auto'

    # for eps in np.arange(.1,.7,.1):
    #     for min_samples in range(5,10):

    ep_samples = [(0.5, 5), (0.1, 20)]

    for eps, min_samples in ep_samples:

        print 'Eps =',eps, 'min_samples=',min_samples,'algorithm:',algorithm,'metric:',metric

        clusterer = DBSCAN(eps=eps,
                           min_samples=min_samples,
                           metric=metric,
                           metric_params=None,
                           algorithm=algorithm,
                           leaf_size=30,
                           p=None,
                           n_jobs=1)

        print 'Getting clusters...'
        clusters = clusterer.fit_predict(cluster_data)

        if detect:
            # printStats(id_data, samples, clusters)
            runDetection(id_data, samples, clusters)
        else:
            printStats(id_data, samples, clusters)
        print

def runDetection(id_data, samples, clusters):

    cluster_preds = {}

    general_clusters = {}

    cluster_samples = {}

    preds = DetectionTesting.testModelOnData(community, id_data)

    cluster_counts = Counter()

    for index in range(len(clusters)):

        cluster = clusters[index]
        sample = samples[index]
        prediction = preds[index]

        if cluster in cluster_preds:
            cluster_preds[cluster].append(prediction)
        else:
            cluster_preds[cluster] = [prediction]

        cluster_counts[cluster] += 1

        if cluster in general_clusters:
            general_clusters[cluster].append(sample['label'])
        else:
            general_clusters[cluster] = [sample['label']]

        if cluster in cluster_samples:
            cluster_samples[cluster].append(sample)
        else:
            cluster_samples[cluster] = [sample]

    print 'Average Predictions:'
    for cluster in cluster_preds:
        cluster_labels = general_clusters[cluster]
        pos_count = cluster_labels.count(1)
        neg_count = cluster_labels.count(0)

        samples = cluster_samples[cluster]
        cluster_evtsources = set([sample['evtsource'] for sample in samples if sample['label']])

        preds = cluster_preds[cluster]

        # denominator = float(cluster_counts[cluster])
        # cluster_preds[cluster] /= denominator
        # print cluster_preds[cluster][:5]
        if np.mean(cluster_preds[cluster]) > 0.01:
            accent = '<<<<<<<<<<'
        else:
            accent = ''
        print 'cluster:',cluster,'avg_pred:',np.mean(preds),'pos_items:',pos_count,'neg_items:',neg_count,accent
        if pos_count:
            print 'Evtsources:', cluster_evtsources
            if neg_count:
                print 'Binary CrossEntropy:', log_loss(cluster_labels, preds)
                print 'ROC AUC score:', roc_auc_score(cluster_labels, preds)
            print 'Mean Squared Error:', mean_squared_error(cluster_labels, preds)
            print 'R2 Score:',r2_score(cluster_labels, preds)
            print
        if accent:
            for sample in samples[:5]:
                print sample['event_id']


def falsePosNeg(y_true, y_pred):
    FP = 0
    FN = 0
    for index in range(len(y_true)):
        if y_true and not y_pred:
            FN += 1
        if not y_true and y_pred:
            FP += 1

def printStats(id_data, samples, clusters):

    general_clusters = {}
    cluster_samples = {}

    for index in range(len(clusters)):
        data_item = id_data[index]
        sample = samples[index]
        cluster = clusters[index]

        # if sample['evtsource'] in evtsources:
        #     browse_clusters[cluster].append(data_item['label'])

        if cluster in general_clusters:
            general_clusters[cluster].append(sample['label'])
        else:
            general_clusters[cluster] = [sample['label']]

        if cluster in cluster_samples:
            cluster_samples[cluster].append(sample)
        else:
            cluster_samples[cluster] = [sample]

    print 'General Clusters:'
    for cluster in sorted(general_clusters.keys()):
        cluster_labels = general_clusters[cluster]
        samples = cluster_samples[cluster]
        cluster_evtsources = set([sample['evtsource'] for sample in samples if sample['label']])

        pos_count = cluster_labels.count(1)
        neg_count = cluster_labels.count(0)

        if pos_count:
            print 'Cluster', cluster, ' Counts -  Pos:', pos_count, 'Neg:', neg_count,'Evtsources:',cluster_evtsources

        # count = 0

        # if pos_count:
        #     for sample in samples:
        #         if count == 10:
        #             break
        #         if sample['label']:
        #             print sample['event_id'], sample['evtsource']
        #             count += 1


def getData(detect):

    last_id = 0
    cluster_data = []
    id_data = []
    samples = []
    counter = 0
    while True:

        sample_batch = getSampleBatchCursor(last_id, detect)
        batch_count = sample_batch.count(with_limit_and_skip=True)

        if not sample_batch or not batch_count:
            logging.info('Sample Generator finished')
            break

        last_id = sample_batch[batch_count-1]['random_id']

        for data_item in sample_batch:
            counter += 1
            if counter % 1000 == 0:
                print 'Counter: ',counter, 'Samples:',len(cluster_data),'last_id',last_id

            if detect:
                id_features = getIdFeatures(data_item)
            else:
                id_features = -1
            if not valid(data_item, id_features):
                continue

            cluster_data.append(getClusterFeatures(data_item))

            id_data.append(id_features)

            samples.append(data_item)

        del sample_batch
        gc.collect()

    if detect:
        id_data = DetectionTraining.reshapeData(id_data)

    return cluster_data, id_data, samples

def getClusterFeatures(sample):
    features = []
    features += getHTMLEmbedding(sample)
    features += getCharEmbedding(sample)

    return features


def getIdFeatures(sample):
    return DetectionTraining.getFeatures(sample)

def getCharEmbedding(data_item):
    char_embedding = list(pickle.loads(data_item['url_embedding']))
    return char_embedding

def getHTMLEmbedding(data_item):
    html_embedding = list(pickle.loads(data_item['html_embedding']))
    return html_embedding


def valid(data_item, id_features):
    if not id_features:
        return False
    if not data_item['label']:
        return data_item['community'] == community
    else:
        return data_item['evtsource'] in evtsources
    # return data_item['community'] == community or data_item['evtsource'] in evtsources

def getSampleBatchCursor(last_id, detect):
    if detect:
        return_fields = {
            'url_embedding':1,
            'html_embedding':1,
            'content_embedding':1,
            'manual_features':1,
            'evtsource':1,
            'event_id':1,
            'community':1,
            'label':1,
            'random_id':1
        }
    else:
        return_fields = {
            'html_embedding': 1,
            'url_embedding':1,
            'evtsource': 1,
            'community': 1,
            'event_id':1,
            'label': 1,
            'random_id': 1
        }
    return Data_Collection.find({'random_id': {'$gt': last_id}, 'community':community },return_fields, no_cursor_timeout=True).limit(batch_size).sort('random_id', 1)




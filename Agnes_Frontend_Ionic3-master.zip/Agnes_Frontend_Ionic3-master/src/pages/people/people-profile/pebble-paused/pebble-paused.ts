import { Component, ViewChild } from '@angular/core';
import { Platform, NavParams, PopoverController, ToastController,
  ActionSheetController, NavController, Events, IonicPage, Slides} from 'ionic-angular';

import { MeService } from '../../../../providers/me.service';

import {PeopleService} from '../../../../providers/people.service'

import { Agnes } from '../../../../app/app.component';



@IonicPage()
@Component({
  selector: 'pebble-paused',
  templateUrl: 'pebble-paused.html',
  providers: [MeService, PeopleService]

})

export class PebblePaused {

  user:Object;
  person: Object;
  isMe: boolean;
  image:string;
  orientation: string;
  fullscreen: boolean;
  spinner: boolean;
  daysLeft: number;
  totalDays: number;

  constructor(private navParams: NavParams,
              public navCtrl: NavController,
              private meService: MeService,
              private peopleService: PeopleService,
              private events: Events,
              private platform: Platform) {
  }

  ngOnInit(){
    this.user = JSON.parse(localStorage.getItem('agnesUser'));
    this.person = this.navParams.get('person');
    this.isMe = this.navParams.get('isMe');
    this.daysLeft = this.navParams.get('daysLeft');
    this.totalDays = this.navParams.get('totalDays');
  }

  imgLoad(ev){
    let img = ev.target;
    if (img.naturalWidth > img.naturalHeight) {
      this.orientation = 'landscape';
    } else if (img.naturalWidth < img.naturalHeight) {
      this.orientation = 'portrait';
    } else {
      this.orientation = 'even';
    }
    this.fullscreen = true;
    this.spinner = false;
  }

  imgError(ev){
    this.fullscreen = false;
    this.spinner = false;
  }

  closePebblePaused() {
    this.navCtrl.pop({
        animation: 'ios-transition',
        duration: 350,
        easing: "ease-in-out",
        direction: "back"
    })
  }
}

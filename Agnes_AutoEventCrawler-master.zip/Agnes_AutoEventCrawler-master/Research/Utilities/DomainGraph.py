"""
DomainGraph Class - models the webpage interconnection of a domain

Types:
Click-Graph - Each node is added as it is 'clicked' on by the scrapy crawler
URL-Graph - Each node is added to the parent based on whether it extends the parent url or not

"""

import networkx as nx
import urlparse

class DomainGraph:

    def __init__(self, graph_type):
        self.graph_type = graph_type
        self.Graph = nx.DiGraph()
        self.root = None

    def add_root(self, root_url):
        self.Graph.add_node(root_url)
        self.root = root_url

    def get_root(self):
        if self.root:
            return self.Graph.nodes()[self.root]
        else:
            return None

    def add_node(self, nodeID, parentID, nodeData=None):
        self.Graph.add_node(nodeID, attr_dict=nodeData)
        if not parentID is None:
            assert parentID is not None
            if type(nodeID) == dict or type(parentID) == dict:
                print 'nodeid',nodeID
                print 'parentid',parentID
            self.Graph.add_edge(u=parentID, v=nodeID)

    def get_nodes(self):
        return [(n,d) for n,d in self.Graph.nodes(data=True)]

    def get_node_data(self, nodeID):
        return self.Graph.nodes(data=True)[nodeID]

    def in_graph(self,nodeID):
        return nodeID in self.Graph.nodes()

    def add_new_url_node(self, node_paths):
        if self.in_graph(node_paths[-1]):
            return

        path_root = node_paths[0]

        # if path root not in graph, attach new path to root
        if not self.in_graph(path_root):
            self.add_node(self.root, path_root, None)

            for index in range(len(node_paths)):
                if index > 0:
                    subpath = node_paths[index]
                    self.add_node(subpath, node_paths[index-1])
        else:
            for index in range(len(node_paths)):
                subpath = node_paths[index]
                if not self.in_graph(subpath):
                    self.add_node(subpath, node_paths[index-1])

    def add_new_crawl_node(self, nodeID, parentID):
        if self.in_graph(nodeID):
            return
        self.add_node(nodeID, parentID)

    def add_new_node(self,nodeID,parentID):
        if self.graph_type == 'url':
            parsed_url = urlparse.urlparse(nodeID)
            path_list = getPathList(parsed_url)
            self.add_new_url_node(path_list)
        elif self.graph_type == 'click':
            self.add_new_crawl_node(nodeID,parentID)

    def add_data_to_node(self,nodeID,data):
        node_data = self.Graph.nodes()[nodeID]['attr_dict']
        for key in data:
            node_data[key] = data[key]

    def get_depth(self, nodeID):
        return len(nx.shortest_path(self.Graph, source=self.root, target=nodeID))

    def write_to_file(self, Domain):
        fname = 'Data/DomainGraph/'+Domain + "_" + self.graph_type + '_Graph.P'
        nx.write_gpickle(self.Graph, fname)

    def read_from_file(self,pickle_file):
        return nx.read_gpickle(pickle_file)


def getPathList(parsed_url):
    paths_separate = [url for url in parsed_url.path.split('/') if url]
    path_root = parsed_url.scheme + "://" + parsed_url.netloc
    path_list = [path_root]
    path_sum = ''
    for subpath in paths_separate:
        path_sum += "/"+subpath
        path = normalizeURL(path_root+path_sum)
        path_list.append(path)
    if parsed_url.query:
        path_list.append(parsed_url.geturl())
    if not path_list:
        path_list.append(path_root)
    return path_list

def normalizeURL(url):
    url = convertToHTTP(url)
    url = removeEndSlash(url)
    return url

def convertToHTTP(url):
    if url[:5] == 'https':
        url = 'http'+url[5:]
    return url

def removeEndSlash(url):
    if url[-1] =='/':
        url = url[:-1]
    return url
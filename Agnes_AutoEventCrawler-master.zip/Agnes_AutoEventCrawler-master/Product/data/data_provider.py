import os
import sys

project_root = os.path.dirname(os.path.abspath(__file__))
current_filepath = os.path.realpath(__file__)

def getCollectionDataPath():
    return os.path.join(project_root, 'collection_data.csv')

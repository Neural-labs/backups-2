import { Injectable } from '@angular/core';
import { Headers, Http, RequestOptions } from '@angular/http';
import { Agnes } from '../app/app.component';
import 'rxjs/add/operator/toPromise';
import 'rxjs/add/operator/timeout';

@Injectable()
export class AnalyticsService {
    private headers = new Headers({'Content-Type': 'application/json'});

    constructor(private http: Http) {
    }

    logAnalytics(data, url){
        data["token"] = localStorage.getItem('agnesToken')
        data["timestamp"] = new Date()
        let addUrl = Agnes.API_URL + url;
        let options = new RequestOptions({ headers: this.headers });

        return this.http.post(addUrl, data, options)
            .timeout(10000)
            .toPromise()
            .then(response => response.json() as Object[])
            .catch(this.handleError);
    }

    private handleError(error: any): Promise<any> {
        console.error('An error occurred', error);
        return Promise.reject(error.message || error);
    }
}

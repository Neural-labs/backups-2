import pickle
import os.path
from sklearn import svm

'''
Data Model:
{
    'model': <model obj>,
    'train_index': int
}
'''

detection_extension = '_detection_model.pkl'
extraction_extension = '_extraction_model.pkl'

def getDetectionModel(model_type):
    filename = model_type + detection_extension
    if os.path.isfile(filename):
        return pickle.load(filename)
    else:
        print 'No such model found:',model_type
        print 'Initializing new', model_type, 'model'
        initializeNewDetectionModel(model_type)
        return getDetectionModel(model_type)

def initializeNewDetectionModel(model_type):
    if model_type == 'svm':
        model = svm.SVC()
        writeDetectionModel(model_type=model_type, train_index=0, model=model)

def writeDetectionModel(model_type, train_index, model):
    filename = model_type + detection_extension
    fileobj = {
        'model': model,
        'train_index': train_index
    }
    pickle.dump(fileobj, filename)


# TODO: decide on how to store models for extraction
# def getExtractionModel(model_type):
#     filename = model_type + extraction_extension
#     if os.path.isfile(filename):
#         return pickle.load(filename)
#     else:
#         print 'No such model found:', model_type
#         return initializeNewExtractionModel(model_type)

# def writeExtractionModel(model_type, train_index, model):
#     filename = model_type + extraction_extension
#     fileobj = {
#         'model':model,
#         'train_index': train_index
#     }
#     pickle.dump(fileobj, filename)
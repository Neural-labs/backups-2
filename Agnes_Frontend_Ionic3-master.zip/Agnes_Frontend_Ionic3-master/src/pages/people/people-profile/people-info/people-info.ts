import { Component, Input } from '@angular/core';
import { NavController, Events, IonicPage, NavParams, PopoverController } from 'ionic-angular';
import { PeopleService } from '../../../../providers/people.service';
import { GroupsService } from '../../../../providers/groups.service';
import { Agnes } from '../../app/app.component';


@IonicPage()
@Component({
    selector: 'people-info',
    templateUrl: 'people-info.html',
    providers: [PeopleService, GroupsService]
})
export class PeopleInfo {
    loading: boolean;
    noInternet: boolean;
    user: Object;
    type: string;
    person: Object;
    isMe: boolean;

    skills: Array<string>;
    interests: Array<string>;
    groups: Array<Object>;

    @Input() inputIsMe;
    @Input() params;


    constructor(public navCtrl: NavController,
                private events: Events,
                private navParams: NavParams,
                private popoverCtrl: PopoverController,
                private groupsService: GroupsService) {
    }

    ngOnInit(){
        this.initPeopleInfo();

    }

    initPeopleInfo(){
        this.isMe = this.inputIsMe != null ? this.inputIsMe : this.params.isMe;
        this.type = this.params.type;
        this.user = JSON.parse(localStorage.getItem('agnesUser'));
        this.person = this.isMe ? this.user : this.params.person;

        //get user groups if this is a groups tab
        if(this.type == 'groups') {
            let data = {
                "grp": this.person['grp'].map(function (a) {
                    return a['groups_id'];
                })
            };

            //get user's groups to display in Groups tab - if no groups, only display About tab
            this.groupsService.getGroupsFromId(data).then(groups => {
                if (groups && groups.length > 0) {
                    this.groups = groups.map(function(a){
                        a['displayURL'] = ((a['thumbnail'] == '' || !a['thumbnail'])
                            ? "assets/img/pattern_" + Math.floor((Math.random() * 15) + 1) + '.png' : a['thumbnail']);

                        return a;
                    });
                }
            }).catch(function(error){console.log(error)});
        }

        this.events.subscribe('userEdited',user => {
            this.user = user;
            this.person = user;
            this.interests = this.person['keywords'].filter(function(a){return a['keytype'] != 'haveskill'}).map(function(a){return a.name;});
            this.interests = this.getUnique(this.interests);
        });
    }

    getUnique(arr){
        let u = {}, a = [];
        for(var i = 0, l = arr.length; i < l; ++i){
            if(u.hasOwnProperty(arr[i])) {
                continue;
            }
            a.push(arr[i]);
            u[arr[i]] = 1;
        }
        return a;
    }



    //redisplay if a person's group has been edited or deleted by admin
    gotGroupData(data){
        let group = data.group;
        let ind = this.groups.map(a => {return a['_id']}).indexOf(group['_id']);

        if(data.category == 'edit'){this.groups[ind] = group;}
        else if(data.category =='delete') {this.groups.splice(ind,1);}
    }

    //edit user fields if this is user's own profile
    edit(type) {
        let editMe = this.popoverCtrl.create(
            'EditMePopup',
            {
                'type': type,
                'me': this.user
            },
            {
                'enableBackdropDismiss':false,
                'cssClass': 'small'
            });
        editMe.present(
            {
                animate: false
            }
        );
        editMe.onDidDismiss(data =>{
            if (data){
                this.user = data['data'];
                this.person = data['data'];
                this.interests = this.user['keywords']
                    .filter(function(a){return (a['keytype'] != 'haveskill')})
                    .map(function(b){return b['name']});
                this.interests = this.getUnique(this.interests);

                this.skills = this.user['keywords'].filter(function(a){return (a['keytype'] == 'haveskill')})
                    .map(function(b){return b['name']});
                this.skills = this.getUnique(this.skills);
            }
        });
    }

    keywordSearch(keyword){

    }
}

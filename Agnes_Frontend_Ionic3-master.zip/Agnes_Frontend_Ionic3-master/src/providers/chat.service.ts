import { Injectable } from '@angular/core';
import { Headers, Http, RequestOptions } from '@angular/http';
import 'rxjs/add/operator/toPromise';
import 'rxjs/add/operator/timeout';
import {Observable} from "rxjs/Rx";
import { Agnes } from '../app/app.component';

@Injectable()
export class ChatService {
  private headers = new Headers({'Content-Type': 'application/json'});

  constructor(private http:Http) {
  }

  listChannel(data): Promise<Object[]> {
    data['token'] = localStorage.getItem('agnesToken');
    let addUrl = Agnes.API_URL + '/listChannels';
    let options = new RequestOptions({ headers: this.headers });

    return this.http.post(addUrl, data, options)
      .timeout(5000)
      .toPromise()
      .then(response => response  .json() as Object[])
      .catch(this.handleError);
  }

  createChannel(data): Promise<any> {
    data['token'] = localStorage.getItem('agnesToken');
    let addUrl = Agnes.API_URL + '/createChannel';
    let options = new RequestOptions({ headers: this.headers });

    return this.http.post(addUrl, data, options)
      .timeout(5000)
      .toPromise()
      .then(response => response  .json() as Object[])
      .catch(this.handleError);
  }

  unreadStatus(data): Promise<any> {
    data['token'] = localStorage.getItem('agnesToken');
    let addUrl = Agnes.API_URL + '/unread_status';
    let options = new RequestOptions({ headers: this.headers });

    return this.http.post(addUrl, data, options)
      .timeout(5000)
      .toPromise()
      .then(response => response  .json() as Object[])
      .catch(this.handleError);
  }

  getMessages(data) : Observable<Object[]> {
     data['token'] = localStorage.getItem('agnesToken');
     let addUrl = Agnes.API_URL + '/allMessage';
     let options = new RequestOptions({ headers: this.headers });

     return this.http.post(addUrl, data, options)
       .timeout(5000)
       .map(response => response  .json() as Object[])
       .catch((error:any) => Observable.throw(error.json().error || 'Server error'));
  }

  sendMessage(data) : Promise<Object[]> {
    data['token'] = localStorage.getItem('agnesToken');
    let addUrl = Agnes.API_URL + '/sendMessage';
    let options = new RequestOptions({ headers: this.headers });

    return this.http.post(addUrl, data, options)
      .timeout(5000)
      .toPromise()
      .then(response => response  .json() as Object[])
      .catch(this.handleError);
  }

  deleteMessage(data): Promise<Object[]> {
    data['token'] = localStorage.getItem('agnesToken');
    let addUrl = Agnes.API_URL + '/deleteMessage';
    let options = new RequestOptions({ headers: this.headers });

    return this.http.post(addUrl, data, options)
      .timeout(5000)
      .toPromise()
      .then(response => response  .json() as Object[])
      .catch(this.handleError);
  }

  twilioToken(data): Promise<Object[]> {
    data['token'] = localStorage.getItem('agnesToken');
    let addUrl = Agnes.API_URL + '/twillioToken';
    let options = new RequestOptions({ headers: this.headers });

    return this.http.post(addUrl, data, options)
      .timeout(5000)
      .toPromise()
      .then(response => response  .json() as Object[])
      .catch(this.handleError);
  }

  private handleError(error: any): Promise<any> {
    console.error('An error occurred', error);
    return Promise.reject(error.message || error);
  }
}

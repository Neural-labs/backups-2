import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';

import { NewChatPage } from './new-chat';
import { ComponentsModule } from '../../../components/components.module';

@NgModule({
    declarations: [
        NewChatPage
    ],
    imports: [
        IonicPageModule.forChild(NewChatPage),
        ComponentsModule
    ],
    exports: [
        NewChatPage
    ],
})

export class NewChatPageModule { }

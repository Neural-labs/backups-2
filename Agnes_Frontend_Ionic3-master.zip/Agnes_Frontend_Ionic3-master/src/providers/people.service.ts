import { Injectable } from '@angular/core';
import { Headers, Http, RequestOptions } from '@angular/http';
import 'rxjs/add/operator/toPromise';
import { Agnes } from '../app/app.component';

@Injectable()
export class PeopleService {
  private headers = new Headers({'Content-Type': 'application/json'});

  constructor(private http:Http) {
  }

  getPeople(data): Promise<any>{
    data["token"] = localStorage.getItem('agnesToken');
    data["timestamp"] = new Date()
    let addUrl = Agnes.API_URL + '/users';
    let options = new RequestOptions({ headers: this.headers });

    return this.http.post(addUrl, data, options)
      .timeout(5000)
      .toPromise()
      .then(response => response.json() as Object[])
      .catch(this.handleError);
  }

  loadMorePeople(data): Promise<any>{
    data["token"] = localStorage.getItem('agnesToken');
    data["timestamp"] = new Date()
    let addUrl = Agnes.API_URL + '/loadUser';
    let options = new RequestOptions({ headers: this.headers });

    return this.http.post(addUrl, data, options)
      .toPromise()
      .then(response => response.json() as Object[])
      .catch(this.handleError);
  }

  searchPeople(data): Promise<any>{
    data["token"] = localStorage.getItem('agnesToken');
    data["timestamp"] = new Date()
    let addUrl = Agnes.API_URL + '/search_user';
    let options = new RequestOptions({ headers: this.headers });

    return this.http.post(addUrl, data, options)
      .toPromise()
      .then(response => response.json() as Object[])
      .catch(this.handleError);
  }

  searchFriends(data): Promise<any>{
      data["token"] = localStorage.getItem('agnesToken');
      data["timestamp"] = new Date()
      let addUrl = Agnes.API_URL + '/user_friends';
      let options = new RequestOptions({ headers: this.headers });

      return this.http.post(addUrl, data, options)
          .toPromise()
          .then(response => response.json() as Object[])
          .catch(this.handleError);
  }

  getUsersFromIds(data): Promise<any>{
    data["token"] = localStorage.getItem('agnesToken');
    data["timestamp"] = new Date()
    let addUrl = Agnes.API_URL + '/user_info';
    let options = new RequestOptions({ headers: this.headers });

    return this.http.post(addUrl, data, options)
      .toPromise()
      .then(response => response.json() as Object[])
      .catch(this.handleError);
  }

  getUsersForAvatars(data): Promise<any>{
    data["token"] = localStorage.getItem('agnesToken');
    data["timestamp"] = new Date()
    let addUrl = Agnes.API_URL + '/user_info_pebbles';
    let options = new RequestOptions({ headers: this.headers });

    return this.http.post(addUrl, data, options)
      .toPromise()
      .then(response => response.json() as Object[])
      .catch(this.handleError);
  }



  streakFriends(data) : Promise<any>{
    data["token"] = localStorage.getItem('agnesToken');
    data["timestamp"] = new Date()
    let addUrl = Agnes.API_URL + '/dayStreakAmongFriends';
    let options = new RequestOptions({ headers: this.headers });
    return this.http.post(addUrl, data, options)
      .toPromise()
      .then(response => response.json() as Object[])
      .catch(this.handleError);
  }

  streakCampus(data) : Promise<any>{
    data["token"] = localStorage.getItem('agnesToken');
    data["timestamp"] = new Date()
    let addUrl = Agnes.API_URL + '/dayStreakOnCampus';
    let options = new RequestOptions({ headers: this.headers });
    return this.http.post(addUrl, data, options)
      .toPromise()
      .then(response => response.json() as Object[])
      .catch(this.handleError);
  }

  streakAgnes(data) : Promise<any>{
    data["token"] = localStorage.getItem('agnesToken');
    data["timestamp"] = new Date()
    let addUrl = Agnes.API_URL + '/dayStreakAcrossAgnes';
    let options = new RequestOptions({ headers: this.headers });
    return this.http.post(addUrl, data, options)
      .toPromise()
      .then(response => response.json() as Object[])
      .catch(this.handleError);
  }


    getUserStreak(data): Promise<any> {
      data["token"] = localStorage.getItem('agnesToken');
      data["timestamp"] = new Date()
      let addUrl = Agnes.API_URL + '/dayStreak';
      let options = new RequestOptions({headers:this.headers});

      return this.http.post(addUrl, data, options)
          .toPromise()
          .then(response => response.json() as Object[])
          .catch(this.handleError)
    }

    getUserRewardCountdown(data): Promise<any> {
      data["token"] = localStorage.getItem('agnesToken');
      data["timestamp"] = new Date()
      let addUrl = Agnes.API_URL + '/untilReward';
      let options = new RequestOptions({headers:this.headers});

      return this.http.post(addUrl, data, options)
          .toPromise()
          .then(response => response.json() as Object[])
          .catch(this.handleError)
    }

    getUserLifetimePebbles(data): Promise<any> {
      data["token"] = localStorage.getItem('agnesToken');
      data["timestamp"] = new Date()
      let addUrl = Agnes.API_URL + '/lifeTimePebbles';
      let options = new RequestOptions({headers:this.headers});

      return this.http.post(addUrl, data, options)
          .toPromise()
          .then(response => response.json() as Object[])
          .catch(this.handleError)
    }

    streakCommunity(data): Promise<any> {
      data["token"] = localStorage.getItem('agnesToken');
      data["timestamp"] = new Date()
      let addUrl = Agnes.API_URL + '/dayStreakCommunity';
      let options = new RequestOptions({headers:this.headers});
      return this.http.post(addUrl, data, options)
          .toPromise()
          .then(response => response.json() as Object[])
          .catch(this.handleError)
    }

    streakCommunityLoadMore(data): Promise<any> {
      data["token"] = localStorage.getItem('agnesToken');
      data["timestamp"] = new Date()
      let addUrl = Agnes.API_URL + '/dayStreakCommunityLoadMore';
      let options = new RequestOptions({headers:this.headers});

      return this.http.post(addUrl, data, options)
          .toPromise()
          .then(response => response.json() as Object[])
          .catch(this.handleError)
    }


    rewardFriends(data): Promise<any> {
      data["token"] = localStorage.getItem('agnesToken');
      data["timestamp"] = new Date()
      let addUrl = Agnes.API_URL + '/untilRewardAmongFriends';
      let options = new RequestOptions({headers:this.headers});

      return this.http.post(addUrl, data, options)
          .toPromise()
          .then(response => response.json() as Object[])
          .catch(this.handleError)
    }

    rewardCampus(data): Promise<any> {
      data["token"] = localStorage.getItem('agnesToken');
      data["timestamp"] = new Date()
      let addUrl = Agnes.API_URL + '/untilRewardOnCampus';
      let options = new RequestOptions({headers:this.headers});

      return this.http.post(addUrl, data, options)
          .toPromise()
          .then(response => response.json() as Object[])
          .catch(this.handleError)
    }

    rewardAgnes(data): Promise<any> {
      data["token"] = localStorage.getItem('agnesToken');
      data["timestamp"] = new Date()
      let addUrl = Agnes.API_URL + '/untilRewardAcrossAgnes';
      let options = new RequestOptions({headers:this.headers});

      return this.http.post(addUrl, data, options)
          .toPromise()
          .then(response => response.json() as Object[])
          .catch(this.handleError)
    }

    rewardCommunity(data): Promise<any> {
      data["token"] = localStorage.getItem('agnesToken');
      data["timestamp"] = new Date()
      let addUrl = Agnes.API_URL + '/untilRewardCommunity';
      let options = new RequestOptions({headers:this.headers});

      return this.http.post(addUrl, data, options)
          .toPromise()
          .then(response => response.json() as Object[])
          .catch(this.handleError)
    }

    rewardCommunityLoadMore(data): Promise<any> {
      data["token"] = localStorage.getItem('agnesToken');
      data["timestamp"] = new Date()
      let addUrl = Agnes.API_URL + '/untilRewardCommunityLoadMore';
      let options = new RequestOptions({headers:this.headers});

      return this.http.post(addUrl, data, options)
          .toPromise()
          .then(response => response.json() as Object[])
          .catch(this.handleError)
    }


    lifetimeFriends(data): Promise<any> {
      data["token"] = localStorage.getItem('agnesToken');
      data["timestamp"] = new Date()
      let addUrl = Agnes.API_URL + '/lifeTimePebblesAmongFriends';
      let options = new RequestOptions({headers:this.headers});

      return this.http.post(addUrl, data, options)
          .toPromise()
          .then(response => response.json() as Object[])
          .catch(this.handleError)
    }

    lifetimeCampus(data): Promise<any> {
      data["token"] = localStorage.getItem('agnesToken');
      data["timestamp"] = new Date()
      let addUrl = Agnes.API_URL + '/lifeTimePebblesOnCampus';
      let options = new RequestOptions({headers:this.headers});

      return this.http.post(addUrl, data, options)
          .toPromise()
          .then(response => response.json() as Object[])
          .catch(this.handleError)
    }

    lifetimeAgnes(data): Promise<any> {
      data["token"] = localStorage.getItem('agnesToken');
      data["timestamp"] = new Date()
      let addUrl = Agnes.API_URL + '/lifeTimePebblesAcrossAgnes';
      let options = new RequestOptions({headers:this.headers});

      return this.http.post(addUrl, data, options)
          .toPromise()
          .then(response => response.json() as Object[])
          .catch(this.handleError)
    }

    lifetimeCommunity(data): Promise<any> {
      data["token"] = localStorage.getItem('agnesToken');
      data["timestamp"] = new Date()
      let addUrl = Agnes.API_URL + '/lifeTimePebblesCommunity';
      let options = new RequestOptions({headers:this.headers});

      return this.http.post(addUrl, data, options)
          .toPromise()
          .then(response => response.json() as Object[])
          .catch(this.handleError)
    }

    lifetimeCommunityLoadMore(data): Promise<any> {

      data["token"] = localStorage.getItem('agnesToken');
      data["timestamp"] = new Date()
      let addUrl = Agnes.API_URL + '/lifeTimePebblesCommunityLoadMore';
      let options = new RequestOptions({headers:this.headers});

      return this.http.post(addUrl, data, options)
          .toPromise()
          .then(response => response.json() as Object[])
          .catch(this.handleError)
    }

  //Doesn't necessarily apply to 'people' but for determining if pebbles is in play
  communityPebblesStatus(data): Promise<any> {
    data["token"] = localStorage.getItem('agnesToken');
    data["timestamp"] = new Date()
    let addUrl = Agnes.API_URL + '/pebbleStatus';
    let options = new RequestOptions({headers:this.headers});

    return this.http.post(addUrl, data, options)
        .toPromise()
        .then(response => response.json() as Object[])
        .catch(this.handleError)
  }


  private handleError(error: any): Promise<any> {
    console.error('An error occurred', error);
    return Promise.reject(error.message || error);
  }
}

import { Injectable } from '@angular/core';
import { Headers, Http, RequestOptions } from '@angular/http';
import 'rxjs/add/operator/toPromise';
import 'rxjs/add/operator/timeout';
import { Agnes } from '../app/app.component';

@Injectable()
export class GroupsService {
  private headers = new Headers({'Content-Type': 'application/json'});

  constructor(private http: Http) {
  }

  joinGroupsFromQuestions(data): Promise<any>{
    data["token"] = localStorage.getItem('agnesToken');
    data["timestamp"] = new Date()
    let addUrl = Agnes.API_URL + '/joinGroupsFromQuestions';
    let options = new RequestOptions({ headers: this.headers });

    return this.http.post(addUrl, data, options)
        .timeout(5000)
        .toPromise()
        .then(response => response.json() as Object[])
        .catch(this.handleError);
  }

  getGroupCategories(data): Promise<any>{
    data["token"] = localStorage.getItem('agnesToken');
    data["timestamp"] = new Date()
    let addUrl = Agnes.API_URL + '/category_list';
    let options = new RequestOptions({ headers: this.headers });

    return this.http.post(addUrl, data, options)
        .timeout(5000)
        .toPromise()
        .then(response => response.json() as Object[])
        .catch(this.handleError);
  }

  getMatchedGroups(data): Promise<any>{
    data["token"] = localStorage.getItem('agnesToken');
    data["timestamp"] = new Date()
    let addUrl = Agnes.API_URL + '/user_match_group';
    let options = new RequestOptions({ headers: this.headers });

    return this.http.post(addUrl, data, options)
      .timeout(10000)
      .toPromise()
      .then(response => response.json() as Object[])
      .catch(this.handleError);
  }

  getAllGroups(data): Promise<any>{
    // data["token"] = localStorage.getItem('agnesToken');
    data['token'] = localStorage.getItem('agnesToken');
    let addUrl = Agnes.API_URL + '/groups';
    let options = new RequestOptions({ headers: this.headers });

    return this.http.post(addUrl, data, options)
      .timeout(10000)
      .toPromise()
      .then(response => response.json() as Object[])
      .catch(this.handleError);
  }

  getGroupsByCategory(data): Promise<any>{
    data['token'] = localStorage.getItem('agnesToken');
    data["timestamp"] = new Date()
    let addUrl = Agnes.API_URL + '/groupListByTopic';
    let options = new RequestOptions({ headers: this.headers });

    return this.http.post(addUrl, data, options)
        .timeout(10000)
        .toPromise()
        .then(response => response.json() as Object[])
        .catch(this.handleError);
  }

  getMostActiveGroups(data): Promise<any>{
    data['token'] = localStorage.getItem('agnesToken');
    data["timestamp"] = new Date()
    let addUrl = Agnes.API_URL + '/mostActiveGroup';
    let options = new RequestOptions({ headers: this.headers });

    return this.http.post(addUrl, data, options)
        .timeout(10000)
        .toPromise()
        .then(response => response.json() as Object[])
        .catch(this.handleError);
  }

  getMostPopularGroups(data): Promise<any>{
    data['token'] = localStorage.getItem('agnesToken');
    data["timestamp"] = new Date()
    let addUrl = Agnes.API_URL + '/mostPopularGroup';
    let options = new RequestOptions({ headers: this.headers });

    return this.http.post(addUrl, data, options)
        .timeout(10000)
        .toPromise()
        .then(response => response.json() as Object[])
        .catch(this.handleError);
  }

  loadMoreGroups(data): Promise<any>{
    data["token"] = localStorage.getItem('agnesToken');
    data["timestamp"] = new Date()
    let addUrl = Agnes.API_URL + '/load_more_groups_list';
    let options = new RequestOptions({ headers: this.headers });

    return this.http.post(addUrl, data, options)
      .timeout(5000)
      .toPromise()
      .then(response => response.json() as Object[])
      .catch(this.handleError);
  }

  searchGroups(data): Promise<any>{
    data["token"] = localStorage.getItem('agnesToken');
    data["timestamp"] = new Date()
    let addUrl = Agnes.API_URL + '/search_group_v2';
    let options = new RequestOptions({ headers: this.headers });

    return this.http.post(addUrl, data, options)
      .timeout(5000)
      .toPromise()
      .then(response => response.json() as Object[])
      .catch(this.handleError);
  }

  claimGroup(data): Promise<any>{
    data["token"] = localStorage.getItem('agnesToken');
    data["timestamp"] = new Date()
    let addUrl = Agnes.API_URL + '/claimGroup';
    let options = new RequestOptions({ headers: this.headers });

    return this.http.post(addUrl, data, options)
      .timeout(5000)
      .toPromise()
      .then(response => response.json() as Object[])
      .catch(this.handleError);
  }

  joinPrivateGroup(data): Promise<any>{
    data["token"] = localStorage.getItem('agnesToken');
    data["timestamp"] = new Date()
    let addUrl = Agnes.API_URL + '/join_private_group';
    let options = new RequestOptions({ headers: this.headers });

    return this.http.post(addUrl, data, options)
      .timeout(5000)
      .toPromise()
      .then(response => response.json() as Object[])
      .catch(this.handleError);
  }

  joinPublicGroup(data): Promise<any>{
    data["token"] = localStorage.getItem('agnesToken');
    data["timestamp"] = new Date()
    let addUrl = Agnes.API_URL + '/join_public_group';

    return this.http.post(addUrl, data)
      .timeout(5000)
      .toPromise()
      .then(response => response.json() as Object[])
      .catch(this.handleError);
  }

  joinGroup(data): Promise<any>{
    data["token"] = localStorage.getItem('agnesToken');
    data["timestamp"] = new Date()
    let addUrl = Agnes.API_URL + '/join_group';

    return this.http.post(addUrl, data)
        .timeout(5000)
        .toPromise()
        .then(response => response.json() as Object[])
        .catch(this.handleError);
  }

  joinGroup2(data): Promise<any>{
    data["token"] = localStorage.getItem('agnesToken');
    data["timestamp"] = new Date()
    let addUrl = Agnes.API_URL + '/join_group_v2';

    return this.http.post(addUrl, data)
        .timeout(5000)
        .toPromise()
        .then(response => response.json() as Object[])
        .catch(this.handleError);
  }

  getGroupsFromId(data): Promise<any>{
    data["token"] = localStorage.getItem('agnesToken');
    data["timestamp"] = new Date()
    let addUrl = Agnes.API_URL + '/group_object';

    return this.http.post(addUrl, data)
      .timeout(5000)
      .toPromise()
      .then(response => response.json() as Object[])
      .catch(this.handleError);
  }

  getGroupsFromCategory(data): Promise<any>{
    data["token"] = localStorage.getItem('agnesToken');
    data["timestamp"] = new Date()
    let addUrl = Agnes.API_URL + '/group_object';

    return this.http.post(addUrl, data)
        .timeout(5000)
        .toPromise()
        .then(response => response.json() as Object[])
        .catch(this.handleError);
  }

  inviteUserToGroup(data): Promise<any>{
    data["token"] = localStorage.getItem('agnesToken');
    data["timestamp"] = new Date()
    let addUrl = Agnes.API_URL + '/invite';

    return this.http.post(addUrl, data)
      .timeout(5000)
      .toPromise()
      .then(response => response.json() as Object[])
      .catch(this.handleError);
  }

  getFBGroups(data): Promise<any>{
    data["token"] = localStorage.getItem('agnesToken');
    data["timestamp"] = new Date()
    let addUrl = Agnes.API_URL + '/user_fb_group';

    return this.http.post(addUrl, data)
      .timeout(5000)
      .toPromise()
      .then(response => response.json() as Object[])
      .catch(this.handleError);
  }

  connectFBGroup(data): Promise<any>{
    data['token'] = localStorage.getItem('agnesToken');
    data["timestamp"] = new Date()
    let addUrl = Agnes.API_URL + '/connect_existing_group';

    return this.http.post(addUrl, data)
        .timeout(5000)
        .toPromise()
        .then(response => response.json() as Object[])
        .catch(this.handleError);
  }

  getAdminGroups(data): Promise<any>{
    data["token"] = localStorage.getItem('agnesToken');
    data["timestamp"] = new Date()
    let addUrl = Agnes.API_URL + '/admin_for_groups';

    return this.http.post(addUrl, data)
      .timeout(5000)
      .toPromise()
      .then(response => response.json() as Object[])
      .catch(this.handleError);
  }

  addGroup(data): Promise<any>{
    data["token"] = localStorage.getItem('agnesToken');
    data["timestamp"] = new Date()
    let addUrl = Agnes.API_URL + '/create_group';

    return this.http.post(addUrl, data)
      .timeout(5000)
      .toPromise()
      .then(response => response.json() as Object[])
      .catch(this.handleError);
  }

  editGroupAbout(data): Promise<any>{
    data["token"] = localStorage.getItem('agnesToken');
    data["timestamp"] = new Date()
    let addUrl = Agnes.API_URL + '/edit_group_v2';

    return this.http.post(addUrl, data)
      .timeout(5000)
      .toPromise()
      .then(response => response.json() as Object[])
      .catch(this.handleError);
  }

  editGroupMembers(data): Promise<any>{
    data["token"] = localStorage.getItem('agnesToken');
    data["timestamp"] = new Date()
    let addUrl = Agnes.API_URL + '/edit_member';

    return this.http.post(addUrl, data)
        .timeout(5000)
        .toPromise()
        .then(response => response.json() as Object[])
        .catch(this.handleError);
  }

  //remove users from group's pendingreq array
  removePendingReq(data): Promise<any>{
    data["token"] = localStorage.getItem('agnesToken');
    data["timestamp"] = new Date()
    let addUrl = Agnes.API_URL + '/removePendingReq';

    return this.http.post(addUrl, data)
        .timeout(5000)
        .toPromise()
        .then(response => response.json() as Object[])
        .catch(this.handleError);
  }


  leaveGroup(data): Promise<any>{
    data["token"] = localStorage.getItem('agnesToken');
    data["timestamp"] = new Date()
    let addUrl = Agnes.API_URL + '/leave_group';

    return this.http.post(addUrl, data)
      .timeout(5000)
      .toPromise()
      .then(response => response.json() as Object[])
      .catch(this.handleError);
  }

  adminRequest(data): Promise<any>{
    data["token"] = localStorage.getItem('agnesToken');
    data["timestamp"] = new Date()
    let addUrl = Agnes.API_URL + '/admin_requests';

    return this.http.post(addUrl, data)
      .timeout(5000)
      .toPromise()
      .then(response => response.json() as Object[])
      .catch(this.handleError);
  }

  removeMatched(data): Promise<any>{
    data["token"] = localStorage.getItem('agnesToken');
    data["timestamp"] = new Date()
    let addUrl = Agnes.API_URL + '/removeMatchGroup';

    return this.http.post(addUrl, data)
      .timeout(5000)
      .toPromise()
      .then(response => response.json() as Object[])
      .catch(this.handleError);
  }

  deleteGroup(data): Promise<any>{
    data["token"] = localStorage.getItem('agnesToken');
    data["timestamp"] = new Date()
    let addUrl = Agnes.API_URL + '/deleteGroup';

    return this.http.post(addUrl, data)
      .timeout(5000)
      .toPromise()
      .then(response => response.json() as Object[])
      .catch(this.handleError);
  }

  updateStatus(data): Promise<any>{
    data["token"] = localStorage.getItem('agnesToken');
    data["timestamp"] = new Date()
    let addUrl = Agnes.API_URL + '/updateStatusQuo';
    let options = new RequestOptions({ headers: this.headers });

    return this.http.post(addUrl, data, options)
        .timeout(5000)
        .toPromise()
        .then(response => response.json() as Object[])
        .catch(this.handleError);
  }

  followGroup(data): Promise<any>{
    data["token"] = localStorage.getItem('agnesToken');
    data["timestamp"] = new Date()
    let addUrl = Agnes.API_URL + '/follow_group';
    let options = new RequestOptions({ headers: this.headers });

    return this.http.post(addUrl, data, options)
        .timeout(5000)
        .toPromise()
        .then(response => response.json() as Object[])
        .catch(this.handleError);
  }

  unfollowGroup(data): Promise<any>{
    data["token"] = localStorage.getItem('agnesToken');
    data["timestamp"] = new Date()
    let addUrl = Agnes.API_URL + '/unfollowGroup';
    let options = new RequestOptions({ headers: this.headers });

    return this.http.post(addUrl, data, options)
        .timeout(5000)
        .toPromise()
        .then(response => response.json() as Object[])
        .catch(this.handleError);
  }

  shareToGroup(data): Promise<any>{
    data["token"] = localStorage.getItem('agnesToken');
    data["timestamp"] = new Date()
    let addUrl = Agnes.API_URL + '/share_with_group';
    let options = new RequestOptions({ headers: this.headers });

    return this.http.post(addUrl, data, options)
        .timeout(5000)
        .toPromise()
        .then(response => response.json() as Object[])
        .catch(this.handleError);
  }

  shareGroupWithFriends(data): Promise<any>{
    data["token"] = localStorage.getItem('agnesToken');
    data["timestamp"] = new Date()
    let addUrl = Agnes.API_URL + '/shareGroupToUser';
    let options = new RequestOptions({ headers: this.headers });

    return this.http.post(addUrl, data, options)
        .timeout(5000)
        .toPromise()
        .then(response => response.json() as Object[])
        .catch(this.handleError);
  }

  getNewsFeed(data): Promise<any>{
    data["token"] = localStorage.getItem('agnesToken');
    data["timestamp"] = new Date()
    let addUrl = Agnes.API_URL + '/getNewsFeed';
    let options = new RequestOptions({ headers: this.headers });

    return this.http.post(addUrl, data, options)
        .timeout(5000)
        .toPromise()
        .then(response => response.json() as Object[])
        .catch(this.handleError);
  }

  addAnnouncement(data): Promise<any>{
    data["token"] = localStorage.getItem('agnesToken');
    data["timestamp"] = new Date()
    let addUrl = Agnes.API_URL + '/add_announcement_v2';
    let options = new RequestOptions({ headers: this.headers });

    return this.http.post(addUrl, data, options)
        .timeout(5000)
        .toPromise()
        .then(response => response.json() as Object[])
        .catch(this.handleError);
  }

  notificationRequests(data): Promise<any>{
    data["token"] = localStorage.getItem('agnesToken');
    data["timestamp"] = new Date()
    let addUrl = Agnes.API_URL + '/notification_requests_handle';
    let options = new RequestOptions({ headers: this.headers });

    return this.http.post(addUrl, data, options)
        .timeout(5000)
        .toPromise()
        .then(response => response.json() as Object[])
        .catch(this.handleError);
  }

  acceptInvite(data): Promise<any>{
    data["token"] = localStorage.getItem('agnesToken');
    data["timestamp"] = new Date()
    let addUrl = Agnes.API_URL + '/memberAcceptInvite';
    let options = new RequestOptions({ headers: this.headers });

    return this.http.post(addUrl, data, options)
        .timeout(5000)
        .toPromise()
        .then(response => response.json() as Object[])
        .catch(this.handleError);
  }

  editAnnouncement(data): Promise<any> {
    data["token"] = localStorage.getItem('agnesToken');
    data["timestamp"] = new Date()
    let addUrl = Agnes.API_URL + '/edit_announcement_v2';
    let options = new RequestOptions({ headers: this.headers });

    return this.http.post(addUrl, data, options)
        .timeout(5000)
        .toPromise()
        .then(response => response.json() as Object[])
        .catch(this.handleError);
  }

  importFbGroupEvents(data): Promise<any> {
    data["token"] = localStorage.getItem('agnesToken');
    data["timestamp"] = new Date()
    let addUrl = Agnes.API_URL + '/createEventForGroup';
    let options = new RequestOptions({ headers: this.headers });

    return this.http.post(addUrl, data, options)
        .timeout(5000)
        .toPromise()
        .then(response => response.json() as Object[])
        .catch(this.handleError);
  }

  syncWithFbGroup(data): Promise<any> {
    data["token"] = localStorage.getItem('agnesToken');
    data["timestamp"] = new Date()
    let addUrl = Agnes.API_URL + '/connect_existing_group';
    let options = new RequestOptions({ headers: this.headers });

    return this.http.post(addUrl, data, options)
        .timeout(5000)
        .toPromise()
        .then(response => response.json() as Object[])
        .catch(this.handleError);
  }

  private handleError(error: any): Promise<any> {
    console.error('An error occurred', error);
    return Promise.reject(error.message || error);
  }

}

import { Component, ViewChild } from '@angular/core';
import { ViewController, NavParams, IonicPage, Events, Select, ToastController } from 'ionic-angular';

import { MeService } from '../../../providers/me.service';
import { QuestionsService } from '../../../providers/questions.service';
import { AnalyticsService } from '../../../providers/analytics.service';
import { Agnes } from '../../../app/app.component';

import * as AWS from 'aws-sdk';
import * as S3 from 'aws-sdk/clients/s3';


@IonicPage()
@Component({
    selector: 'edit-me',
    templateUrl: 'edit-me.html',
    providers: [MeService, QuestionsService, AnalyticsService]

})

export class EditMe {
    edited: boolean;
    loading: boolean;
    shouldBlur: boolean;

    me: Object;
    oldPic: string;
    oldCover: string;
    userName: string;
    hideProfile: boolean;

    localPicImg: string;
    localCoverImg: string;

    keywordArray: Array<Object>;
    keywordInput: string;
    keywordAutofill: Array<Object>;

    majorInput: string;
    majorAutofill: Array<Object>;

    genders: Array<string>;
    studentTypes: Array<string>;

    @ViewChild('yearSelect') yearSelect: Select;
    @ViewChild('genderSelect') genderSelect: Select;

    constructor(public viewCtrl: ViewController,
                private toastCtrl: ToastController,
                private meService: MeService,
                private analyticsService: AnalyticsService,
                private events: Events,
                private questionsService: QuestionsService,
                private navParams: NavParams) {
    }

    ngOnInit(){
        this.me = {... this.navParams.get('me')};
        this.oldPic = this.me['picurl'];
        this.oldCover = this.me['cover'];
        this.me['gender'] = !this.me['gender'] ? '' : this.me['gender'];
        this.userName = this.me['fname'] + ' ' + this.me['lname'];
        this.hideProfile = !this.me['display'];

        this.localPicImg = this.me['picurl'];
        this.localCoverImg = this.me['cover'];

        this.edited = false;
        this.loading = false;
        this.shouldBlur = true;

        this.keywordArray = this.me['keywords'].filter(x => {return x['keytype'] == 'interest'})
            .map(a => {return a['name']});

        this.keywordInput = '';
        this.keywordAutofill = [];

        this.majorInput = this.me['major'].toString().replace(',', ', ');
        this.majorAutofill = [];

        this.genders = ["Female", "Male", "Nonbinary", "Unspecified"];

        this.studentTypes = [
            "Freshman", "Sophomore", "Junior", "Senior", "Fifth year", "Masters", "PhD", "Alum", "Staff", "Other"
        ];
    }

    closeEditMe(data) {
        this.viewCtrl.dismiss(data, '', {
            animate: true,
            animation: 'ios-transition',
            duration: 350,
            easing: "ease-in-out",
            direction: "back"
        });
    }

    closeSelect(type, year?){
        if(type == 'year'){
            this.me['studenttype'] = year;
            this.yearSelect.close();
        }
        else {this.genderSelect.close();}
    }

    //send edits
    submitEdits(){
        this.addKeyword(null,null);
        let names = this.userName.trim().split(' ');

        //for basic info: must have first and last name and at least 1 major
        if (this.majorInput.trim() != '' && names.length >= 2) {
            this.loading = true;

            this.me['keywords'] = this.keywordArray.map(a => {return {'keytype':'interest', 'name': a}});
            this.me['user_id'] = this.me['_id'];
            this.me['haveskill'] = [];
            this.me['keyactive'] = [];
            this.me['postcol'] = [];
            this.me['issues'] = [];
            this.me['interest'] = this.keywordArray;

            this.me['major'] = this.majorInput.split('/,\s*/');

            // //upload new profile pic
            if (this.localPicImg != '' && (this.localPicImg != this.oldPic)){
                let creds = {
                    bucket: 'agnesimages',
                    access_key: 'AKIAJYQU6AUVQQKITAPQ',
                    secret_key: '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'
                };

                let uniqueFilename = "";
                var possible = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
                for (var j = 0; j < 8; j++) {
                    uniqueFilename += possible.charAt(Math.floor(Math.random() * possible.length));
                }

                let data = this.baseToBlob(this.localPicImg);
                AWS.config.update({region: 'us-east-1',credentials: {
                    accessKeyId: "AKIAJYQU6AUVQQKITAPQ",
                    secretAccessKey:"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"
                }});

                let keyname = '_' + uniqueFilename + '.jpg';

                //Bucket Parameters
                let bucketParams = {
                    Key: keyname,
                    ContentType: ".jpg",
                    Body: data ,
                    ServerSideEncryption: 'AES256',
                    Bucket: creds.bucket
                };

                //bucket to define
                let bucket = new S3({ params: { Bucket: 'agnesimages' } });

                bucket.putObject(bucketParams, (err, data) => {
                    if(err) {
                        console.log('bucket error',err);
                        return false;
                    }
                    else {
                        // Upload Successfully Finished
                        let pic = 'https://s3.amazonaws.com/agnesimages/' + keyname;
                    }
                });

                this.me['picurl'] = 'https://s3.amazonaws.com/agnesimages/' + keyname;
            }
            if (this.localCoverImg != '' && (this.localCoverImg != this.oldCover)){
                let creds = {
                    bucket: 'agnesimages',
                    access_key: 'AKIAJYQU6AUVQQKITAPQ',
                    secret_key: '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'
                };

                let uniqueFilename = "";
                var possible = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
                for (var j = 0; j < 8; j++) {
                    uniqueFilename += possible.charAt(Math.floor(Math.random() * possible.length));
                }

                let data = this.baseToBlob(this.localCoverImg);
                AWS.config.update({region: 'us-east-1',credentials: {
                    accessKeyId: "AKIAJYQU6AUVQQKITAPQ",
                    secretAccessKey:"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"
                }});

                let keyname = '_' + uniqueFilename + '.jpg';

                //Bucket Parameters
                let bucketParams = {
                    Key: keyname,
                    ContentType: ".jpg",
                    Body: data ,
                    ServerSideEncryption: 'AES256',
                    Bucket: creds.bucket
                };

                //bucket to define
                let bucket = new S3({ params: { Bucket: 'agnesimages' } });

                bucket.putObject(bucketParams, (err, data) => {
                    if(err) {
                        console.log('bucket error',err);
                        return false;
                    }
                    else {
                        // Upload Successfully Finished
                        let pic = 'https://s3.amazonaws.com/agnesimages/' + keyname;
                    }
                });

                this.me['cover'] = 'https://s3.amazonaws.com/agnesimages/' + keyname;
            }

            this.meService.editMe(this.me)
                .then( data => {
                    this.loading = false;
                    if (data){
                        this.me = data;
                        data['localCover'] = this.localCoverImg;
                        data['localPic'] = this.localPicImg;

                        localStorage.setItem('agnesUser', JSON.stringify(this.me));
                        this.events.publish('updatedMe', data);
                        this.toastCtrl.create({
                            message: "Edits saved!",
                            duration: 2500,
                            position: 'top',
                            closeButtonText: ' ',
                            showCloseButton: true
                        }).present();

                        this.closeEditMe(null);
                    }
                    else {
                        Agnes.showError("Sorry, couldn't save your edits right now - try again!");
                    }
                })
                .catch(err => {
                    this.loading = false;
                    Agnes.showError("Sorry, couldn't save your edits right now - try again!");
                });
        }
    }

    //autofill interests or majors
    search(type) {
        let matches = [];
        let term = '';
        if(type == 'interest') {
            term = this.keywordInput.trim().toLowerCase();;
        }
        else {
            let majors = this.majorInput.split(/,\s/);
            term = majors[majors.length-1].trim().toLowerCase();
        }

        let data = {"searchTerm": term, 'type': type};

        if (term.length == 0) {
            if(type == 'interest'){this.keywordAutofill = [];}
            else {this.majorAutofill = [];}
        }
        else {
            if(type == 'interest'){
                this.questionsService.autocomplete(data).then(value => {
                    if (value) {
                        matches = value;
                        this.keywordAutofill = matches.map(function (a) {
                            return a['keyword']
                        });
                    }
                    else {
                        this.keywordAutofill = [];
                    }
                });
            }
            else if(type == 'major'){
                this.questionsService.majorAutocomplete(data).then(value => {
                    if (value) {
                        matches = value;
                        this.majorAutofill = matches.map(function (a) {
                            return a['keyword'].toLowerCase()
                        });
                    }
                    else {
                        this.majorAutofill = [];
                    }
                });
            }
        }
    }

    //add major to end of string
    addMajor(major){
        let majors = this.majorInput.split(/,\s*/);
        this.majorInput = majors.slice(0,majors.length-1).concat([major]).join(', ');
        this.majorAutofill = [];
    }

    //for adding keywords to skills or interests
    addKeyword(term, e){
        //for keeping keyboard up when + button is pressed
        if(e){
            e.preventDefault();
            this.shouldBlur = false;
        }

        let keyword = term ? term : this.keywordInput.trim();

        if(keyword.trim() != '' && this.keywordArray.indexOf(keyword) == -1) {
            this.keywordArray.push(keyword);
            this.keywordInput = '';
        }

        this.keywordAutofill = [];
    }

    //clear results list if user taps off of it
    clearSearch(){
        this.majorAutofill = [];
        this.keywordAutofill = [];
    }

    //for removing keywords from skills or interests
    removeKeyword(keyword){
        let ind = this.keywordArray.indexOf(keyword);
        if(ind != -1) {this.keywordArray.splice(ind,1);}
    }

    //adding keywords using the Enter key
    onEnter(ev){
        if(ev.keyCode == 13) {
            this.addKeyword(null, null);
        }
    }

    //adding/changing profile photo where type is either camera or upload
    addPhoto(type){
        let source = Agnes.camera.PictureSourceType.PHOTOLIBRARY;
        let options = {
            quality: 25,
            allowEdit: true,
            cameraDirection: Agnes.camera.Direction.FRONT,
            correctOrientation: true,
            destinationType: Agnes.camera.DestinationType.DATA_URL,
            sourceType: source
        };

        Agnes.camera.getPicture(options).then((value) => {
            if (value && typeof(value)=='string'){
                let base64Image = 'data:image/jpeg;base64,' + value;
                if(type == 'picurl'){this.localPicImg = base64Image;}
                else {this.localCoverImg = base64Image;}
            }
            else {
                console.log('not base64', value);
                Agnes.showError("Couldn't process your photo - try again!");
            }
        }).catch(err => {
            console.log('camera err', err);
            if (err != 'Camera cancelled.' && err != 'no image selected') {
                Agnes.showError("Couldn't get your photos - make sure Agnes has photo access permissions and try again!");
            }
        });
    }

    //for converting uploaded/camera photo
    baseToBlob(dataURI) {
        // convert base64/URLEncoded data component to raw binary data held in a string
        var byteString;
        if (dataURI.split(',')[0].indexOf('base64') >= 0)
            byteString = atob(dataURI.split(',')[1]);
        else
            byteString = (dataURI.split(',')[1]);

        // separate out the mime component
        // var mimeString = dataURI.split(',')[0].split(':')[1].split(';')[0];

        // write the bytes of the string to a typed array
        var ia = new Uint8Array(byteString.length);
        for (var i = 0; i < byteString.length; i++) {
            ia[i] = byteString.charCodeAt(i);
        }

        return new Blob([ia.buffer], {type: "image/jpeg"});
    }

    //toggle profile display
    hideMyProfile(){

        this.hideProfile = !this.hideProfile;
        let disp = !this.hideProfile;

        if (!this.me['display'] == disp) {
            let data = {
                "id":this.me['_id'],
                "display": disp
            };

            this.meService.hideProfile(data).then(value => {
                if (value){
                    this.me['display'] = disp;
                    this.events.publish('updateUser');
                }
                else {
                    this.hideProfile = !disp;
                    Agnes.showError("There was a problem hiding your profile - try again!");
                }
            }).catch(() => {
                this.hideProfile = !disp;
                Agnes.showError("There was a problem hiding your profile - try again!");
            });
        }
    }

    //logout
    logout(){
        this.events.publish('logout');
    }

    //open privacy policy
    readPrivacy() {
        //send Read Privacy analytics
        this.analyticsService.logAnalytics({community: this.me['community'], users_id: this.me['_id']}, '/readPrivacy');

        window.open("https://www.iubenda.com/privacy-policy/7883920");
    }

    //open terms of use page
    openTermsOfUse(){
        //send terms of use analytics
        this.analyticsService.logAnalytics({community: this.me['community'], users_id: this.me['_id']}, '/termOfUse');

        window.open("http://agnes.io/terms");
    }

    //open email client w user data info to send feedback
    sendFeedback(){

        //send feedback analytics
        this.analyticsService.logAnalytics({community: this.me['community'], users_id: this.me['_id']}, '/sendFeedback');

        Agnes.socialSharing.canShareViaEmail().then(() => {
            // Sharing via email is possible
            let subj = "Questions/comments/concerns about Agnes!";
            let message = '\n\n--\n' +
                'Agnes version: ' + Agnes.version + '\n' +
                'Cordova version: ' + Agnes.device.cordova +'\n' +
                'os: ' + Agnes.device.platform + ' ' + Agnes.device.version + '\n' +
                'Device Id: ' + this.me['deviceid'] + '\n' +
                'Device brand: ' + Agnes.device.manufacturer + '\n' +
                'Device model: ' + Agnes.device.model + '\n' +
                'Screen width: ' + window.innerWidth + '\n' +
                'Screen height: ' + window.innerHeight + '\n' +
                'User ID: ' + this.me['_id'] + '\n' +
                'User email: ' + this.me['email']['uid'] + '\n';
            Agnes.socialSharing.shareViaEmail(message,subj,['admin@agnes.io']).then(() => {
                // Success!
            }).catch(() => {
                Agnes.showError("Agnes can't open your email client - feel free to send your own email to admin@agnes.io!");
            });
        }).catch(() => {
            Agnes.showError("Agnes can't find an email client on this device - please try again!");
        });
    }

}

import logging
import os
from db import functions
from db.config import getNewConn
from Rank import rankItemsA
from multiprocessing import Pool, JoinableQueue, cpu_count, Process
import time
# from Crypto.Hash import MD5
import hashlib
from pymongo import UpdateOne
import pickle
import traceback
import gc
import datetime
import copy
from bson.objectid import ObjectId
from bson import json_util
# import json
import cPickle

UPDATE_INTERVAL = 60 * 5

def runRanking():

    # NUM_WORKER_THREADS = max(cpu_count()-1, 1)
    # NUM_WRITER_THREADS = 1
    # NUM_WORKER_THREADS = 1
    NUM_WORKER_THREADS = cpu_count()
    task_queue_maxsize = 50

    logging.info('Starting Workers...')
    task_queue = JoinableQueue(task_queue_maxsize)
    done_queue = JoinableQueue()

    worker_pool = Pool(NUM_WORKER_THREADS, worker_main, (task_queue, done_queue))

    # for ind in range(NUM_WRITER_THREADS):
    #     writer_thread = Process(target=mongoWriter, args=(done_queue,))
    #     writer_thread.start()
    total_counter = 0
    last_id = None
    start = time.time()
    try:
        while True:
            # logging.info('Updating Huddle Feeds')
            huddle_cursor = functions.getHuddleCursorBatch(last_id)
            batch_count = huddle_cursor.count(with_limit_and_skip=True)
            if not huddle_cursor or not batch_count:
                logging.info('last_id %s' % last_id)
                end = time.time()
                logging.info('Finished Huddle Cursor with total time = %s' % str(end - start))
                start = time.time()
                last_id = None
                # break
                continue
            last_id = huddle_cursor[batch_count-1]['_id']
            counter = 0

            for huddle in huddle_cursor:
                counter += 1
                total_counter += 1
                if total_counter % 100 == 0:
                    end = time.time()
                    logging.info(' -- Batch Progress: %d | Total Progress: %d  - at %s seconds ---' % (counter,total_counter, str(end-start) ))
                task_queue.put((huddle, counter), block=True)

            task_queue.join()
            end = time.time()
            logging.info('Finished Huddle Batch with batch time = %s' % str(end-start))
            # time.sleep(UPDATE_INTERVAL)
            del huddle_cursor
            gc.collect()
            # break

    except KeyboardInterrupt as e:
        logging.error('Keyboard Interrupt!')
        # task_queue.terminate()
        task_queue.close()
        done_queue.close()
        worker_pool.terminate()
        exit(-1)

def worker_main(task_queue, done_queue):
    worker_id = os.getpid()
    logging.info('Worker %s Alive' % str(worker_id))
    worker_conn = getNewConn()
    huddle_feed_collection = worker_conn.Agnes.huddle_feeds
    # huddle_current_requests = worker_conn.Agnes.huddle_requests
    # huddle_past_requests = worker_conn.Agnes.huddle_requests_past
    while True:
        try:
            huddle, counter = task_queue.get()
            user_id = str(huddle['users_id'])


            huddle = addLiveUpdates(huddle)
            huddle = cleanHuddle(huddle)

            # start = time.time()
            isUpdated = checkHuddle(huddle)
            # end = time.time()
            # print 'took',end-start

            if not isUpdated:
                # logging.info('Updating! user_id %s' % str(user_id))
                safe_huddle = copyDict(huddle)
                huddle_hash = generateNewHuddleHash(safe_huddle)

                # checkEqual(huddle, safe_huddle)
                # print '----\n'
                new_feed = rankHuddle(huddle)

                functions.updateHuddle(huddle_feed_collection, user_id, new_feed, huddle_hash, safe_huddle)


            task_queue.task_done()
        except Exception as e:
            logging.info('Exception:')
            traceback.print_exc()
            logging.info(e)
            exit()
        except KeyboardInterrupt as e:
            logging.info('Killing worker %s' % str(worker_id))
            exit(-1)

def copyDict(obj):
    return copy.deepcopy(obj)

def checkEqual(d1, d2):
    wanted_keys = ['featuredGroup', 'latestGroupUpdate', 'groupUpdate', 'recommendedGroup', 'recommendedEvent', 'eventFeatured','eventTrending',
                   'recentlyAddedEvent', 'eventHappeningNow', 'news', 'eventsFriends', 'discoverGroup', 'discoverEvent']
    for key in wanted_keys:
        print key, d1[key] == d2[key]

    print d1 == d2
    print str(d1) == str(d2)
    print cPickle.dumps(d1) == cPickle.dumps(d2)
    print json_util.dumps(d1, sort_keys=True) == json_util.dumps(d2, sort_keys=True)
    print
    print

def mongoWriter(done_queue):
    worker_id = os.getpid()
    logging.info('Mongo Reader Alive %s' % str(worker_id))
    writer_conn = getNewConn()
    huddle_feed_coll = writer_conn.Agnes.huddle_feeds
    total_updated = 0
    batch = []

    while True:
        while not done_queue.empty():
            mongo_update = done_queue.get()
            batch.append(mongo_update)
        if len(batch) > 50:

            total_updated += len(batch)
            huddle_feed_coll.bulk_write(batch, ordered=False)
            batch = []

# returns True if huddle is up to date
def checkHuddle(huddle):
    if not 'live_update' in huddle:
        functions.initLiveUpdate(huddle['users_id'])
        huddle['live_update'] = []
    if not 'huddle_hash' in huddle or not 'currentFeed' in huddle or huddle['live_update']:
        return False
    else:

        stored_huddle_hash = huddle['huddle_hash']

        # print ''
        runtime_huddle_hash = generateNewHuddleHash(huddle)

        # print 'Hash Check'
        # # print 'User ID',huddle['users_id']
        # print 'Stored:',stored_huddle_hash
        # print runtime_huddle_hash
        # print
        return stored_huddle_hash == runtime_huddle_hash

def addLiveUpdates(user_huddle):
    live_updates = user_huddle['live_update']

    for item in live_updates:
        if not 'object' in item:
            continue
        item_type = item['type']
        item_entity = item['object']
        item_entity['timestamp'] = item['timeStamp']

        if item_type == 'groupUpdate':
            user_huddle['groupUpdate'] = [g_obj for g_obj in user_huddle['groupUpdate'] if g_obj['_id'] != item_entity['_id']]
            user_huddle['groupUpdate'].insert(0, item_entity)
        elif item_type == 'eventsFriend':
            user_huddle['eventsFriends'] = [f_obj for f_obj in user_huddle['eventsFriends'] if f_obj['_id'] != item_entity['_id']]
            user_huddle['eventsFriends'].insert(0,item_entity)
    user_huddle['groupUpdate'] = user_huddle['groupUpdate'][:50]
    user_huddle['eventsFriends'] = user_huddle['eventsFriends'][:50]
    return user_huddle

# remove events that are past
def cleanHuddle(huddle):
    huddle['recentlyAddedEvent'] = checkEventTimeList(huddle['recentlyAddedEvent'])
    huddle['eventTrending'] = checkEventTimeList(huddle['eventTrending'])
    huddle['eventsFriends'] = checkEventTimeList(huddle['eventsFriends'])
    huddle['eventFeatured'] = checkEventTimeList(huddle['eventFeatured'])
    huddle['recommendedEvent'] = checkEventTimeList(huddle['recommendedEvent'], debug=False)
    huddle['discoverEvent'] = checkEventTimeList(huddle['discoverEvent'])

    return huddle

def checkEventTimeList(event_list, debug=False):
    if debug:
        print len(event_list)
        print [checkEventTime(a) for a in event_list]
        raise ValueError('stap')
    return [a for a in event_list if checkEventTime(a)]

# returns true if event is within 30 minutes of ending, false otherwise
def checkEventTime(event):

    now = datetime.datetime.now()
    timedelta = event['endtime'] - now

    threshold = 30*60

    return timedelta.total_seconds() > threshold

def isGroupUpdate(item):
    return 'grpname' in item

def generateNewHuddleHash(huddle):
    wanted_keys = ['featuredGroup', 'latestGroupUpdate', 'groupUpdate', 'recommendedGroup', 'recommendedEvent', 'eventFeatured','eventTrending',
                   'recentlyAddedEvent', 'eventHappeningNow', 'news', 'eventsFriends', 'discoverGroup', 'discoverEvent', '_id']
    for key in huddle.keys():
        if not key in wanted_keys:
            del huddle[key]

    # for key in wanted_keys:
    #     if isinstance(huddle[key], list):
    #         print key, len(huddle[key])
    #     else:
    #         print key, huddle[key]
    # start = time.time()
    # json_util.dumps(huddle, sort_keys=True)
    # # json.dumps(huddle, sort_keys=True)
    # end = time.time()
    # print 'json time',end-start
    # print hashlib.sha1(json_util.dumps(huddle, sort_keys=True)).hexdigest()
    return hashlib.sha1(json_util.dumps(huddle, sort_keys=True)).hexdigest()

def rankHuddle(huddle):
    return rankItemsA(huddle)

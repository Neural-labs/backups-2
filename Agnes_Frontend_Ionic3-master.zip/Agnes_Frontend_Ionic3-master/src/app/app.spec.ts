import { TestBed, ComponentFixture, async } from '@angular/core/testing';
import { IonicModule } from 'ionic-angular';
import { HttpModule } from '@angular/http';
import { Agnes } from './app.component';
import { LoginPage } from '../pages/login/login';
import { Deploy } from '@ionic/cloud-angular';
import { DeployMock } from '../mocks';

import { ActionSheet } from '@ionic-native/action-sheet';
import { Badge } from '@ionic-native/badge';
import { Calendar } from '@ionic-native/calendar';
import { Camera } from '@ionic-native/camera';
import { DatePicker } from '@ionic-native/date-picker';
import { Deeplinks } from '@ionic-native/deeplinks';
import { Device } from '@ionic-native/device';
import { Facebook } from '@ionic-native/facebook';
import { Geolocation } from '@ionic-native/geolocation';
import { Keyboard } from '@ionic-native/keyboard';
import { LaunchNavigator } from '@ionic-native/launch-navigator';
import { Network } from '@ionic-native/network';
import { PhotoViewer } from '@ionic-native/photo-viewer';
import { Push } from '@ionic-native/push';
import { SocialSharing } from '@ionic-native/social-sharing';
import { SplashScreen } from '@ionic-native/splash-screen';
import { StatusBar } from '@ionic-native/status-bar';

let comp: Agnes;
let fixture: ComponentFixture<Agnes>;

describe('Component: Root Component', () => {

    beforeEach(async(() => {

        TestBed.configureTestingModule({

            declarations: [Agnes, LoginPage],

            providers: [
                { provide: Deploy, useClass: DeployMock},
                ActionSheet,
                Badge,
                Calendar,
                Camera,
                DatePicker,
                Deeplinks,
                Device,
                Facebook,
                Geolocation,
                Keyboard,
                LaunchNavigator,
                Network,
                PhotoViewer,
                Push,
                SocialSharing,
                SplashScreen,
                StatusBar
            ],

            imports: [
                HttpModule,
                IonicModule.forRoot(Agnes)
            ]

        }).compileComponents();

    }));

    beforeEach(() => {

        fixture = TestBed.createComponent(Agnes);
        comp    = fixture.componentInstance;

    });

    afterEach(() => {
        fixture.destroy();
        comp = null;
    });

    it('is created', () => {

        expect(fixture).toBeTruthy();
        expect(comp).toBeTruthy();

    });

    it('initialises with a root page of LoginPage', () => {
        expect(comp['rootPage']).toBe('LoginPage');
    });

});
"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var core_1 = require('@angular/core');
var ionic_angular_1 = require('ionic-angular');
var people_service_1 = require('./people.service');
var ionic_native_1 = require('ionic-native');
var PeoplePage = (function () {
    function PeoplePage(navCtrl, events, peopleService, platform, popoverCtrl) {
        this.navCtrl = navCtrl;
        this.events = events;
        this.peopleService = peopleService;
        this.popoverCtrl = popoverCtrl;
        this.people = [];
        this.displayed = [];
        this.platform = platform;
    }
    PeoplePage.prototype.ngOnInit = function () {
        this.initPeople();
    };
    PeoplePage.prototype.ionViewWillEnter = function () {
        this.events.publish('showChat', true);
    };
    PeoplePage.prototype.initPeople = function () {
        this.loading = true;
        if (ionic_native_1.Network.type != 'none') {
            this.noInternet = false;
            ionic_native_1.GoogleAnalytics.trackView("People");
            this.user = JSON.parse(localStorage.getItem("agnesUser"));
            this.searchOpen = true;
            this.peopleSearch = "";
            this.searching = false;
            this.studentTypes = ["freshman", "sophomore", "junior", "senior", "fifth year", "masters", "phd"];
            this.getPeople(null);
        }
        else {
            this.noInternet = true;
            this.loading = false;
        }
    };
    PeoplePage.prototype.getPeople = function (refresher) {
        var _this = this;
        var stored = JSON.parse(localStorage.getItem('agnesPeople'));
        var t = new Date(JSON.parse(localStorage.getItem('agnesPeopleTimeout')));
        var timeout = new Date(t.setHours(t.getHours() + 12));
        var now = new Date();
        if (!stored || now > timeout || stored.length == 0) {
            var data = { 'users_id': this.user["_id"], 'user': this.user, 'community': this.user['community'] };
            this.peopleService.getPeople(data).then(function (value) {
                if (refresher) {
                    refresher.complete();
                }
                if (value) {
                    _this.displayPeople(value, false);
                }
            }).catch(function (error) {
                if (refresher) {
                    refresher.complete();
                }
                _this.loading = false;
                //if timeout, show connection error screen
                if (error == 'timeout') {
                    _this.noInternet = true;
                }
                console.log(error);
            });
        }
        else {
            this.loading = false;
            this.displayed = stored;
            if (refresher) {
                refresher.complete();
            }
        }
    };
    PeoplePage.prototype.isStudent = function (type) {
        return (this.studentTypes.indexOf(type.toLowerCase()) != -1);
    };
    PeoplePage.prototype.loaded = function () {
        this.loading = false;
    };
    PeoplePage.prototype.displayPeople = function (people, addingMore) {
        var ids = this.people.map(function (a) { return a._id; });
        var adding = [];
        for (var p in people) {
            if (this.isStudent(people[p]['studenttype'])) {
                if ((ids.indexOf(people[p]["_id"]) == -1 && people[p]['_id'] != this.user['_id']) || this.searching) {
                    people[p].keywordString = people[p].keywords.map(function (a) { return a.name; }).toString().replace(/,/g, ', ');
                    adding.push(people[p]);
                }
            }
        }
        if (!this.searching) {
            if (addingMore) {
                this.people = this.people.concat(adding);
            }
            else {
                this.people = adding;
            }
            this.displayed = this.people;
            localStorage.setItem('agnesPeople', JSON.stringify(this.displayed));
            localStorage.setItem('agnesPeopleTimeout', JSON.stringify(new Date()));
        }
        else {
            this.displayed = adding;
        }
    };
    PeoplePage.prototype.searchPeople = function () {
        var _this = this;
        this.peopleContent.scrollToTop(0);
        this.searching = true;
        var filter = this.peopleSearch;
        var data = { "searchTerm": filter, "community": this.user['community'] };
        if (filter && filter.length > 0) {
            this.peopleService.searchPeople(data).then(function (value) {
                if (value) {
                    _this.displayPeople(value, false);
                }
            }).catch(function (error) { console.log(error); });
        }
        else {
            this.searching = false;
            this.displayed = JSON.parse(localStorage.getItem('agnesPeople'));
        }
    };
    PeoplePage.prototype.loadMorePeople = function (infiniteScroll) {
        var _this = this;
        var data = {
            "users_id": this.user["_id"],
            "_id": this.displayed[this.displayed.length - 1]["_id"]
        };
        this.peopleService.loadMorePeople(data).then(function (value) {
            if (value.filter(function (a) {
                return _this.isStudent(a['studenttype']);
            }).length == 0) {
                infiniteScroll.enable(false);
            }
            else {
                _this.displayPeople(value, true);
            }
            infiniteScroll.complete();
        }).catch(function (error) { console.log(error); });
    };
    //clear search bar
    PeoplePage.prototype.clearSearch = function () {
        this.searchOpen = false;
        this.displayed = JSON.parse(localStorage.getItem('agnesPeople'));
        this.peopleSearch = "";
        this.searching = false;
        this.peopleContent.scrollToTop(0);
    };
    PeoplePage.prototype.refreshPeople = function (refresher) {
        localStorage.removeItem('agnesPeople');
        localStorage.removeItem('agnesPeopleTimeout');
        this.people = [];
        this.getPeople(refresher);
    };
    __decorate([
        core_1.ViewChild(ionic_angular_1.Content)
    ], PeoplePage.prototype, "peopleContent", void 0);
    PeoplePage = __decorate([
        core_1.Component({
            selector: 'page-people',
            templateUrl: 'people.html',
            providers: [people_service_1.PeopleService]
        })
    ], PeoplePage);
    return PeoplePage;
}());
exports.PeoplePage = PeoplePage;

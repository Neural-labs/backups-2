"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var core_1 = require('@angular/core');
var events_service_1 = require('../../events/events.service');
var login_service_1 = require('../../login/login.service');
var me_service_1 = require('../../me/me.service');
var groups_service_1 = require('../../groups/groups.service');
var app_component_1 = require('../../../app/app.component');
var InviteFriends = (function () {
    function InviteFriends(navCtrl, platform, eventsService, loginService, meService, groupsService, viewCtrl, navParams, facebook, socialSharing) {
        this.navCtrl = navCtrl;
        this.platform = platform;
        this.eventsService = eventsService;
        this.loginService = loginService;
        this.meService = meService;
        this.groupsService = groupsService;
        this.viewCtrl = viewCtrl;
        this.navParams = navParams;
        this.facebook = facebook;
        this.socialSharing = socialSharing;
    }
    InviteFriends.prototype.ngOnInit = function () {
        this.user = this.navParams.data.user;
        this.objectID = this.navParams.data.objectID;
        this.type = this.navParams.data.type;
        this.friends = [];
        this.peopleSearch = '';
        this.searching = false;
        this.loading = true;
        this.invites = [];
        this.event = this.navParams.data.event;
        this.buttonText = this.type == 'share' ? 'Share' : 'Invite';
        this.helpText = (this.type == 'IGIYG')
            ? "Select friends below to let them know that you'll go to this event if they will"
            : (this.type == 'share'
                ? "Select friends to share this event with"
                : "Select friends you want to invite to your group");
        this.getFriends();
    };
    //close this popup
    InviteFriends.prototype.closeInviteSearch = function () {
        this.viewCtrl.dismiss(null, {}, {
            animate: true,
            animation: 'ios-transition',
            duration: 350,
            easing: "ease-in-out",
            direction: "back"
        });
    };
    //filter friend list by name (first or last)
    InviteFriends.prototype.matchesSearch = function (person) {
        var term = this.peopleSearch.trim().toLowerCase();
        var len = term.length;
        if (len > 0) {
            if (term.indexOf(' ') != -1) {
                //user has searched a first and last name
                var ts = term.replace(/\s+/g, ' ').split(' ');
                var fname_1 = person['fname'].toLowerCase().substring(0, ts[0].length) == ts[0];
                var lname_1 = person['lname'].toLowerCase().substring(0, ts[1].length) == ts[1];
                return (fname_1 && lname_1);
            }
            var fname = person['fname'].toLowerCase().substring(0, len) == term;
            var lname = person['lname'].toLowerCase().substring(0, len) == term;
            return (fname || lname);
        }
        else {
            return true;
        }
    };
    //close search
    InviteFriends.prototype.clearSearch = function () {
        this.searching = false;
        this.peopleSearch = "";
    };
    //invite friends to download Agnes by sharing download link
    InviteFriends.prototype.inviteFriendsToAgnes = function () {
        //tracking
        if (window['fabric']) {
            window['fabric'].Answers.sendCustomEvent('IGIYG search', { type: 'invite' });
        }
        if (this.platform.is('cordova')) {
            var link = 'http://onelink.to/hrnse3';
            var message = "Hey check out this new events app!\n" + link;
            var subj = "Agnes: new events app";
            this.socialSharing.share(message, subj, '', '')
                .then(function (val) {
            })
                .catch(function (err) {
                app_component_1.Agnes.showError("Couldn't share the app with friends, try again!");
            });
        }
        else {
            app_component_1.Agnes.showError("Please install Agnes from the App Store or Google Play store to share groups.");
        }
    };
    //add or remove someone from invites list
    InviteFriends.prototype.listInvite = function (person) {
        var id = person['_id'];
        var ind = this.invites.indexOf(id);
        if (ind == -1) {
            this.invites.push(id);
        }
        else {
            this.invites.splice(ind, 1);
        }
    };
    //connect user's account to user's FB data
    InviteFriends.prototype.connectFB = function () {
        var _this = this;
        //tracking
        if (window['fabric']) {
            window['fabric'].Answers.sendCustomEvent('IGIYG search', { type: 'connect to FB' });
        }
        this.facebook.getLoginStatus().then(function (value) {
            console.log(value);
            if (value && value.status) {
                var upd_1 = {
                    access_token: '',
                    users_id: _this.user['_id']
                };
                if (value.status == 'connected') {
                    upd_1['access_token'] = value['authResponse']['accessToken'];
                    _this.loginService.fbUpdate(upd_1).then(function (value) {
                        _this.getFriends();
                    }).catch(function (err) {
                        console.log('fb after update error', err);
                        app_component_1.Agnes.showError('Could not connect to Facebook - please try again!');
                    });
                }
                else if (value.status == 'not_authorized') {
                    app_component_1.Agnes.showError('Please allow Agnes access to your Facebook account!');
                }
                else {
                    var permissions = ['public_profile',
                        'user_friends',
                        'email',
                        'user_about_me',
                        'user_education_history',
                        'user_birthday',
                        'user_managed_groups',
                        'user_likes',
                        'user_work_history',
                        'pages_show_list',
                        'user_religion_politics'];
                    _this.facebook.login(permissions).then(function (value) {
                        if (value && value.status == 'connected') {
                            upd_1['access_token'] = value['authResponse']['accessToken'];
                            _this.loginService.fbUpdate(upd_1).then(function (value) {
                                _this.getFriends();
                            }).catch(function (err) {
                                console.log('fb after update error', err);
                                app_component_1.Agnes.showError('Could not connect to Facebook - please try again!');
                            });
                        }
                        else {
                            app_component_1.Agnes.showError('Could not connect to Facebook - please try again!');
                        }
                    }).catch(function (error) {
                        console.log('Facebook.login error', error);
                        app_component_1.Agnes.showError('Could not connect to Facebook - please try again!');
                    });
                }
            }
        }).catch(function (error) { app_component_1.Agnes.showError('Could not connect to Facebook - please try again!'); });
    };
    //get list of Agnes users who are connected to this user via FB
    InviteFriends.prototype.getFriends = function () {
        var _this = this;
        var data = {
            "users_id": this.user['_id'],
            "community": this.user['community']
        };
        this.meService.getFriends(data).then(function (value) {
            _this.loading = false;
            _this.friends = value.friends;
            _this.fb = value.fb;
        }).catch(function (err) {
            _this.loading = false;
            console.log(err);
            app_component_1.Agnes.showError("Couldn't retrieve your friends, try again!");
        });
    };
    //send invites to all friends in invites list
    InviteFriends.prototype.sendInvites = function () {
        var _this = this;
        if (this.invites.length > 0) {
            //tracking
            if (window['fabric']) {
                window['fabric'].Answers.sendCustomEvent('IGIYG search', { type: 'send IGIYG' });
            }
            //send I'll Go If You Go invites
            if (this.type == 'IGIYG') {
                var data = {
                    'sender_users_id': this.user['_id'],
                    'receiver_users_id': '',
                    'events_id': this.objectID
                };
                for (var i = 0; i < this.invites.length; i++) {
                    data['receiver_users_id'] = this.invites[i];
                    this.eventsService.sendIYG(data).then(function (value) {
                        _this.closeInviteSearch();
                    }).catch(function (err) {
                        app_component_1.Agnes.showError("Sorry, there was a problem sending your invites - try again!");
                    });
                }
            }
            else if (this.type == 'group') {
                var data = {
                    "groups_id": this.objectID,
                    "users_id": '',
                    "sharedby": this.user['_id'],
                    "community": this.user['community']
                };
                for (var i = 0; i < this.invites.length; i++) {
                    data['users_id'] = this.invites[i];
                    this.groupsService.inviteUserToGroup(data).then(function (value) {
                        _this.closeInviteSearch();
                    }).catch(function (err) {
                        app_component_1.Agnes.showError("Sorry, there was a problem sending your invites - try again!");
                    });
                }
            }
            else if (this.type == 'share') {
                var data = {
                    'sender_users_id': this.user['_id'],
                    'receiver_users_id': '',
                    'events_id': this.objectID
                };
                for (var i = 0; i < this.invites.length; i++) {
                    data['receiver_users_id'] = this.invites[i];
                    this.eventsService.shareEvent(data).then(function (value) {
                        _this.closeInviteSearch();
                    }).catch(function (err) {
                        app_component_1.Agnes.showError("Sorry, there was a problem sending your invites - try again!");
                    });
                }
            }
        }
    };
    InviteFriends.prototype.loaded = function (last, person) {
        var ind = this.friends.indexOf(person);
        this.friends[ind]['noPic'] = false;
        this.loading = last;
    };
    InviteFriends.prototype.imgError = function (last, person) {
        var ind = this.friends.indexOf(person);
        this.friends[ind]['noPic'] = true;
        this.loading = last;
    };
    InviteFriends.prototype.shareOutside = function () {
        if (this.platform.is('cordova')) {
            var message = "Hey! I think you might be interested in this event:\n\n" +
                this.event['evtname'] + '\n\n';
            var subj = "Check out \"" + this.event['evtname'] + "\"";
            this.socialSharing.share(message, subj, this.event['picurl'], 'https://agnes.io/share/event/' + this.event['_id'])
                .then(function (val) {
            })
                .catch(function (err) {
            });
        }
        else {
            app_component_1.Agnes.showError("Please install Agnes from the App Store or Google Play store to share events.");
        }
    };
    InviteFriends = __decorate([
        core_1.Component({
            selector: 'invite-friends',
            templateUrl: 'invite-friends.html',
            providers: [events_service_1.EventsService, login_service_1.LoginService, me_service_1.MeService, groups_service_1.GroupsService]
        })
    ], InviteFriends);
    return InviteFriends;
}());
exports.InviteFriends = InviteFriends;

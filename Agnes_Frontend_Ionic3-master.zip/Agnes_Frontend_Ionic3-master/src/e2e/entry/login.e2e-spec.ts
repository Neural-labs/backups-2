// import { browser, element, by, ElementFinder } from 'protractor';
// import { TestBed, ComponentFixture, async } from '@angular/core/testing';
// import { DebugElement } from '@angular/core';
//
// import { IonicModule } from 'ionic-angular';
// import { HttpModule } from '@angular/http';
// import { Agnes } from '../../app/app.component';
//
// import { LoginPageObject } from './page-objects/login.page-object';
//
// import { LoginPage } from '../../pages/login/login';
//
// import { FormBuilder } from '@angular/forms';
// import { NavController, AlertController, PopoverController, Platform, Events, App, MenuController, IonicPage } from 'ionic-angular';
//
//
// import { LoginService }  from '../../providers/login.service';
// import { MeService } from '../../providers/me.service';
//
// import { AppMock } from '../../mocks';
//
// let comp: LoginPage;
// let de: DebugElement;
// let el: HTMLElement;
// let navCtrl: NavController;
//
// let loginPage = new LoginPageObject();
// let loginOverlay = new LoginOverlayObject();

// describe('Login Page Test', () => {

    // Run before each function
    // beforeEach(() => {
    //     browser.waitForAngularEnabled(false);
    //     browser.get('')
    //     browser.driver.sleep(500);
    // });
    //
    // afterEach(() => {
    //     browser.executeScript('window.sessionStorage.clear();');
    //     browser.executeScript('window.localStorage.clear();');
    // });

    // Check logo image and text displays
    // it('Logos display correctly',() => {
    //     let pic = loginPage.getPic()
    //     let text = loginPage.getText()
    //
    //     expect(pic.isDisplayed()).toBeTruthy()
    //     expect(text.isDisplayed()).toBeTruthy()
    // })

    // Check Buttons Display
    // it('Login Buttons display correctly',() => {
    //
    //     browser.explore()
    //
    //     let fbIcon = loginPage.getFBicon()
    //     let fbText = loginPage.getFBText()
    //     let loginText = loginPage.getLoginButton()
    //     let signup = loginPage.getSignupButton()
    //
    //
    //     expect(fbIcon.isDisplayed()).toBeTruthy()
    //     expect(fbText.isDisplayed()).toBeTruthy()
    //     expect(loginText.isDisplayed()).toBeTruthy()
    //     expect(signup.isDisplayed()).toBeTruthy()
    // })

    // Make sure that the app correctly goes to the signup page
    // it('Signup Button transitions to signup correctly',() => {
    //     let signup = loginPage.getSignupButton()
    //
    //     signup.click().then(function(){
    //         return browser.driver.wait(function() {
    //             return browser.driver.getCurrentUrl().then(function(url) {
    //                 return /questions/.test(url);
    //             });
    //         }, 10000);
    //     });
    // })

    // Same thing but with the login popover
    // it('Login Button transitions to login correctly', () => {
    //     let login = loginPage.getLoginButton()
        // browser.wait(protractor.ExpectedConditions.presenceOf(this.uploadFileButton), 5000);
    //
    //     login.click().then(function(){
    //         return browser.driver.wait(function() {
    //
    //             let display = loginPopup.getDisplay()
    //
    //             return display.isDisplayed()
    //
    //         }, 10000);
    //     });
    // })
    //






    // it('login page is displayed by default', () => {
    //
    //     expect(element(by.css('.ion-page.show-page ion-content'))
    //         .getAttribute('id'))
    //         .toContain('loginPage');
    //
    // });
    //
    // it('clicking Login button has opened login popup', () => {
    //     loginPage.getLoginButton().click();
    //     browser.driver.sleep(500);
    //
    //     expect(element(by.css('ion-popover ion-content')) // Grab the title of the selected tab
    //         .getAttribute('id')) // Get the text content
    //         .toContain('loginPopup');
    // });
    //
    // it('clicking Signup with Email button brings user to questions page', () => {
    //
    //     let signupButton = loginPage.getSignupButton();
    //     signupButton.click();
    //
    //     browser.driver.sleep(1000);
    //
    //     expect(element(by.css('.ion-page.show-page ion-content')) // Grab the title of the selected tab
    //         .getAttribute('id')) // Get the text content
    //         .toContain('questions');
    // });
    //
    // it('auto login successful after logging in and restarting', () => {
    //    loginPage.getLoginButton().click();
    //    browser.driver.sleep(500);
    //
    //    browser.driver.actions().mouseDown(loginPopup.getInput('email')).click().sendKeys("becca@groupten.com").perform();
    //    browser.driver.actions().mouseDown(loginPopup.getInput('password')).click().sendKeys("alalalal").perform();
    //
    //    browser.driver.sleep(500);
    //    loginPopup.getLoginButton().click();
    //
    //    browser.driver.sleep(1000);
    //    browser.get('');
    //
    //    browser.driver.sleep(1000);
    //    expect(element(by.css('page-events')).isPresent()).toBeTruthy();
    // });

// });
// // let loginOverlay = new LoginOverlayObject();
//
// describe('Login Page Test', () => {
//
//     // Run before each function
//     beforeEach(() => {
//         browser.waitForAngularEnabled(false);
//         browser.get('')
//         browser.driver.sleep(500);
//     });
//
//     afterEach(() => {
//         browser.executeScript('window.sessionStorage.clear();');
//         browser.executeScript('window.localStorage.clear();');
//     });
//
//     // Check logo image and text displays
//     it('Logos display correctly',() => {
//         let pic = loginPage.getPic()
//         let text = loginPage.getText()
//
//         expect(pic.isDisplayed()).toBeTruthy()
//         expect(text.isDisplayed()).toBeTruthy()
//     })
//
//     // Check Buttons Display
//     it('Login Buttons display correctly',() => {
//
//         browser.explore()
//
//         let fbIcon = loginPage.getFBicon()
//         let fbText = loginPage.getFBText()
//         let loginText = loginPage.getLoginButton()
//         let signup = loginPage.getSignupButton()
//
//
//         expect(fbIcon.isDisplayed()).toBeTruthy()
//         expect(fbText.isDisplayed()).toBeTruthy()
//         expect(loginText.isDisplayed()).toBeTruthy()
//         expect(signup.isDisplayed()).toBeTruthy()
//     })
//
//     // Make sure that the app correctly goes to the signup page
//     it('Signup Button transitions to signup correctly',() => {
//         let signup = loginPage.getSignupButton()
//
//         signup.click().then(function(){
//             return browser.driver.wait(function() {
//                 return browser.driver.getCurrentUrl().then(function(url) {
//                     return /questions/.test(url);
//                 });
//             }, 10000);
//         });
//     })
//
//     // Same thing but with the login popover
//     it('Login Button transitions to login correctly', () => {
//         let login = loginPage.getLoginButton()
//         // browser.wait(protractor.ExpectedConditions.presenceOf(this.uploadFileButton), 5000);
//
//         login.click().then(function(){
//             return browser.driver.wait(function() {
//
//                 let display = loginPopup.getDisplay()
//
//                 return display.isDisplayed()
//
//             }, 10000);
//         });
//     })
//
//
//
//
//
//
//
//     // it('login page is displayed by default', () => {
//     //
//     //     expect(element(by.css('.ion-page.show-page ion-content'))
//     //         .getAttribute('id'))
//     //         .toContain('loginPage');
//     //
//     // });
//     //
//     // it('clicking Login button has opened login popup', () => {
//     //     loginPage.getLoginButton().click();
//     //     browser.driver.sleep(500);
//     //
//     //     expect(element(by.css('ion-popover ion-content')) // Grab the title of the selected tab
//     //         .getAttribute('id')) // Get the text content
//     //         .toContain('loginPopup');
//     // });
//     //
//     // it('clicking Signup with Email button brings user to questions page', () => {
//     //
//     //     let signupButton = loginPage.getSignupButton();
//     //     signupButton.click();
//     //
//     //     browser.driver.sleep(1000);
//     //
//     //     expect(element(by.css('.ion-page.show-page ion-content')) // Grab the title of the selected tab
//     //         .getAttribute('id')) // Get the text content
//     //         .toContain('questions');
//     // });
//     //
//     // it('auto login successful after logging in and restarting', () => {
//     //    loginPage.getLoginButton().click();
//     //    browser.driver.sleep(500);
//     //
//     //    browser.driver.actions().mouseDown(loginPopup.getInput('email')).click().sendKeys("becca@groupten.com").perform();
//     //    browser.driver.actions().mouseDown(loginPopup.getInput('password')).click().sendKeys("alalalal").perform();
//     //
//     //    browser.driver.sleep(500);
//     //    loginPopup.getLoginButton().click();
//     //
//     //    browser.driver.sleep(1000);
//     //    browser.get('');
//     //
//     //    browser.driver.sleep(1000);
//     //    expect(element(by.css('page-events')).isPresent()).toBeTruthy();
//     // });
//
// });

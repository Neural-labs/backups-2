# imports
import socket

import requests
import urllib3

from config import db_config
from positiveConfig import config

# Config
CONFIG = db_config.getConfig()
dbconn = CONFIG['dbConn']

# DB
Agnes = dbconn.Agnes

# Collections
evtsourceColl = Agnes.evtSource_Community
calendarColl = Agnes.autocrawler_calendarData



def CollectPositive():

    URLs = config['urls']

    for url in URLs:
        error,HTML = sendHTTPCall(url)
        if not error:
            pageItem = {}
            pageItem['url'] = url
            pageItem['HTML'] = HTML
            pageItem['label'] = True
            insertIntoMongo(pageItem)





def getEvtSources():
    cursor = evtsourceColl.find({})
    evtsources = []
    for item in cursor:
        evtsources.append("http://www." + item['evtsource'].encode('ascii','ignore'))
    return evtsources


def sendHTTPCall(url):
    response = ''
    error = False
    try:
        response = requests.get(url, timeout=5)

    except socket.timeout as e:
        print(e, url)
        error = True

    except socket.error as e:
        print(e, url)
        error = True

    except UnicodeEncodeError as e:
        print (e, url)
        error = True

    except requests.exceptions.Timeout as e:
        print (e, url)
        error = True

    except urllib3.exceptions.LocationParseError as e:
        print (e, url)
        error = True

    except requests.exceptions.RequestException as e:
        print (e, url)
        error = True

    if not error:
        response = response.text

    return error, response

def insertIntoMongo(pageItem):
    calendarColl.find_one_and_update({"url":pageItem['url']},{"$set":{"HTML":pageItem['HTML'],"label":pageItem['label']}}, upsert=True)
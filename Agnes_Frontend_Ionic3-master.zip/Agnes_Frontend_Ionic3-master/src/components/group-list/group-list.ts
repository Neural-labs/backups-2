import { Component, Input, Output, EventEmitter } from '@angular/core';
import { PopoverController, Platform, Events, App } from 'ionic-angular';


@Component({
  selector: 'group-list',
  templateUrl: 'group-list.html',
  providers: []
})

export class GroupList {
  @Input() groupList;
  @Input() user;
  @Input() isMatched;
  @Input() hasStatus;
  @Output() groupEmitter: EventEmitter<any> = new EventEmitter();

  constructor(public popoverCtrl: PopoverController,
              private events: Events,
              public appCtrl:App,
              private platform: Platform) {
  }

  openGroupProfile(group){

    this.events.subscribe('groupProfileData', data => {
      if(data){
        this.groupEmitter.emit(data);
      }
      this.events.unsubscribe('groupProfileData');
    });

    this.appCtrl.getRootNav().push(
      'GroupProfile',
      {
        'group':group,
        'user':this.user,
        'platform': this.platform
      }, {
        animation: 'ios-transition',
        duration: 350
      });
  }
}

import { Component } from '@angular/core';
import { ViewController, NavParams } from 'ionic-angular';


@Component({
  selector: 'map-options',
  templateUrl: 'map-options.html',
  providers: []

})

export class MapOptions {
  selected: string;
  maps: Array<string>;

  constructor(public viewCtrl: ViewController,
              private navParams: NavParams) {
  }

  ngOnInit(){
    this.maps = this.navParams.data.maps;
  }

  closeMapOptions(data) {
    this.viewCtrl.dismiss(data, '', {
      animate: true,
      animation: 'ios-transition',
      duration: 350,
      easing: "ease-in-out",
      direction: "back"
    });
  }

}

"""
Module for embedding html using both positive and negative pages

Each 'sentence' is one entire html page tokenized as follows:

<tag attribute="value0 value1"></tag> => "tag value0 value1 .. valueN /tag"


"""
from gensim.models import Word2Vec
from config import db_config
from CollectIdentificationFeatures import tokenizeH2V_W
from Utilities.DataFilter import getCleanSoup
from multiprocessing import cpu_count
import logging
import gc
import sys
sys.setrecursionlimit(5000)

dbConn = db_config.getDBConn('dev')
Agnes = dbConn.Agnes
Event_Collection = Agnes.autocrawler_events
Domain_Collection = Agnes.autocrawler_domain_pages

batch_size = 100
cores = cpu_count()

class TokenIterator(object):

    def __iter__(self):
        for item in pageGenerator():
            # # print '??'
            # print item
            # raise ValueError('stap')
            yield item
        dbConn.close()

def runEmbeddingTrainer():

    sentences = TokenIterator()

    # (
    # sentences = None, size = 100, alpha = 0.025, window = 5, min_count = 5, max_vocab_size = None, sample = 0.001, seed = 1, workers = 3, min_alpha = 0.0001, sg = 0, hs = 0, negative = 5, cbow_mean = 1, hashfxn = < built - in function
    # hash >, iter = 5, null_word = 0, trim_rule = None, sorted_vocab = 1, batch_words = 10000, compute_loss = False, callbacks = ())

    # sentences, size=100, window=5, min_count=5, workers=4
    model = Word2Vec(sentences,size=200, sg=1, min_count=1, workers=cores)
    fname = 'gensim_model_page_embedding'
    model.save(fname)

def pageGenerator():

    for page in posGenerator():
        try:
            html = str(getCleanSoup(page['HTML']))
            tokens = tokenizeH2V_W(html, find_body=False)
            if tokens:
                # if 'head' == tokens[0]:
                #     # print html
                #     print tokens
                #     print tokens.index('head')
                #     print page['url']
                #     raise ValueError('stop')
                yield tokens
        except RuntimeError as e:
            print e

    for page in negGenerator():
        try:
            html = str(getCleanSoup(page['HTML']))
            tokens = tokenizeH2V_W(html, find_body=False)
            if tokens:
                yield tokens
        except RuntimeError as e:
            print e

    return

def posGenerator():
    total_samples = Event_Collection.count()
    counter = 0
    last_id = None
    while True:
        batch = getSampleBatchCursor(Event_Collection, last_id)
        batch_count = batch.count(with_limit_and_skip=True)

        if not batch or not batch_count:
            break

        last_id = batch[batch_count-1]['_id']

        for item in batch:
            if counter % 100 == 0:
                logging.info('Pos Generator - %d of %d, LastID: %s' % (counter, total_samples, str(last_id)))
            if valid(item):
                yield item
                counter += 1
        del batch
        gc.collect()

def negGenerator():
    total_samples = Domain_Collection.count()
    counter = 0
    last_id = None
    while True:
        batch = getSampleBatchCursor(Domain_Collection, last_id)
        batch_count = batch.count(with_limit_and_skip=True)

        if not batch or not batch_count:
            break

        last_id = batch[batch_count-1]['_id']

        for item in batch:
            if counter % 100 == 0:
                logging.info('Neg Generator - %d of %d, LastID: %s' % (counter, total_samples, str(last_id)))
            if valid(item):
                yield item
                counter += 1

        del batch
        gc.collect()

def valid(item):
    if 'HTML' not in item:
        return False
    return True

def getSampleBatchCursor(collection, last_id):
    if not last_id:
        return collection.find({}, no_cursor_timeout=True).limit(batch_size).sort('_id',1)
    return collection.find({'_id': {'$gt': last_id}}, {'HTML':1, 'url':1}, no_cursor_timeout=True).limit(batch_size)
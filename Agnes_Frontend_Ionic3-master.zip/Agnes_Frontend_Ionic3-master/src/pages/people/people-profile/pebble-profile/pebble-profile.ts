import { Component, ViewChild } from '@angular/core';
import { Platform, NavParams, PopoverController, ToastController,
  ActionSheetController, NavController, Events, IonicPage, Slides} from 'ionic-angular';

import { MeService } from '../../../../providers/me.service';
import { AnalyticsService } from '../../../../providers/analytics.service';
import {PeopleService} from '../../../../providers/people.service'

import { Agnes } from '../../../../app/app.component';



@IonicPage()
@Component({
  selector: 'pebble-profile',
  templateUrl: 'pebble-profile.html',
  providers: [MeService, PeopleService, AnalyticsService]

})

export class PebbleProfile {

  user:Object;
  person: Object;
  isMe: boolean;
  referralCode: string;

  page: number;
  progressSlides: Array<Object>
  direction: string;
  streak : number;
  streakGoal : number;
  lifetime: number;
  reward : number;
  streakCountdown: any;
  rewardCountdown : number;

  currFriends: number;
  currCampus: number;
  currAgnes: number;
  currLoadPage: number;

  currRankings: Array<Object>

  noFriends: boolean;
  scrollEnabled: boolean;


  @ViewChild('pebbleProgressSlides') slides:Slides;

  constructor(private navParams: NavParams,
              public navCtrl: NavController,
              public popoverCtrl: PopoverController,
              private meService: MeService,
              private analyticsService: AnalyticsService,
              private peopleService: PeopleService,
              private events: Events,
              private platform: Platform) {
  }

  ngOnInit(){
    this.user = JSON.parse(localStorage.getItem('agnesUser'));
    this.person = this.navParams.get('person');
    this.isMe = this.navParams.get('isMe');

    this.page = this.navParams.get('page');
    this.direction = 'forwards';
    this.noFriends = this.navParams.get('noFriends')
    this.scrollEnabled = true;


    this.streak = this.navParams.get('streak');
    this.streakGoal = this.navParams.get('streakGoal');
    this.lifetime = this.navParams.get('lifetime');
    this.reward = this.navParams.get('reward');
    this.currRankings = [];

    //converting the numerics in the sentences to words
    var converter = require('number-to-words');
    this.streakCountdown = (converter.toWords(this.streakGoal - this.streak))
    this.rewardCountdown = converter.toWords(50 - this.reward)

    //preparing the headers for all the slides
    this.progressSlides = [{'label': 'Day Streak', 'blurb': this.streakCountdown + ' days left until you get a bonus pebble!', 'curr' : this.streak, 'goal' : this.streakGoal}]
    this.progressSlides.push({'label': 'Until Reward', 'blurb': this.reward != 50 ? 'Only ' + this.rewardCountdown + ' more pebbles left to earn until you can claim a $10 gift card of your choice!' : 'Congrats! Click to claim your reward!', 'curr' : this.reward , 'goal' : 50})
    this.progressSlides.push({'label': 'Lifetime Pebbles', 'blurb': 'The total amount of pebbles you have accrued on the Agnes App', 'curr' : this.lifetime, 'goal' : this.lifetime})

    if(this.page == 0) {
      this.loadRanks()
    }

    this.retrieveCode()

    //send Pebble Profile view analytics
    this.analyticsService.logAnalytics({community: this.user['community'], users_id: this.user['_id']}, '/pebblePageView');
  }

  closePebbleProfile() {
    //send Back Button analytics
    this.analyticsService.logAnalytics({
      backButtonName: 'pebbleProfile',
      users_id: this.user['_id']}, '/backButton');

    this.navCtrl.pop({
        animation: 'ios-transition',
        duration: 350,
        easing: "ease-in-out",
        direction: "back"
    });
  }



  progressSlideChanged(){
    this.currLoadPage = 1;
    this.scrollEnabled = true;
    this.currRankings = [];
    let curr = this.slides.getActiveIndex()
    if(curr < this.page) {
      this.direction = 'backwards'
    } else {
      this.direction = 'forwards'
    }
    this.page = curr;

    this.loadRanks()
  }

  //preparing the data for the bottom half of all the slides
  loadRanks() {
    let data = {"users_id":this.person['_id'], "community":this.person['community']}
    switch(this.page) {
      case 0:
        this.retrieveStreakRanks(data)
        break
      case 1:
        this.retrieveRewardRanks(data)
        break
      case 2:
        this.retrieveLifeRanks(data)
    }
  }

  retrieveStreakRanks(data) {

    if(!this.noFriends) {
      this.peopleService.streakFriends(data).then(value => {
        this.currFriends = value['dayStreakAmongFriends']
      }).catch(error => {
        console.log(error)
      })
    }

    this.peopleService.streakCampus(data).then(value => {
      this.currCampus = value['dayStreakAmongCommunity']
    }).catch(error => {
      console.log(error)
    })

    this.peopleService.streakAgnes(data).then(value => {
      this.currAgnes = value['dayStreakAmongAgnes']
    }).catch(error => {
      console.log(error)
    })

  this.peopleService.streakCommunity({'community' : this.person['community']}).then(value => {
    this.formatPeopleRankings(value);
    }).catch(error => {
      console.log(error)
    })
  }

  retrieveRewardRanks(data) {
    if(!this.noFriends) {
      this.peopleService.rewardFriends(data).then(value => {
        this.currFriends = value['untilRewardAmongFriends']
      }).catch(error => {
        console.log(error)
      })
    }

    this.peopleService.rewardCampus(data).then(value => {
      this.currCampus = value['untilRewardOnCampus']
    }).catch(error => {
      console.log(error)
    })

    this.peopleService.rewardAgnes(data).then(value => {
      this.currAgnes = value['untilRewardAgnes']
    }).catch(error => {
      console.log(error)
    })

    this.peopleService.rewardCommunity({'community' : this.person['community']}).then(value => {
    this.formatPeopleRankings(value);
    }).catch(error => {
      console.log(error)
    })
  }

  retrieveLifeRanks(data)  {
    if(!this.noFriends) {
      this.peopleService.lifetimeFriends(data).then(value => {
        this.currFriends = value['lifeTimePebbleAmongFriends']
      }).catch(error => {
        console.log(error)
      })
    }

    this.peopleService.lifetimeCampus(data).then(value => {
      this.currCampus = value['lifeTimePebbleOnCampus']
    }).catch(error => {
      console.log(error)
    })

    this.peopleService.lifetimeAgnes(data).then(value => {
      this.currAgnes = value['lifeTimePebblesAgnes']
    }).catch(error => {
      console.log(error)
    })

    this.peopleService.lifetimeCommunity({'community' : this.person['community']}).then(value => {
      this.formatPeopleRankings(value)
    }).catch(error => {
      console.log(error)
    })
  }

  formatPeopleRankings(rankings, infiniteScroll?) {
    let people = rankings.map(r => {
      return r['users_id']
    })

    this.peopleService.getUsersForAvatars({'users': people}).then(value => {
      this.currRankings = this.currRankings.concat(value.map(val => {
            return Object.assign({}, val, rankings.filter(rank => val['_id'] == rank['users_id'])[0])
        }).sort(function(a,b){return a['__v']-b['__v']}))
        infiniteScroll.complete()
    }).catch(err => {
    })

  }

  claimReward() {
    this.navCtrl.push(
    'ClaimPage', {
      }, {
      animation: 'ios-transition',
      duration: 350
    });

    //send Claim Reward analytics
    this.analyticsService.logAnalytics({community: this.user['community'], users_id: this.user['_id']}, '/claimRewardButton');
  }

  retrieveCode() {
    this.meService.getReferral({'users_id' : this.user['_id']}).then(val => {
      this.referralCode = val['referralCode'].toUpperCase()
    }).catch(err => {
      console.log(err)
    })
  }

  referFriends() {


    if (this.platform.is('cordova')) {

      let link = 'http://onelink.to/hrnse3';
      let message = this.user['fname'] + " just sent you 5 pebbles on Agnes. Create an account to apply them towards a free burrito! Agnes is the best way to find and do more on campus. Use referral code: "

      let subj = "Agnes: The new events app"

      this.meService.getReferralLink({'users_id': this.user['_id']}).then(val => {
        link = val['url']
        message = message.concat(this.referralCode + '. ' + link)

        Agnes.socialSharing.share(message, subj, '', '')
            .then((val) => {
            })
            .catch((err) => {
              console.log(err)
            });

      }).catch(err => {
        console.log(err)
        message = message.concat(this.referralCode + '. ' + link)

        Agnes.socialSharing.share(message, subj, '', '')
            .then((val) => {
            })
            .catch((err) => {
              console.log(err)
            });
      })

    } else {
      Agnes.showError("Please install Agnes from the App Store or Google Play store to share events.");
    }
  }

  openProfile(userId) {
    console.log(userId)
    this.peopleService.getUsersFromIds({'users' : userId}).then(person => {
      this.popoverCtrl.create('PeopleProfile',
      {
      isMe: false,
      person: person[0],
      }, {}).present({
        animate:true,
        animation: 'ios-transition',
        duration: 350,
        easing: "ease-in-out",
        direction: "forward",
      })
    }).catch(err => {
      console.log(err)
    })
  }

  //default to initials if profile pic is bad
  imgError(person){
      person['noPic'] = true;
  }

}

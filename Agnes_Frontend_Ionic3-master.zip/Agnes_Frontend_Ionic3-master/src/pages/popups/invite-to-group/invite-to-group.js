"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var core_1 = require('@angular/core');
var groups_service_1 = require('../../groups/groups.service');
var app_component_1 = require('../../../app/app.component');
var InviteToGroup = (function () {
    function InviteToGroup(viewCtrl, navParams, groupsService, toastCtrl) {
        this.viewCtrl = viewCtrl;
        this.navParams = navParams;
        this.groupsService = groupsService;
        this.toastCtrl = toastCtrl;
    }
    InviteToGroup.prototype.ngOnInit = function () {
        this.user = this.navParams.data.user;
        this.person = this.navParams.data.person;
        this.groups = this.navParams.data.groups;
        this.loading = false;
        this.groups = this.groups.map(function (a) {
            a['thumbnail'] = (a['thumbnail'] == '' || !a['thumbnail'])
                ? "assets/img/pattern_" + Math.floor((Math.random() * 15) + 1) + '.png' : a['thumbnail'];
            a['keywordString'] = a['keywords'].toString().replace(/,/g, ', ');
            return a;
        });
    };
    InviteToGroup.prototype.ngAfterViewInit = function () {
        window.setTimeout(function () {
            document.getElementsByClassName('popover-content')[0]['style']['left'] = '0px';
        }, 0);
    };
    //close popup
    InviteToGroup.prototype.closeInviteToGroup = function () {
        this.viewCtrl.dismiss(null);
    };
    //send person an invite to a group you are admin of
    InviteToGroup.prototype.inviteToGroup = function (group) {
        var _this = this;
        var data = {
            "groups_id": group._id,
            "users_id": this.person['_id'],
            "sharedby": this.user['_id'],
            "community": this.user['community']
        };
        this.groupsService.inviteUserToGroup(data).then(function (value) {
            if (value) {
                _this.toastCtrl.create({
                    message: 'You successfully invited ' + _this.person['fname'] + ' to ' + group['grpname'],
                    duration: 4000,
                    position: 'bottom'
                }).present();
                _this.closeInviteToGroup();
            }
            else {
                app_component_1.Agnes.showError('Something went wrong - try sending your invite again!');
            }
        }).catch(function (error) { console.log(error); });
    };
    //if 404 on group image, default to random pattern pic from assets folder
    InviteToGroup.prototype.imgError = function (group) {
        var ind = this.groups.indexOf(group);
        this.groups[ind]['thumbnail'] = "assets/img/pattern_" + Math.floor((Math.random() * 15) + 1) + '.png';
    };
    InviteToGroup = __decorate([
        core_1.Component({
            selector: 'invite-to-group',
            templateUrl: 'invite-to-group.html',
            providers: [groups_service_1.GroupsService]
        })
    ], InviteToGroup);
    return InviteToGroup;
}());
exports.InviteToGroup = InviteToGroup;

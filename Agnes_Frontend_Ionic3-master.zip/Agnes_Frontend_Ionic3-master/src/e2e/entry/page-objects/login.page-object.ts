import { browser, element, by, ElementFinder } from 'protractor';
export class LoginPageObject {

    constructor(){

    }

    getLoginButton(){
        // return element(by.css('#loginPage .agnesButton.clear'));
        return element(by.id('buttonToLogin'));
    }

    getPic() {
        return browser.findElement(by.className('agnesLogoPic'))
        // return element(by.css('#passwordPopup #submitPasswordPopupButton'));
    }

    getText() {
        return browser.findElement(by.className('agnesLogoWords'))
    }

    getSignupButton(){
        return element(by.css('#loginPage .agnesButton.signup'));
    }

    getLoginButtons() {
        return element(by.xpath('//div[@id="loginButtons"]'))
    }

    getFBText() {
        return browser.findElement(by.className('fbText'));
    }

    getFBicon() {
        return browser.findElement(by.name('logo-facebook'))
    }

    browseToPage(){
        let el = element(by.css('ion-popover'));
        if(!el) {
            element(by.id('toLogin')).click();
        }
        else {
            element(by.css('#loginPopup .loginHeader .popupClose')).click();
        }
    }

}
import { Component, ViewChild } from '@angular/core';
import { NavController, NavParams, IonicPage, ViewController, Events, Select,
    ToastController, PopoverController } from 'ionic-angular';

import { GroupsService } from '../../../../providers/groups.service';
import { PeopleService } from '../../../../providers/people.service';
import { EventsService } from '../../../../providers/events.service';
import { AnalyticsService } from '../../../../providers/analytics.service';

import { Agnes } from '../../../../app/app.component';

import * as AWS from 'aws-sdk';
import * as S3 from 'aws-sdk/clients/s3';
import * as ValidURL from 'valid-url';

@IonicPage()
@Component({
    selector: 'edit-group',
    templateUrl: 'edit-group.html',
    providers: [GroupsService, PeopleService, EventsService, AnalyticsService]
})
export class EditGroup {

    group: Object;
    user: Object;
    shouldBlur: boolean;
    loading: boolean;
    blueButtonText: string;
    clearButtonText: string;
    canToggle: boolean;
    canPromote:boolean;
    fromFb: boolean;

    edited: boolean;
    picChanged: boolean;
    email:string;
    website:string;
    keywordInput: string;
    localImg: string;
    typeHelpText: string;

    statusLimit = 200;
    descLimit = 1000;

    userSearch: string;
    pendingreqs: Array<Object>;
    memberList: Array<Object>;
    searchHelpText: string;

    rvadmin: Array<Object>;
    newadmin: Array<Object>;
    rvmember: Array<Object>;
    newmember: Array<Object>;

    selectedMembers: Array<Object>;

    userEvents = [];
    hostedEvents = [];
    eventName = '';

    groupCategories = [
        'Advocacy and Awareness',
        'Business',
        'Campus, Support, and Discourse',
        'Greek Life',
        'Identity, Culture, and Language',
        'Media',
        'Performing Arts',
        'Politics, Governance, and Law',
        'Religions and Spirituality',
        'Service',
        'Sports, Recreation, and Wellness',
        'STEM',
        'Visual and Literary Arts'
    ];

    @ViewChild('eventSelect') eventSelect: Select;
    @ViewChild('categorySelect') categorySelect: Select;

    constructor(public navCtrl: NavController,
                public viewCtrl: ViewController,
                public events: Events,
                private toastCtrl: ToastController,
                private popoverCtrl: PopoverController,
                private groupsService: GroupsService,
                private peopleService: PeopleService,
                private eventsService: EventsService,
                private analyticsService: AnalyticsService,
                private navParams: NavParams) {
    }

    ngOnInit(){

        this.user = JSON.parse(localStorage.getItem('agnesUser'));
        this.group = JSON.parse(JSON.stringify(this.navParams.get('group')));
        this.picChanged = false;
        this.edited = false;
        this.shouldBlur = true;
        this.loading = false;
        this.group['category'] = this.group['category'] ? this.group['category'] : '';

        this.pendingreqs = this.navParams.get('pendingreqs');

        this.memberList = [];
        this.getGroupPeople();

        this.getUserEvents();

        this.localImg = this.group['picurl'];
        this.fromFb = this.group['other'] && this.group['other']['facebookId'] && this.group['other']['facebookId'] != '';
        this.blueButtonText = 'Save';
        this.email = this.group['grpemail'] ? this.group['grpemail'].toString().replace(',',', ') : '';
        this.website = this.group['weburl'].toString().replace(',',', ');
        this.keywordInput = '';
        this.typeHelpText = this.group['grptype'] == 'public' ? 'Anyone can join this group' :
            (this.group['grptype'] == 'private' ? 'This group is invite-only' : 'Only group members can view this group');

        this.events.subscribe('groupMembersEdited', (val) => {
            if(val['_id'] == this.group['_id']){
                this.memberList = [];
                this.group['admin'] = val['admin'];
                this.group['members'] = val['members'];
                this.getGroupPeople();
            }
        });

        //send Edit Group button click analytics
        this.analyticsService.logAnalytics({community: this.user['community'], users_id: this.user['_id']}, '/edit_group_bt');
    }

    //get events a user is admin of
    getUserEvents(){
        this.userEvents = [];
        this.eventsService.getEventsFromId({"evt":this.user['evtrsvp'], 'community': this.user['community']}).then(value => {
            if (value && value.length > 0) {
                value = value
                    .filter(event => {
                        return event['admin'].indexOf(this.user['_id']) != -1;
                    })
                    .map(event => {
                        return {
                            evtname: event['evtname'],
                            _id: event['_id'],
                            picurl: event['picurl']
                        };
                    });
                this.userEvents = value;
            }
        }).catch(err => {
        });
    }

    closeEditGroup(data, edited){
        this.loading = false;
        if(this.edited){
            Agnes.showError('Do you want to save your changes?', ['Not now', 'Save']);
            this.events.subscribe('agnesAlertData', ind => {
                if(ind == 1){
                    this.submitEditGroup();
                }
                else {
                    this.viewCtrl.dismiss(null,'',{
                        animate: true,
                        animation: 'ios-transition',
                        duration: 350,
                        easing: "ease-in-out",
                        direction: "back"
                    });
                }
            });
        }
        else {
            if(edited){
                this.toastCtrl.create({
                    message: "You've successfully edited your group!",
                    position:'top',
                    showCloseButton: true,
                    closeButtonText: ' ',
                    duration: 2500
                }).present();

                this.events.publish('groupEdited', data);
            }

            if(this.pendingreqs){data = this.memberList.map(a => {return a['_id']});}
            this.viewCtrl.dismiss(data,null,{
                animation: 'ios-transition',
                duration: 350,
                easing: "ease-in-out",
                direction: "back"
            });
        }
    }

    submitEditGroup(){

        this.addKeyword(null);

        let nameValid = this.group['grpname'].trim() != '';
        let keywordsValid = this.group['keywords'].length > 0;
        if(this.website.trim() != '' && !ValidURL.isWebUri(this.website)) {
            this.website = 'http://' + this.website.trim();
        }

        if(nameValid && keywordsValid) {
            this.loading = true;

            if (this.group['picurl'] != '' && this.picChanged){
                let creds = {
                    bucket: 'agnesgroupimage',
                    access_key: 'AKIAJYQU6AUVQQKITAPQ',
                    secret_key: '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'
                };
                let uniqueFilename = "";
                var possible = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";

                for (var i = 0; i < 8; i++) {
                    uniqueFilename += possible.charAt(Math.floor(Math.random() * possible.length));
                }

                this.localImg = this.group['picurl'];
                let data = this.baseToBlob(this.group['picurl']);
                AWS.config.update({region: 'us-east-1',credentials: {
                    accessKeyId: "AKIAJYQU6AUVQQKITAPQ",
                    secretAccessKey:"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"
                }});

                let keyname = uniqueFilename + '.jpg';
                keyname = '_' + keyname;

                //Bucket Parameters
                let bucketParams = {
                    Key: keyname,
                    ContentType: ".jpg",
                    Body: data ,
                    ServerSideEncryption: 'AES256',
                    Bucket: creds.bucket
                };

                //bucket to define
                let bucket = new S3({ params: { Bucket: 'agnesgroupimage' } });

                bucket.putObject(bucketParams, function(err, data) {
                    if(err) {
                        console.log('bucket error',err);
                        return false;
                    }
                });

                this.group['picurl'] = 'https://s3.amazonaws.com/agnesgroupimage/' + keyname;
            }

            this.group['grpemail'] = this.email ? this.email : this.group['email'];
            this.group['weburl'] = this.website
                ? this.website.trim().replace(/,\s+/,',').split(',') : this.group['weburl'];

            this.group['groups_id'] = this.group['_id'];

            this.groupsService.editGroupAbout(this.group).then(val => {
                if(val){
                    this.edited = false;
                    // set the local img to the b64 data to show immediately
                    if(this.localImg){
                        val['picurl'] = this.localImg
                    }
                    this.closeEditGroup(val, true);
                }
                else {
                    Agnes.showError('Could not edit your group right now - try again!');
                }
            }).catch(err => {
                Agnes.showError('Could not edit your group right now - try again!');
            });
        }
    }

    //chose group category
    selectCategory(category){
        if(category){
            this.group['topic'] = category;
        }
        this.categorySelect.close();
    }

    //chose an event to attach
    selectEvent(event){
        if(event){
            let ind = this.hostedEvents.indexOf(event);
            if(ind == -1) {this.hostedEvents.push(event);}

            ind = this.group['hostedEvents'].indexOf(event['_id']);
            if(ind == -1) {this.group['hostedEvents'].push(event['_id']);}
        }
        this.eventSelect.close();
    }

    //remove event as hosted event
    removeEvent(event){
        let ind = this.hostedEvents.indexOf(event);
        if(ind != -1) {this.hostedEvents.splice(ind,1);}

        ind = this.group['hostedEvents'].indexOf(event['_id']);
        if(ind != -1) {this.group['hostedEvents'].splice(ind,1);}
    }

    //add keyword from keyword input field into event's keyword array
    addKeyword(e){
        //for keeping keyboard up when + button is pressed
        if(e){
            e.preventDefault();
            this.shouldBlur = false;
        }

        if(this.group['keywords'].length < 6 && this.keywordInput.trim() != '') {
            let add = this.keywordInput.toLowerCase().trim().replace(/,\s+/,',').split(',')
                .map(a => {return a.trim()}).filter(a => {return this.group['keywords'].indexOf(a) == -1});
            this.group['keywords'] = this.group['keywords'].concat(add);

            this.changeEdited();
        }
        this.keywordInput = '';
    }

    //remove keyword from group
    removeKeyword(key){
        let ind = this.group['keywords'].indexOf(key);
        if(ind != -1){
            this.group['keywords'].splice(ind,1);
            this.changeEdited();
        }
    }

    //use return key to enter keyword
    onEnter(ev){
        if(ev.keyCode == 13) {
            this.addKeyword(null);
        }
    }

    //change help text of group type segment
    toggleType(){
        this.typeHelpText = this.group['grptype'] == 'public' ? 'Anyone can join this group'
            : (this.group['grptype'] == 'private' ? 'This group is invite-only'
                : 'Only group members can view this group');

        this.changeEdited();
    }

    //upload an image for this group
    addPhoto(){
        let options = {
            quality: 25,
            allowEdit: true,
            cameraDirection: Agnes.camera.Direction.FRONT,
            correctOrientation: true,
            destinationType: Agnes.camera.DestinationType.DATA_URL,
            sourceType: Agnes.camera.PictureSourceType.PHOTOLIBRARY
        };

        Agnes.camera.getPicture(options).then((value) => {
            if (value && typeof(value)=='string'){
                let base64Image = 'data:image/jpeg;base64,' + value;
                this.group['picurl'] = base64Image;
                this.picChanged = true;
                this.changeEdited();
            }
            else {
                console.log('not base64', value);
                Agnes.showError("Couldn't process your photo - try again!");
            }
        }, (err) => {
            console.log(err);
        }).catch(err => {
            Agnes.showError("Couldn't get your photos - make sure Agnes has photo access permissions and try again!");
        });
    }

    // convert base64/URLEncoded data component to raw binary string
    baseToBlob(dataURI) {
        var byteString;
        if (dataURI.split(',')[0].indexOf('base64') >= 0)
            byteString = atob(dataURI.split(',')[1]);
        else
            byteString = (dataURI.split(',')[1]);

        // write the bytes of the string to a typed array
        var ia = new Uint8Array(byteString.length);
        for (var i = 0; i < byteString.length; i++) {
            ia[i] = byteString.charCodeAt(i);
        }

        return new Blob([ia.buffer], {type: "image/jpeg"});
    }

    changeEdited(){
        this.edited = true;
    }

    //open edit members popup
    editMembers(){
        this.user['isAdmin'] = true;

        this.popoverCtrl.create('GroupMembers',{
            'group': this.group,
            'type': 'edit',
            'memberList': [this.user].concat(this.memberList)
        }).present({
            animation: 'ios-transition',
            duration: 350
        });
    }

    /************************************************************************************************************/
    /************************************************************************************************************/
    /*************************************** MEMBER STUFF ***********************************************/
    /************************************************************************************************************/
    /************************************************************************************************************/

    //get group admins and members
    getGroupPeople(){
        this.loading = true;

        let adminProm = this.peopleService.getUsersFromIds(
            {'users':this.group['admin'].filter( x => x != this.user['_id'])});

        //filter admins out of members, if any (should not ever be the case though)
        let memProm = this.peopleService.getUsersFromIds(
            {'users':this.group['members'].filter(a => this.group['admin'].indexOf(a) == -1)});

        let promArray = [adminProm, memProm];
        if(this.group['followers'].length > 0){
            let followProm = this.peopleService.getUsersFromIds({'users':this.group['followers']});
            promArray.push(followProm);
        }

        Promise.all(promArray).then(val => {
            this.loading = false;

            let admins = val[0];
            if(admins){
                admins = admins.map(a => {
                    a['isAdmin'] = true;
                    return a;
                }).sort((a,b) => {
                    return (b['fname'] < a['fname'] ? 1 : -1);
                });
                this.memberList = this.memberList.concat(admins);
            }

            let mems = val[1];
            if(mems){
                //filter admins out of members and sort admins alphabetically
                mems = mems.map(a => {
                    a['isMember'] = true;
                    return a;
                }).sort((a,b) => {
                    return (b['fname'] < a['fname'] ? 1 : -1);
                });

                this.memberList = this.memberList.concat(mems);
            }

            let followers = val[2];
            if(followers) {
                followers = followers.sort((a,b) => {
                    return (b['fname'] < a['fname'] ? 1 : -1);
                });

                this.memberList = this.memberList.concat(followers);
            }
        }).catch(err => {
            console.log(err);
            this.loading = false;
            Agnes.showError('Sorry, could not get your group members right now - exit out of this page and try again!');
        });
    }

    //user name matches user search input
    matchesSearch(person){
        let term = this.userSearch.trim().toLowerCase();
        let len = term.length;
        if(len > 0){
            if (term.indexOf(' ') != -1){
                //user has searched a first and last name
                let ts = term.replace(/\s+/g,' ').split(' ');
                let fname = person['fname'].toLowerCase().substring(0,ts[0].length) == ts[0];
                let lname = person['lname'].toLowerCase().substring(0,ts[1].length) == ts[1];
                return (fname && lname);
            }
            let fname = person['fname'].toLowerCase().substring(0,len) == term;
            let lname = person['lname'].toLowerCase().substring(0,len) == term;
            return (fname || lname);
        }
        else {
            return true;
        }
    }

    //if editing - make person member, admin, or remove as past of group
    //if viewing members - go to member profile
    togglePerson(person){
        if(this.canToggle && person['_id'] != this.user['_id']){
            let ind = this.selectedMembers.indexOf(person['_id']);
            if(ind == -1){
                this.selectedMembers.push(person['_id']);
                this.checkCanPromote();
            }
            else {
                this.selectedMembers.splice(ind,1);
                this.checkCanPromote();
            }
          }
    }

    //see if selected array contains any admins or not to see whether user can promote selected people
    checkCanPromote(){
        if(this.selectedMembers.filter(a => {return this.group['admin'].indexOf(a) == -1}).length
            != this.selectedMembers.length) {
            this.canPromote = false;
        }
        else {
            this.canPromote = true;
        }
    }

    //remove current members or group requests
    removeMembers(){
        if(this.selectedMembers.length > 0){
            if(this.pendingreqs){
                let data = {
                    'groups_id':this.group['_id'],
                    'users_ids': this.selectedMembers
                };

                this.groupsService.removePendingReq(data).then(val => {
                    this.removeDisplayed(true);
                }).catch(err => {
                    console.log(err);
                    Agnes.showError('Sorry, could not remove these requests right now - please try again!');
                });
            }
            else {
                let data = {
                    'users_id': this.user['_id'],
                    'groups_id': this.group['_id'],
                    'newmember': [],
                    'newadmin': [],
                    'rvmember': this.selectedMembers.filter(a => {return this.group['members'].indexOf(a) != -1}),
                    'rvadmin': this.selectedMembers.filter(a => {return this.group['admin'].indexOf(a) != -1}),
                    'community': this.user['community']
                };

                this.groupsService.editGroupMembers(data).then(val => {
                    this.removeDisplayed(false);
                }).catch(err => {
                    console.log(err);
                    Agnes.showError('Sorry, could not remove these members right now - please try again!');
                });
            }
        }
    }

    promoteMembers(){
        if(this.selectedMembers.length > 0 && this.canPromote) {
            let data = {
                'users_id': this.user['_id'],
                'groups_id': this.group['_id'],
                'newmember': [],
                'newadmin': this.selectedMembers,
                'rvmember': this.selectedMembers,
                'rvadmin': [],
                'community': this.user['community']
            };

            this.groupsService.editGroupMembers(data).then(val => {
                Agnes.showError("Promotion"+(this.selectedMembers.length > 1 ? 's' : '')+ " successful!");

                //change local view of admins and members according to promotion
                this.group['admin'] = this.group['admin'].concat(this.selectedMembers);
                this.group['members'] = this.group['members'].filter(a => {
                    return this.selectedMembers.indexOf(a) == -1;
                });

                this.sortMemberList();

                //add admin badge to member list items
                this.events.publish('promotedMembers', {'group': this.group, 'members': this.selectedMembers});

                //clear selected members
                this.selectedMembers = [];
            }).catch(err => {
                console.log(err);
                Agnes.showError('Sorry, could not remove these members right now - please try again!');
            });
        }
    }

    //for keeping keyboard up when + button is pressed for keywords
    keepKeyboard(event){
        if(!this.shouldBlur){
            event.target.focus();
            this.shouldBlur = true;
        }
    }

    //remove people from displayed list after their request has been accepted/rejected
    removeDisplayed(isPendingReqs){
        this.memberList = this.memberList.filter(a => {
            return this.selectedMembers.indexOf(a['_id']) == -1;
        });

        //send removed members to group profile
        if(!isPendingReqs){
            this.events.publish('removedMembers', {'group': this.group, 'members': this.selectedMembers});
        }

        //reset selected members
        this.selectedMembers = [];

        //close list if no more people to accept/reject
        if(this.memberList.length == 0){
            this.closeEditGroup([], false);
        }
    }

    /************************************************************************************************************/
    /************************************************************************************************************/
    /***************************************** GROUP REQS STUFF *************************************************/
    /************************************************************************************************************/
    /************************************************************************************************************/

    submitGroupReqs(){
        if (!this.membersEdited()) {
            Agnes.showError("Please add changes before submitting!")
        } else {

            let data = {
                newmember: this.newmember,
                newadmin: this.newadmin,
                rvmember: this.rvmember.concat(this.rvadmin),
                users_id: this.user['_id'],
                groups_id: this.group['_id']
            };

            this.loading = true;

            this.groupsService.notificationRequests(data)
                .then(groupData => {
                    this.loading = false;

                    let toast = this.toastCtrl.create({
                        message: "Request responses saved!",
                        duration: 2500,
                        position: 'top',
                        closeButtonText: ' ',
                        showCloseButton: true
                    });
                    toast.present();
                    this.events.publish('groupReqsResponse', data);
                    this.viewCtrl.dismiss(this.newmember.concat(this.newadmin).concat(this.rvmember).concat(this.rvadmin),null,{
                        animation: 'ios-transition',
                        duration: 350,
                        easing: "ease-in-out",
                        direction: "back"
                    });
                })
                .catch(err => {
                    this.loading = false;
                    console.log(err);
                    Agnes.showError("Something went wrong, try submitting your requests again!");
                })
        }
    }

    // check whether any members have been edited
    membersEdited() {
        return this.newmember.length > 0 || this.newadmin.length > 0 || this.rvadmin.length > 0 || this.rvmember.length > 0
    }

    //sort member list by admins first alphabetically and then members alphabetically
    sortMemberList(){
        //sort admins alphabetically above members
        let admins = this.memberList.filter(a => {return this.group['admin'].indexOf(a['_id']) != -1});
        admins = admins.sort((a,b) => {
            return (b['fname'] < a['fname'] ? 1 : -1);
        });

        let mems = this.memberList.filter(a => {
            return this.group['members'].indexOf(a['_id']) != -1 && this.group['admin'].indexOf(a['_id']) == -1;
        });
        mems = mems.sort((a,b) => {
            return (b['fname'] < a['fname'] ? 1 : -1);
        });

        this.memberList = admins.concat(mems);
    }

    viewMembers() {

    }
}

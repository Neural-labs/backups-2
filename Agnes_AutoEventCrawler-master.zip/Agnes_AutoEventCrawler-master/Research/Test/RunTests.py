'''
Testing Suite


'''
from Utilities import DateExtraction


def runInitialTestQuery():

    runTestLoop()

    stop = raw_input('Are you finished? y/n: ')

    while stop != 'y':
        runTestLoop()

        stop = raw_input('Are you finished? y/n: ')

def runTestLoop():
    runSpecificTest = raw_input('Would you like to run a specific test? y/n: ')

    if runSpecificTest == 'y':

        tests = getTests()

        specificIndices = raw_input(
            'Select the indices (separated by commas) of the tests you would like to run: ').split(',')

        runSpecificTests(tests, specificIndices)

    else:
        runAllTests()

def getTests():
    tests = [
        extractDate

    ]
    for test in tests:
        print 'Index:',tests.index(test),'Test:',test.__name__

    return tests

def runAllTests():
    print 'Running all tests...'
    pass

def runSpecificTests(tests, specificIndices):
    print 'Running Tests'
    for index, test in enumerate(tests):
        if str(index) in specificIndices:
            test()
    print 'Done.'

def extractDate():
    test_string = raw_input('Enter the string you would like to extract dates from: ')
    dates = DateExtraction.getDates(test_string)
    print 'Dates:'
    for date in dates:
        print date[0].isoformat()

def setup():
    pass

def teardown():
    pass
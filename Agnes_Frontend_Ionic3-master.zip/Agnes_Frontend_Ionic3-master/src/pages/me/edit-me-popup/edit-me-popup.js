"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var core_1 = require('@angular/core');
var ionic_native_1 = require('ionic-native');
var me_service_1 = require('../me.service');
var app_component_1 = require('../../../app/app.component');
var AWS = require('aws-sdk');
var S3 = require('aws-sdk/clients/s3');
var EditMePopup = (function () {
    function EditMePopup(viewCtrl, meService, navParams) {
        this.viewCtrl = viewCtrl;
        this.meService = meService;
        this.navParams = navParams;
    }
    EditMePopup.prototype.ngOnInit = function () {
        this.type = this.navParams.data.type;
        this.me = this.navParams.data.me;
        this.loading = false;
        this.aboutme = this.me['aboutme'];
        this.fname = this.me['fname'];
        this.lname = this.me['lname'];
        this.studenttype = this.me['studenttype'];
        this.edited = false;
        this.picurl = this.me['picurl'];
        this.interestsAdd = this.skillsAdd = this.majorAdd = '';
        this.major = this.me['major'];
        this.interests = this.me['keywords'].filter(function (a) { return a.keytype == 'interest'; }).map(function (a) { return a.name; });
        this.skills = this.me['keywords'].filter(function (a) { return a.keytype == 'haveskill'; }).map(function (a) { return a.name; });
        this.oldPic = this.me['picurl'];
        this.studentTypes = [
            "Freshman", "Sopohomore", "Junior", "Senior", "Fifth year", "Masters", "PhD", "Alum", "Staff", "Other"
        ];
    };
    EditMePopup.prototype.closeEditMe = function (data) {
        this.viewCtrl.dismiss(data, {}, {
            animate: false,
            animation: 'ios-transition',
            duration: 350,
            easing: "ease-in-out",
            direction: "back"
        });
    };
    //send edits
    EditMePopup.prototype.submitEdits = function () {
        var _this = this;
        if (this.type == 'Interests' && this.interests.length == 0) {
            document.getElementById('interestsError').classList.add('active');
        }
        else {
            this.loading = true;
            if (this.type == 'Interests') {
                document.getElementById('interestsError').classList.remove('active');
            }
            //submit edits
            this.me['keywords'] = this.interests.map(function (a) { return { 'keytype': 'interest', 'name': a }; })
                .concat(this.skills.map(function (a) { return { 'keytype': 'haveskill', 'name': a }; }));
            this.me['users_id'] = this.me['_id'];
            this.me['haveskill'] = this.skills;
            this.me['interest'] = this.interests;
            this.me['keyactive'] = [];
            this.me['postcol'] = [];
            this.me['issues'] = [];
            this.me['aboutme'] = this.aboutme;
            this.me['fname'] = this.fname;
            this.me['lname'] = this.lname;
            this.me['major'] = this.major;
            this.me['studenttype'] = this.studenttype;
            this.me['picurl'] = this.picurl;
            if (this.me['picurl'] != '' && (this.me['picurl'] != this.oldPic)) {
                var creds = {
                    bucket: 'agnesimages',
                    access_key: 'AKIAJYQU6AUVQQKITAPQ',
                    secret_key: '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'
                };
                var uniqueFilename = "";
                var possible = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
                for (var j = 0; j < 8; j++) {
                    uniqueFilename += possible.charAt(Math.floor(Math.random() * possible.length));
                }
                var data = this.baseToBlob(this.me['picurl']);
                AWS.config.update({ region: 'us-east-1', credentials: {
                        accessKeyId: "AKIAJYQU6AUVQQKITAPQ",
                        secretAccessKey: "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"
                    } });
                var keyname_1 = uniqueFilename + '.jpg';
                keyname_1 = '_' + keyname_1;
                //TODO if the orientation stuff came up!
                /* if(this.orientation){
                 keyname = '_' + keyname;
                 }
                 else{
                 keyname = '_' + uniqueFilename
                 }
                 */
                //Bucket Parameters
                var bucketParams = {
                    Key: keyname_1,
                    ContentType: ".jpg",
                    Body: data,
                    ServerSideEncryption: 'AES256',
                    Bucket: creds.bucket
                };
                //bucket to define
                var bucket = new S3({ params: { Bucket: 'agnesimages' } });
                bucket.putObject(bucketParams, function (err, data) {
                    if (err) {
                        console.log('bucket error', err);
                        return false;
                    }
                    else {
                        // Upload Successfully Finished
                        var pic = 'https://s3.amazonaws.com/agnesimages/' + keyname_1;
                    }
                });
                this.me['picurl'] = 'https://s3.amazonaws.com/agnesimages/' + keyname_1;
            }
            this.meService.editMe(this.me)
                .then(function (data) {
                _this.loading = false;
                if (data) {
                    _this.closeEditMe(data);
                }
                else {
                    app_component_1.Agnes.showError("Sorry, couldn't save your edits right now - try again!");
                }
            })
                .catch(function (err) {
                _this.loading = false;
                app_component_1.Agnes.showError("Sorry, couldn't save your edits right now - try again!");
            });
        }
    };
    //for adding keywords to skills or interests
    EditMePopup.prototype.addKeyword = function (type) {
        var keyword = this[type + 'Add'].toLowerCase();
        if (keyword.trim() != '' && this[type].indexOf(keyword) == -1) {
            this[type].push(keyword);
            this[type + 'Add'] = '';
            var elem = document.getElementById(type + 'Keywords');
            elem.scrollTop = elem.scrollHeight;
        }
    };
    //for removing keywords from skills or interests
    EditMePopup.prototype.removeKeyword = function (type, keyword) {
        var ind = this[type].indexOf(keyword);
        if (ind != -1) {
            this[type].splice(ind, 1);
        }
    };
    //adding keywords using the Enter key
    EditMePopup.prototype.onEnter = function (ev, type) {
        if (ev.keyCode == 13) {
            this.addKeyword(type);
        }
    };
    //adding/changing profile photo where type is either camera or upload
    EditMePopup.prototype.addPhoto = function (type) {
        var _this = this;
        var source = (type == 'camera') ? ionic_native_1.Camera.PictureSourceType.CAMERA : ionic_native_1.Camera.PictureSourceType.PHOTOLIBRARY;
        var options = {
            quality: 25,
            allowEdit: false,
            cameraDirection: ionic_native_1.Camera.Direction.FRONT,
            correctOrientation: true,
            destinationType: ionic_native_1.Camera.DestinationType.DATA_URL,
            sourceType: source
        };
        ionic_native_1.Camera.getPicture(options).then(function (value) {
            if (value && typeof (value) == 'string') {
                var base64Image = 'data:image/jpeg;base64,' + value;
                _this.picurl = base64Image;
            }
            else {
                console.log('not base64', value);
                app_component_1.Agnes.showError("Couldn't process your photo - try again!");
            }
        }).catch(function (err) {
            console.log('camera err', err);
            if (err != 'Camera cancelled.' && err != 'no image selected') {
                app_component_1.Agnes.showError("Couldn't get your photos - make sure Agnes has photo access permissions and try again!");
            }
        });
    };
    //for converting uploaded/camera photo
    EditMePopup.prototype.baseToBlob = function (dataURI) {
        // convert base64/URLEncoded data component to raw binary data held in a string
        var byteString;
        if (dataURI.split(',')[0].indexOf('base64') >= 0)
            byteString = atob(dataURI.split(',')[1]);
        else
            byteString = (dataURI.split(',')[1]);
        // separate out the mime component
        // var mimeString = dataURI.split(',')[0].split(':')[1].split(';')[0];
        // write the bytes of the string to a typed array
        var ia = new Uint8Array(byteString.length);
        for (var i = 0; i < byteString.length; i++) {
            ia[i] = byteString.charCodeAt(i);
        }
        return new Blob([ia.buffer], { type: "image/jpeg" });
    };
    EditMePopup = __decorate([
        core_1.Component({
            selector: 'edit-me-popup',
            templateUrl: 'edit-me-popup.html',
            providers: [me_service_1.MeService]
        })
    ], EditMePopup);
    return EditMePopup;
}());
exports.EditMePopup = EditMePopup;

"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var core_1 = require('@angular/core');
var groups_service_1 = require('../groups.service');
var events_service_1 = require('../../events/events.service');
var ionic_native_1 = require('ionic-native');
var report_1 = require('../../popups/report/report');
var group_details_1 = require('../../popups/group-details/group-details');
var people_service_1 = require('../../people/people.service');
var app_component_1 = require('../../../app/app.component.ts');
var event_profile_1 = require('../../events/event-profile/event-profile');
var invite_friends_1 = require('../../popups/invite-friends/invite-friends');
var GroupProfile = (function () {
    function GroupProfile(navParams, actionSheetCtrl, app, events, navCtrl, alertCtrl, groupsService, eventsService, toastCtrl, popoverCtrl, peopleService) {
        this.navParams = navParams;
        this.actionSheetCtrl = actionSheetCtrl;
        this.app = app;
        this.events = events;
        this.navCtrl = navCtrl;
        this.alertCtrl = alertCtrl;
        this.groupsService = groupsService;
        this.eventsService = eventsService;
        this.toastCtrl = toastCtrl;
        this.popoverCtrl = popoverCtrl;
        this.peopleService = peopleService;
        this.app = app;
    }
    GroupProfile.prototype.ngOnInit = function () {
        this.canClose = true;
        this.group = this.navParams.data.group;
        this.user = this.navParams.data.user;
        this.image = 'url("' + this.group["picurl"] + '")';
        this.platform = this.navParams.data.platform;
        this.groupTab = "About";
        this.edited = false;
        this.tabVals = ['About', 'Members', 'Events'];
        this.getMembers();
        this.getEvents();
        this.claimReqs = JSON.parse(localStorage.getItem('agnesClaimReqs'));
        if (this.claimReqs) {
            this.canClaim = this.claimReqs.indexOf(this.group['_id']) == -1;
        }
        else {
            this.claimReqs = [];
            this.canClaim = true;
        }
        //if no group profile, default display pic as random pattern
        this.group['displayURL'] = (this.group['displayURL'] == '')
            ? "assets/img/pattern_" + Math.floor((Math.random() * 15) + 1) + '.png' : this.group['picurl'];
        localStorage.setItem('agnesCurrentGroup', this.group['_id']);
        this.events.publish('pagePushed');
        this.setMenuButtons();
    };
    GroupProfile.prototype.imgLoad = function (ev) {
        var img = ev.target;
        if (img.naturalWidth > img.naturalHeight) {
            this.orientation = 'landscape';
        }
        else if (img.naturalWidth < img.naturalHeight) {
            this.orientation = 'portrait';
        }
        else {
            this.orientation = 'even';
        }
    };
    GroupProfile.prototype.imgError = function () {
        this.group['displayURL'] = "assets/img/pattern_" + Math.floor((Math.random() * 15) + 1) + '.png';
    };
    GroupProfile.prototype.closeGroupProfile = function (e, action) {
        if ((!e || e.direction == 4)) {
            var data = (this.edited || action) ? { 'group': this.group, 'category': (this.edited ? 'edit' : action) } : null;
            if (data) {
                this.events.publish('groupProfileData', data);
            }
            localStorage.removeItem('agnesCurrentGroup');
            this.navCtrl.pop({
                animate: true,
                animation: 'ios-transition',
                duration: 350,
                easing: "ease-in-out",
                direction: "back"
            }).then(function () {
            });
        }
    };
    //set buttons on action sheet menu
    GroupProfile.prototype.setMenuButtons = function () {
        var _this = this;
        this.menuButtons = [];
        if (this.group['admin'].length == 0) {
            //add Claim group if the group has no admins
            this.menuButtons.push({
                text: 'Claim Group',
                icon: 'md-people',
                handler: function () { _this.claimGroup(); }
            });
        }
        else {
            //add Edit button if user is admin of group
            if (this.group['admin'].indexOf(this.user['_id']) != -1) {
                this.menuButtons.push({
                    text: 'Edit Group',
                    icon: 'md-create',
                    handler: function () { _this.editGroup(); }
                });
                //add invite friends to group button
                this.menuButtons.push({
                    text: 'Invite Friends to Group',
                    icon: 'md-contacts',
                    handler: function () { _this.inviteFriends(); }
                });
            }
        }
        //add Leave button is user is admin or member
        if (this.group['members'].indexOf(this.user['_id']) != -1 || this.group['admin'].indexOf(this.user['_id']) != -1) {
            this.menuButtons.push({
                text: 'Leave Group',
                icon: 'md-log-out',
                handler: function () { _this.leaveGroup(); }
            });
        }
        //add Event Website button if event has a website
        if (this.group['weburl'].length > 0
            && this.group['weburl'][0] != ''
            && !this.group['weburl'][0].match(/orgsync|collegiate|simplicity/g)) {
            this.menuButtons.push({
                text: 'Group Website',
                icon: 'ios-link',
                handler: function () {
                    //tracking
                    if (window['fabric']) {
                        window['fabric'].Answers.sendCustomEvent('Group Profile', { type: 'website' });
                    }
                    window.open(_this.group['weburl'][0], '_blank', 'location=yes');
                }
            });
        }
        //add Share Group button (always)
        this.menuButtons.push({
            text: 'Share Group',
            icon: 'md-share',
            handler: function () { _this.shareGroup(); }
        });
        //add Delete Group button if user is admin of group
        if (this.group['admin'].indexOf(this.user['_id']) != -1) {
            this.menuButtons.push({
                text: 'Delete Group',
                icon: 'md-trash',
                handler: function () { _this.deleteGroup(); }
            });
        }
        else {
            if (this.group['members'].indexOf(this.user['_id']) == -1) {
                this.menuButtons.push({
                    text: 'Report Group',
                    icon: 'md-flag',
                    handler: function () { _this.reportEntity(); }
                });
            }
        }
        //add Cancel button (always)
        this.menuButtons.push({
            text: 'Cancel',
            role: 'cancel',
            icon: 'md-close',
            handler: function () { }
        });
    };
    //open group options menu w/ 3-dot toggle
    GroupProfile.prototype.openGroupMenu = function () {
        var actionSheet = this.actionSheetCtrl.create({
            title: '',
            buttons: this.menuButtons
        });
        actionSheet.present();
    };
    GroupProfile.prototype.getMembers = function () {
        var _this = this;
        this.memberList = [];
        var ids = this.group['admin'].concat(this.group['members']);
        var data = { 'users': ids };
        this.peopleService.getUsersFromIds(data).then(function (value) {
            _this.memberList = value;
            if (_this.memberList.length > 0) {
                for (var p in _this.memberList) {
                    if (_this.memberList[p]['picurl'] == "" || !_this.memberList[p]['picurl']) {
                        _this.memberList[p]['displayURL'] = "url('assets/img/icons/tabs-people-orange.png')";
                    }
                    else {
                        _this.memberList[p]['displayURL'] = "url('" + _this.memberList[p]['picurl'] + "')";
                    }
                    _this.memberList[p].keywordString = _this.memberList[p]['keywords'].map(function (a) { return a.name; }).toString().replace(/,/g, ', ');
                }
            }
            else {
                _this.tabVals.splice(_this.tabVals.indexOf('Members'), 1);
            }
        })
            .catch(function (err) {
            console.log(err);
        });
    };
    GroupProfile.prototype.getEvents = function () {
        var _this = this;
        this.groupEvents = [];
        var evtdata = { "evt": this.group['events'] };
        this.eventsService.getEventsFromId(evtdata).then(function (events) {
            if (events) {
                for (var e in events) {
                    events[e]['keywordString'] = events[e]['keywords'].toString().replace(/,/g, ', ');
                    events[e]['displayURL'] = "url("
                        + (events[e]['picurl'] == "" ? "assets/img/pattern_" + Math.floor((Math.random() * 15) + 1) + '.png' : events[e]['picurl'])
                        + ")";
                    var time = app_component_1.Agnes.processGMT(events[e]['starttime']);
                    events[e]['date'] = time.date.substring(5, time.date.length);
                    events[e]['time'] = time.time;
                }
                events.sort(function (a, b) {
                    var aDate = +new Date(a["starttime"]);
                    var bDate = +new Date(b["starttime"]);
                    return aDate - bDate;
                });
                _this.groupEvents = events;
            }
            else {
                app_component_1.Agnes.showError("Couldn't get this group's events, sorry - try reloading the page!");
            }
            if (_this.groupEvents.length == 0) {
                _this.tabVals.splice(_this.tabVals.indexOf('Events'), 1);
            }
        }).catch(function (err) {
            console.log(err);
            app_component_1.Agnes.showError("Couldn't get this group's events, sorry - try reloading the page!");
            _this.tabVals.splice(_this.tabVals.indexOf('Events'), 1);
        });
    };
    GroupProfile.prototype.editGroup = function () {
        var _this = this;
        //tracking
        if (window['fabric']) {
            window['fabric'].Answers.sendCustomEvent('Group Profile', { type: 'edit' });
        }
        var editGroup = this.popoverCtrl.create(group_details_1.GroupDetails, {
            'type': 'Edit',
            'user': this.user,
            'platform': this.platform,
            'group': this.group
        }, { 'enableBackdropDismiss': true });
        editGroup.present({
            animate: true,
            animation: 'ios-transition',
            duration: 500,
            easing: "ease-in-out",
            direction: "right"
        });
        editGroup.onDidDismiss(function (data) {
            if (data) {
                if (data.deleted) {
                    _this.deleteGroup();
                }
                else {
                    _this.group = data;
                    _this.edited = true;
                }
            }
        });
    };
    GroupProfile.prototype.joinGroup = function () {
        var _this = this;
        //tracking
        if (window['fabric']) {
            window['fabric'].Answers.sendCustomEvent('Group Profile', { type: 'join' });
        }
        // if user has already requested to join
        if (this.group['grptype'] == "private" && this.group['pendingreq'].indexOf(this.user['_id']) != -1) {
            app_component_1.Agnes.showError("You've already requested to join " + this.group['grpname'] + "!");
        }
        else if (this.group['grptype'] == "public" && (this.group['members'].indexOf(this.user['_id']) != -1 ||
            this.group['admin'].indexOf(this.user['_id']) != -1)) {
            app_component_1.Agnes.showError("You're already a part of " + this.group['grpname'] + "!");
        }
        else {
            var alert_1 = this.alertCtrl.create({
                title: 'Join a group',
                message: "Are you sure you want to join " + this.group['grpname'] + "?",
                buttons: [
                    {
                        text: 'Cancel',
                        handler: function () {
                            app_component_1.Agnes.removeFilter();
                        },
                        role: 'cancel'
                    },
                    {
                        text: 'Yes',
                        handler: function () {
                            app_component_1.Agnes.removeFilter();
                            var data = {
                                "groups_id": _this.group['_id'],
                                "users_id": _this.user['_id'],
                                "community": _this.user['community']
                            };
                            //user wants to join public group
                            if (_this.group['grptype'] == "public") {
                                _this.groupsService.joinPublicGroup(data).then(function (value) {
                                    if (value) {
                                        _this.group['members'].push(_this.user['_id']);
                                        _this.group['memcount'] = _this.group['memcount'] + 1;
                                        _this.user['grp'].push({ 'groups_id': _this.group['_id'], 'admin': false });
                                        _this.events.publish('updateUser', { 'user': _this.user, 'showChat': _this.user['canChat'] });
                                        _this.toastCtrl.create({
                                            message: "You are now a part of " + _this.group['grpname'] + "!",
                                            duration: 4000,
                                            position: 'bottom'
                                        }).present();
                                    }
                                    else {
                                        app_component_1.Agnes.showError("Sorry, something went wrong - try joining " + _this.group['grpname'] + " again!");
                                    }
                                }).catch(function (error) {
                                    console.log('join public error', error);
                                    app_component_1.Agnes.showError("Sorry, something went wrong - try joining " + _this.group['grpname'] + " again!");
                                });
                            }
                            else {
                                _this.groupsService.joinPrivateGroup(data).then(function (value) {
                                    if (value) {
                                        _this.group['pendingreq'].push(_this.user['_id']);
                                        _this.toastCtrl.create({
                                            message: "Your request to join " + _this.group['grpname'] + " has been sent!",
                                            duration: 4000,
                                            position: 'bottom'
                                        }).present();
                                    }
                                    else {
                                        app_component_1.Agnes.showError("Sorry, something went wrong - try requesting to join " + _this.group['grpname'] + " again!");
                                    }
                                }).catch(function (error) {
                                    console.log('join private error', error);
                                    app_component_1.Agnes.showError("Sorry, something went wrong - try requesting to join " + _this.group['grpname'] + " again!");
                                });
                            }
                        }
                    }
                ]
            });
            document.getElementsByTagName("ng-component")[0]["style"]["filter"] = "blur(3vw)";
            alert_1.present();
        }
    };
    GroupProfile.prototype.claimGroup = function () {
        var _this = this;
        //tracking
        if (window['fabric']) {
            window['fabric'].Answers.sendCustomEvent('Group Profile', { type: 'claim' });
        }
        var alert = this.alertCtrl.create({
            title: 'Claim a group',
            message: "Would you like to claim " + this.group['grpname'] + " as a group that you're an admin of? If approved, " +
                "you will be given full administrative access to the group.",
            buttons: [
                {
                    text: 'Cancel',
                    handler: function () {
                        app_component_1.Agnes.removeFilter();
                    },
                    role: 'cancel'
                },
                {
                    text: 'Yes',
                    handler: function () {
                        app_component_1.Agnes.removeFilter();
                        var data = {
                            "group_id": _this.group['_id'],
                            "users_id": _this.user['_id'],
                            "grpname": _this.group['grpname']
                        };
                        _this.groupsService.claimGroup(data).then(function (value) {
                            if (value == 'sent') {
                                //successfully sent claim for group
                                _this.canClaim = false;
                                _this.claimReqs.push(_this.group['_id']);
                                localStorage.setItem('agnesClaimReqs', JSON.stringify(_this.claimReqs));
                                _this.toastCtrl.create({
                                    message: "You've requested to be an admin of " + _this.group['grpname'] + "!",
                                    duration: 4000,
                                    position: 'bottom'
                                }).present();
                            }
                            else {
                                var message = "";
                                if (value == 'already exist') {
                                    //already have admin access (i.e. userID is in group.admin and userEmail is in group.grpemail)
                                    message = "You are already an admin of " + _this.group['grpname'] + "!";
                                }
                                else {
                                    message = "Sorry, I couldn't process your request for admin access to " + _this.group['grpname'] + ". Try again!";
                                }
                                app_component_1.Agnes.showError(message);
                            }
                        });
                    }
                }
            ]
        });
        document.getElementsByTagName("ng-component")[0]["style"]["filter"] = "blur(3vw)";
        alert.present();
    };
    GroupProfile.prototype.shareGroup = function () {
        //tracking
        if (window['fabric']) {
            window['fabric'].Answers.sendShare('group');
        }
        var errorMessage = "";
        var hasError = false;
        if (this.platform.is('cordova')) {
            var message = "Hey! I think you might be interested in this group:\n\n" +
                this.group['grpname'] + '\n\n';
            var subj = "Check out \"" + this.group['grpname'] + "\"";
            ionic_native_1.SocialSharing.share(message, subj, this.group['picurl'], "https://agnes.io/share/group/" + this.group["_id"])
                .then(function (val) {
            })
                .catch(function (err) {
            });
        }
        else {
            hasError = true;
            errorMessage = "Please install Agnes from the App Store or Google Play store to share groups.";
        }
        if (hasError) {
            app_component_1.Agnes.showError(errorMessage);
        }
    };
    GroupProfile.prototype.leaveGroup = function () {
        var _this = this;
        //tracking
        if (window['fabric']) {
            window['fabric'].Answers.sendCustomEvent('Group Profile', { type: 'leave' });
        }
        var alert = this.alertCtrl.create({
            title: 'Leave this group',
            message: "Are you sure you want to leave " + this.group['grpname'] + "?",
            buttons: [
                {
                    text: 'Cancel',
                    handler: function () {
                        app_component_1.Agnes.removeFilter();
                    },
                    role: 'cancel'
                },
                {
                    text: 'Yes',
                    handler: function () {
                        app_component_1.Agnes.removeFilter();
                        var data = {
                            "groups_id": _this.group['_id'],
                            "users_id": _this.user['_id']
                        };
                        _this.groupsService.leaveGroup(data).then(function (value) {
                            //leaveGroup returns 1 for success
                            if (value) {
                                var aInd = _this.group['admin'].indexOf(_this.user['_id']);
                                var mInd = _this.group['members'].indexOf(_this.user['_id']);
                                if (aInd != -1) {
                                    _this.group['admin'].splice(aInd, 1);
                                }
                                if (mInd != -1) {
                                    _this.group['members'].splice(mInd, 1);
                                }
                                _this.closeGroupProfile(null, 'leave');
                                _this.toastCtrl.create({
                                    message: "You've left " + _this.group['grpname'] + "!",
                                    duration: 4000,
                                    position: 'bottom'
                                }).present();
                            }
                            else {
                                console.log('leave group err', value);
                                app_component_1.Agnes.showError('Sorry, could not remove this group from your groups list - try again!');
                            }
                        }).catch(function (err) {
                            console.log('leave group err', err);
                            app_component_1.Agnes.showError('Sorry, could not remove this group from your groups list - try again!');
                        });
                    }
                }
            ]
        });
        alert.present();
    };
    GroupProfile.prototype.contactGroup = function () {
        //tracking
        if (window['fabric']) {
            window['fabric'].Answers.sendCustomEvent('Group Profile', { type: 'contact' });
        }
        //allow user to email only if on mobile phone
        if (this.platform.is('mobile')
            && this.platform.is('cordova') &&
            (this.platform.is('ios') || this.platform.is('android'))) {
            //if user is already member, do not add prepopulated subject line
            var subj = (this.group['members'].indexOf(this.user['_id']) == -1)
                ? "Saw \"" + this.group['grpname'] + "\" on Agnes" : '';
            ionic_native_1.SocialSharing.shareViaEmail('', subj, this.group['grpemail']).then(function () {
                // Success!
            }).catch(function () {
                app_component_1.Agnes.showError("Agnes can't open your email client to contact this group - please try again!");
            });
        }
        else {
            app_component_1.Agnes.showError("Please install Agnes from the App Store or Google Play store to email groups.");
        }
    };
    GroupProfile.prototype.reportEntity = function () {
        //tracking
        if (window['fabric']) {
            window['fabric'].Answers.sendCustomEvent('Group Profile', { type: 'report' });
        }
        var reportPage = this.popoverCtrl.create(report_1.ReportPage, {
            'entityID': this.group['_id'],
            'entityName': this.group['grpname'],
            'user': this.user,
            'type': 'group',
            'platform': this.platform
        }, { 'enableBackdropDismiss': true });
        reportPage.present({
            animate: false
        });
        reportPage.onDidDismiss(function () {
        });
    };
    GroupProfile.prototype.deleteGroup = function () {
        var _this = this;
        //tracking
        if (window['fabric']) {
            window['fabric'].Answers.sendCustomEvent('Group Profile', { type: 'delete' });
        }
        var alert = this.alertCtrl.create({
            title: 'Delete your group',
            message: "Are you sure you want to delete " + this.group['grpname'] + "?",
            buttons: [
                {
                    text: 'Cancel',
                    handler: function () {
                        app_component_1.Agnes.removeFilter();
                    },
                    role: 'cancel'
                },
                {
                    text: 'Yes',
                    handler: function () {
                        app_component_1.Agnes.removeFilter();
                        // admin does want to delete this group
                        var data = { 'groups_id': _this.group['_id'] };
                        _this.groupsService.deleteGroup(data).then(function (value) {
                            if (value) {
                                var ind = _this.user['grp'].map(function (a) { return a['groups_id']; }).indexOf(_this.group['_id']);
                                if (ind != -1) {
                                    _this.user['grp'].splice(ind, 1);
                                }
                                _this.events.publish('updateUser', { 'user': _this.user, 'showChat': _this.user['canChat'] });
                                var toast = _this.toastCtrl.create({
                                    message: "You've successfully deleted " + _this.group['grpname'] + ".",
                                    duration: 4000,
                                    position: 'bottom',
                                    cssClass: 'delete',
                                    showCloseButton: true,
                                    closeButtonText: 'Undo'
                                });
                                toast.present();
                                localStorage.removeItem('agnesPeople');
                                localStorage.removeItem('agnesPeopleTimeout');
                                _this.closeGroupProfile(null, 'delete');
                            }
                        }).catch(function (error) {
                            app_component_1.Agnes.showError("Sorry, something went wrong - try deleting " + _this.group['grpname'] + " again!");
                        });
                    }
                }
            ]
        });
        alert.present();
        for (var e = 0; e < document.getElementsByTagName("ion-popover").length; e++) {
            document.getElementsByTagName("ion-popover")[e]["style"]["filter"] = "blur(3vw)";
        }
        document.querySelector("ng-component")["style"]["filter"] = "blur(3vw)";
    };
    GroupProfile.prototype.userOpened = function () {
        this.closeGroupProfile(null, null);
    };
    //TODO
    GroupProfile.prototype.keywordSearch = function (keyword) {
    };
    GroupProfile.prototype.viewGrpImg = function () {
        if (!this.group['noPic'] && this.group != '') {
            ionic_native_1.PhotoViewer.show(this.group['picurl']);
        }
    };
    GroupProfile.prototype.openEventProfile = function (event) {
        this.navCtrl.push(event_profile_1.EventProfile, {
            'event': event,
            'user': this.user,
            'type': 'all'
        }, {
            animation: 'ios-transition',
            duration: 350
        });
    };
    //invite friends to this group (friends connected through fb
    GroupProfile.prototype.inviteFriends = function () {
        var inviteFriends = this.popoverCtrl.create(invite_friends_1.InviteFriends, {
            'user': this.user,
            'objectID': this.group['_id'],
            'type': 'group'
        }, { 'enableBackdropDismiss': false });
        inviteFriends.present({
            animate: false
        });
    };
    __decorate([
        core_1.ViewChild('descriptionScroll')
    ], GroupProfile.prototype, "descriptionScroll", void 0);
    __decorate([
        core_1.ViewChild('profileScroll')
    ], GroupProfile.prototype, "profileScroll", void 0);
    GroupProfile = __decorate([
        core_1.Component({
            selector: 'group-profile',
            templateUrl: 'group-profile.html',
            providers: [groups_service_1.GroupsService, people_service_1.PeopleService, events_service_1.EventsService]
        })
    ], GroupProfile);
    return GroupProfile;
}());
exports.GroupProfile = GroupProfile;

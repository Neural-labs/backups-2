from conf import dev_conn, prod_conn

def get_devConn():
    return dev_conn

def get_prodConn():
    return prod_conn

import { Component, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import {Slides, ViewController, ToastController, NavParams } from 'ionic-angular';

import { LoginService }  from '../../../providers/login.service';
import { MeService } from '../../../providers/me.service';

@Component({
  selector: 'password-popup',
  templateUrl: 'password-popup.html',
  providers: [LoginService, MeService]
})

export class PasswordPopup {
  form: FormGroup;
  email: string;
  loading: boolean;
  user: Object;
  buttonText: string;
  emailError: string;
  hasEmailError: boolean;
  type: string;
  passcodeText : string;
  helpText: string;

  @ViewChild('passwordPopupSlides') slides:Slides;

  constructor(private loginService:LoginService,
              private meService: MeService,
              private viewCtrl: ViewController,
              private formBuilder:FormBuilder,
              private toastCtrl: ToastController,
              private navParams: NavParams) {
    this.form = this.formBuilder.group({
      passcode: ['', [Validators.required]],
      password: ['', [Validators.required, Validators.minLength(7)]],
      verify: ['',[Validators.required, Validators.minLength(7)]]
    });
  }

  ngOnInit(){

    this.slides.lockSwipes(true);
    this.email = '';
    this.loading = false;
    this.buttonText = "Next";
    this.hasEmailError = false;
    this.emailError = "Please enter a valid .edu email address";
    this.type = this.navParams.data.type;
    this.user = this.navParams.data.user;
    this.passcodeText = (this.type == 'Forgot') ? 'Passcode' : 'Password';
    this.helpText = (this.type == 'Forgot') ? 'Please type in the confirmation code we emailed to you'
        : 'Please enter your current password';
  }

  //make sure popover is not shifted to the left
  ngAfterViewInit() {
    window.setTimeout(function(){
      for (var e = 0; e < document.getElementsByClassName('popover-content').length; e++){
        document.getElementsByClassName('popover-content')[e]['style']['left'] = '0px';
      }
    },0);
  }

  closePasswordPopup(){
    this.viewCtrl.dismiss(false,'',{
      animate: true,
      animation: 'ios-transition',
      duration: 350,
      easing: "ease-in-out",
      direction: "back"
    });
  }

  submit(){
    //TODO: close keyboard
    let ind = this.slides.getActiveIndex();

    //on submitting email page
    if(ind==0 && this.type == 'Forgot'){
      this.hasEmailError = false;
      if(this.email.trim() == '' || this.email.indexOf('@') == -1){
        this.emailError = "Please enter a valid email address!";
        this.hasEmailError = true;
      }
      else {
        let data = {"email_id": this.email};
        this.loading = true;
        this.loginService.forgotPassword(data).then( value => {
          this.loading = false;
          if (value){
            this.hasEmailError = false;
            this.buttonText = "Submit";
            this.slides.lockSwipes(false);
            this.slides.slideNext();
            this.slides.lockSwipes(true);
          }
          else {
            this.emailError = "Looks like Agnes doesn't have your email on file - try again or try signing up!";
            this.hasEmailError = true;
          }
        });
      }
    }

    //on submitting change password page
    else {
      if(this.form.valid && (this.form.controls['verify'].value == this.form.controls['password'].value)){
        //user forgot password
        if(this.type == 'Forgot') {

          let data = {
            "email_id":this.email,
            "passcode":this.form.controls['passcode'].value,
            "password":this.form.controls['password'].value
          };

          this.loginService.checkPasscode(data)
            .then( value => {
              if(value){
                //password reset was a success, send to events
                this.hasEmailError = false;
                let user = JSON.stringify(value);
                localStorage.setItem("agnesUser",user);
                this.toastCtrl.create({
                  message: 'Password successfully reset!',
                  duration: 2500,
                  position:'top',
                    closeButtonText: ' ',
                    showCloseButton: true
                }).present();
                this.viewCtrl.dismiss(value);
              }
              else {
                document.getElementById('passcodeError').classList.add('active');
              }
            }).catch(err => {document.getElementById('passcodeError').classList.add('active');})
        }
        //user came from settings, wants to change password
        else {

          let data = {
            "users_id":this.user['_id'],
            "new_password":this.form.value['password'],
            "old_password":this.form.value['passcode']
          };
          this.meService.changePassword(data).then(value => {
            if(value){
              this.toastCtrl.create({
                message: 'Password successfully changed!',
                duration: 2500,
                position:'top',
                  closeButtonText: ' ',
                  showCloseButton: true
              }).present();
              this.viewCtrl.dismiss(value);
            }
            else {
              document.getElementById('passcodeError').classList.add('active');
            }
          }).catch(err => {
            document.getElementById('passcodeError').classList.add('active');});
        }
      }
      else {
        if (!this.form.controls["password"].valid){
          document.getElementById('passwordError').classList.add('active');
        }
        else {
          document.getElementById('passwordError').classList.remove('active');
          let match = this.form.controls["verify"].valid &&
            (this.form.controls['verify'].value == this.form.controls['password'].value);

          if (!match){
            document.getElementById('verifyError').classList.add('active');
          }
          else {
            document.getElementById('verifyError').classList.remove('active');
          }
        }

        if(!this.form.controls['passcode'].valid){
          document.getElementById('passcodeError').classList.add('active');
        }
        else{
          document.getElementById('passcodeError').classList.remove('active');
        }
      }
    }
  }

}

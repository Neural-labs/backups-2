"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var core_1 = require('@angular/core');
var ionic_angular_1 = require('ionic-angular');
var group_profile_1 = require('./group-profile/group-profile');
var group_details_1 = require('../popups/group-details/group-details');
var groups_service_1 = require('./groups.service');
var me_service_1 = require('../me/me.service');
var ionic_native_1 = require('ionic-native');
var app_component_1 = require('../../app/app.component');
var GroupsPage = (function () {
    function GroupsPage(navCtrl, groupsService, platform, meService, popoverCtrl, events, alertCtrl, toastCtrl) {
        this.navCtrl = navCtrl;
        this.groupsService = groupsService;
        this.meService = meService;
        this.popoverCtrl = popoverCtrl;
        this.events = events;
        this.alertCtrl = alertCtrl;
        this.toastCtrl = toastCtrl;
        this.allGroups = [];
        this.matchedGroups = [];
        this.storedAll = [];
        this.platform = platform;
    }
    //initialize groups page - get and display matched groups first
    //TODO: test search term check
    GroupsPage.prototype.ngOnInit = function () {
        this.initGroups();
    };
    //make sure bottom right chat bubble is shown when this page is visible
    GroupsPage.prototype.ionViewWillEnter = function () {
        this.events.publish('showChat', true);
    };
    GroupsPage.prototype.initGroups = function () {
        var _this = this;
        this.loading = true;
        if (ionic_native_1.Network.type != 'none') {
            this.noInternet = false;
            ionic_native_1.GoogleAnalytics.trackView("Groups");
            this.user = JSON.parse(localStorage.getItem("agnesUser"));
            this.groupsType = 'Matched';
            this.searchOpen = false;
            this.groupSearch = "";
            this.searching = false;
            this.matchedGroups = [];
            this.allGroups = [];
            this.storedAll = [];
            //TODO: check if user has loaded from search term
            var searchTerm = localStorage.getItem("agnesGroupSearch");
            localStorage.removeItem("agnesGroupSearch");
            if (searchTerm) {
                this.groupsType = 'All';
                this.showSearch();
                this.groupSearch = searchTerm;
                this.searchGroups();
            }
            else {
                this.getMatchedGroups(null);
                this.getAllGroups(null);
            }
            this.events.subscribe('openAddedGroup', function (data) {
                _this.openGroupProfile(data);
            });
        }
        else {
            this.noInternet = true;
            this.loading = false;
        }
    };
    GroupsPage.prototype.ionViewWillLeave = function () {
        this.events.unsubscribe('openAddedGroup');
    };
    //get all groups in user's community
    GroupsPage.prototype.getAllGroups = function (refresher) {
        var _this = this;
        if (!refresher) {
            this.loading = true;
        }
        var data = { 'users_id': this.user["_id"], 'community': this.user['community'] };
        this.groupsService.getAllGroups(data).then(function (value) {
            _this.loading = false;
            if (value) {
                _this.allGroups = value;
                _this.displayGroups(value, false, 'all');
            }
            if (refresher) {
                refresher.complete();
            }
        }).catch(function (error) {
            this.loading = false;
            if (refresher) {
                refresher.complete();
                app_component_1.Agnes.showError('Could not refresh groups - try again!');
            }
            console.log('all group error', error);
        });
    };
    //get user's matched groups
    GroupsPage.prototype.getMatchedGroups = function (refresher) {
        var _this = this;
        //this.groupsContent.scrollToTop(0);
        if (!refresher) {
            this.loading = true;
        }
        var stored = JSON.parse(localStorage.getItem('agnesMatchedGroups'));
        var t = new Date(JSON.parse(localStorage.getItem('agnesGroupsTimeout')));
        var timeout = new Date(t.setHours(t.getHours() + 12));
        var now = new Date();
        if (!stored || now > timeout) {
            var data = { 'id': this.user["_id"], 'community': this.user['community'] };
            this.groupsService.getMatchedGroups(data).then(function (value) {
                _this.loading = false;
                if (value) {
                    _this.matchedGroups = value;
                    _this.displayGroups(value, false, 'matched');
                }
                if (refresher) {
                    refresher.complete();
                }
            }).catch(function (error) {
                this.loading = false;
                if (refresher) {
                    refresher.complete();
                    app_component_1.Agnes.showError('Could not refresh groups - try again!');
                }
                //if timeout, show connection error screen
                if (error == 'timeout') {
                    this.noInternet = true;
                }
                console.log(error);
            });
        }
        else {
            this.matchedGroups = stored;
            this.loading = false;
        }
    };
    //display groups (matched OR all OR search)
    GroupsPage.prototype.displayGroups = function (groups, addingMore, type) {
        var _this = this;
        //filter out all null and unavilable groups, add displayURL to each group
        groups = groups.filter(function (a) { return a != null; }).map(function (a) {
            a['displayURL'] = (a['picurl'] == '' || !a['picurl'] || !_this.isImage(a.picurl)
                ? "assets/img/pattern_" + Math.floor((Math.random() * 15) + 1) + '.png' : a['picurl']);
            return a;
        });
        if (addingMore) {
            this[type + 'Groups'] = this[type + 'Groups'].concat(groups);
            this.storedAll = this.storedAll.concat(groups);
        }
        else {
            if (type == 'search') {
                this['allGroups'] = groups;
            }
            else {
                this[type + 'Groups'] = groups;
                if (type == 'all') {
                    this.storedAll = groups;
                    this.events.publish('updateGroupList');
                }
                else {
                    localStorage.setItem('agnesMatchedGroups', JSON.stringify(this.matchedGroups));
                    localStorage.setItem('agnesGroupsTimeout', JSON.stringify(new Date()));
                }
            }
        }
    };
    //check to see if image will load
    GroupsPage.prototype.isImage = function (src) {
        var image = new Image();
        var isImage = true;
        image.src = src;
        image.onerror = function () {
            isImage = false;
        };
        image.onload = function () {
            isImage = true;
        };
        return isImage;
    };
    //open search bar
    GroupsPage.prototype.showSearch = function () {
        var _this = this;
        //tracking
        if (window['fabric']) {
            window['fabric'].Answers.sendSearch('groups');
        }
        this.searchOpen = true;
        setTimeout(function () {
            _this.grpSearch.setFocus();
        }, 100);
    };
    //close search bar
    GroupsPage.prototype.closeSearch = function () {
        this.searchOpen = false;
        this.groupSearch = "";
        this.searching = false;
        this.allGroups = this.storedAll;
        ionic_native_1.Keyboard.close();
    };
    //search groups by name or keyword
    GroupsPage.prototype.searchGroups = function () {
        var _this = this;
        if (this.groupSearch && this.groupSearch.trim().length > 0) {
            var data = { "searchTerm": this.groupSearch, "community": this.user["community"] };
            this.searching = true;
            this.groupsService.searchGroups(data)
                .then(function (value) {
                if (value) {
                    _this.displayGroups(value, false, 'search');
                }
                else {
                    _this.searching = false;
                    _this.allGroups = _this.storedAll;
                }
            })
                .catch(function (error) { console.log(error); });
        }
        else {
            this.allGroups = this.storedAll;
        }
    };
    GroupsPage.prototype.addGroup = function () {
        var _this = this;
        //tracking
        if (window['fabric']) {
            window['fabric'].Answers.sendCustomEvent('Groups', { 'type': 'create group' });
        }
        var addGroup = this.popoverCtrl.create(group_details_1.GroupDetails, {
            'type': 'Add',
            'user': this.user,
            'platform': this.platform
        }, { 'enableBackdropDismiss': true });
        addGroup.present({
            animate: true,
            animation: 'ios-transition',
            duration: 500,
            easing: "ease-in-out",
            direction: "right"
        });
        addGroup.onDidDismiss(function (group) {
            if (group) {
                var id = group['_id'];
                if (id) {
                    _this.user['grp'].push({ 'groups_id': id, 'admin': true });
                }
                _this.events.publish('updateUser', { 'user': _this.user, 'showChat': _this.user['canChat'] });
                _this.openGroupProfile(group);
            }
        });
    };
    //load more groups in All Groups on infinite scroll
    GroupsPage.prototype.loadMoreGroups = function (infiniteScroll) {
        var _this = this;
        var data = {
            "community": this.user["community"],
            "users_id": this.user["_id"],
            "_id": this.allGroups[this.allGroups.length - 1]["_id"]
        };
        this.groupsService.loadMoreGroups(data).then(function (moreGroups) {
            if (moreGroups) {
                if (moreGroups.length == 1) {
                    infiniteScroll.enable(false);
                }
                else {
                    _this.displayGroups(moreGroups.slice(1), true, 'all');
                }
            }
            infiniteScroll.complete();
        })
            .catch(function (error) { console.log(error); });
    };
    //refresh groups
    GroupsPage.prototype.refreshGroups = function (refresher) {
        if (this.groupsType == 'Matched') {
            localStorage.removeItem('agnesMatchedGroups');
            localStorage.removeItem('agnesGroupsTimeout');
            this.getMatchedGroups(refresher);
        }
        else {
            this.getAllGroups(refresher);
        }
    };
    GroupsPage.prototype.openGroupProfile = function (group) {
        var _this = this;
        //tracking
        if (window['fabric']) {
            window['fabric'].Answers.sendCustomEvent('Groups', { 'type': 'opening \'matched\' profile ' });
        }
        this.events.subscribe('groupProfileData', function (data) {
            if (data) {
                var group_1 = data.group;
                if (data.leftGroup) {
                    _this.leftGroup(group_1);
                }
                else {
                    _this.updateGroup(group_1);
                }
            }
            _this.events.unsubscribe('groupProfileData');
        });
        this.navCtrl.push(group_profile_1.GroupProfile, {
            'group': group,
            'user': this.user,
            'platform': this.platform
        }, {
            animation: 'ios-transition',
            duration: 350
        });
    };
    GroupsPage.prototype.gotGroupData = function (data) {
        var group = data.group;
        if (data.category == 'leave') {
            this.leftGroup(group);
        }
        else if (data.category == 'delete') {
            this.leftGroup(group);
            //remove group from all groups and
            var ind = this.allGroups.map(function (a) { return a['_id']; }).indexOf(group['_id']);
            if (ind != -1) {
                this.allGroups.splice(ind, 1);
            }
            ind = this.storedAll.map(function (a) { return a['_id']; }).indexOf(group['_id']);
            if (ind != -1) {
                this.storedAll.splice(ind, 1);
            }
        }
        else if (data.category == 'edit') {
            this.updateGroup(group);
        }
    };
    //if group has been edited, update group object in displayed lists to reflect changes
    GroupsPage.prototype.updateGroup = function (group) {
        var mInd = this.matchedGroups.map(function (a) { return a['_id']; }).indexOf(group['_id']);
        var aInd = this.allGroups.map(function (a) { return a['_id']; }).indexOf(group['_id']);
        var sInd = this.storedAll.map(function (a) { return a['_id']; }).indexOf(group['_id']);
        this.matchedGroups[mInd] = group;
        this.allGroups[aInd] = group;
        this.storedAll[sInd] = group;
    };
    //user chose to leave this group, remove group from user's matched list (in display and backend)
    GroupsPage.prototype.leftGroup = function (group) {
        var _this = this;
        var data = {
            'groups_id': group['_id'],
            'users_id': this.user['_id']
        };
        this.groupsService.removeMatched(data).then(function (val) {
            if (val) {
                var uInd = _this.user['grp'].map(function (a) { return a['groups_id']; }).indexOf(group['_id']);
                var dispInd = _this.matchedGroups.map(function (a) { return a['_id']; }).indexOf(group['_id']);
                _this.user['grp'].splice(uInd, 1);
                _this.matchedGroups.splice(dispInd, 1);
                localStorage.setItem('agnesMatchedGroups', JSON.stringify(_this.matchedGroups));
                _this.events.publish('updateUser', { 'user': _this.user, 'showChat': _this.user['canChat'] });
            }
        }).catch(function (err) {
            console.log('remove matched error', err);
            app_component_1.Agnes.showError("Sorry, couldn't remove this group from your matched events - try again!");
        });
    };
    //join group from swiping right
    GroupsPage.prototype.joinGroup = function (group, card) {
        var _this = this;
        //tracking
        if (window['fabric']) {
            window['fabric'].Answers.sendCustomEvent('Groups', { 'type': 'join' });
        }
        card.close();
        // if user has already requested to join
        if (group['grptype'] == "private" && group['pendingreq'].indexOf(this.user['_id']) != -1) {
            app_component_1.Agnes.showError("You've already requested to join " + group['grpname'] + "!");
        }
        else if (group['grptype'] == "public" && (group['members'].indexOf(this.user['_id']) != -1 ||
            group['admin'].indexOf(this.user['_id']) != -1)) {
            app_component_1.Agnes.showError("You're already a part of " + group['grpname'] + "!");
        }
        else {
            var alert_1 = this.alertCtrl.create({
                title: 'Join a group',
                message: "Are you sure you want to join " + group['grpname'] + "?",
                buttons: [
                    {
                        text: 'Cancel',
                        handler: function () {
                            app_component_1.Agnes.removeFilter();
                        },
                        role: 'cancel'
                    },
                    {
                        text: 'Yes',
                        handler: function () {
                            app_component_1.Agnes.removeFilter();
                            var data = {
                                "groups_id": group['_id'],
                                "users_id": _this.user['_id'],
                                "community": _this.user['community']
                            };
                            //user wants to join public group
                            if (group['grptype'] == "public") {
                                _this.groupsService.joinPublicGroup(data).then(function (value) {
                                    if (value) {
                                        group['members'].push(_this.user['_id']);
                                        group['memcount'] = group['memcount'] + 1;
                                        _this.user['grp'].push({ 'groups_id': group['_id'], 'admin': false });
                                        _this.events.publish('updateUser', { 'user': _this.user, 'showChat': _this.user['canChat'] });
                                        _this.toastCtrl.create({
                                            message: "You are now a part of " + group['grpname'] + "!",
                                            duration: 4000,
                                            position: 'bottom'
                                        }).present();
                                    }
                                    else {
                                        app_component_1.Agnes.showError("Sorry, something went wrong - try joining " + group['grpname'] + " again!");
                                    }
                                }).catch(function (error) {
                                    console.log('join public error', error);
                                    app_component_1.Agnes.showError("Sorry, something went wrong - try joining " + group['grpname'] + " again!");
                                });
                            }
                            else {
                                _this.groupsService.joinPrivateGroup(data).then(function (value) {
                                    if (value) {
                                        group['pendingreq'].push(_this.user['_id']);
                                        _this.toastCtrl.create({
                                            message: "Your request to join " + group['grpname'] + " has been sent!",
                                            duration: 4000,
                                            position: 'bottom'
                                        }).present();
                                    }
                                    else {
                                        app_component_1.Agnes.showError("Sorry, something went wrong - try requesting to join " + group['grpname'] + " again!");
                                    }
                                }).catch(function (error) {
                                    console.log('join private error', error);
                                    app_component_1.Agnes.showError("Sorry, something went wrong - try requesting to join " + group['grpname'] + " again!");
                                });
                            }
                        }
                    }
                ]
            });
            document.getElementsByTagName("ng-component")[0]["style"]["filter"] = "blur(3vw)";
            alert_1.present();
        }
    };
    //leave or delete group from swiping left
    GroupsPage.prototype.removeGroup = function (group, card) {
        card.close();
        //user was part of group before, wants to leave
        if (this.user['grp'].indexOf(group['_id']) != -1) {
            this.leaveGroup(group);
        }
        else {
            this.leftGroup(group);
        }
    };
    //leave group
    GroupsPage.prototype.leaveGroup = function (group) {
        var _this = this;
        //tracking
        if (window['fabric']) {
            window['fabric'].Answers.sendCustomEvent('Groups', { type: 'leave' });
        }
        var alert = this.alertCtrl.create({
            title: 'Leave this group',
            message: "Are you sure you want to leave " + group['grpname'] + "?",
            buttons: [
                {
                    text: 'Cancel',
                    handler: function () {
                        app_component_1.Agnes.removeFilter();
                    },
                    role: 'cancel'
                },
                {
                    text: 'Yes',
                    handler: function () {
                        app_component_1.Agnes.removeFilter();
                        var data = {
                            "groups_id": group['_id'],
                            "users_id": _this.user['_id']
                        };
                        _this.groupsService.leaveGroup(data).then(function (value) {
                            //leaveGroup returns 1 for success
                            if (value) {
                                var aInd = group['admin'].indexOf(_this.user['_id']);
                                var mInd = group['members'].indexOf(_this.user['_id']);
                                if (aInd != -1) {
                                    group['admin'].splice(aInd, 1);
                                }
                                if (mInd != -1) {
                                    group['members'].splice(mInd, 1);
                                }
                                _this.leftGroup(group);
                                _this.toastCtrl.create({
                                    message: "You've successfully left " + group['grpname'] + "!",
                                    duration: 4000,
                                    position: 'bottom'
                                }).present();
                            }
                            else {
                                console.log('leave group err', value);
                                app_component_1.Agnes.showError('Sorry, could not remove this group from your groups list - try again!');
                            }
                        }).catch(function (err) {
                            console.log('leave group err', err);
                            app_component_1.Agnes.showError('Sorry, could not remove this group from your groups list - try again!');
                        });
                    }
                }
            ]
        });
        alert.present();
    };
    GroupsPage.prototype.swipeGroup = function (group, card, ev) {
        if (ev.direction == 4) {
            this.joinGroup(group, card);
        }
    };
    GroupsPage.prototype.keepKeyboard = function (event) {
        if (!this.shouldBlur || event.relatedTarget || this.reset) {
            event.target.focus();
            // Reset so other elements will blur the keyboard
            this.shouldBlur = true;
            this.reset = !this.reset;
        }
        else {
            if (this.groupSearch.trim() != '') {
                var data = {
                    'users_id': this.user['_id'],
                    'keyword': this.groupSearch.trim(),
                    'source': 'groups'
                };
                this.meService.logSearch(data).then(function (val) {
                }).catch(function (err) {
                });
            }
        }
    };
    GroupsPage.prototype.resetBlur = function () {
        this.reset = true;
    };
    GroupsPage.prototype.flipBlur = function () {
        this.shouldBlur = false;
        this.reset = false;
    };
    GroupsPage.prototype.scrollTop = function () {
        //tracking
        if (window['fabric']) {
            window['fabric'].Answers.sendCustomEvent('Groups', { 'type': 'toggle to ' + this.groupsType });
        }
        this.groupsContent.scrollToTop(0);
    };
    __decorate([
        core_1.ViewChild(ionic_angular_1.Content)
    ], GroupsPage.prototype, "groupsContent", void 0);
    __decorate([
        core_1.ViewChild('groupSearchInput')
    ], GroupsPage.prototype, "grpSearch", void 0);
    GroupsPage = __decorate([
        core_1.Component({
            selector: 'page-groups',
            templateUrl: 'groups.html',
            providers: [groups_service_1.GroupsService, me_service_1.MeService]
        })
    ], GroupsPage);
    return GroupsPage;
}());
exports.GroupsPage = GroupsPage;

import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';

import { AgnesRating } from './agnes-rating';

@NgModule({
    declarations: [
        AgnesRating
    ],
    imports: [
        IonicPageModule.forChild(AgnesRating)
    ],
    exports: [
        AgnesRating
    ]
})

export class AgnesRatingModule { }

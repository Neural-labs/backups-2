'''
Shuffle samples from 1 data collection to N data collections with random samples in each to help training

'''



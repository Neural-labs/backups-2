import { Component, ViewChild } from '@angular/core';
import { AlertController, Platform, ToastController, DomController,
  ViewController, NavParams, Slides, DateTime, Events } from 'ionic-angular';
import { Directive, Renderer } from '@angular/core';

import { EventsService } from '../../../providers/events.service';
import { GroupsService } from '../../../providers/groups.service';
import { AnalyticsService } from "../../../providers/analytics.service";

import { Agnes } from '../../../app/app.component';

import * as AWS from 'aws-sdk';
import * as S3 from 'aws-sdk/clients/s3';
import * as ValidURL from 'valid-url';



@Component({
  selector: 'event-details',
  templateUrl: 'event-details.html',
  providers: [ EventsService, GroupsService, AnalyticsService ]

})

export class EventDetails {
  event:Object;
  image:any;
  user:Object;
  loading:boolean;

  website:string;
  keywordInput: string;
  picChanged: boolean;
  localImg: string;
  typeHelpText: string;
  edited: boolean;

  hasGroups: boolean;
  inGroups: boolean;
  adminGroups = [];
  today: any;

  shouldBlur: boolean;
  isPrivate : boolean;

  starttime: string;
  endtime: string;

  @ViewChild('eventDetailsSlides') slides:Slides;
  @ViewChild('startPicker') startPicker:DateTime;
  @ViewChild('endPicker') endPicker:DateTime;

  constructor(public viewCtrl:ViewController,
              private navParams:NavParams,
              private platform: Platform,
              private eventsService: EventsService,
              private groupsService: GroupsService,
              private analyticsService: AnalyticsService,
              private toastCtrl: ToastController,
              private alertCtrl: AlertController,
              private domCtrl: DomController,
              private renderer: Renderer,
              private events: Events) {
  }

  ngOnInit() {
    this.user = JSON.parse(localStorage.getItem('agnesUser'));
    this.event = JSON.parse(JSON.stringify(this.navParams.get('event')));
    this.event['sendNotification'] = true;
    this.loading = false;
    this.image = 'url(' + this.event["picurl"] + ')';
    this.keywordInput = '';
    this.website = '';
    this.picChanged = false;
    this.typeHelpText = '';

    this.shouldBlur = true;
    this.isPrivate = this.event['evttype'] == 'private';

    let today = new Date();
    let month = (today.getMonth() + 1 < 10) ? '0' + (today.getMonth() + 1) : (today.getMonth() + 1);
    let day = (today.getDate() + 1 < 10) ? '0' + today.getDate() : today.getDate();
    this.today = today.getFullYear() + '-' + month + '-' + day;

    let start = Agnes.processGMT(this.event['starttime']);
    this.starttime = start['date'].substring(5,start['date'].length) + ' ' + start['time'];

    let end = Agnes.processGMT(this.event['endtime']);
    this.endtime = end['date'].substring(5,start['date'].length) + ' ' + start['time'];

    //check if any fields have been changed so if user exits, can ask if he/she wants to save changes
    this.edited = false;

    this.getUserGroups();

    //send Edit Event button click analytics
    this.analyticsService.logAnalytics({community: this.user['community'], users_id: this.user['_id']}, '/edit_event_bt');
  }

  //get list of groups that user is admin of
  getUserGroups() {
    this.adminGroups = [];
    this.groupsService.getAdminGroups({"users_id":this.user['_id']}).then(value => {
      if (value){
        for (var v in value) {
          let group = value[v];
          if (group){
            let ind = this.user['grp'].map(function(a){return a['groups_id'];}).indexOf(group['_id']);
            if (this.user['grp'][ind]['admin']
                && this.adminGroups.map(function(a){return a['groups_id']}).indexOf(group['_id']) == -1){
              this.adminGroups.push(group);
            }
          }
        }

        this.adminGroups.push({
          'grpname': 'No Host',
          'thumbnail': 'assets/img/icons/eventNope.png'
        });

        this.hasGroups = this.adminGroups.length > 0;
      }
      else {
        this.hasGroups = false;
      }
    }).catch(err => {
      this.hasGroups = false;
    });
  }

  //show error if user has no groups
  noGroupsAlert(){
    Agnes.showError('Looks like you aren\'t an admin of any groups - create or claim a group to host an event for that group!');
  }

  //save event edits
  submitEdits(){
    let valid =
        this.event['evtname'] != '' && this.event['location'] != '' &&
        this.starttime != '' && this.endtime != '' && this.event['keywords'].length > 0;

    if (valid){
      if (this.event['picurl'] != '' && this.picChanged){
        this.localImg = this.event['picurl'];
        let creds = {
          bucket: 'agneseventimage',
          access_key: 'AKIAJYQU6AUVQQKITAPQ',
          secret_key: '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'
        };
        let uniqueFilename = "";
        var possible = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";

        for (var i = 0; i < 8; i++) {
          uniqueFilename += possible.charAt(Math.floor(Math.random() * possible.length));
        }

        let data = this.baseToBlob(this.event['picurl']);
        AWS.config.update({region: 'us-east-1',credentials: {
          accessKeyId: "AKIAJYQU6AUVQQKITAPQ",
          secretAccessKey:"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"
        }});

        let keyname = uniqueFilename + '.jpg';
        keyname = '_' + keyname;

        //TODO if the orientation stuff came up!
        /* if(this.orientation){
         keyname = '_' + keyname;
         }
         else{
         keyname = '_' + uniqueFilename
         }
         */

        //Bucket Parameters
        let bucketParams = {
          Key: keyname,
          ContentType: ".jpg",
          Body: data ,
          ServerSideEncryption: 'AES256',
          Bucket: creds.bucket
        };

        //bucket to define
        let bucket = new S3({ params: { Bucket: 'agneseventimage' } });

        bucket.putObject(bucketParams, function(err, data) {
          if(err) {
            console.log('bucket error',err);
            return false;
          }
          else {
            // Upload Successfully Finished
          }
        });

        this.event['picurl'] = 'https://s3.amazonaws.com/agneseventimage/' + keyname;
      }

      if (this.website != ''){this.event['weburl'] = [this.website];}

      let st = new Date(this.event['starttime']);
      let end = new Date(this.event['endtime']);
      this.event['starttime'] = st.toISOString();
      this.event['endtime'] = end.toISOString();

      this.loading = true;

      //submit event edits
      let data = this.event;
      data['events_id'] = this.event['_id'];

      this.eventsService.editEvent(data)
          .then(value => {
            if(value){
              value['picurl'] = this.localImg ? this.localImg : value['picurl'];
              this.toastCtrl.create({
                message: "You've successfully edited " + this.event['evtname'] + "!",
                duration: 2500,
                position:'top',
                closeButtonText: ' ',
                showCloseButton: true
              }).present();
              if(this.platform.is('cordova')) {
                this.modifyInCalendar();
                this.events.publish('editDone',value)
                this.viewCtrl.dismiss(value)
              }
              else {
                this.events.publish('editDone',value)
                this.viewCtrl.dismiss(value);
              }
            }
            else {
              this.loading = false;
              Agnes.showError("Couldn't save your event edits right now - try again!");
            }
          })
          .catch(err => {
            console.log('Edit event error:\n', err);
            this.loading = false;
            Agnes.showError("Couldn't save your event edits right now - try again!");
          });
    }
    else {
      Agnes.showError("Please make sure you have an event name and location, valid start/end times, " +
          "and at least one keyword before submitting!");
    }
  }

  //close edit event popup - but check first if events have been made and if so, check to see if user wants to save them
  closeEditEvent(doDelete?){
    if(this.edited){

      Agnes.showError('Do you want to save your changes?', ['Not now', 'Save']);
      this.events.subscribe('agnesAlertData', ind => {
        if(ind == 1){
          this.submitEdits();
        }
        else {
          this.viewCtrl.dismiss(null,'',{
            animate: true,
            animation: 'ios-transition',
            duration: 350,
            easing: "ease-in-out",
            direction: "back"
          });
        }
      });
    }
    else {
      this.viewCtrl.dismiss(null,'',{
        animate: true,
        animation: 'ios-transition',
        duration: 350,
        easing: "ease-in-out",
        direction: "back"
      });
    }
  }

  imgLoad(last){
    if(last){this.loading = false;}
  }

  imgError(group, last){
    let ind = this.adminGroups.map(a => {return a['_id']}).indexOf(group['_id']);
    this.adminGroups[ind]['displayURL'] = "assets/img/icons/defaultGroup.png";
    if (last) {this.loading = false;}
  }

  selectAdminGroup(group){
    this.event['grps'] = [group['_id']];
    this.event['admin'] = [];

    for(var a in group['admin']){
      if (this.event['admin'].indexOf(group['admin'][a]) == -1) {this.event['admin'].push(group['admin'][a]);}
    }

    this.inGroups = false;
  }

  //use if you want the cursor to move to the end of the input on focus (does not scroll the cursor/end of text into view though)
  // focusInput(e){
  //   setTimeout(() => {
  //     e.target.value = e.target.value;
  //   },1);
  // }

  //set date and time for start/end of event
  openDatePicker(type){
    let d = new Date();
    let current = this.event['starttime'] == '' ? d : new Date(this.event['starttime']);
    Agnes.datePicker.show({
      date: current,
      mode: 'datetime',
      titleText: 'Event Start Time',
      minDate: d,
      maxDate: new Date().setFullYear(d.getFullYear() + 1),
      androidTheme: Agnes.datePicker.ANDROID_THEMES.THEME_DEVICE_DEFAULT_DARK,
      allowOldDates: false
    }).then(
        date => {
          if(date){
            date = new Date(date);
            let start = Agnes.processGMT(date);
            this.starttime = start['date'].substring(5,start['date'].length) + ' ' + start['time'];
            this.event['starttime'] = date.toISOString();
            let end = new Date(date);
            this.event['endtime'] = new Date(end.setHours(end.getHours() + 1));

            setTimeout(() => {
              Agnes.datePicker.show({
                date: this.event['endtime'],
                mode: 'datetime',
                titleText: 'Event End Time',
                minDate: d,
                maxDate: new Date().setFullYear(d.getFullYear() + 1),
                androidTheme: Agnes.datePicker.ANDROID_THEMES.THEME_DEVICE_DEFAULT_DARK,
                allowOldDates: false
              }).then(
                  date => {
                    if(date){
                      date = new Date(date);
                      let end = Agnes.processGMT(date.toISOString());
                      this.endtime = end['date'].substring(5,end['date'].length) + ' ' + end['time'];
                      this.event['endtime'] = date.toISOString();
                    }

                  },
                  err => console.log('Error occurred while getting date: ', err)
              );
            },500);
          }
        },
        err => console.log('Error occurred while getting date: ', err)
    );
  }

  addKeyword(e){
    //for keeping keyboard up when + button is pressed
    if(e){
      e.preventDefault();
      this.shouldBlur = false;
    }

    if(this.event['keywords'].length < 6 && this.keywordInput.trim() != '') {
      let add = this.keywordInput.toLowerCase().trim().replace(/,\s+/,',').split(',')
          .map(a => {return a.trim()}).filter(a => {return this.event['keywords'].indexOf(a) == -1});
      this.event['keywords'] = this.event['keywords'].concat(add);
      this.changeEdited();
    }
    this.keywordInput = '';
    let elem = document.getElementById('eventKeywords');
    elem.scrollTop = elem.scrollHeight;
  }

  removeKeyword(key){
    let ind = this.event['keywords'].indexOf(key);
    if(ind != -1){
      this.event['keywords'].splice(ind,1);
      this.changeEdited();
    }
    let elem = document.getElementById('eventKeywords');
    elem.scrollTop = elem.scrollHeight;
  }

  //choose whether to send an edit notification to attendees
  toggleNotification(){
    this.event['sendNotification'] = !this.event['sendNotification'];
  }

  //change event type
  toggleEventType(){
    this.event['evttype'] = this.event['evttype'] == 'private' ? 'public' : 'private';
    this.isPrivate = !this.isPrivate;
  }

  addPhoto(type){

    let buttons = [
      {name: 'Camera',
        icon:'md-camera'},
      {name: 'Upload',
        icon: 'ios-share-outline'}
    ];

    Agnes.showError('Choose a photo source', buttons, false, false, true);

    this.events.subscribe('agnesAlertData', ind => {
      if(ind){
        let source = ind == 0 ? Agnes.camera.PictureSourceType.CAMERA : Agnes.camera.PictureSourceType.PHOTOLIBRARY;

        let options = {
          quality: 25,
          allowEdit: true,
          cameraDirection: Agnes.camera.Direction.FRONT,
          correctOrientation: true,
          destinationType: Agnes.camera.DestinationType.DATA_URL,
          sourceType: source
        };

        Agnes.camera.getPicture(options).then((value) => {
          if (value && typeof(value)=='string'){
            let base64Image = 'data:image/jpeg;base64,' + value;
            this.event['picurl'] = base64Image;
            this.picChanged = true;
          }
          else {
            console.log('not base64', value);
            Agnes.showError("Couldn't process your photo - try again!");
          }
        }, (err) => {
          console.log(err);
        }).catch(err => {
          Agnes.showError("Couldn't get your photos - make sure Agnes has photo access permissions and try again!");
        });
      }
    });
  }

  baseToBlob(dataURI) {
    // convert base64/URLEncoded data component to raw binary data held in a string
    var byteString;
    if (dataURI.split(',')[0].indexOf('base64') >= 0)
      byteString = atob(dataURI.split(',')[1]);
    else
      byteString = (dataURI.split(',')[1]);

    // separate out the mime component
    // var mimeString = dataURI.split(',')[0].split(':')[1].split(';')[0];

    // write the bytes of the string to a typed array
    var ia = new Uint8Array(byteString.length);
    for (var i = 0; i < byteString.length; i++) {
      ia[i] = byteString.charCodeAt(i);
    }

    return new Blob([ia.buffer], {type: "image/jpeg"});
  }

  getOrientation(file, callback) {
    var reader = new FileReader();
    reader.onload = function (e) {

      var view = new DataView(e.target['result']);
      if (view.getUint16(0, false) != 0xFFD8) return callback(-2);
      var length = view.byteLength, offset = 2;
      while (offset < length) {
        var marker = view.getUint16(offset, false);
        offset += 2;
        if (marker == 0xFFE1) {
          if (view.getUint32(offset += 2, false) != 0x45786966) return callback(-1);
          var little = view.getUint16(offset += 6, false) == 0x4949;
          offset += view.getUint32(offset + 4, little);
          var tags = view.getUint16(offset, little);
          offset += 2;
          for (var i = 0; i < tags; i++)
            if (view.getUint16(offset + (i * 12), little) == 0x0112)
              return callback(view.getUint16(offset + (i * 12) + 8, little));
        }
        else if ((marker & 0xFF00) != 0xFF00) break;
        else offset += view.getUint16(offset, false);
      }
      return callback(-1);
    };
    reader.readAsArrayBuffer(file.slice(0, 64 * 1024));
  }

  onEnter(ev){
    if(ev.keyCode == 13) {
      this.addKeyword(null);
    }
  }

  //user has made an edit
  changeEdited(){
    this.edited = true;
  }

  disableScroll(enable){
    Agnes.keyboard.disableScroll(enable);
  }

  //edit event in user's native calendar to reflect changes
  modifyInCalendar(){
    let event = this.navParams.data.event;
    let title = event['evtname'].replace(/\s+/g, ' ');
    let startDate = new Date(event['starttime'].replace(/[-\+]\d\d\d\d/,'Z'));
    let endDate = new Date(event['endtime'].replace(/[-\+]\d\d\d\d/,'Z'));

    Agnes.calendar.modifyEvent(title,'','',startDate,endDate,
      this.event['evtname'],this.event['location'],
      this.event['evtdesc'].replace(/\s+/g, ' ').substring(0,2000),
      new Date(this.event['starttime'].replace(/[-\+]\d\d\d\d/,'Z')),
      new Date(this.event['endtime'].replace(/[-\+]\d\d\d\d/,'Z'))).then(message => {
        this.viewCtrl.dismiss(this.event);
    }).catch(err => {
      console.log('mod error', err);
      this.viewCtrl.dismiss(this.event);
    });
  }

  //for keeping keyboard up when + button is pressed for keywords
  keepKeyboard(event){
    if(!this.shouldBlur){
      event.target.focus();
      this.shouldBlur = true;
    }
  }

}

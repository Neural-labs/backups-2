import { Component, Input } from '@angular/core';

/**
 * show skeleton list of 10 cards split over 3 skeleton date groups
 *
 */

@Component({
  selector: 'skeleton-card-list',
  templateUrl: 'skeleton-card-list.html'
})
export class SkeletonCardListComponent {

  @Input() type: string;

  constructor() {
  }

}

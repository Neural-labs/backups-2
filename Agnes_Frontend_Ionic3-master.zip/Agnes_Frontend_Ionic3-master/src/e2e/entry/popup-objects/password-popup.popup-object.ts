// import { element, by } from 'protractor';
// export class PasswordPopupObject {
//
//     constructor(){
//
//     }
//
//     getDisplay() {
//         return element(by.css('password-popup'))
//     }
//
//     getTitle(){
//         return element(by.css('#passwordPopup .popupTitle')).getText();
//     }
//
//     getBackButton(){import { element, by } from 'protractor';
// export class PasswordPopupObject {
//
//     constructor(){
//
//     }
//
//     getDisplay() {
//         return element(by.css('password-popup'))
//     }
//
//     getTitle(){
//         return element(by.css('#passwordPopup .popupTitle')).getText();
//     }
//
//     getBackButton(){
//         return element(by.css('#passwordPopup .popupClose'));
//     }
//
//     getSubmitButton(){
//         return element(by.css('#passwordPopup #submitPasswordPopupButton'));
//     }
//
//     getInput(type){
//         return element(by.css('#passwordPopup' + type));
//     }
//
//     getError(type){
//         return element(by.css('#passwordPopup #' + type + 'Error'));
//     }
//
// }
//         return element(by.css('#passwordPopup .popupClose'));
//     }
//
//     getSubmitButton(){
//         return element(by.css('#passwordPopup #submitPasswordPopupButton'));
//     }
//
//     getInput(type){
//         return element(by.css('#passwordPopup' + type));
//     }
//
//     getError(type){
//         return element(by.css('#passwordPopup #' + type + 'Error'));
//     }
//
// }
'''
Module to collect samples for event page detection training

Uses module CollectIdentificationFeatures to get features for a specific page

Inserts new sample with features to mongodb collection: autocrawler_id_data

'''

from config import db_config
from multiprocessing import cpu_count, JoinableQueue, Pool
from Preprocessing.CollectFeatures.CollectIdentificationFeatures import extractFeaturesManual, extractContentFeaturesEmbedding,\
    extractURLFeaturesEmbedding, extractHTMLFeaturesEmbedding, getPageEmbedding, getWord2VecEmbedding, getCharEmbedding, getPageEmbeddingV2
import gc
import logging
import os
import random
import time
import numpy as np
from Utilities import DataFilter

Agnes = db_config.getDBConn('dev').Agnes
Event_Collection = Agnes.autocrawler_events
Control_Collection = Agnes.autocrawler_domain_pages

batch_size = 100

global html_embedding_model
global w2v_embedding_model
global char_embedding_model


def RunIdentificationSampleCollection():
    print 'Starting Identification Sample Collection...'

    initGlobals()

    NUM_THREADS = cpu_count()
    # NUM_THREADS = 1
    # NUM_THREADS = 13
    print 'Spawning', NUM_THREADS, 'Workers...'

    QUEUE_MAXSIZE = 50

    queue = JoinableQueue(QUEUE_MAXSIZE)

    pool = Pool(NUM_THREADS, worker_main, (queue,))

    counter = 0

    try:

        for page,label in pageGenerator():
            counter += 1
            if counter % 100 == 0:
                logging.info('Queued: %d' % counter)
            queue.put((page, label, counter), block=True)

        print 'All events in queue'
        queue.join()

    except KeyboardInterrupt as e:
        print 'Keyboard interrupt'
        pool.terminate()
        pool.join()
        exit()

    print 'Finished Collecting Samples'

def initGlobals():
    global html_embedding_model
    global w2v_embedding_model
    global char_embedding_model

    html_embedding_model = getPageEmbeddingV2()
    w2v_embedding_model = getWord2VecEmbedding()
    char_embedding_model = getCharEmbedding()

    print 'Finished Loading Embeddings'
    gc.collect()
    # time.sleep(2)

# initGlobals()

def pageGenerator():

    for page in posGenerator():
        yield page, 1

    for page in negGenerator():
        yield page, 0

    return

def posGenerator():
    total_samples = Event_Collection.count()
    counter = 0
    last_id = None
    while True:
        batch = getSampleBatchCursor(Event_Collection, last_id)
        batch_count = batch.count(with_limit_and_skip=True)

        if not batch or not batch_count:
            break

        last_id = batch[batch_count-1]['_id']

        for item in batch:
            if counter % 100 == 0:
                logging.info('Pos Generator - %d of %d, LastID: %s' % (counter, total_samples, str(last_id)))
            if validPos(item):
                yield item
                counter += 1
        del batch
        gc.collect()

def negGenerator():
    total_samples = Control_Collection.count()
    counter = 0
    last_id = None
    while True:
        batch = getSampleBatchCursor(Control_Collection, last_id)
        batch_count = batch.count(with_limit_and_skip=True)

        if not batch or not batch_count:
            break

        last_id = batch[batch_count-1]['_id']

        for item in batch:
            if counter % 100 == 0:
                logging.info('Neg Generator - %d of %d, LastID: %s' % (counter, total_samples, str(last_id)))
            if validNeg(item):
                yield item
                counter += 1

        del batch
        gc.collect()


def validPos(item):
    if 'HTML' not in item:
        return False
    if 'evtsource' not in item or not item['evtsource']:
        return False
    if not 'netx_tree_pkl' in item or item['netx_tree_pkl'] == {}:
        return False
    return True

def validNeg(item):
    if 'HTML' not in item:
        return False
    if 'url' not in item:
        return False
    if not item['HTML'] or not item['url']:
        return False
    return True

def worker_main(queue):
    worker_id = os.getpid()
    dbConn = db_config.getNewClientDBConn()
    data_collection = dbConn.Agnes.autocrawler_id_data
    print worker_id, 'Alive'

    while True:
        try:
            page, label, counter = queue.get(True)
            if counter % 500 == 0:
                logging.info('Worker %s received page %d' % (str(worker_id), counter))
        except KeyboardInterrupt as e:
            print 'Worker', worker_id, 'stopping'
            exit()

        error, sample = parseSample(page, label)

        if not error:
            # updateSample(data_collection, sample)
            # writeSample(data_collection, sample)
            pass
        queue.task_done()

def parseSample(page, label):
    global html_embedding_model
    global w2v_embedding_model
    global char_embedding_model

    page_html = str(DataFilter.getDirtySoup(page['HTML']))

    if not 'url' in page and not 'weburl' in page and not page['weburl']:
        return True, None

    if 'url' in page:
        page_url = page['url']
    elif 'weburl' in page:
        page_url = page['weburl'][0]
    else:
        return True, None

    manual_features = extractFeaturesManual(page_url, page_html)

    html_features = extractHTMLFeaturesEmbedding(html_embedding_model, page_html)

    content_features = extractContentFeaturesEmbedding(w2v_embedding_model, page_html)

    url_features = extractURLFeaturesEmbedding(char_embedding_model, page['url'])

    for features in [html_features, content_features, url_features, manual_features]:
        if not features:
            return True, None

    if np.isnan(np.sum(manual_features)):
        return True, None

    sample = {}
    sample['manual_features'] = manual_features
    sample['html_embedding'] = html_features
    sample['content_embedding'] = content_features
    sample['url_embedding'] = url_features
    sample['event_id'] = page['_id']
    sample['random_id'] = generateRandom()
    sample['evtsource'] = getPageEvtSource(page)
    sample['community'] = getPageCommunity(page)
    sample['label'] = label
    sample['url'] = page_url

    if not sample['community']:
        return True, None

    # if sample['evtsource'] == 'browse.calendar.gwu.edu':
    #     print sample['manual_features']
    #     print sample['']

    return False, sample

def getPageEvtSource(page):
    if 'evtsource' in page:
        return page['evtsource']
    else:
        return ''

def getPageCommunity(page):
    comm = page['community']
    bad_comms = ['agnes','groupten']
    if isinstance(comm, list):
        comm = [a for a in comm if not a in bad_comms]
        comm = comm[0] if comm else None
    return comm

def generateRandom():
    return int(abs(random.getrandbits(62))) # 2^62 possible ids

def getSampleBatchCursor(collection, last_id):
    return_fields = {
        'HTML':1,
        'url':1,
        'evtsource':1,
        'weburl':1,
        'community':1,
        'netx_tree_pkl':1
    }
    if not last_id:
        return collection.find({},return_fields, no_cursor_timeout=True).limit(batch_size).sort('_id',1)
    return collection.find({'_id': {'$gt': last_id}}, return_fields, no_cursor_timeout=True).limit(batch_size).sort('_id',1)

# def printSample(sample):

def updateSample(collection, sample):
    collection.replace_one({'event_id':sample['event_id']}, sample)

def writeSample(collection, sample):
    collection.insert(sample)

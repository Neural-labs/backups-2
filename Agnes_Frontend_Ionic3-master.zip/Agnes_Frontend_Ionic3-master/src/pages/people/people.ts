import { Component, ViewChild } from '@angular/core';
import { NavController, Content, Events, IonicPage } from 'ionic-angular';
import { PeopleService } from '../../providers/people.service';
import { Agnes } from '../../app/app.component';
import { MeService } from '../../providers/me.service';

@IonicPage()
@Component({
  selector: 'page-people',
  templateUrl: 'people.html',
  providers: [PeopleService,MeService]
})
export class PeoplePage {
  people = [];
  displayed = [];
  user: Object;
  searchOpen: boolean;
  searching: boolean;
  peopleSearch: string;
  loading: boolean;
  studentTypes: Array<string>;
  noInternet: boolean;
  hasPlugins: boolean;

  @ViewChild(Content) peopleContent: Content;


  constructor(public navCtrl: NavController,
              private events: Events,
              private peopleService: PeopleService) {
  }

  ngOnInit(){
    this.initPeople();
  }

  initPeople(){
    this.loading = true;
    this.hasPlugins = Agnes.hasPlugins();

    if(!this.hasPlugins || Agnes.network.type != 'none'){

      this.noInternet = false;
      this.user = JSON.parse(localStorage.getItem("agnesUser"));
      this.searchOpen = true;
      this.peopleSearch = "";
      this.searching = false;
      this.studentTypes = ["freshman", "sophomore", "junior", "senior", "fifth year", "masters", "phd"];
      this.getPeople(null);
    }
    else {
      this.noInternet = true;
      this.loading = false;
    }
  }

  getPeople(refresher){
    let stored = JSON.parse(localStorage.getItem('agnesPeople'));
    let t = new Date(JSON.parse(localStorage.getItem('agnesPeopleTimeout')));
    let timeout = new Date(t.setHours(t.getHours()+ 12));
    let now = new Date();

    if(!stored || now > timeout || stored.length == 0){
      let data = {'users_id': this.user["_id"], 'user':this.user, 'community': this.user['community']};
      this.peopleService.getPeople(data).then(value => {
        if(refresher){refresher.complete();}
        if(value){
          this.displayPeople(value,false);
        }
      }).catch(error => {
        if(refresher){refresher.complete();}
        this.loading = false;
        //if timeout, show connection error screen
        if(error == 'timeout') {this.noInternet = true;}
        console.log(error)});
    }
    else {
      this.loading = false;
      this.displayed = stored;
      if(refresher){refresher.complete();}
    }
  }

  isStudent(type){
    return (this.studentTypes.indexOf(type.toLowerCase()) != -1);
  }

  loaded(){
    this.loading = false;
  }

  displayPeople(people, addingMore){
    let ids = this.people.map(function(a){return a._id;});
    let adding = [];
    for (let p in people) {
      if(this.isStudent(people[p]['studenttype'])) {
        if ((ids.indexOf(people[p]["_id"]) == -1 && people[p]['_id'] != this.user['_id']) || this.searching){
          people[p].keywordString = people[p].keywords.map(function(a){return a.name}).toString().replace(/,/g,', ');
          adding.push(people[p]);
        }
      }
    }

    if (!this.searching){
      if (addingMore) {
        this.people = this.people.concat(adding);
      }
      else {
        this.people = adding;
      }

      this.displayed = this.people;

      localStorage.setItem('agnesPeople',JSON.stringify(this.displayed));
      localStorage.setItem('agnesPeopleTimeout', JSON.stringify(new Date()));
    }
    else {
      this.displayed = adding;
    }
  }

  searchPeople(){
    this.peopleContent.scrollToTop(0);
    this.searching = true;
    let filter = this.peopleSearch;
    let data = {"searchTerm":filter, "community":this.user['community']};
    if (filter && filter.length > 0) {
      this.peopleService.searchPeople(data).then(value => {
        if (value){
          this.displayPeople(value,false);
        }
      }).catch(function(error){console.log(error)});
    }
    else {
      this.searching = false;
      this.displayed = JSON.parse(localStorage.getItem('agnesPeople'));
    }
  }

  loadMorePeople(infiniteScroll){
    let data = {
      "users_id":this.user["_id"],
      "_id": this.displayed[this.displayed.length - 1]["_id"]
    };

    this.peopleService.loadMorePeople(data).then(value => {
      if (value.filter((a) => {
        return this.isStudent(a['studenttype'])}).length == 0){
        infiniteScroll.enable(false);
      }
      else {
        this.displayPeople(value,true);
      }
      infiniteScroll.complete();
    }).catch(function(error){console.log(error)});
  }

  //clear search bar
  clearSearch(){
    this.searchOpen = false;
    this.displayed = JSON.parse(localStorage.getItem('agnesPeople'));
    this.peopleSearch = "";
    this.searching = false;
    this.peopleContent.scrollToTop(0);
  }

  refreshPeople(refresher){
    localStorage.removeItem('agnesPeople');
    localStorage.removeItem('agnesPeopleTimeout');
    this.people = [];
    this.getPeople(refresher);
  }

}

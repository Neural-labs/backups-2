import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { DirectivesModule } from '../../../directives/directives.module';

import { CreateGroupPage } from './create-group';

@NgModule({
    declarations: [
        CreateGroupPage
    ],
    imports: [
        IonicPageModule.forChild(CreateGroupPage),
        DirectivesModule
    ],
    exports: [
        CreateGroupPage
    ],
})

export class CreateGroupPageModule { }

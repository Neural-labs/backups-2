import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';

import { EditGroup } from './edit-group';
import { SuperTabsModule } from 'ionic2-super-tabs';
import { ComponentsModule } from '../../../../components/components.module';
import { DirectivesModule } from '../../../../directives/directives.module';

@NgModule({
    declarations: [
        EditGroup
    ],
    imports: [
        IonicPageModule.forChild(EditGroup),
        SuperTabsModule,
        ComponentsModule,
        DirectivesModule
    ],
    exports: [
        EditGroup
    ],
})

export class EditGroupModule { }

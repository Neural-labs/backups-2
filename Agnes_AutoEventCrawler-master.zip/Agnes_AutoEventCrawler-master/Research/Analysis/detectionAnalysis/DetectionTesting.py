from Preprocessing.CollectFeatures import CollectIdentificationFeatures
from DetectionTraining import getModel, scaleFeatures
from config import db_config
import pickle
import numpy as np
import requests
import logging
from sklearn.metrics import log_loss, mean_squared_error, roc_auc_score

from DetectionTraining import useCharEmb, useHTMLEmb, useContentEmb, useManual


Agnes = db_config.getDBConn('dev').Agnes

Data_Collection = Agnes.autocrawler_data

global char_embedding_model
global html_embedding_model
global content_embedding_model

def testClassifier():

    logging.info('Loading Embeddings')
    initGlobals()

    logging.info('Loading Model')
    model = getModel()
    model.load_weights('identification_classifier.hdf5')

    logging.info('Sending Requests')
    X,y, samples = getSamples()

    preds = model.predict(X)

    runStats(preds,y, samples)

def testModelOnData(test_community, data):
    logging.info('Loading Model')
    model = getModel()
    fname = 'identification_classifier_test_'+test_community+'.hdf5'

    logging.info('predictions using model - %s' % fname)

    model.load_weights(fname)

    preds = model.predict(data)

    return preds

def initGlobals():
    global char_embedding_model
    global html_embedding_model
    global content_embedding_model

    char_embedding_model = CollectIdentificationFeatures.getCharEmbedding()
    html_embedding_model = CollectIdentificationFeatures.getPageEmbedding()
    content_embedding_model = CollectIdentificationFeatures.getWord2VecEmbedding()

def runStats(preds,y, samples):

    for index in range(len(samples)):
        print samples[index]
        print preds[index]
        print y[index]
        print

    print '-----------------------------'
    print 'Binary CrossEntropy:',log_loss(y, preds)
    print 'Mean Squared Error:',mean_squared_error(y, preds)
    print 'ROC AUC score:',roc_auc_score(y, preds)


def getSamples():
    samples = []
    X = []
    y = []
    for page_url in pos_page_urls:

        html = fetchHTML(page_url)

        features = getFeatures(page_url, html)

        if features:
            features = scaleFeatures(features)
            X.append(features)
            y.append(1)
            samples.append(page_url)
        else:
            # print html
            print 'Invalid page:',page_url

            # raise ValueError('stop')

    for page_url in neg_page_urls:
        html = fetchHTML(page_url)

        features = getFeatures(page_url, html)

        if features:
            features = scaleFeatures(features)
            X.append(features)
            y.append(0)
            samples.append(page_url)
        else:
            # print html
            print 'Invalid page:',page_url

            # raise ValueError('stop')

    X = np.array(X)
    X = X.reshape(X.shape[0], 1, X.shape[1])
    return X,y, samples

def fetchHTML(url):
    try:
        html = requests.get(url).text
    except Exception as e:
        print 'error',e
        return None
    return html

def invalidSample(sample):
    fields = ['html_embedding', 'url_embedding', 'content_embedding', 'manual']
    for field in fields:
        if not field in sample:
            return True
    return False

def getFeatures(url, html):
    global char_embedding_model
    global html_embedding_model
    global content_embedding_model

    url_embedding = CollectIdentificationFeatures.extractURLFeaturesEmbedding(char_embedding_model, url)
    html_embedding = CollectIdentificationFeatures.extractHTMLFeaturesEmbedding(html_embedding_model, html)
    content_embedding = CollectIdentificationFeatures.extractContentFeaturesEmbedding(content_embedding_model, html)

    if not url_embedding:
        return None
    if not html_embedding:
        return None
    if not content_embedding:
        return None

    manual_features = CollectIdentificationFeatures.extractFeaturesManual(url, html)

    features = []

    if useCharEmb:
        features += list(pickle.loads(url_embedding))
    if useHTMLEmb:
        features += list(pickle.loads(html_embedding))
    if useContentEmb:
        features += list(pickle.loads(content_embedding))
    if useManual:
        features += manual_features

    if np.isnan(np.sum(features)):
        return None

    return features

def getRandomBatch():
    val_batch_size = 500
    return Data_Collection.aggregate([{"$sample": {'size': val_batch_size}}])


pos_page_urls = [

    # UMASS
    'https://www.umass.edu/events/talk-neoliberalism-and-its',
    'https://www.umass.edu/events/fulbright-us-student-program-0',
    'https://www.umass.edu/events/bridge2impacts-luncheon',
    'https://www.umass.edu/events/talk-intimate-partner-violence',
    'https://www.umass.edu/events/softball-vs-rhode-island-0',
    'https://www.umass.edu/events/lecture-keeping-it-real-eureka',
    'https://www.umass.edu/events/lecture-tropical-cyclone',
    'https://www.umass.edu/events/talk-original-sin-europe%E2%80%99s',
    'https://www.umass.edu/events/talk-bellevue-three-centuries',
    'https://www.umass.edu/events/19th-annual-animation-show',
    'https://www.umass.edu/events/exhibition-5-takes-african',

    # UNC
    'https://www.unc.edu/event/2018-carolina-global-photography-exhibition/',
    'https://www.unc.edu/event/aswarm-spirits-ages-inconceivable-spaces-slavery-freedom/',
    'https://www.unc.edu/event/joy-going-bayard-wootten-photographs-north-carolina-south/',
    'https://www.unc.edu/event/truth-eight-point-type-daily-tar-heel-celebrates-125-years-editorial-freedom/',
    'https://www.unc.edu/event/black-communities-conference-collaboration/',
    'https://www.unc.edu/event/studio-art-class-2018-senior-show-cl-us-ter/',
    'https://www.unc.edu/event/carolina-public-humanities-great-books-reading-group-2/2018-04-24/',
    'https://www.unc.edu/event/unc-chapel-hill-visitors-center-sense-place-tour/2018-04-24/',
    'https://www.unc.edu/event/chocolate-cities-black-map-american-life/',
    'https://www.unc.edu/event/unc-chapel-hill-visitors-center-sense-place-tour/2018-04-25/',
    'https://www.unc.edu/event/eoc-lunch-learn-training-self-identification-need-know/',

    # GWU
    'http://browse.calendar.gwu.edu/EventList.aspx?fromdate=4/11/2018&todate=5/10/2018&display=&type=public&eventidn=16057&view=EventDetails&information_id=30382',
    'http://browse.calendar.gwu.edu/EventList.aspx?fromdate=4/1/2018&todate=4/30/2018&display=Month&type=public&eventidn=16015&view=EventDetails&information_id=30297',
    'http://browse.calendar.gwu.edu/EventList.aspx?fromdate=4/1/2018&todate=4/30/2018&display=Month&type=public&eventidn=15624&view=EventDetails&information_id=29471',
    'http://browse.calendar.gwu.edu/EventList.aspx?fromdate=4/1/2018&todate=4/30/2018&display=Month&type=public&eventidn=4487&view=EventDetails&information_id=8659',
    'http://browse.calendar.gwu.edu/EventList.aspx?fromdate=4/1/2018&todate=4/30/2018&display=Month&type=public&eventidn=16037&view=EventDetails&information_id=30341',
    'http://browse.calendar.gwu.edu/EventList.aspx?fromdate=4/1/2018&todate=4/30/2018&display=Month&type=public&eventidn=16043&view=EventDetails&information_id=30353',
    'http://browse.calendar.gwu.edu/EventList.aspx?fromdate=4/1/2018&todate=4/30/2018&display=Month&type=public&eventidn=16060&view=EventDetails&information_id=30388',
    'http://browse.calendar.gwu.edu/EventList.aspx?fromdate=4/1/2018&todate=4/30/2018&display=Month&type=public&eventidn=16089&view=EventDetails&information_id=30446',
    'http://browse.calendar.gwu.edu/EventList.aspx?fromdate=4/1/2018&todate=4/30/2018&display=Month&type=public&eventidn=15970&view=EventDetails&information_id=30207',
    'http://browse.calendar.gwu.edu/EventList.aspx?fromdate=4/1/2018&todate=4/30/2018&display=Month&type=public&eventidn=16005&view=EventDetails&information_id=30277',
    'http://browse.calendar.gwu.edu/EventList.aspx?fromdate=4/24/2018&todate=5/23/2018&display=&type=public&eventidn=16010&view=EventDetails&information_id=30287'

    # UMD
    'http://calendar.umd.edu/cal/event/eventView.do?b=de&calPath=%2Fpublic%2Fcals%2FMainCal&guid=CAL-ff808081-62be06f0-0162-c12194af-00005ddfdemobedework@mysite.edu&recurrenceId=',
    'http://calendar.umd.edu/cal/event/eventView.do?b=de&calPath=%2Fpublic%2Fcals%2FMainCal&guid=CAL-ff808081-62b8a95a-0162-bb360b30-00004415demobedework@mysite.edu&recurrenceId=',
    'http://calendar.umd.edu/cal/event/eventView.do?b=de&calPath=%2Fpublic%2Fcals%2FMainCal&guid=CAL-ff808081-62d379b4-0162-d4397a58-00001938demobedework@mysite.edu&recurrenceId=',
    'http://calendar.umd.edu/cal/event/eventView.do?b=de&calPath=%2Fpublic%2Fcals%2FMainCal&guid=CAL-ff808081-614b7370-0161-4d8f0c26-00001004demobedework@mysite.edu&recurrenceId=',
    'http://calendar.umd.edu/cal/event/eventView.do?b=de&calPath=%2Fpublic%2Fcals%2FMainCal&guid=CAL-ff808081-62e1dcb3-0162-e4c96cc8-00003efcdemobedework@mysite.edu&recurrenceId=',
    'http://calendar.umd.edu/cal/event/eventView.do?b=de&calPath=%2Fpublic%2Fcals%2FMainCal&guid=CAL-ff808081-61d15a40-0161-d3d8386d-000042d3demobedework@mysite.edu&recurrenceId=',
    'http://calendar.umd.edu/cal/event/eventView.do?b=de&calPath=%2Fpublic%2Fcals%2FMainCal&guid=CAL-ff808081-62cd7a84-0162-cf39f840-00007bb5demobedework@mysite.edu&recurrenceId=',
    'http://calendar.umd.edu/cal/event/eventView.do?b=de&calPath=%2Fpublic%2Fcals%2FMainCal&guid=CAL-ff808081-62f6acd8-0162-f8afa195-0000171edemobedework@mysite.edu&recurrenceId=',
    'http://calendar.umd.edu/cal/event/eventView.do?b=de&calPath=%2Fpublic%2Fcals%2FMainCal&guid=CAL-ff808081-628fae29-0162-92cc0c3d-00000ebedemobedework@mysite.edu&recurrenceId=',
    'http://calendar.umd.edu/cal/event/eventView.do?b=de&calPath=%2Fpublic%2Fcals%2FMainCal&guid=CAL-ff808081-6294d3fc-0162-97616b3e-00005029demobedework@mysite.edu&recurrenceId=',
    'http://calendar.umd.edu/cal/event/eventView.do?b=de&calPath=%2Fpublic%2Fcals%2FMainCal&guid=CAL-ff808081-62b8a95a-0162-ba68f41a-00002365demobedework@mysite.edu&recurrenceId='

    # USC
    'http://calendar.usc.edu/event/chamber_music_festival_vocal_arts_4975',
    'http://calendar.usc.edu/event/senior_scendoff_2018',
    'http://calendar.usc.edu/event/congregations_ending_homelessness_in_la',
    'http://calendar.usc.edu/event/womens_rowing_vs_ucla_692',
    'http://calendar.usc.edu/event/usc_alumni_awards',
    'http://calendar.usc.edu/event/38th_annual_chicanxlatinx_graduate_celebration',
    'http://calendar.usc.edu/event/grand_opening_of_the_archive_at_the_center_for_occupation_and_lifestyle_redesign',
    'http://calendar.usc.edu/event/pop-up_dream_center',
    'http://calendar.usc.edu/event/student_geometry_topology_seminar_28',
    'http://calendar.usc.edu/event/usc_stem_cell_seminar_janet_rossant_university_of_torontoduke_university',
    'http://calendar.usc.edu/event/lute_masterclass_with_paul_odette'

    # BC
    'http://events.bc.edu/event/group_formation_100_years_of_student_clubs_and_societies_at_boston_college',
    'http://events.bc.edu/event/cao_jun_hymns_to_nature_exhibition',
    'http://events.bc.edu/event/applied_microeconomics_seminar_3187',
    'http://events.bc.edu/event/jesuit_panel',
    'http://events.bc.edu/event/thea_bowman_ahana_and_intercultural_center_after_hours',
    'http://events.bc.edu/event/the_dead_sea_scrolls_after_70_years_what_have_we_learned',
    'http://events.bc.edu/event/candlelight_mass',
    'http://events.bc.edu/event/lunch_and_learn_diversity_series',
    'http://events.bc.edu/event/microeconomics_seminar_6057',
    'http://events.bc.edu/event/boston_college_zen_meditation_group_6444',
    'http://events.bc.edu/event/stop_making_sense'

    # Columbia
    'https://events.columbia.edu/cal/event/eventView.do?b=de&calPath=%2Fpublic%2Fcals%2FMainCal&guid=CAL-00bbdcc6-628a89b3-0162-8ce0c27c-00001ef0events@columbia.edu&recurrenceId=',
    'https://events.columbia.edu/cal/event/eventView.do?b=de&calPath=%2Fpublic%2Fcals%2FMainCal&guid=CAL-00bbdc41-62a97893-0162-ab57bf10-00001be8events@columbia.edu&recurrenceId=',
    'https://events.columbia.edu/cal/event/eventView.do?b=de&calPath=%2Fpublic%2Fcals%2FMainCal&guid=CAL-00bbdcc6-62856361-0162-86d9284d-00001005events@columbia.edu&recurrenceId=',
    'https://events.columbia.edu/cal/event/eventView.do?b=de&calPath=%2Fpublic%2Fcals%2FMainCal&guid=CAL-00bbdcc7-62d7ce61-0162-d9559a26-00000c20events@columbia.edu&recurrenceId=',
    'https://events.columbia.edu/cal/event/eventView.do?b=de&calPath=%2Fpublic%2Fcals%2FMainCal&guid=CAL-00bbdc41-61fa97c6-0161-fd513fa2-000021d0events@columbia.edu&recurrenceId=',
    'https://events.columbia.edu/cal/event/eventView.do?b=de&calPath=%2Fpublic%2Fcals%2FMainCal&guid=CAL-00bbdcc7-61e0d337-0161-e2f47264-0000197eevents@columbia.edu&recurrenceId=',
    'https://events.columbia.edu/cal/event/eventView.do?b=de&calPath=%2Fpublic%2Fcals%2FMainCal&guid=CAL-00bbdcc6-628a89b3-0162-8cc08f34-000018f2events@columbia.edu&recurrenceId=',
    'https://events.columbia.edu/cal/event/eventView.do?b=de&calPath=%2Fpublic%2Fcals%2FMainCal&guid=CAL-00bbdcc6-62e215cc-0162-e3a734bd-00000f71events@columbia.edu&recurrenceId=',
    'https://events.columbia.edu/cal/event/eventView.do?b=de&calPath=%2Fpublic%2Fcals%2FMainCal&guid=CAL-00bbdcc6-62b8e3d5-0162-bb916bee-00001f8cevents@columbia.edu&recurrenceId=',
    'https://events.columbia.edu/cal/event/eventView.do?b=de&calPath=%2Fpublic%2Fcals%2FMainCal&guid=CAL-00bbdcc7-620a0593-0162-0c3e931b-00001574events@columbia.edu&recurrenceId=',
    'https://events.columbia.edu/cal/event/eventView.do?b=de&calPath=%2Fpublic%2Fcals%2FMainCal&guid=CAL-00bbdcc6-614b7691-0161-4cf33f68-0000136devents@columbia.edu&recurrenceId='

    # Oregon State
    'https://events.oregonstate.edu/event/spring_career_expo',
    'https://events.oregonstate.edu/event/statistics_consulting_appointments',
    'https://events.oregonstate.edu/event/health_professions_fair',
    'https://events.oregonstate.edu/event/library_research_consulting_drop-ins',
    'https://events.oregonstate.edu/event/spring_speed_mock_interviews',
    'https://events.oregonstate.edu/event/life_after_graduation_do_you_have_an_immigration_plan',
    'https://events.oregonstate.edu/event/asosu_senate_meeting_public',
    'https://events.oregonstate.edu/event/danny_way_wse_seminar',
    'https://events.oregonstate.edu/event/spring_career_expo',
    'https://events.oregonstate.edu/event/bedrock_lectures_josh_fox',
    'https://events.oregonstate.edu/event/visa_permanent_residence_options_for_international_academicsscholars'

    # UC Boulder
    'https://calendar.colorado.edu/event/a_century_of_views_of_colorado_1820-1920_8796?utm_campaign=widget&utm_medium=widget&utm_source=University+of+Colorado+Boulder',
    'https://calendar.colorado.edu/event/act_on_it_exhibit_on_cu_student_activism?utm_campaign=widget&utm_medium=widget&utm_source=University+of+Colorado+Boulder',
    'https://calendar.colorado.edu/event/archive_notes_from_the_field?utm_campaign=widget&utm_medium=widget&utm_source=University+of+Colorado+Boulder',
    'https://calendar.colorado.edu/event/preservation_week?utm_campaign=widget&utm_medium=widget&utm_source=University+of+Colorado+Boulder',
    'https://calendar.colorado.edu/event/preservation_week_display?utm_campaign=widget&utm_medium=widget&utm_source=University+of+Colorado+Boulder',
    'https://calendar.colorado.edu/event/planning_for_finals?utm_campaign=widget&utm_medium=widget&utm_source=University+of+Colorado+Boulder',
    'https://calendar.colorado.edu/event/millie_chen_four_recollections?utm_campaign=widget&utm_medium=widget&utm_source=University+of+Colorado+Boulder',
    'https://calendar.colorado.edu/event/the_transfer_scoop_ice_cream_topics_toppings?utm_campaign=widget&utm_medium=widget&utm_source=University+of+Colorado+Boulder',
    'https://calendar.colorado.edu/event/nordic_faculty_talk_environmental_place-knowledge_in_pre-christian_iceland_with_dr_mathias_nordvig?utm_campaign=widget&utm_medium=widget&utm_source=University+of+Colorado+Boulder',
    'https://calendar.colorado.edu/event/lily_hoang_reading_creative_writing_reading_series?utm_campaign=widget&utm_medium=widget&utm_source=University+of+Colorado+Boulder',
    'https://calendar.colorado.edu/event/creation_validation_and_departmental_approval_of_april_jes_and_pets_for_fund_3031_projects_and_fund_34_gift_fund_journals_due?utm_campaign=widget&utm_medium=widget&utm_source=University+of+Colorado+Boulder'

    # Texas A&M
    'http://calendar.tamu.edu/live/events/38994-department-appreciation-day---saw2018',
    'http://calendar.tamu.edu/live/events/38869-denim-day',
    'http://calendar.tamu.edu/live/events/38870-stand-up-workshop',
    'http://calendar.tamu.edu/live/events/25815-jeanne-robertson',
    'http://calendar.tamu.edu/live/events/37441-distinguished-achievement-awards-ceremony',
    'http://calendar.tamu.edu/live/events/38996-maroon-white-walk-and-fitness-friday-at-the',
    'http://calendar.tamu.edu/live/events/38871-pie-an-aggie',
    'http://calendar.tamu.edu/#!view/event/event_id/38886',
    'http://calendar.tamu.edu/live/events/38872-purple-dash',
    'http://calendar.tamu.edu/live/events/39493-viz-a-gogo-25',
    'http://calendar.tamu.edu/live/events/25442-hazlewood-deadline-for-spring-2018'


]

neg_page_urls = [

    # UMASS
    'https://www.umass.edu/',
    'https://www.umass.edu/giving/foundation',
    'https://www.umass.edu/events/',
    'https://www.isenberg.umass.edu/',
    'http://www.umass.edu/gateway/academics',
    'https://www.umass.edu/chancellor/',
    'https://www.umass.edu/chancellor/campus-leaders',
    'https://www.umass.edu/art/'
    'http://www.umass.edu/gateway/audience/current-students'
    'https://www.umass.edu/art/people/listings/faculty',
    'https://www.umass.edu/researchnext/'

    # UNC
    'https://www.unc.edu/',
    'https://www.unc.edu/schools/'
    'https://www.unc.edu/discover/',
    'https://www.unc.edu/discover/saving-an-endangered-language/',
    'https://www.unc.edu/about/support-the-university/',
    'https://www.unc.edu/school/nursing/',
    'https://www.unc.edu/diversity/',
    'https://asianstudies.unc.edu/arabic/',
    'https://asianstudies.unc.edu/arabic/arabic-faculty/',
    'https://asianstudies.unc.edu/chinese/chinese-language-courses/',
    'http://library.unc.edu/',

    # GWU
    'https://www.gwu.edu/',
    'https://gwtoday.gwu.edu/stormy-daniels%E2%80%99-lawyer-%E2%80%98i%E2%80%99ve-never-quite-had-case-%E2%80%99?utm_source=GW%20Today%20Section&utm_medium=GWToday_MainStory%202&utm_campaign=gwhomepage-gwtoday',
    'https://summer.gwu.edu/8-reasons-take-courses-summer?utm_source=community_stories&utm_medium=2nd_row_left&utm_campaign=gwhomepage-flex-space&utm_content=summer-programs',
    'http://www.programs.gwu.edu/undergraduate',
    'http://www.programs.gwu.edu/undergraduate/civil-engineering',
    'https://www.cee.seas.gwu.edu/',
    'https://www.cee.seas.gwu.edu/program-objectives-and-student-outcomes',
    'https://www.gwu.edu/athletics-recreation',
    'https://campusrecreation.gwu.edu/',
    'https://nondegree.gwu.edu/',
    'https://nondegree.gwu.edu/general-study-applicants'

    # UMD
    'https://www.umd.edu/'
    'https://www.provost.umd.edu/calendar/',
    'https://www.umd.edu/directories',
    'https://www.counseling.umd.edu/',
    'https://www.umd.edu/colleges-and-schools',
    'http://www.arhu.umd.edu/',
    'https://www.scholars.umd.edu/',
    'http://www.arch.umd.edu/',
    'http://www.arch.umd.edu/urban-studies-and-planning',
    'http://www.arch.umd.edu/phd-home'
    'http://thestamp.umd.edu/memorial_chapel'

    # USC
    'https://www.usc.edu/',
    'https://about.usc.edu/',
    'https://about.usc.edu/administration/',
    'http://admit.usc.edu/',
    'https://academics.usc.edu/',
    'https://research.usc.edu/',
    'https://about.usc.edu/patient-care/',
    'https://communities.usc.edu/',
    'https://arts.usc.edu/',
    'https://global.usc.edu/',
    'https://news.usc.edu/141181/growing-up-at-usc-village-can-be-fun-for-a-kid/',

    # BC
    'http://www.bc.edu/',
    'http://www.bc.edu/bc-web/about.html',
    'http://www.bc.edu/bc-web/admission.html',
    'http://www.bc.edu/bc-web/academics.html',
    'http://www.bc.edu/bc-web/campus-life.html',
    'http://www.bc.edu/bc-web/research.html',
    'http://www.bc.edu/bc-web/bcnews/humanities/literature/donal-ryan-literary-archives.html',
    'http://events.bc.edu/',
    'http://www.bc.edu/offices/stserv/academic/current/calendar.html',
    'http://www.bc.edu/sites/accessibility.html',
    'http://www.bc.edu/bc-web/academics/majors-minors.html'

    # Columbia
    'https://www.columbia.edu/',
    'https://www.columbia.edu/content/admissions',
    'https://www.columbia.edu/content/academics/departments',
    'https://courseworks.columbia.edu/',
    'http://registrar.columbia.edu/',
    'http://library.columbia.edu/',
    'https://universitylife.columbia.edu/',
    'https://sipa.columbia.edu/',
    'https://www.columbia.edu/content/research',
    'https://www.arch.columbia.edu/',
    'http://science.fas.columbia.edu/neuroscience/'

    # University of Portland
    'https://www.up.edu/',
    'https://www.up.edu/academics/majors-and-minors.html',
    'https://library.up.edu/index.html',
    'http://www.up.edu/provost/index.html',
    'https://www.up.edu/residencelife/residence-halls/index.html',
    'https://www.up.edu/residencelife/housing-and-dining/index.html',
    'https://www.up.edu/residencelife/faqs/index.html',
    'http://uportland.bncollege.com/',
    'http://www.up.edu/directory',
    'https://www.up.edu/news/index.html',
    'https://calendar.up.edu/MasterCalendar/MasterCalendar.aspx?data=f1bM4GJyEC6LkXntxE0K61Wh7jYl%2f3zcPAwpqk646GNtsHgGnRZdDbDy4bsL02O8wUOQUPx%2fC6eTh9t3cUdoCg%3d%3d'

    # Oregon State
    'https://oregonstate.edu/',
    'https://oregonstate.edu/future',
    'http://today.oregonstate.edu/news/researchers-use-%E2%80%9Cenvironmental-dna%E2%80%9D-identify-killer-whales-puget-sound',
    'http://families.oregonstate.edu/',
    'https://oregonstate.edu/osuresearch',
    'http://agsci.oregonstate.edu/',
    'http://liberalarts.oregonstate.edu/',
    'http://vetmed.oregonstate.edu/',
    'http://honors.oregonstate.edu/',
    'http://gradschool.oregonstate.edu/',
    'http://oregonstate.edu/terra/category/healthies/healthy-planet/'

    # Colorado Boulder
    'https://www.colorado.edu/',
    'https://www.colorado.edu/about',
    'https://www.colorado.edu/research',
    'https://www.colorado.edu/2018/04/23/novel-antioxidant-makes-old-blood-vessels-seem-young-again',
    'http://www.colorado.edu/events',
    'http://www.colorado.edu/parents',
    'https://www.colorado.edu/admissions',
    'https://www.colorado.edu/academics/cu-boulder-difference',
    'https://www.colorado.edu/academics/academic-resources',
    'https://www.colorado.edu/academics/first-year-seminar',
    'https://www.colorado.edu/academics/programs/asian-languages-and-civilizations'

]




import { Component, ViewChild } from '@angular/core';
import { NavController, Events, IonicPage, NavParams, ModalController, ViewController, Content, PopoverController } from 'ionic-angular';
import { GroupsService } from '../../../../providers/groups.service';
import { PeopleService } from '../../../../providers/people.service';
import { Agnes } from '../../../../app/app.component';

@IonicPage()
@Component({
    selector: 'group-feed',
    templateUrl: 'group-feed.html',
    providers: [GroupsService, PeopleService]
})
export class GroupFeedPage {
    user: Object;
    group: Object;
    isFollowing: boolean;
    isAdmin: boolean;
    isMember: boolean;
    newsFeed: Array<Object>;

    newsFeedInput: string;
    today: string;
    yesterday: string;
    tomorrow: string;
    canLoadMore: boolean;
    index: number;
    canScroll: boolean;

    openedUsers: Array<Object>;
    canOpenProfile = true; //for ensuring that people can't double click on user thumbnails

    @ViewChild('feedContent') feedContent: Content;

    constructor(public navCtrl: NavController,
                private viewCtrl: ViewController,
                private events: Events,
                private navParams: NavParams,
                private modalCtrl: ModalController,
                private popoverCtrl: PopoverController,
                private peopleService: PeopleService,
                private groupsService: GroupsService) {
    }

    ngOnInit(){
        this.initGroupFeed(null);
        this.isAdmin = this.group['admin'].indexOf(this.user['_id']) != -1;
        this.group['displayURL'] = (this.group['displayURL'] == '')
            ? "assets/img/pattern_" + Math.floor((Math.random() * 15) + 1) + '.png' : this.group['picurl'];

        this.canScroll = true;
        this.openedUsers = [];

        //user's request to join this group has been accepted, reflect new member status
        this.events.subscribe('reqAcceptedNewMember', (groupsID) => {
            if(this.group['_id'] == groupsID){
                if(this.group['members'].indexOf(this.user['_id']) == -1){this.group['members'].push(this.user['_id']);}
                this.isAdmin = false;
                this.isMember = true;
            }
        });
    }

    initGroupFeed(refresher){

        this.user = JSON.parse(localStorage.getItem('agnesUser'));
        this.group = this.navParams.data.group;

        this.isMember = this.group['members'].indexOf(this.user['_id']) != -1;
        this.isAdmin = this.group['admin'].indexOf(this.user['_id']) != -1;
        this.newsFeedInput = '';

        this.newsFeed = [];

        let t = new Date();
        this.today = t.toDateString().match(/[a-zA-Z]{3} [a-zA-Z]{3} \d\d/)[0];
        this.today = this.today.replace(/([a-zA-Z]{3})(\s[a-zA-Z]{3}\s)(\d{2})/, "$1.$2$3");
        t.setDate(t.getDate() - 1);
        this.yesterday = t.toDateString().match(/[a-zA-Z]{3} [a-zA-Z]{3} \d\d/)[0];
        this.yesterday = this.yesterday.replace(/([a-zA-Z]{3})(\s[a-zA-Z]{3}\s)(\d{2})/, "$1.$2$3");
        t.setDate(t.getDate() + 2);
        this.tomorrow = t.toDateString().match(/[a-zA-Z]{3} [a-zA-Z]{3} \d\d/)[0];
        this.tomorrow = this.today.replace(/([a-zA-Z]{3})(\s[a-zA-Z]{3}\s)(\d{2})/, "$1.$2$3");

        //group has been edited
        this.events.subscribe('groupEdited', group => {
            this.group = group;
            this.isMember = this.group['members'].indexOf(this.user['_id']) != -1;
            this.isAdmin = this.group['admin'].indexOf(this.user['_id']) != -1;
            this.newsFeedInput = '';
        });

        this.index = 0;
        this.processAnnouncements(this.index, null, refresher);
        this.canLoadMore = true;
    }

    //get news feed items
    processAnnouncements(ind,infiniteScroll, refresher?) {

      if(refresher) {
        this.newsFeed = []
      }
        let data = {
            groups_id: this.group['_id'],
            index: ind
        };

        this.groupsService.getNewsFeed(data).then(val => {
            if(val && val.length > 0){
                this.index += val.length;

                //max number of news feed items returned is 25, if less, no more news feed items after this return
                if(val.length < 25) {
                    this.canLoadMore = false;
                }

                if(!(this.isMember || this.isAdmin)){

                    val = val.filter(a => a['privacy'] == 'public');

                    if(val.length == 0){
                        this.canLoadMore = false;
                    }
                }

                val.sort(function(a,b){
                    let aDate = +new Date(a['timestamp']);
                    let bDate = +new Date(b['timestamp']);
                    return bDate - aDate;
                });

                for(let a in val) {
                    //process timestamp
                    val[a]['timestamp'] = val[a]['timestamp'].replace(/[-\+]\d\d\d\d/,'Z');
                    let start = Agnes.processGMT(val[a]['timestamp']);
                    let date = (start.date == this.today) ? '' : (start.date == this.yesterday) ? 'Yesterday ' : start.date + ' ';
                    let time = (start.time == "12:01AM") ? "All Day" : start.time;
                    val[a]['timestamp'] = date + time;
                    //TODO: process event object
                    if(val[a]['type'] == 'event'){
                    }
                }

                //get user's name and thumbnails to display
                this.peopleService.getUsersForAvatars({'users': val.map(a => a['users_id'])}).then(users => {
                    let ind;
                    val = val.map(a => {
                        if (a['users_id']) {
                            ind = users.map(a => a['_id']).indexOf(a['users_id']);
                            if (ind != -1){
                                a['name'] = users[ind]['fname'] + ' ' + users[ind]['lname'].charAt(0);
                                a['picurl'] = users[ind]['thumbnail'];
                            }
                        }
                        a['name'] = a['name'] ? a['name'] : ' ';
                        return a;
                    }).reverse();

                    this.newsFeed = this.newsFeed.concat(val);
                }).catch(err => {
                    this.newsFeed = this.newsFeed.concat(val);;
                })

            }
            else {
                this.canLoadMore = false;
            }

            if(infiniteScroll){infiniteScroll.complete();}
            if(refresher){refresher.complete();}


        }).catch(err => {
            Agnes.showError('Could not load this group\'s newsfeed - try again later!');
            console.log('newsfeed err', err);

            if(infiniteScroll){infiniteScroll.complete();}
            if(refresher){refresher.complete();}
        });
    }

    //load more of the news feed
    loadMoreFeed(infiniteScroll){
        this.processAnnouncements(this.index, infiniteScroll);
    }


    updateNewsFeed(newItem) {
        for (let i = 0; i < this.newsFeed.length; i++) {
            if (this.newsFeed[i]['_id'] == newItem['_id']) {
                this.newsFeed[i] = newItem
                this.group['newsfeed'] = this.newsFeed
                // Send the updates to my groups
                this.events.publish('groupProfileData',{category:'edit',group:this.group})
            }
        }
    }

    closeGroupFeed() {
        //if this is a notification, send notification closed event so notifications can be opened again
        this.events.publish('notificationClosed');

        this.viewCtrl.dismiss(null, '', {
            animation: 'ios-transition',
            duration: 350,
            easing: "ease-in-out",
            direction: "back"
        });
    }

    // Edit an existing announcement
    editAnnouncement(item){
        let prevAnnouncement = item
        let id = prevAnnouncement['_id']
        this.newsFeedInput = prevAnnouncement['announcement']
        let inp = this.newsFeedInput;
        let agnesInput = this.modalCtrl.create('AgnesInput',
            {
                inp: inp,
                header: 'Edit your announcement',
                limit: 300,
                placeholder: "Edit your announcement",
                type: 'feed'
            });

        agnesInput.onDidDismiss((announcement) => {
            Agnes.removeFilter();
            if(announcement) {
                let nDate = new Date().toISOString();
                let data = {
                    'newAnnouncement': announcement['agnesInput'],
                    'groups_id': this.group['_id'],
                    'timestamp': nDate,
                    'id':id,
                    'privacy':announcement['privacy'],
                    'sendNotification': announcement['sendNotification'],
                    'users_id': this.user['_id']
                };
                this.groupsService.editAnnouncement(data).then(val => {

                    // let nDate = new Date().toISOString();
                    nDate = nDate.replace(/[-\+]\d\d\d\d/,'Z');
                    let start = Agnes.processGMT(nDate);
                    let date = (start.date == this.today) ? '' : (start.date == this.yesterday) ? 'Yesterday ' : start.date + ' ';
                    let time = (start.time == "12:01AM") ? "All Day" : start.time;
                    date = date + time;

                    let newItem = {
                        announcement: announcement['agnesInput'].trim(),
                        privacy: announcement['privacy'],
                        type: 'text',
                        timestamp: date,
                        _id: id
                    };

                    // reflect changes in DOM
                    this.updateNewsFeed(newItem)


                }).catch(err => {
                    Agnes.showError('Sorry, couldn\'t update your group status right now - try again later!');
                    console.log(err);
                });
            }
        });
        agnesInput.present();
      }

    // open agnes input to add announcement
    openUpdateBox(){
        let inp = this.newsFeedInput;
        let agnesInput = this.modalCtrl.create('AgnesInput',
            {
                inp: inp,
                header: '',
                limit: 300,
                placeholder: "",
                type: 'feed',
                height: 'bottom',
            });

        agnesInput.onDidDismiss((announcement) => {
            Agnes.removeFilter();
            if(announcement) {
                let data = {
                    'announcement': announcement['agnesInput'].trim(),
                    'groups_id': this.group['_id'],
                    'privacy': announcement['privacy'],
                    'sendNotification': announcement['sendNotification'],
                    'users_id': this.user['_id']
                };
                this.groupsService.addAnnouncement(data).then(val => {

                    let nDate = new Date().toISOString();
                    nDate = nDate.replace(/[-\+]\d\d\d\d/,'Z');
                    let start = Agnes.processGMT(nDate);
                    let date = (start.date == this.today) ? '' : (start.date == this.yesterday) ? 'Yesterday ' : start.date + ' ';
                    let time = (start.time == "12:01AM") ? "All Day" : start.time;
                    date = date + time;

                    let newItem = {
                        announcement: announcement['agnesInput'].trim(),
                        privacy: announcement['privacy'],
                        type: 'text',
                        timestamp: date,
                        name: this.user['fname'] + ' ' + this.user['lname'].charAt(0),
                        picurl: this.user['thumbnail'],
                        users_id: this.user['_id']
                    };

                    this.newsFeed.push(newItem);
                    this.canScroll = true;

                }).catch(err => {
                    Agnes.showError('Sorry, couldn\'t update your group status right now - try again later!');
                    console.log(err);
                });
            }
        });
        for (let e = 0; e < document.getElementsByTagName("ion-popover").length; e++){
            document.getElementsByTagName("ion-popover")[e]["style"]["filter"]="blur(3vw)";
        }
        document.getElementsByTagName("ng-component")[0]["style"]["filter"]="blur(3vw)";
        agnesInput.present();
    }

    refreshFeed(refresher) {
      if(!Agnes.network || Agnes.network.type != 'none'){
        this.events.publish('updateUser');
        this.events.subscribe('updateDone',() => {
          this.events.unsubscribe('updateDone');
          this.user = JSON.parse(localStorage.getItem('agnesUser'));
          this.initGroupFeed(refresher);
        });
      }

      else {
        //lack of internet connection - alert
        Agnes.showError('You are offline! Try refreshing again when you reconnect.');
        refresher.complete();
      }
    }

    scrollChat(){
        if(this.feedContent){
            this.feedContent.resize();
            this.feedContent.scrollToBottom();
            this.canScroll = false;
        }
    }

    //open person's profile when you click on their thumbnail
    openPeopleProfile(personID){
        if(this.canOpenProfile){
            this.canOpenProfile = false;

            let ind = this.openedUsers.map(a => a['_id']).indexOf(personID);
            let personProm = ind == -1 ? this.peopleService.getUsersFromIds({'users': [personID]}) : null;

            Promise.all([personProm]).then(val => {
                let p;

                if(val && val[0] && val[0][0]){
                    p = val[0][0];
                    this.openedUsers.push(p);
                }
                else {
                    if(ind != -1){
                        p = this.openedUsers[ind];
                    }
                    else {
                        Agnes.showError('Couldn\'t open this person\'s profile - try again!');
                    }
                }

                if(p){
                    let profile = this.popoverCtrl.create('PeopleProfile',{
                        person: p,
                        isMe: p['_id'] == this.user['_id']
                    });

                    profile.present({
                        animation: 'ios-transition',
                        duration: 200
                    });

                    profile.onDidDismiss(() => {
                        this.canOpenProfile = true;
                    });
                }
                else {
                    this.canOpenProfile = true;
                }
            }).catch(err => {
                console.log('open thumbnail profile err', err);
                this.canOpenProfile = true;
                Agnes.showError('Couldn\'t open this person\'s profile - try again!');
            });
        }
    }
}

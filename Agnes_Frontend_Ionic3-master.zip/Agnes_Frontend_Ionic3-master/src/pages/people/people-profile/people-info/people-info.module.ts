import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';


import { PeopleInfo } from './people-info';
import { ComponentsModule } from '../../../../components/components.module';

@NgModule({
    declarations: [
        PeopleInfo
    ],
    imports: [
        IonicPageModule.forChild(PeopleInfo),
        ComponentsModule
    ],
    exports: [
        PeopleInfo
    ]
})

export class PeopleInfoModule { }

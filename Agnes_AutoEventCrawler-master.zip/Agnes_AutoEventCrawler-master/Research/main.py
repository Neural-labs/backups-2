import time
import logging
from Analysis import analysisAPI
from Collection import collectionAPI
from Learning import LearningAPI
from Preprocessing import preprocessingAPI
from Test import RunTests
from config import db_config
import sys
logging.basicConfig(stream=sys.stdout, level=logging.DEBUG)
# logging.basicConfig(filename='example.log',level=logging.DEBUG)

'''
General Functions:
1. Collection - Collect and store pages in mongo 
2. Preprocessing - Preprocess the data (cleaning, filtering, collecting samples, collecting features)
3. Analysis - Analyze the data (training, testing models)
4. Visualization - Gather/show results
5. Learning - Run Learning Functions
'''

def main(isScheduled):

    db_config.InitConfig('dev', True)
    if isScheduled:
        runScheduled()
        return

    print "AutoCrawler Started..."
    start = time.time()

    # runCollection()

    # runPreprocessing()

    runAnalysis()

    # runLearning()

    end = time.time()
    print 'AutoCrawler took',float(end-start)/60,'minutes.'

def runScheduled():
    collectionAPI.CollectHTML()

def runTests():
    RunTests.runInitialTestQuery()

def runCollection():
    api = collectionAPI
    # api.CollectPastEvents()
    # api.CollectCurrentEvents()
    api.CollectHTML()
    # api.CollectControlPages()
    # api.runGraphBuilder()
    # api.CollectCalendarsPositive()
    # api.CollectCalendarsNegative()
    # api.runCeleryCrawler()

def runPreprocessing():
    api = preprocessingAPI
    # api.shuffleEvents()
    # api.cleanDataWrapper()
    # api.removeDuplicates('url')
    api.examineAllData()
    # api.extractionExamination()
    # api.examineSinglePage()
    # api.runTreeCollection()
    # api.runExtractionSampleCollection()
    # api.runIdentificationSampleCollection()
    # api.trainEventEmbedding('h2v') # emb_type is in ['w2v','d2v','c2v','h2v']
    # api.trainPageEmbedding()
    # api.collect_unique_events()
    # api.parse_unique_events()

def runAnalysis():
    api = analysisAPI
    # api.CrawlGraph()
    # api.Analysis()
    # api.ExtractionClassification()
    api.train_id_classifier()
    # api.test_id_classifier()
    # api.train_ext_classifier(model_type='name') # model_type is in ['node','subtree', 'name', 'description', 'location', 'date']
    # api.test_ext_classifier()
    # api.test_clustering(detect=True) # if detect True, run detection classifier on clusters

def runLearning():
    api = LearningAPI
    # api.beautifulsoup()
    # api.IoLearning()
    # api.eventLearning()
    # api.RunKerasLearning()
    # api.RunKerasIMBD()
    # api.runWord2VecTrain()
    # api.runLocLearning()
    # api.runKazem()
    # api.runNetworkx()
    # api.runClassifierTraining(part='name')  # part is in ['name','description', 'location','date']
    api.runClassifierTesting()

if __name__ == "__main__":

    # print os.environ['HOME']
    if len(sys.argv) > 1:
        scheduled = True
    else:
        scheduled = False
    main(scheduled)
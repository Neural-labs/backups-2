from config import db_config

CONFIG = db_config.getConfig()
dbConn = CONFIG['dbConn']
Agnes = dbConn.Agnes
Domain_Pages = Agnes.autocrawler_domain_pages

def removeDuplicates(key):
    pipeline = [
        {"$sort": {"_id": 1}},
        {"$group": {
            "_id": "$url",
            "doc": {"$first": "$$ROOT"}
        }},
        {"$replaceRoot": {"newRoot": "$doc"}},
        {"$out": "autocrawler_domain_pages"}
    ]

    Domain_Pages.aggregate(pipeline,allowDiskUse=True)


    # data = getDocuments()
    # count = 0
    # uniqueKeys = set([])
    # for document in data:
    #     count += 1
    #     print count
    #     doc_key = document[key]
    #     if doc_key in uniqueKeys:
    #         removeFromMongo(key,doc_key)
    #     else:
    #         uniqueKeys.add(doc_key)

def getDocuments():
    return Domain_Pages.find({},no_cursor_timeout=True)

def removeFromMongo(key,value):
    Domain_Pages.delete_one({key:value})
import { Component , Input, Output, EventEmitter } from '@angular/core';
import { App, PopoverController, Events } from 'ionic-angular';
import { EventsService } from '../../providers/events.service';
import { GroupsService } from '../../providers/groups.service';

/**
 * item block component for all events/groups lists besides matched
 */
@Component({
    selector: 'agnes-item',
    templateUrl: 'agnes-item.html',
    providers: [EventsService, GroupsService]
})
export class AgnesItemComponent {

    @Input() object: Object;
    @Input() type: string;
    @Input() objTime: string;
    @Input() action: string;
    @Input() noTap: boolean;
    @Input() hasMajorString: boolean;
    @Input() actionType: string;

    @Output() itemEmitter: EventEmitter<any> = new EventEmitter();

    majorString: string;
    objName: string;
    about: string;
    isSelected: boolean;

    constructor(public appCtrl: App,
                private popoverCtrl: PopoverController,
                private events: Events,
                public eventsService: EventsService,
                public groupsService: GroupsService) {
    }

    ngOnInit(){
        this.objName = (this.type == 'group' ? this.object['grpname']
            : this.type == 'event' ? this.object['evtname'] : this.object['fname'] + ' ' + this.object['lname'].charAt(0));


        if(this.type == 'people' && this.hasMajorString){
            if(this.object['notReal']) {
                this.majorString = '';
            }
            else {
                this.majorString = this.object['studenttype'] == 'other' ? '' :
                    ((this.object['studenttype'] == 'phd' ? 'PhD' : this.object['studenttype'].charAt(0).toUpperCase()
                        + this.object['studenttype'].substring(1,this.object['studenttype'].length)) + ' ') +
                    (this.object['studenttype'] == 'alum' || this.object['studenttype'] == 'staff' || this.object['studenttype'] == 'other' ?
                        'studied ' : 'studying ')
                    + this.object['major'].toString().replace(/,/g,', ');
                let lc = this.majorString.lastIndexOf(',');
                this.majorString = (lc != -1) ? this.majorString.substring(0,lc) + ' and' + this.majorString.substring(lc + 1) : this.majorString;
            }
        }
        this.about = this.object['aboutme'] ? this.object['aboutme'] : '';
        if(this.about.length > 35) {
          this.about = this.about.substr(0, 35) + ' ...';
        }

        this.isSelected = false;

        this.object['thumbnail'] = this.object['thumbnail'] == ''
            ? this.object['picurl'] == '' ? 'assets/img/pattern_0.png' : this.object['picurl']
            : this.object['thumbnail'];

        //add admin badge if person has been promoted from group edit members view
        this.events.subscribe('promotedMembers', (data) => {
            let members = data.members;
            if(members.indexOf(this.object['_id']) != -1) {
                this.object['isAdmin'] = true;
                this.isSelected = false;
            }
        });
    }

    //default profile pic if user profile pic does not load
    imgError() {
        this.object['noPic'] = true;
    }

    itemTap(){
        if(!this.noTap){
            if(this.action == 'returnObject') {
                this.itemEmitter.next(this.object);
            }
            else if(this.action == 'openProfile') {
                if(this.type == 'group'){
                    //open group profile
                    let grpPromise;
                    if(!this.object['grpemail']) {
                        grpPromise = this.groupsService.getGroupsFromId({'grp':[this.object['_id']]});
                    }

                    Promise.all([grpPromise]).then(val => {

                        let canOpen = true;
                        if(grpPromise && val) {

                            if(val[0] && val[0][0]) {
                                this.object = val[0][0];
                            }
                            else {
                                canOpen = false;
                                this.itemEmitter.next("Sorry, could not open this group profile - try again!");
                            }
                        }

                        //open group profile
                        if(canOpen){
                            this.appCtrl.getRootNav().push(
                                'GroupProfile',
                                {
                                    'group':this.object,
                                    'type':'matched'
                                }, {
                                    animation: 'ios-transition',
                                    duration: 350
                                });
                        }
                    }).catch(err => {
                        console.log(err);
                        this.itemEmitter.next("Sorry, could not open this group profile - try again!");
                    });
                }
                else if (this.type == 'event') {

                    let evtPromise;
                    if(!this.object['picurl']) {
                        evtPromise = this.eventsService.getEventsFromId({
                            'evt':[this.object['_id']],
                            'community': JSON.parse(localStorage.getItem('agnesUser'))['community']
                        });
                    }

                    Promise.all([evtPromise]).then(val => {
                        let canOpen = true;
                        if(evtPromise && val) {

                            if(val[0] && val[0][0]) {
                                let pic = this.object['picurl'];
                                this.object = val[0][0];
                                this.object['picurl'] = pic;
                            }
                            else {
                                canOpen = false;
                                this.itemEmitter.next("Sorry, could not open this event profile - try again!");
                            }
                        }

                        //open event profile
                        if(canOpen){
                            this.appCtrl.getRootNavs()[0].push(
                                'EventProfile',
                                {
                                    'event': this.object,
                                    'type': 'matched'
                                }, {
                                    animation: 'ios-transition',
                                    duration: 350
                                });
                        }
                    }).catch(err => {
                        console.log(err);
                        this.itemEmitter.next("Sorry, could not open this event profile - try again!");
                    });
                }
                else {
                    //open people profile
                    this.popoverCtrl.create('PeopleProfile',{
                        person: this.object,
                        isMe: this.object['_id'] == JSON.parse(localStorage.getItem('agnesUser'))['_id']
                    }).present({
                        animation: 'ios-transition',
                        duration: 200
                    });
                }
            }
            else {
                this.isSelected = !this.isSelected;
            }
        }
    }

}

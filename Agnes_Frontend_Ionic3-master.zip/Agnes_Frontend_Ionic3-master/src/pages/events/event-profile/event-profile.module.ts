import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';

import { EventProfile } from './event-profile';

@NgModule({
    declarations: [
        EventProfile
    ],
    imports: [
        IonicPageModule.forChild(EventProfile)
    ],
    exports: [
        EventProfile
    ],
})

export class EventProfileModule { }

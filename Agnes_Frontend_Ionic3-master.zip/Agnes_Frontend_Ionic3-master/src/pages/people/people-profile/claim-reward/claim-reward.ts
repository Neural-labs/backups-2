import { Component, ViewChild } from '@angular/core';
import { Platform, NavParams, PopoverController, ToastController,
  ActionSheetController, NavController, Events, IonicPage, App} from 'ionic-angular';

import { MeService } from '../../../../providers/me.service';
import { AnalyticsService } from '../../../../providers/analytics.service';
import { Agnes } from '../../../../app/app.component';



@IonicPage()
@Component({
  selector: 'claim-reward',
  templateUrl: 'claim-reward.html',
  providers: [MeService, AnalyticsService]

})

export class ClaimPage {

  user:Object;
  image: string;
  orientation: string;
  fullscreen: boolean;
  spinner: boolean;

  rewards: Array<any>;
  selectedReward: string;

  constructor(private navParams: NavParams,
              public navCtrl: NavController,
              public appCtrl: App,
              private meService: MeService,
              private analyticsService: AnalyticsService,
              private events: Events,
              private platform: Platform) {
  }

  ngOnInit(){
    this.user = JSON.parse(localStorage.getItem('agnesUser'));
    this.image = (this.user['cover'] != '') ? 'url(' + this.user['cover'] + ')' : 'url(' + this.user["picurl"] + ')';

    this.loadRewards();

  }

  imgLoad(ev){
    let img = ev.target;
    if (img.naturalWidth > img.naturalHeight) {
      this.orientation = 'landscape';
    } else if (img.naturalWidth < img.naturalHeight) {
      this.orientation = 'portrait';
    } else {
      this.orientation = 'even';
    }
    this.fullscreen = true;
    this.spinner = false;
  }


  loadRewards() {
    this.meService.pebbleRewards().then(val => {
      this.rewards = val;
      this.rewards[0]['type'] = this.selectedReward
    }).catch(err => {
      console.log(err)
    })
  }

  selectCard(card){
    this.selectedReward = card;
  }

  submitFinalClaim() {
    this.meService.claimReward({'typeOfGiftCard': this.selectedReward, 'users_id': this.user['_id']}).then( val =>{
      if (val == 'success') {
        Agnes.showError("Congrats on claiming your reward! You should be receiving an email shortly.")
        this.closeClaimPage()
      }
    })
  }

    closeClaimPage() {
      //send Back Button analytics
      this.analyticsService.logAnalytics({
        backButtonName: 'claimReward',
        users_id: this.user['_id']}, '/backButton');

      this.navCtrl.pop({
          animation: 'ios-transition',
          duration: 350,
          easing: "ease-in-out",
          direction: "back"
      })
    }


}

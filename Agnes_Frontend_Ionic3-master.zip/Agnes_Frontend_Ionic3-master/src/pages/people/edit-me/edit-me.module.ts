import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { DirectivesModule } from '../../../directives/directives.module';

import { EditMe } from './edit-me';

@NgModule({
    declarations: [
        EditMe
    ],
    imports: [
        IonicPageModule.forChild(EditMe),
        DirectivesModule
    ],
    exports: [
        EditMe
    ]
})

export class EditMePopupModule { }

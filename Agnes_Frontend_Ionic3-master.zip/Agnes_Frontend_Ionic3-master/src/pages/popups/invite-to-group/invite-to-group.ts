import { Component } from '@angular/core';
import { ToastController, ViewController, NavParams } from 'ionic-angular';

import { GroupsService } from '../../../providers/groups.service';

import { Agnes } from '../../../app/app.component';

@Component({
  selector: 'invite-to-group',
  templateUrl: 'invite-to-group.html',
  providers: [GroupsService]

})

export class InviteToGroup {
  user:Object;
  person:Object;
  groups: Array<Object>;
  loading: boolean;

  constructor(public viewCtrl: ViewController,
              private navParams: NavParams,
              private groupsService : GroupsService,
              private toastCtrl: ToastController) {
  }

  ngOnInit() {
    this.user = this.navParams.data.user;
    this.person = this.navParams.data.person;
    this.groups = this.navParams.data.groups;
    this.loading = false;

    this.groups = this.groups.map((a) => {
      a['thumbnail'] = (a['thumbnail'] == '' || !a['thumbnail'])
        ? "assets/img/pattern_" + Math.floor((Math.random() * 15) + 1) + '.png' : a['thumbnail'];
      a['keywordString'] = a['keywords'].toString().replace(/,/g,', ');
      return a;
    });
  }

  ngAfterViewInit(){
    window.setTimeout(function(){
      document.getElementsByClassName('popover-content')[0]['style']['left'] = '0px';
    },0);
  }

  //close popup
  closeInviteToGroup(){
    this.viewCtrl.dismiss(null, null, {
      animation: 'ios-transition',
      duration: 350,
      easing: "ease-in-out",
      direction: "back"
    });
  }

  //send person an invite to a group you are admin of
  inviteToGroup(group){
    let data = {
      "groups_id": group._id,
      "users_id": this.person['_id'],
      "sharedby": this.user['_id'],
      "community": this.user['community']
    };

    this.groupsService.inviteUserToGroup(data).then(value => {
      if(value){
        this.toastCtrl.create({
          message: 'You successfully invited ' + this.person['fname'] + ' to ' + group['grpname'],
          duration: 2500,
          position:'top',
            closeButtonText: ' ',
            showCloseButton: true
        }).present();

        this.closeInviteToGroup();
      }
      else {
        Agnes.showError('Something went wrong - try sending your invite again!');
      }
    }).catch(function(error){console.log(error)});
  }

  //if 404 on group image, default to random pattern pic from assets folder
  imgError(group){
    let ind = this.groups.indexOf(group);
    this.groups[ind]['thumbnail'] = "assets/img/pattern_" + Math.floor((Math.random() * 15) + 1) + '.png';
  }
}

import { Injectable } from '@angular/core';
import { Headers, Http, RequestOptions } from '@angular/http';
import 'rxjs/add/operator/toPromise';
import 'rxjs/add/operator/timeout';
import { Agnes } from '../app/app.component';

@Injectable()
export class QuestionsService {
  private headers = new Headers({'Content-Type': 'application/json'});

  constructor(private http:Http) {
  }

  verifyCommunity(email): Promise<any> {
    email["token"] = localStorage.getItem('agnesToken');
    email["timestamp"] = new Date()
    let addUrl = Agnes.API_URL + '/verifyCommunity_v2';
    let options = new RequestOptions({ headers: this.headers });

    return this.http.post(addUrl, email, options)
        .toPromise()
        .then(response => response.json() as Object[])
        .catch(this.handleError);

  }

  majorAutocomplete(data): Promise<Object[]> {
    data['token'] = localStorage.getItem('agnesToken');
    data["timestamp"] = new Date()
    let addUrl = Agnes.API_URL + '/majors';
    let options = new RequestOptions({ headers: this.headers });

    return this.http.post(addUrl, data, options)
      .timeout(5000)
      .toPromise()
      .then(response => response.json() as Object[])
      .catch(this.handleError);
  }

  autocomplete(data): Promise<Object[]> {
    data['token'] = localStorage.getItem('agnesToken');
    data["timestamp"] = new Date()
    let api = (data['type'] == 'haveskill') ? '/skills_autocomplete' : '/autocomplete';
    let addUrl = Agnes.API_URL + api;
    let options = new RequestOptions({ headers: this.headers });

    return this.http.post(addUrl, data, options)
      .timeout(5000)
      .toPromise()
      .then(response => response.json() as Object[])
      .catch(this.handleError);
  }

  getCommunityInfo(data): Promise<Object[]> {
    let addUrl = Agnes.API_URL + '/getCommunityInfo';
    data["timestamp"] = new Date()
    let options = new RequestOptions({ headers: this.headers });

    return this.http.post(addUrl, data, options)
        // .timeout(5000)
        .toPromise()
        .then(response => response.json() as Object[])
        .catch(this.handleError);
  }

  register(data): Promise<Object[]> {
    data['token'] = localStorage.getItem('agnesToken');
    data["timestamp"] = new Date()
    let addUrl = Agnes.API_URL + '/register_v3';
    let options = new RequestOptions({ headers: this.headers });

    return this.http.post(addUrl, data, options)
      .toPromise()
      .then(response => response.json() as Object[])
      .catch(this.handleError);
  }

  fbRegister(email): Promise<any> {
    email["token"] = localStorage.getItem('agnesToken');
    email["timestamp"] = new Date()
    let addUrl = Agnes.API_URL + '/fbregister_v3';
    let options = new RequestOptions({ headers: this.headers });

    return this.http.post(addUrl, email, options)
        .toPromise()
        .then(response => response.json() as Object[])
        .catch(this.handleError);

  }


  private handleError(error: any): Promise<any> {
    console.error('An error occurred', error);
    return Promise.reject(error.message || error);
  }
}

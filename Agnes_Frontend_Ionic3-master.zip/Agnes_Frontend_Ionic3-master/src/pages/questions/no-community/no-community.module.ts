import { NgModule } from '@angular/core';
import { NoCommunityPage } from './no-community';
import { IonicPageModule } from 'ionic-angular';
import { ComponentsModule } from '../../../components/components.module';
import {RoundProgressModule} from 'angular-svg-round-progressbar';

@NgModule({
  declarations: [
    NoCommunityPage
  ],
  imports: [
    IonicPageModule.forChild(NoCommunityPage),
    ComponentsModule,
    RoundProgressModule,
  ],
  exports: [
    NoCommunityPage
  ]
})

export class NoCommunityPageModule { }

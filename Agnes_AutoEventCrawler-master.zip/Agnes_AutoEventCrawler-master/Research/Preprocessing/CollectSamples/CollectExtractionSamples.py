'''
Module to collect samples (html nodes and subtrees) for classification within an html page i.e. extraction

Samples are used to train the classification model

'''
from config import db_config
import pickle
import os
import gc
import logging
from gensim.models import Word2Vec
from Preprocessing.CollectFeatures.CollectExtractionFeatures import extractFeaturesManual, extractFeaturesHTML, extractFeaturesStructure,\
    extractFeaturesContent, getContentEmbeddingModel, getHTMLEmbeddingModel
from multiprocessing import Pool, Queue, JoinableQueue, cpu_count
import random
import numpy as np
from bson.objectid import ObjectId

Agnes = db_config.getDBConn('dev').Agnes
Parent_Event_Collection = Agnes.autocrawler_events

# Ext_Data_Collection = Agnes.autocrawler_ext_data
# Ext_Data_Collection = Agnes.autocrawler_test

global html_embedding_model
global content_embedding_model

def RunExtractionSampleCollection():

    logging.info('Starting Extraction Sample Collection...')

    global html_embedding_model
    global content_embedding_model

    html_embedding_model = getHTMLEmbeddingModel()
    content_embedding_model = getContentEmbeddingModel()

    NUM_THREADS = cpu_count()
    # NUM_THREADS = 1

    logging.info('Starting %d Workers...' % NUM_THREADS)

    QUEUE_MAXSIZE = 100

    queue = JoinableQueue(QUEUE_MAXSIZE)

    pool = Pool(NUM_THREADS, worker_main, (queue,))

    counter = 0
    total = Parent_Event_Collection.count()
    batch_size = 100
    last_id = None
    # last_id = ObjectId('58eb13c7aefa5b6b3200bfa0')

    try:
        while True:

            events = getEventBatchCursor(last_id, batch_size)
            cursor_size = events.count(with_limit_and_skip=True)

            if not events or not cursor_size:
                break

            last_id = events[cursor_size-1]['_id']

            for event in events:

                if invalidEvent(event):
                    continue

                counter += 1
                if counter % 100 == 0:
                    logging.info('%d of %d - Last_id: %s' % (counter, total, str(last_id)))
                queue.put((event, counter), block=True)

            events.close()
            gc.collect()

        logging.info('All events in queue')
        pool.close()
        queue.join()

    except KeyboardInterrupt as e:
        logging.info('Keyboard interrupt')
        pool.terminate()
        pool.join()
        exit()

    print 'Finished Collecting Samples'

def invalidEvent(event):
    keys = ['evtname', 'evtdesc', 'location', 'starttime']
    for key in keys:
        if not event[key]:
            return True
    if 'netx_tree_pkl' not in event:
        return True
    if event['netx_tree_pkl'] == {}:
        return True
    if not 'evtsource' in event or not event['evtsource']:
        return True
    return False

def worker_main(queue):
    worker_id = os.getpid()
    dbConn = db_config.getNewClientDBConn()
    collection = dbConn.Agnes.autocrawler_ext_data
    # collection = dbConn.Agnes./
    print worker_id, 'Alive'

    while True:
        try:
            event, counter = queue.get(True)
        except Queue.Empty as e:
            logging.info('Queue Empty')
            exit()

        error, samples  = getSamplesFromTree(event)

        if not error:

            writeSamples(collection, samples)

        queue.task_done()

def getSamplesFromTree(event):
    global html_embedding_model
    global content_embedding_model
    samples = []

    parts = ['name','description','location','date','other']

    event_tree = pickle.loads(event['netx_tree_pkl'])

    event_nodes = event_tree.get_event_nodes()

    for node_id, node_data in event_tree.get_nodes():

        sample = {}

        text = convertTagToStr(node_data['attr_dict']['tag'])

        subtree_labels = node_data['attr_dict']['subtree_label']
        node_labels = node_data['attr_dict']['node_label']

        subtree_labels = [subtree_labels[part] for part in parts]
        node_labels = [node_labels[part] for part in parts]

        single_label = getSingleLabel(event_nodes, node_id, subtree_labels)

        html_features = extractFeaturesHTML(html_embedding_model, text)

        content_features = extractFeaturesContent(content_embedding_model, text)

        manual_features = extractFeaturesManual(text)

        if not html_features:
            continue

        if not content_features:
            continue

        if np.isnan(np.sum(manual_features)):
            continue

        sample['single_label'] = single_label
        sample['subtree_label'] = subtree_labels
        sample['node_label'] = node_labels
        sample['content_embedding'] = content_features
        sample['html_embedding'] = html_features
        sample['manual_features'] = manual_features
        sample['structure_features'] = extractFeaturesStructure(event_tree, node_id)
        sample['random_id'] = generateRandom()
        sample['evtsource'] = event['evtsource']
        sample['text'] = text
        sample['event_id'] = event['_id']

        samples.append(sample)

    random.shuffle(samples)
    return False, samples

def getSingleLabel(event_nodes, node_id, subtree_labels):

    for part in event_nodes:
        if part == 'event':
            continue
        if node_id == event_nodes[part]:
            return part

    parts = ['name', 'description', 'location', 'date', 'other']
    for part in parts:
        if 1 < subtree_labels[parts.index(part)] > 0:
            return part
    return ''


def generateRandom():
    return int(abs(random.getrandbits(62))) # 2^62 possible ids

def convertTagToStr(tagobj):
    tagstr = str(tagobj)
    tagstr = tagstr.encode('ascii','ignore')
    return tagstr

def writeSamples(collection, samples):
    collection.insert_many(samples)

def getEventBatchCursor(last_id, batch_size):
    # db.students.find({'_id': {'$gt': last_id}}).limit(10)
    return_fields = {
        'evtname':1,
        'evtdesc':1,
        'location':1,
        'starttime':1,
        'evtsource': 1,
        'HTML':1,
        'netx_tree_pkl':1
    }
    if not last_id:
        return Parent_Event_Collection.find({}, no_cursor_timeout=True).limit(batch_size).sort('_id',1)
    return Parent_Event_Collection.find({'_id': {'$gt': last_id}},return_fields, no_cursor_timeout=True).limit(batch_size).sort('_id',1)
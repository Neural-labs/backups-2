import { Component } from '@angular/core';
import { PopoverController, NavParams, ViewController, Events, IonicPage } from 'ionic-angular';

@IonicPage()
@Component({
    selector: 'agnes-alert',
    templateUrl: 'agnes-alert.html',
    providers: []
})

export class AgnesAlert {
    alertMessage: string;
    alertButtons: Array<Object>;
    fullButtons: boolean;

    keywordsList: Array<string>;
    selectedKeywords: Array<string>;
    keywordColor:string;
    isKeywordsPopup: boolean;
    otherKeywords = '';
    otherSelected: boolean;

    hasFbButton: boolean;
    hasIcons: boolean;

    constructor(public popoverCtrl: PopoverController,
                public navParams: NavParams,
                public events: Events,
                public viewCtrl: ViewController) {
    }

    ngOnInit(){
        this.alertMessage = this.navParams.get('alertMessage');
        this.alertButtons = [];
        this.fullButtons = this.navParams.data.fullButtons;

        this.keywordsList = this.navParams.data.keywordsList;
        this.selectedKeywords = this.navParams.data.selectedKeywords ? this.navParams.data.selectedKeywords : [];
        this.keywordColor = '#2D9ef0';
        this.isKeywordsPopup = !!(this.navParams.data.keywordsList);
        this.otherSelected = false;

        this.fullButtons = this.navParams.get('fullButtons');
        this.hasFbButton = this.navParams.get('hasFbButton');
        this.hasIcons = this.navParams.get('hasIcons');

        if(this.navParams.data.alertButtons && this.navParams.data.alertButtons.length == 0) {
            //this is a toast
            setTimeout(() => {
               this.closeAgnesAlert(null);
            },2000);
        } else {
            if(!this.navParams.data.alertButtons) {this.alertButtons = ['Ok']}
            else {
                for(let x in this.navParams.data.alertButtons) {
                    this.alertButtons.push(this.navParams.data.alertButtons[x]);
                }
            }
        }

    }

    //add or remove keyword from selectedKeywordsArray
    addOrRemove(keyword) {
        if(keyword == 'Other'){
            this.otherSelected = !this.otherSelected;
        }
        else {
            let index = this.selectedKeywords.indexOf(keyword);
            let inList = index != -1;
            if (inList) {
                this.selectedKeywords.splice(index,1);
            }
            else {
                this.selectedKeywords.push(keyword);
            }
        }
    }

    closeAgnesAlert(button){
        let data = null;
        if (this.isKeywordsPopup) {
            data = this.selectedKeywords;
            if(this.otherKeywords.trim() != ''){
                data = data.concat(this.otherKeywords.split(/,\s*/).map(a => a.trim()));
            }

        }
        else {
            data = button ? this.alertButtons.indexOf(button) : null;
        }

        this.events.publish('agnesAlertData', data);
        this.viewCtrl.dismiss();
    }

    clearOther(){
        this.otherKeywords = '';
        this.otherSelected = false;
    }

}

import { Component, Input } from '@angular/core';
import { Content } from 'ionic-angular';

/**
 * component for scroll to top of ion content
 */

@Component({
  selector: 'agnes-scroll-top',
  templateUrl: 'agnes-scroll-top.html'
})

export class AgnesScrollTopComponent {

  @Input('content') content: Content;
  scrollingUp: boolean;

  constructor() {
  }

  ngOnInit(){
  }

  scrollToTop(){
    this.scrollingUp = true;
    this.content.scrollToTop(250).then(() =>{
      this.scrollingUp = false;
    });
  }

}

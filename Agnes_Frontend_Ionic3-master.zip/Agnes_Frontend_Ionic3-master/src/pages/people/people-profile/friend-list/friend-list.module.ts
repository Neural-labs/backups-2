import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';

import { FriendList } from './friend-list';
import { ComponentsModule } from '../../../../components/components.module';

@NgModule({
    declarations: [
        FriendList
    ],
    imports: [
        IonicPageModule.forChild(FriendList),
        ComponentsModule
    ],
    exports: [
        FriendList
    ],
})

export class FriendListModule { }

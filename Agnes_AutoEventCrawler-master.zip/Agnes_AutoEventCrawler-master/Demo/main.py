# encoding=utf8
from gensim.models import Word2Vec, keyedvectors
from Collector import Collect
from Detector import detector
from Extractor import extractor
import re
from bs4 import BeautifulSoup
import sys
from demo_config import initConfig

reload(sys)
sys.setdefaultencoding('utf8')

Agnes = initConfig.getDBConn('dev').Agnes
demo_coll = Agnes.demo_coll

global html_embedding_model
global content_embedding_model

config_objs = {}
config_objs['usgbc'] = {
    'source':'usgbc.org'
}
config_objs['harvard_peabody'] = {
    'source':'peabody.harvard.edu'
}
config_objs['harvard_gsas'] = {
    'source':'gsas.harvard.edu'
}

# config_objs['harvard_fas_linguistics'] = {
#     'source':'linguistics.fas.harvard.edu'
# }

config_objs['harvard_law'] = {
    'source':'hls.harvard.edu'
}

def main():
    print 'Starting Demo'

    print 'Loading embedding models...'
    load_embeddings()

    initConfig.InitConfig('dev', True)

    sources = getSources()

    while sources:

        source = sources.pop(0)

        print '\n####################################  Collecting ',source, 'Events  ####################################\n'

        print '\n ------------- Running Detection ---------------- \n'
        link_html_list = Collect.collect_pages(source)

        print '\n ------------- Running Extraction ---------------- \n'

        link_html_list = [(link,cleanstrhtml(html)) for link, html in link_html_list]

        # html_list = []
        # for link, html in link_html_list:
        #     # html = unidecode.unidecode(html)
        #     html = str(BeautifulSoup(html,'lxml')).decode('utf8', 'ignore').encode('ascii','ignore')
        #     html_list.append(html)
            # html = html.encode('utf-8','ignore').encode('ascii','ignore')
        event_items = extractor.ExtractFields(source, link_html_list, html_embedding_model, content_embedding_model)

        # for item in event_items:
        #     print 'Event:'
        #     # if 'event_name' in item:
        #     print 'Name:'
        #     print item['event_name']
        #     print 'Date:'
        #     print item['event_date']
        #     print 'Location:'
        #     print item['event_location']
        #     print 'Description:'
        #     print item['event_description']
        #     print
        #     insertItem(item)
        # print

        print 'Inserting collected items into mongodb...'
        if event_items:
            print 'Inserting collected items into mongodb...'
            insertItems(event_items)


        # source = getSource()
        # if source is None:
        #     break

    print 'Ending Demo... goodbyte!'
    exit()

def load_embeddings():
    global html_embedding_model
    global content_embedding_model

    html_embedding_model = Word2Vec.load('gensim_model_w2v_hw')
    content_embedding_model = keyedvectors.KeyedVectors().load_word2vec_format('GoogleNews-vectors-negative300.bin', binary=True)

def cleanhtml(raw_html):
    cleanr = re.compile('<[^<]+?>')
    cleantext = re.sub(cleanr, ' ', raw_html)
    cleantext = ' '.join(cleantext.split())
    return cleantext

def cleanstrhtml(raw_html):
    return str(BeautifulSoup(raw_html,'lxml')).decode('utf8', 'ignore').encode('ascii','ignore')

def getSources():
    print 'Enter the source you would like to start at, enter \'all\' to crawl all sources, or enter \'exit\' to exit\n'
    for key in config_objs.keys():
        print 'Option: ',key
        print

    while True:
        source = raw_input('----> ')
        if source in config_objs.keys():
            obj = config_objs[source]
            return [obj['source']]
        elif source == 'all':
            return [config_objs[key]['source'] for key in config_objs.keys()]
        elif source == 'exit':
            print 'Exiting...'
            return None
        else:
            print 'Invalid Source! Try again.'

def insertItems(items):
    demo_coll.insert_many(items)

if __name__=='__main__':
    main()
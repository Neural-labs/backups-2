import { Component, ViewChild } from '@angular/core';
import { NavParams, Platform, Content, ToastController, App, Events, ViewController } from 'ionic-angular';

import { EventsService } from '../../../providers/events.service';
import { LoginService } from '../../../providers/login.service';
import { MeService } from '../../../providers/me.service';
import { GroupsService } from '../../../providers/groups.service';
import { PeopleService } from '../../../providers/people.service';
import { AnalyticsService } from "../../../providers/analytics.service";

import { Agnes } from '../../../app/app.component';

@Component({
  selector: 'invite-friends',
  templateUrl: 'invite-friends.html',
  providers: [EventsService, LoginService, MeService, GroupsService, PeopleService, AnalyticsService]
})

export class InviteFriends {
  peopleSearch: string;
  user: Object;
  searching: boolean;
  friends: Object[];
  fb: boolean;
  loading: boolean;
  objectID: string;
  invites: string[];
  type: string;
  helpText: string;
  event: Object;
  buttonText: string;
  oldIDs: string[];
  group: Object;
  sentFriends: Array <string>;

  @ViewChild('inviteFriends') scrollContent: Content;

  constructor(private platform: Platform,
              private eventsService: EventsService,
              private viewCtrl: ViewController,
              private loginService: LoginService,
              private analyticsService:AnalyticsService,
              private meService: MeService,
              private groupsService: GroupsService,
              private peopleService: PeopleService,
              private toastCtrl: ToastController,
              private appCtrl: App,
              private events: Events,
              private navParams: NavParams) {
  }

  ngOnInit(){
    this.user = this.navParams.data.user;
    this.objectID = this.navParams.data.objectID;
    this.type = this.navParams.data.type;
    this.friends = [];
    this.peopleSearch = '';
    this.searching = false;
    this.loading = true;
    this.invites = [];
    this.event = this.navParams.data.event;
    this.buttonText = this.type == 'share_event' ? 'Share this event!' : this.type == 'share_group' ? 'Share this group with friends!'
        : this.type == 'IGIYG' ? "I'll go if you go!" : 'Invite';
    this.oldIDs = [];
    this.group = this.navParams.data.group;
    this.sentFriends = this.navParams.data.sentFriends ? this.navParams.data.sentFriends : []


    this.helpText = (this.type == 'IGIYG')
      ? "Select friends below to let them know that you'll go to this event if they will"
      : (this.type == 'share_event')
        ? "Select friends to share this event with"
      : (this.type == 'share_group')
        ? "Select friends to share this group with"
      :  (this.type =='group')
        ? "Select people you want to invite to your group"
      :  (this.type == 'event')
       ? "Select friends you want to invite to your event"
        : "Select friends you want to invite";

    this.getFriends();


  }

  //close this popup
  closeInviteSearch(){
      this.viewCtrl.dismiss(null,null,{
          animation: 'ios-transition',
          duration: 350,
          easing: "ease-in-out",
          direction: "back"
      });
  }

  searchByInput() {
    if (this.type == "group") {
      let filterIDs = this.navParams.get('filterIDs');

        if (this.peopleSearch.length == 0) {
          this.getFriends();
        }
        if (this.peopleSearch && this.peopleSearch.trim().length > 0) {
            let data = {"searchTerm":this.peopleSearch, "community":this.user["community"]}
            this.peopleService.searchPeople(data)
                .then(value => {
                  this.friends = value.filter(a => {return a['_id'] != this.user['_id'] && filterIDs.indexOf(a['_id']) == -1})
                      .map(b => {b.keywordString = b.keywords.map(function(a){return a.name}).toString().replace(/,/g,', ');
                        return b;
                      });
                    this.friends = this.friends.map(f => {
                      if(this.sentFriends.indexOf(f['_id']) == -1) {
                        f['invited'] = false;
                      } else {
                        f['invited'] = true;
                      }
                      return f;
                    })
                })
                .catch(error => {
                    console.log('searchpeople err')
                    console.log(error)
                })
        }
    }
  }

  //filter friend list by name (first or last)
  matchesSearch(person){
    let term = this.peopleSearch.trim().toLowerCase();
    let len = term.length;
    if(len > 0){
      let fname = person['fname'].toLowerCase().substring(0,len) == term;
      let lname = person['lname'].toLowerCase().substring(0,len) == term;
      let fullname = (person['fname'] + ' ' + person['lname']).toLowerCase() == term;
      let interests = this.matchesInterests(person, term);

      return (fname || lname || fullname || interests);
    }
    else {
      return true;
    }
  }

  //filter friend list by interest
  matchesInterests(person,term){
    let ints = person['keywords'] ? person['keywords'].filter(a => {return a['keytype'] == 'interest'})
            .map(b => {return b['name'];}) : [];
    if(person['major']){ints = ints.concat(person['major']);}

    let len = term.length;
    for(let i = 0; i < ints.length; i ++){
      if(ints[i].toLowerCase().substring(0,len) == term) {return true;}
    }
    return false;
  }

  //close search
  clearSearch(){
    this.searching = false;
    this.peopleSearch= "";
    this.getFriends();
  }

  //invite friends to download Agnes by sharing download link
  inviteFriendsToAgnes(){

    if (this.platform.is('cordova')) {

      let link = 'http://onelink.to/hrnse3';
      let message = "Hey check out this new events app!\n" + link;
      let subj = "Agnes: new events app";

      Agnes.socialSharing.share(message, subj, '', '')
        .then((val) => {
        })
        .catch((err) => {
          Agnes.showError("Couldn't share the app with friends, try again!");
        });
    }
    else {
      Agnes.showError("Please install Agnes from the App Store or Google Play store to share groups.");
    }
  }

  //add or remove someone from invites list
  listInvite(person){
      if (!person['notReal']) {
        if(!person['invited']) {
          let id = person['_id'];
          let ind = this.invites.indexOf(id);
          if (ind == -1) {
              this.invites.push(id);
          }
          else {
              this.invites.splice(ind, 1);
          }
        }
      }
      // clicked on the last thingy
      else {
          this.shareOutside();
      }
  }

  //connect user's account to user's FB data
  connectFB(){

    Agnes.facebook.getLoginStatus().then(value => {

      if(value && value.status) {

        let upd = {
          access_token: '',
          users_id: this.user['_id']
        };

        if (value.status == 'connected') {
          upd['access_token'] = value['authResponse']['accessToken'];

          this.loginService.fbUpdate(upd).then(value => {
            this.getFriends();
          }).catch(err => {
            console.log('fb after update error',err);
            Agnes.showError('Could not connect to Facebook - please try again!');
          });
        }
        else if (value.status == 'not_authorized') {
          Agnes.showError('Please allow Agnes access to your Facebook account!');
        }
        else {
          let permissions = ['public_profile',
            'user_friends',
            'email',
            'user_birthday',
            'user_managed_groups',
            'user_likes',
            'pages_show_list',
            'user_events'];

          Agnes.facebook.login(permissions).then(value => {

            if (value && value.status == 'connected') {
              upd['access_token'] = value['authResponse']['accessToken'];

              this.loginService.fbUpdate(upd).then(value => {
                this.getFriends()
              }).catch(err => {
                console.log('fb after update error',err);
                Agnes.showError('Could not connect to Facebook - please try again!');
              });
            }
            else {
              Agnes.showError('Could not connect to Facebook - please try again!');
            }
          }).catch(error => {
            console.log('Facebook.login error', error);
            Agnes.showError('Could not connect to Facebook - please try again!');
          });
        }
      }
    }).catch(error => {Agnes.showError('Could not connect to Facebook - please try again!')});
  }

  //get list of Agnes users who are connected to this user via FB
  getFriends(){
      let data = {
          "users_id": this.user['_id'],
          "community": this.user['community']
      };

      if(this.type == 'group') {
        let filterIDs = this.navParams.get('filterIDs');

        this.peopleService.getPeople(data).then(value => {
          this.loading = false;
          this.friends = value.filter(a => {return a['_id'] != this.user['_id'] && filterIDs.indexOf(a['_id']) == -1})
              .map(b => {b.keywordString = b.keywords.map(function(a){return a.name}).toString().replace(/,/g,', ');
            return b;
          });
          this.friends = this.friends.map(f => {
            if(this.sentFriends.indexOf(f['_id']) == -1) {
              f['invited'] = false;
            } else {
              f['invited'] = true;
            }
            return f;
          })
          console.log(this.friends)

          this.fb = true;
        }).catch(error => {
          this.loading = false;
          console.log(error);
          Agnes.showError("Couldn't retrieve your community, try again!");
        });
      }
      else {
        this.meService.getFriends(data).then(value => {
          this.loading = false;
            this.friends = value.friends.filter(a => {return a['_id'] != this.user['_id']}).map(b => {
                b.keywordString = b.keywords.map(function(a){return a.name}).toString().replace(/,/g,', ');
                return b;
            });
            //making sure friends who have already been chosen are marked
            this.friends = this.friends.map(f => {
              if(this.sentFriends.indexOf(f['_id']) == -1) {
                f['invited'] = false;
              } else {
                f['invited'] = true;
              }
              return f;
            })

            if(this.friends.length != 0){
                //add Invite friends to Agnes button
                this.friends.push({
                    'thumbnail': 'assets/img/icons/new-user-icon.png',
                    'noPic': false,
                    'notReal': true,
                    'fname': 'Invite friends to Agnes',
                    'lname': '',
                    '_id': '',
                    'keywords': [],
                });
                this.fb = value.fb;
            }
        }).catch(err => {
          this.loading = false;
          console.log(err);
          Agnes.showError("Couldn't retrieve your friends, try again!");
        });
      }
  }

  //send invites to all friends in invites list
  sendInvites(){
    if(this.invites.length > 0) {

      //send I'll Go If You Go invites
      if(this.type == 'IGIYG') {
        let data = {
          'sender_users_id': this.user['_id'],
          'receiver_users_id':'',
          'events_id':this.objectID
        };

        this.loading = true;
        let inviteProm = null;
        let promArray = [];

        for(var i = 0; i < this.invites.length; i++){
          data['receiver_users_id'] = this.invites[i];

          inviteProm = this.eventsService.sendIYG(data);
          promArray.push(inviteProm);
        }

        this.events.publish('friendsIGIYGSent', this.invites);

        Promise.all(promArray).then(val => {
            this.toastCtrl.create({
                message: "Invite" + (this.invites.length > 1 ? "s" : "") + " sent!",
                position:'top',
                duration: 2500,
                closeButtonText: ' ',
                showCloseButton: true
            }).present();
            this.closeInviteSearch();
        }).catch(err => {
            this.loading = false;
            Agnes.showError("Sorry, there was a problem sending your invite" + (this.invites.length > 1 ? "s" : "") + " - try again!");
        });
      }

      //send Invite to Group invites
      else if (this.type == 'group') {

        console.log(this.invites)

        let data = {
          "users": this.invites,
          "sharedby": this.user['_id'],
          "groups_id": this.objectID,
        };

        this.loading = true;

        this.groupsService.inviteUserToGroup(data).then(value => {
          this.loading = false;
          let toast = this.toastCtrl.create({
              message: "Invite" + (this.invites.length > 1 ? "s" : "") + " sent!",
              position:'top',
              duration: 2500,
              closeButtonText: ' ',
              showCloseButton: true
          });
          this.events.publish('friendsInvited', this.invites);
          toast.present();
          this.closeInviteSearch();

        }).catch(err => {
          this.loading = false;
            Agnes.showError("Sorry, there was a problem sending your invite" + (this.invites.length > 1 ? "s" : "") + " - try again!");
        });

      }

      //send Share Event notifications
      else if (this.type == 'share_event' || this.type == 'event') {

        let data = {
          'sender_users_id': this.user['_id'],
          'receiver_users_id':this.invites,
          'events_id':this.objectID,
          'obj_id': this.objectID,
          'objName': this.event['evtname']
        };

        this.loading = true;
        this.events.publish('friendsShareSent', this.invites);

        this.eventsService.shareEvent(data).then(value => {
          this.loading = false;
          let toast = this.toastCtrl.create({
              message: "Event shared!",
              position:'top',
              duration: 2500,
              closeButtonText: ' ',
              showCloseButton: true
          });
          toast.present();

          this.closeInviteSearch();
        }).catch(err => {
          this.loading = false;
          Agnes.showError("Sorry, there was a problem sending your invite" + (this.invites.length > 1 ? "s" : "") + " - try again!");
        });
      }

      //send Share Group w Friends notification
      else if(this.type == 'share_group') {
          let data = {
              'sender_users_id': this.user['_id'],
              'users_ids':this.invites,
              'groups_id':this.objectID
          };

          this.loading = true;

          console.log(data);

          this.groupsService.shareGroupWithFriends(data).then(value => {
              console.log(value);

              this.loading = false;
              let toast = this.toastCtrl.create({
                  message: "Group shared!",
                  position:'top',
                  duration: 2500,
                  closeButtonText: ' ',
                  showCloseButton: true
              });
              toast.present();

              this.closeInviteSearch();
          }).catch(err => {
              this.loading = false;
              Agnes.showError("Sorry, there was a problem sharing this group - try again!");
          });
      }
    }
  }

  loaded(last, person){
    let ind = this.friends.indexOf(person);
    this.friends[ind]['noPic'] = false;
    this.loading = last;
  }

  imgError(last, person) {
    let ind = this.friends.indexOf(person);
    this.friends[ind]['noPic'] = true;
    this.loading = last;
  }

  shareOutside(){
    if (this.platform.is('cordova')) {
      let link = 'http://onelink.to/hrnse3';

      let message = "Hey check out this new events app!\n" + link;

      let subj = "Agnes: new events app";

      Agnes.socialSharing.share(message, subj, '', '')
          .then((val) => {
          })
          .catch((err) => {
            Agnes.showError("Couldn't share the app with friends, try again!");
          });
    }
    else {
      Agnes.showError("Please install Agnes from the App Store or Google Play store to share events.");
    }
  }


  loadMoreFriends(infiniteScroll){
    if (this.shouldRefresh()) {

        let data = {
            "users_id":this.user['_id'],
            "_id": this.friends[this.friends.length -1]['_id'],
            "community":this.user['community'],
        };

        this.peopleService.loadMorePeople(data).then(val => {
            if(val && val.length > 0){
                this.addMoreFriends(val, infiniteScroll);
            }
            else {
                infiniteScroll.enable(false);
                infiniteScroll.complete();
            }
        }).catch(err => {
            infiniteScroll.complete();
        });
    }
  }

  shouldRefresh() {
    return this.friends && this.friends.length > 0
  }

  addMoreFriends(moreFriends, infiniteScroll) {
      let filterIDs = this.navParams.get('filterIDs');

      //compare previously returned IDs to newly loaded IDs
      moreFriends = moreFriends.filter(a => {return this.oldIDs.indexOf(a['_id']) == -1});


      if(moreFriends.length > 0) {
          //store newly loaded IDs
          this.oldIDs = moreFriends.map(a => {return a['_id']});

          //filter newly loaded users
          moreFriends = this.filterFriends(moreFriends);

          moreFriends = moreFriends.filter(a => {return a['_id'] != this.user['_id']
              && filterIDs.indexOf(a['_id']) == -1})
              .map(b => {b.keywordString = b.keywords.map(function(a){return a.name}).toString().replace(/,/g,', ');
                  return b;
              });

          for (let friend in moreFriends){
              this.friends.push(moreFriends[friend]);
          }
          if(infiniteScroll){infiniteScroll.complete();}
      }
      else {
          infiniteScroll.complete();
          infiniteScroll.enable(false);
      }


  }

  // removes invisible and duplicate friends
  filterFriends(friends) {
    return friends.filter(a=> {return a['display'] == true})
        .filter(a=> {return this.friends.map(a=> {return a['_id']}).indexOf(a['_id']) == -1});
  }

}

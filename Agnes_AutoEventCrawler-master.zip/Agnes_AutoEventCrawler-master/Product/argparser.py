import argparse

arg_parser = argparse.ArgumentParser(prog='AgnesCrawler',
                                     description='Automated Smart Crawler for Agnes.io',
                                     epilog='Copyright @ Agnes 2018',
                                     )

arg_parser.add_argument('--run_modules',
                        help='Define which modules to run: Collection, Detection, Extraction',
                        nargs=3)

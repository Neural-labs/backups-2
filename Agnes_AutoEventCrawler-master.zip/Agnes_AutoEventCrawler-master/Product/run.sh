#!/bin/bash

python core.py --run_modules collection detection extraction
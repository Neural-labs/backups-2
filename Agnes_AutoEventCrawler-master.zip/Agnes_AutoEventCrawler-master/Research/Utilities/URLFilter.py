import logging
import robotparser
import urlparse
import tldextract
from bs4 import BeautifulSoup
from config.crawler.config import HomePage, Domain

robotParser = robotparser.RobotFileParser()
tldlogger = logging.getLogger('tldextract')
tldlogger.setLevel('WARNING')

GLOBAL_DOMAIN = Domain
GLOBAL_HOMEPAGE = HomePage

def getPageLinks(currentURL,HTML):

    links = []
    if HTML == '':
        return links
    soup = BeautifulSoup(HTML,"lxml")

    for aTag in soup.findAll("a"):

        url = aTag.get('href')
        url = convertToAbsolute(currentURL,url)

        if invalidURL(url):
            continue

        # url = removeQueries(url)

        links.append(url)

    return set(links)

def removeQueries(url):
    parsed_url = urlparse.urlparse(url)
    return parsed_url.scheme + "://" +  parsed_url.netloc + parsed_url.path

def convertToAbsolute(currentURL,url):
    if not url:
        return url
    if url[:2] == '//':
        if '.' in url:
            url = 'http:' + url
        else:
            url = url[1:]
    if not (bool(urlparse.urlparse(url).netloc)):
        parsed_currentURL = urlparse.urlparse(currentURL)
        return parsed_currentURL.scheme + "://" + parsed_currentURL.netloc + url
    else:
        return url

def getdomain(url):
    ext = tldextract.extract(url)
    return ext.domain

def linkInDomain(link):
    domain = getdomain(link)
    return domain == GLOBAL_DOMAIN

# INVALID DOE
def invalidURL(url):

    if not url:
        return True

    if url == '#':
        return True

    if 'mailto' in url:
        return True

    if badExtension(url):
        return True

    if not linkInDomain(url):
        return True

    return False

def badExtension(link):
    badExtensions = [
        '.ics',
        '.pdf',
        '.cfm',
        '.jpg',
        '.jpeg',
        '.png',
        '.tiff',
        '.gif',
        '.mp3',
        '.mp4',
        '.aif',
        '.wav',
        '.7z',
        '.pkg',
        '.tar.gz',
        '.rar',
        '.z',
        '.zip',
        '.dmg',
        '.bin',
        '.vcd',
        '.iso',
        '.csv',
        '.dat',
        '.log',
        '.sql',
        '.tar',
        '.exe',
        '.xml',
        '.jar',
        '.fnt',
        '.ai',
        '.bmp',
        '.ico',
        '.ps',
        '.tif',
        '.svg'
    ]
    for ext in badExtensions:
        if ext in link:
            return True
    return False
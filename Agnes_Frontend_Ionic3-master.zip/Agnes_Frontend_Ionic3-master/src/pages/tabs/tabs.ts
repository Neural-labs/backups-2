import { Component, ViewChild } from '@angular/core';
import { IonicPage, Events, Tabs, App, PopoverController } from 'ionic-angular';
import { FormControl } from '@angular/forms';
import { MeService } from '../../providers/me.service';
import { Agnes } from '../../app/app.component';
import { GroupsService } from '../../providers/groups.service';
import { AnalyticsService } from '../../providers/analytics.service';
import { PebblePopup } from '../popups/pebble-popup/pebble-popup';

@IonicPage()
@Component({
  templateUrl: 'tabs.html',
  providers:[GroupsService, MeService, AnalyticsService]
})

export class TabsPage {

  @ViewChild(Tabs) tabRef: Tabs;

  tab1Root = 'HuddlePage';
  tab2Root = 'EventsPage';
  tab3Root = 'GroupsPage';
  tab4Root = 'SavedPage';

  newChats: any;
  notifCount: number;

  user: Object;
  spinner: boolean;
  fullscreen: boolean;
  orientation: string;
  picurl: string;

  canNotify: boolean;
  shouldNotify: boolean;
  currentTab: number;

  searchInput: string;
  searchControl: FormControl;

  loading:boolean;
  creating: boolean;
  noAnimation: boolean;

  searchCategory: string;

  constructor(private events:Events,
              private analyticsService: AnalyticsService,
              private popoverCtrl: PopoverController,
              private appCtrl: App,
              private meService: MeService) {
    this.searchControl = new FormControl();
    this.searchInput = '';
  }

  ngOnInit(){
    this.user = JSON.parse(localStorage.getItem('agnesUser'));
    this.picurl = this.user['picurl'];
    let chats =  Agnes.getNewChats();
    this.newChats = chats.length > 0 ? '' + chats.length : '';
    this.canNotify = false;
    this.shouldNotify = false;
    this.notifCount = 0;
    this.creating = false;
    this.noAnimation = true;
    this.searchCategory = '';

    this.events.subscribe('changeInNotifCount', num => {
      this.notifCount = num;
    });

    this.events.subscribe('gotNewNotif', () => {
      this.notifCount += 1;
    });

    this.events.subscribe('updatedMe', data => {
      this.user = JSON.parse(localStorage.getItem('agnesUser'));
      this.picurl = this.user['localPic'] ? this.user['localPic'] : this.user['picurl'];
    });

    this.getNotifications(null);

    //switches for profile pic in nav bar
    this.spinner = true;
    this.fullscreen = false;
    this.orientation = 'even';

    this.events.subscribe('selectGroups', () => {
      this.events.unsubscribe('selectGroups');
      this.tabRef.select(2);
    });

    this.openPebbles()

  }

  // Handle searching
  ionViewDidLoad() {
    this.searchControl.valueChanges.debounceTime(350).subscribe(search => {
      if(this.currentTab == 1 || this.currentTab == 3) {
        let type = this.currentTab == 1 ? 'event' : 'group';
        this.events.publish(type + 'Search', search);
        if(search.trim() == ''){
          if(this.currentTab == 1){localStorage.removeItem('agnesEventSearch');}
          if(this.currentTab == 3){localStorage.removeItem('agnesGroupSearch');}
        }
      }
      else if (this.currentTab == 0){
        this.events.publish('huddleSearch', this.searchInput.trim());
      }
    });
  }

  //remove spinner when user profile pic loads
  imgLoad(ev){
    let img = ev.target;
    if (img.naturalWidth > img.naturalHeight) {
      this.orientation = 'landscape';
    } else if (img.naturalWidth < img.naturalHeight) {
      this.orientation = 'portrait';
    } else {
      this.orientation = 'even';
    }
    this.fullscreen = true;
    this.spinner = false;
  }

  onTabsChange(){

    let selectedTab = this.tabRef.getSelected().index;

    //save search input for appropriate tabs
    if(this.currentTab == 1){
      if(this.searchInput.trim() != '') {localStorage.setItem('agnesEventSearch', this.searchInput.trim());}
    }
    else if(this.currentTab == 3){
      if(this.searchInput.trim() != '') {localStorage.setItem('agnesGroupSearch', this.searchInput.trim());}
    }

    //set new current tab
    this.currentTab = selectedTab;

    //reset search input
    if(this.currentTab == 1 || this.currentTab == 3){
      let searchTerm = this.currentTab == 1 ? localStorage.getItem('agnesEventSearch') : localStorage.getItem('agnesGroupSearch');
      this.searchInput = !!searchTerm ? searchTerm : '';
    }
    else {
      this.searchInput = '';
    }

    this.searchCategory = this.currentTab == 1 ? 'events'
        : this.currentTab == 3 ? 'groups'
            : this.currentTab == 4 ? 'saved'
                : '';
  }

  //view profile from nav bar click
  viewMyProfile() {
    this.appCtrl.getRootNavs()[0].push(
        'PeopleProfile',
        {
          person: this.user,
          isMe: true
        }, {
          animation: 'ios-transition',
          duration: 350
        });
  }

  //opening notification menu
  openNotifications() {
    this.appCtrl.getRootNav().push(
      'NotificationsPage',
      {}, {
        animation: 'ios-transition',
        duration: 350
      });
  }


  openPebbles() {
    // this.popoverCtrl.create(PebblePopup).present()
  }


  initNotifications(refresher){
      this.notifCount = 0;
      this.user = JSON.parse(localStorage.getItem('agnesUser'));
      this.getNotifications(refresher);
  }

  //get all notifications
  //TODO update based on variable in notifications
  getNotifications(refresher){
    let data = {'users_id': this.user['_id']};
    this.meService.getNotifications(data).then(val => {
      let notif = val['notifications'];
      for(let n in notif) {
        if(notif[n]['read'] == false) {
          this.notifCount++;
        }
      }
    });
  }

  imgError(ev){
    this.spinner = false;
  }

  ngOnDestroy(){
    this.events.unsubscribe('updateMeBadge');
    this.events.unsubscribe('realNotifNum');
    this.events.unsubscribe('updateChatBadge');
    this.events.unsubscribe('toMeTab');
    this.events.unsubscribe('meInit');
    this.events.unsubscribe('goToHostEvent_2');
    this.events.unsubscribe('changeInNotifCount');
  }

  createToggle(){
    this.creating = !this.creating;
    this.noAnimation = false;
  }

  //open create group popup
  createGroup(){
    if(this.creating) {
    //send Create Group Button analytics
    this.analyticsService.logAnalytics({community: this.user['community'], users_id: this.user['_id']}, '/createGroupButton');

    this.appCtrl.getRootNav().push(
        'CreateGroupPage',
        {}, {
          animation: 'ios-transition',
          duration: 350
        });
      }
  }

  //open up create event popup
  createEvent(isOpen){
    if(this.creating) {
    //send Create Event Button analytics
    this.analyticsService.logAnalytics({community: this.user['community'], users_id: this.user['_id']}, '/createEventButton');

    this.appCtrl.getRootNav().push(
        'CreateEventPage',
        {}, {
          animation: 'ios-transition',
          duration: 350
        });
    }
  }
}

from db import functions


def runWorker():

    while True:
        # send requests
        huddle_requests_cursor = functions.readHuddleRequests(new=True)

        if huddle_requests_cursor:
            for request in huddle_requests_cursor:
                user_id = request['request_ids']['users_id']
                setNewUpdate(user_id)


def setNewUpdate(user_id):
    pass
#!/bin/sh
python main.py scheduled
import { Component, ElementRef, ViewChild } from '@angular/core';
import { Events, IonicPage, App, ModalController, PopoverController, Select } from 'ionic-angular';

import { AnalyticsService } from "../../../providers/analytics.service";
import { EventsService } from '../../../providers/events.service';
import { MeService } from '../../../providers/me.service';
import { GroupsService } from '../../../providers/groups.service';

import { InviteFriends } from '../../popups/invite-friends/invite-friends';

import { Agnes } from '../../../app/app.component';
import * as AWS from 'aws-sdk';
import * as S3 from 'aws-sdk/clients/s3';

@IonicPage()
@Component({
    selector: 'create-event',
    templateUrl: 'create-event.html',
    providers: [EventsService, MeService, GroupsService, AnalyticsService]
})

export class CreateEventPage {
    @ViewChild('hostSelect') hostSelect: Select;

    user: Object;
    event: Object;
    hasGroups: boolean;
    adminGroups: Array<Object>;
    keywordInput: string;

    secretHost: boolean;
    starttime: string;
    endtime: string;
    host: string;
    localImg: string;
    website: string;

    descLimit = 1000;

    loading: boolean;
    shouldBlur: boolean;
    reset:boolean;
    isPrivate: boolean;
    submitted: boolean;

    constructor(private eventsService: EventsService,
                private groupsService: GroupsService,
                private modalCtrl: ModalController,
                private popoverCtrl: PopoverController,
                private events: Events,
                private analyticsService: AnalyticsService,
                private appCtrl: App){}

    //initialize Create Event page
   ngOnInit(){
       this.user = JSON.parse(localStorage.getItem('agnesUser'));
       this.loading = false;
       this.reset = true;
       this.shouldBlur = true;
       this.isPrivate = false;

       this.initEvent(null);

       //add created group to list of groups able to host a new event
       this.events.subscribe('hostGroupCreated', group => {
           if (group && group['grptype'] != 'secret'){
               this.adminGroups.push(group);
               let user = JSON.parse(localStorage.getItem('agnesUser'));
               let ind = user['grp'].map(a => {return a['groups_id']}).indexOf(group['_id']);
               if(ind == -1){
                   user['grp'].push({
                       'groups_id': group['_id'],
                       'admin': true
                   });
               }
               this.user = user;
               localStorage.setItem('agnesUser', JSON.stringify(user));
           }
       });

       //delete group from host list when user has deleted group from database
       this.events.subscribe('groupDeleted', groupID => {
           let ind = this.adminGroups.map(a => {return a['_id']}).indexOf(groupID);
           if(ind != -1){
               this.adminGroups.splice(ind,1);
           }
           this.hasGroups = this.adminGroups.length > 0;

           let user = JSON.parse(localStorage.getItem('agnesUser'));
           ind = user['grp'].map(a => {return a['groups_id']}).indexOf(groupID);
           if(ind != -1){
               user['grp'].splice(ind,1);
           }
           this.user = user;
           localStorage.setItem('agnesUser', JSON.stringify(user));
       });

       //edit group (mostly for privacy stuff) in group admin list
       this.events.subscribe('groupEdited', group => {
          let ind = this.adminGroups.map(a => {return a['_id']}).indexOf(group['_id']);
          if(ind != -1){this.adminGroups[ind] = group};
       });


    }

    ionViewWillEnter(){
        this.adminGroups = [];
        this.getUserGroups();
    }

    initEvent(host){
        this.event = {};
        this.event['grps'] = [];
        this.event['keywords'] = [];
        this.event['evtname'] = this.event['evtdesc'] = this.event['location'] = this.event['endtime'] = this.event['starttime'] = this.event['picurl'] = '';
        this.event['evttype'] = 'public';
        this.event['admin'] = [this.user['_id']];
        this.event['repeat'] = false;
        this.event['repeatData'] = {};
        this.event['community'] = this.user['community'];
        this.event['weburl'] = [];

        this.starttime = '';
        this.endtime = '';
        this.keywordInput = '';
        this.secretHost = false;
        this.host = host ? host : null;
        this.localImg = '';
        this.website = '';

        this.submitted = false;

    }

    //get groups that user is admin of
    getUserGroups() {
        this.adminGroups = [];
        this.groupsService.getAdminGroups({"users_id":this.user['_id']}).then(value => {
            if (value){
                for (var v in value) {
                    let group = value[v];
                    if (group){
                        let ind = this.user['grp'].map(function(a){return a['groups_id'];}).indexOf(group['_id']);
                        if (this.user['grp'][ind]['admin']
                            && this.adminGroups.map(function(a){return a['groups_id']}).indexOf(group['_id']) == -1){
                            this.adminGroups.push(group);
                        }
                    }
                }
                this.hasGroups = this.adminGroups.length > 0;
            }
            else {
                this.hasGroups = false;
            }
        }).catch(err => {
            this.hasGroups = false;
        });
    }

    closeCreateEvent(backButton?) {
        if(backButton){
            //send Back Button analytics
            this.analyticsService.logAnalytics({
                backButtonName: 'createEvent',
                users_id: this.user['_id']}, '/backButton');
        }

      this.appCtrl.getRootNav().pop({
          animation: 'ios-transition',
          duration: 350,
          easing: "ease-in-out",
          direction: "back"
      })
    }

    //user has selected a group to host event
    selectAdminGroup(group){
        if(group){
            // this.event['grps'] = [group['_id']];
            // this.event['admin'] = [];
            this.event['admin'] = group['admin'];

            //secret group cannot have public events, so don't show public/private option
            if(group['grptype'] == 'secret') {
                this.secretHost = true;
                this.event['evttype'] = 'private';
            }
            else {
                this.secretHost = false;
                if(group['grptype'] == 'public') {
                    this.event['evttype'] = 'public';
                }
            }

            this.setHostFromGroup(group);
        }
        else {
            this.event['grps'] = [];
            this.event['admin'] = [this.user['_id']];
            this.host = null;
        }

        this.hostSelect.close();
    }

    setHostFromGroup(group) {
        this.host = group;
        this.event['grps'] = [group['_id']];
    }

    //togglePrivacy
    toggleEventType() {
      this.isPrivate = !this.isPrivate;
    }

    //set date and time for start/end of event
    openDatePicker(type){
        let d = new Date();
        let current = this.event['starttime'] == '' ? d : new Date(this.event['starttime']);
        Agnes.datePicker.show({
            date: current,
            mode: 'date',
            titleText: 'Event Start Time',
            minDate: d,
            maxDate: new Date().setFullYear(d.getFullYear() + 1),
            androidTheme: Agnes.datePicker.ANDROID_THEMES.THEME_DEVICE_DEFAULT_DARK,
            allowOldDates: false
        }).then(
            date => {
                if(date){
                    date = new Date(date);
                    let start = Agnes.processGMT(date);
                    this.starttime = start['date'].substring(5,start['date'].length) + ' ' + start['time'];
                    this.event['starttime'] = date.toISOString();
                    let end = new Date(date);
                    this.event['endtime'] = new Date(end.setHours(end.getHours() + 1));

                    setTimeout(() => {
                        Agnes.datePicker.show({
                            date: this.event['endtime'],
                            mode: 'datetime',
                            titleText: 'Event End Time',
                            minDate: d,
                            maxDate: new Date().setFullYear(d.getFullYear() + 1),
                            androidTheme: Agnes.datePicker.ANDROID_THEMES.THEME_DEVICE_DEFAULT_DARK,
                            allowOldDates: false
                        }).then(
                            date => {
                                if(date){
                                    date = new Date(date);
                                    let end = Agnes.processGMT(date.toISOString());
                                    this.endtime = end['date'].substring(5,end['date'].length) + ' ' + end['time'];
                                    this.event['endtime'] = date.toISOString();
                                }

                            },
                            err => console.log('Error occurred while getting date: ', err)
                        );
                    },500);
                }
            },
            err => console.log('Error occurred while getting date: ', err)
        );
    }

    //add keyword from keyword input field into event's keyword array
    addKeyword(e){

        //for keeping keyboard up when + button is pressed
        if(e){
            e.preventDefault();
            this.shouldBlur = false;
        }

        if(this.event['keywords'].length < 6 && this.keywordInput.trim() != '') {
            let add = this.keywordInput.toLowerCase().trim().replace(/,\s+/,',').split(',')
                .map(a => {return a.trim()}).filter(a => {return this.event['keywords'].indexOf(a) == -1});
            this.event['keywords'] = this.event['keywords'].concat(add);
        }
        this.keywordInput = '';
    }

    //remove keyword from event
    removeKeyword(key){
        let ind = this.event['keywords'].indexOf(key);
        if(ind != -1){
            this.event['keywords'].splice(ind,1);
        }
    }

    //use return or comma key to enter keyword
    onEnter(ev){
        if((ev.keyCode == 13) || (ev.keyCode == 188)) {
            this.addKeyword(null);
        }
    }


    //upload event picture
    addPhoto(){

        let buttons = [
            {name: 'Camera',
            icon:'md-camera'},
            {name: 'Upload',
            icon: 'ios-share-outline'}
        ];

        Agnes.showError('Choose a photo source', buttons , false, false, true);

        this.events.subscribe('agnesAlertData', ind => {
              this.events.unsubscribe('agnesAlertData');
                let source = ind == 0 ? Agnes.camera.PictureSourceType.CAMERA : Agnes.camera.PictureSourceType.PHOTOLIBRARY;
                let options = {
                    quality: 25,
                    allowEdit: true,
                    correctOrientation: true,
                    destinationType: Agnes.camera.DestinationType.DATA_URL,
                    encodingType: Agnes.camera.EncodingType.JPEG,
                    sourceType: source
                };

                Agnes.camera.getPicture(options).then((value) => {
                    if (value && typeof(value)=='string'){
                        let base64Image = 'data:image/jpeg;base64,' + value;
                        this.event['picurl'] = base64Image;
                    }
                    else {
                        console.log('not base64', value);
                        Agnes.showError("Couldn't process your photo - try again!");
                    }
                }).catch(err => {
                    console.log(err);
                    Agnes.showError("Couldn't get your photos - make sure Agnes has photo access permissions and try again!");
                });
        });
    }

    //set/cancel repeat for event
    setRepeat(){
        let eventRepeat = this.modalCtrl.create('EventRepeat',
            {
                repeatData: this.event['repeatData']
            });
        eventRepeat.onDidDismiss((data) => {
            Agnes.removeFilter();
            if(!data || data['none']) {
                this.event['repeat'] = false;
                this.event['repeatData'] = {};
            }
            else {
                this.event['repeat'] = true;
                this.event['repeatData'] = data;
            }
        });
        for (var e = 0; e < document.getElementsByTagName("ion-popover").length; e++){
            document.getElementsByTagName("ion-popover")[e]["style"]["filter"]="blur(3vw)";
        }
        document.getElementsByTagName("ng-component")[0]["style"]["filter"]="blur(3vw)";
        eventRepeat.present();
    }

    // convert base64/URLEncoded data component to raw binary string
    baseToBlob(dataURI) {
        var byteString;
        if (dataURI.split(',')[0].indexOf('base64') >= 0)
            byteString = atob(dataURI.split(',')[1]);
        else
            byteString = (dataURI.split(',')[1]);

        // write the bytes of the string to a typed array
        var ia = new Uint8Array(byteString.length);
        for (var i = 0; i < byteString.length; i++) {
            ia[i] = byteString.charCodeAt(i);
        }

        return new Blob([ia.buffer], {type: "image/jpeg"});
    }

    //validate event details and submit event to database
    submitEvent(){

        this.submitted = true;

        this.addKeyword(null);

        this.event['weburl'] = this.website.trim() != '' ? [this.website] : [];

        let nameValid = this.event['evtname'] != '';
        let dateValid = this.starttime != '' && this.endtime != ''
            && new Date(this.event['starttime']) < new Date(this.event['endtime']);
        let locationValid = this.event['location'] != '';
        let keywordsValid = this.event['keywords'].length > 0;

        if(nameValid && dateValid && locationValid && keywordsValid){
            if (this.event['picurl'] != ''){
                let creds = {
                    bucket: 'agneseventimage',
                    access_key: 'AKIAJYQU6AUVQQKITAPQ',
                    secret_key: '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'
                };
                let uniqueFilename = "";
                var possible = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";

                for (var i = 0; i < 8; i++) {
                    uniqueFilename += possible.charAt(Math.floor(Math.random() * possible.length));
                }

                this.localImg = this.event['picurl'];

                let data = this.baseToBlob(this.event['picurl']);
                AWS.config.update({region: 'us-east-1',credentials: {
                    accessKeyId: "AKIAJYQU6AUVQQKITAPQ",
                    secretAccessKey:"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"
                }});

                let keyname = uniqueFilename + '.jpg';
                keyname = '_' + keyname;

                //TODO if the orientation stuff came up!
                /* if(this.orientation){
                 keyname = '_' + keyname;
                 }
                 else{
                 keyname = '_' + uniqueFilename
                 }
                 */

                //Bucket Parameters
                let bucketParams = {
                    Key: keyname,
                    ContentType: ".jpg",
                    Body: data ,
                    ServerSideEncryption: 'AES256',
                    Bucket: creds.bucket
                };

                //bucket to define
                let bucket = new S3({ params: { Bucket: 'agneseventimage' } });

                bucket.putObject(bucketParams, function(err, data) {
                    if(err) {
                        console.log('bucket error',err);
                        return false;
                    }
                    else {
                        // Upload Successfully Finished
                    }
                });

                this.event['picurl'] = 'https://s3.amazonaws.com/agneseventimage/' + keyname;
            }

            this.loading = true;

            //check for zero repeat
            if(Object.keys(this.event['repeatData']).length == 0){
                this.event['repeatData']['frequency'] = 'single';
                this.event['repeatData']['repeatDays'] = '';
                this.event['repeatData']['stopAfter'] = '';
            }

            // Add event
            this.eventsService.addEvent(this.event)
                .then(data => {

                    this.loading = false;

                    if (data){

                        if(this.localImg){
                            data['picurl'] = this.localImg;
                        }
                        let message = 'You\'ve successfully created "' + this.event['evtname'] + '"!';
                        let buttons = ['Event Profile', 'Invite People'];

                        this.events.subscribe('agnesAlertData', index => {
                            this.events.unsubscribe('agnesAlertData');
                            if(index == 0){
                                //TODO: make 'event' the return from eventsService call
                                //go to event profile
                                this.appCtrl.getRootNav().push(
                                    'EventProfile',
                                    {
                                        'event':data,
                                        'user':this.user,
                                        'type': 'my'
                                    }, {
                                        animation: 'ios-transition',
                                        duration: 350
                                    });
                            }
                            else if (index == 1){
                                //invite friends to event
                                this.appCtrl.getRootNav().push(
                                    InviteFriends,
                                    {
                                        'user': JSON.parse(localStorage.getItem('agnesUser')),
                                        'type':'event',
                                        'objectID':data['_id'],
                                        'event':data
                                    });

                                this.events.publish('toMyEvents');
                            }
                            this.initEvent(null);
                        });
                        Agnes.going(data,false);
                        Agnes.showError(message,buttons);
                        this.closeCreateEvent();

                        //update group that is hosting this event
                        if(data['grps'].length > 0) {
                            this.events.publish('eventHosted',{'groupID': data['grps'][0], 'eventID':data['_id']});
                        }
                    }
                    else {
                        // Agnes.showError("Sorry, couldn't create your event right now - try again!");
                        Agnes.showError("Uh oh. We lost connection.");
                    }
                })
                .catch(err => {
                    this.loading = false;
                    console.log(err);
                    Agnes.showError("Uh oh. We lost connection.");
                });
        }
    }

    //lock tabs when in edit description
    lockTabs(lock){
        this.events.publish('lockCreateEventTabs', lock);
    }

    //for keeping keyboard up when + button is pressed for keywords
    keepKeyboard(event){
        if(!this.shouldBlur){
            event.target.focus();
            this.shouldBlur = true;
        }
    }

}

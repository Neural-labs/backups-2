import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';

import { EventAttendees } from './event-attendees';
import { ComponentsModule } from '../../../../components/components.module';

@NgModule({
    declarations: [
        EventAttendees
    ],
    imports: [
        IonicPageModule.forChild(EventAttendees),
        ComponentsModule
    ],
    exports: [
        EventAttendees
    ],
})

export class EventAttendeesModule { }

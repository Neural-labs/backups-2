from pymongo import MongoClient
dev_conn = MongoClient('mongodb://arpit:groupten123!@agnesautocrawler-shard-00-00-1mhnx.mongodb.net:27017,agnesautocrawler-shard-00-01-1mhnx.mongodb.net:27017,agnesautocrawler-shard-00-02-1mhnx.mongodb.net:27017/admin?replicaSet=AgnesAutoCrawler-shard-0&ssl=true')

prod_conn = MongoClient("mongodb://arpit:groupten123!@agnesdatabase-shard-00-00-1mhnx.mongodb.net:27017,agnesdatabase-shard-00-01-1mhnx.mongodb.net:27017,agnesdatabase-shard-00-02-1mhnx.mongodb.net:27017/<DATABASE>?ssl=true&replicaSet=AgnesDatabase-shard-0&authSource=admin")
import numpy as np
from keras.models import Sequential
from keras.layers import Activation, Conv1D, MaxPooling1D, LSTM, Dense
from keras.optimizers import SGD
from ExtractionFeatures import extractFeaturesManual, extractFeaturesContent, extractFeaturesHTML
from Utility_Modules import EventTree, DateExtraction, DataFilter
from gensim.models import Word2Vec, keyedvectors
import re


global html_embedding_model
global content_embedding_model

MAXIMUM_DATE_LENGTH = 100
MAXIMUM_LOCATION_LENGTH = 100
MINIMUM_DESCRIPTION_LENGTH = 300
MINIMUM_LOCATION_LENGTH = 10


def ExtractFields(source, HTML_list, html_emb_model, content_emb_model):
    global html_embedding_model
    global content_embedding_model
    # print 'Loading embeddings'
    # html_embedding_model = Word2Vec.load('gensim_model_w2v_hw')
    # content_embedding_model = keyedvectors.KeyedVectors().load_word2vec_format('GoogleNews-vectors-negative300.bin', binary=True)

    html_embedding_model = html_emb_model
    content_embedding_model = content_emb_model

    # name_model = getModel(input_dim=568)
    description_model = getModel(input_dim=614)
    location_model = getModel(input_dim=614)
    date_model = getModel(input_dim=614)

    # name_model.load_weights('keras_classifier_name.hdf5')
    description_model.load_weights('keras_classifier_description_v2.hdf5')
    location_model.load_weights('keras_classifier_location_v2.hdf5')
    date_model.load_weights('keras_classifier_date_v2.hdf5')

    counter = 0
    final_items = []
    for link, HTML in HTML_list:
        counter += 1

        event_tree = EventTree.EventTree(HTML)

        samples,X = getSamples(event_tree)

        # name_preds = name_model.predict(X)
        description_preds = description_model.predict(X)
        location_preds = location_model.predict(X)
        date_preds = date_model.predict(X)

        all_predictions = [description_preds, location_preds, date_preds]
        fields = ['event_description', 'event_location', 'event_date']

        field_values = zip(fields, all_predictions)

        final_values = {}

        for part, type_preds in field_values:

            sample_preds = zip(type_preds, samples)

            sorted_preds = sorted(sample_preds, key=lambda x: x[0][0])

            final_values[part] = (sorted_preds[0][0], cleanhtml(str(sorted_preds[-1][1][1])))

        final_values = getManualValues(source, final_values, HTML, samples)

        # final_items.append(final_values)
        if validateEventItem(source, final_values):
            for key in final_values:
                final_values[key] = final_values[key][1]
            final_values['url'] = link

            print 'Event:'
            print 'Name:'
            print final_values['event_name']
            print 'Date:'
            print final_values['event_date']
            print 'Location:'
            print final_values['event_location']
            print 'Description:'
            print final_values['event_description']
            print

            final_items.append(final_values)
        else:
            print 'Invalid Event:', final_values['event_name']

    return final_items


def validateEventItems(source, event_items):
    validItems = []
    for item in event_items:
        item = validateEventItem(source, item)
        if item:
            validItems.append(item)
    return validItems

def validateEventItem(source, item):
    event_name = item['event_name'][1]
    event_date = item['event_date'][1]
    event_description = item['event_description'][1]
    event_location = item['event_location'][1]

    if len(event_date) > MAXIMUM_DATE_LENGTH:
        print event_date
        return False

    if len(event_description) < MINIMUM_DESCRIPTION_LENGTH:
        return False

    if len(event_location) < MINIMUM_LOCATION_LENGTH:
        return False

    # dates = DateExtraction.getDates(item['event_date'])
    #
    # if not dates:
    #     return None
    #
    # item['event_date'] = dates[0][0]
    return True

def validateContent(content, length):
    return len(content) > length

def getModel(input_dim):
    kernel_size = 5
    pool_size = 4
    filters = 64
    lstm_output_size = 64
    input_dim = input_dim
    consume_less = 1  # 1 for cpu, 2 for gpu
    model = Sequential()
    # model.add(Dense(input_dim, input_shape=(input_dim,)))
    # model.add(Embedding(
    #     input_dim=max_features,
    #     output_dim=embedding_dim,
    #     input_length=max_len))
    # trainable=False,
    # weights=[embedding_matrix]))
    # model.add(Dropout(0.25))
    # print model.summary()
    model.add(Conv1D(filters,
                     kernel_size,
                     padding='same',
                     strides=1,
                     kernel_initializer='uniform',
                     input_shape=(None, input_dim),
                     batch_input_shape=(None, 1,input_dim)
                     ))
                     # ))
                     # batch_size=batch_size,
                     # batch_input_shape=(None, input_dim)))
    # model.summary()
    model.add(Activation('relu'))
    # model.add(Flatten())
    # model.add(GlobalMaxPool1D())
    # model.add(Flatten())
    model.add(MaxPooling1D(padding='same'))
    # model.add(Dropout(0.25))
    # model.summary()
    # model.add(Flatten())
    model.add(LSTM(lstm_output_size))
    model.add(Dense(64, activation='relu'))
    model.add(Dense(64, activation='relu'))
    model.add(Dense(1, activation='sigmoid'))
    # model.add(Activation('sigmoid'))
    # sgd = SGD(lr=0.01, momentum=0.0, decay=0.0, nesterov=False)
    model.compile(loss='binary_crossentropy',
                  optimizer='adam',
                  metrics=['accuracy'])
    # model.summary()
    return model

def getSamples(event_tree):
    samples = []
    X = []
    for node_id, node_data in event_tree.get_nodes():
        if invalidSample(node_data):
            continue

        tag = node_data['attr_dict']['tag']

        text = convertTagToStr(tag)

        features = getFeatures(text)

        if not features:
            continue

        samples.append((node_id, tag))
        X.append(features)

    X = np.array(X)
    X = X.reshape(X.shape[0], 1, X.shape[1])
    return samples,X

def invalidSample(node_data):
    tag = node_data['attr_dict']['tag']
    text = convertTagToStr(tag)
    skip_values = ['Internet Explorer','Incompatible browser','Curriculum Solutions']
    for item in skip_values:
        if item in text:
            return True
    return False

def convertTagToStr(tagobj):
    tagstr = str(tagobj)
    tagstr = tagstr.encode('ascii','ignore')
    return tagstr

def getFeatures(text):
    global html_embedding_model
    global content_embedding_model
    features = []
    html_features = extractFeaturesHTML(html_embedding_model, text)

    content_features = extractFeaturesContent(content_embedding_model, text)

    if html_features is None:
        return None

    if content_features is None:
        return None

    features += list(html_features)
    features += list(content_features)
    features += extractFeaturesManual(text)

    return features

def getManualValues(source, final_values, HTML, samples):

    soup = DataFilter.removeBadThings(HTML)

    final_values['event_name'] = getName(source, samples)

    if source == 'usgbc.org':
        pass
    elif source == 'peabody.harvard.edu':
        pass
    elif source == 'gsas.harvard.edu':
        description, location, date = getHarvardGSAS(soup)

        final_values['event_description'] = (1,description)
        final_values['event_location'] = (1, location)
        final_values['event_date'] = (1, date)

    elif source == 'linguistics.fas.harvard.edu':
        location = getHarvardFASLinguistics(soup)

        final_values['event_location'] = (1, location)
    elif source == 'hls.harvard.edu':
        location = getHarvardLaw(soup)
        final_values['event_location'] = (1, location)
    else:
        raise ValueError('source incorrectly specified!')

    return final_values


def getHarvardGSAS(soup):

    description_selector = '#content > div > section > div.ds-1col.node.node-event.view-mode-full.clearfix > div p'

    location_selector = '#block-ds-extras-attend-event > div > div > div.field.field-name-field-address span'

    date_selector = '#block-ds-extras-attend-event > div > div > div.field.field-name-event-date-sidebar > div.field.field-name-field-event-date.field-type-datetime.field-label-hidden > div > div > span'

    description = getTagsContentFromSoup(soup, description_selector)

    location = getTagsContentFromSoup(soup, location_selector)

    date = getTagsContentFromSoup(soup, date_selector)

    return description, location, date

# def getHarvardPeabody(soup):
#
#     pass

def getHarvardFASLinguistics(soup):

    location_selector = 'div > div > section.field.field-name-field-event-location.field-type-text.field-label-inline.clearfix.view-mode-full > h2'

    location = getTagsContentFromSoup(soup, location_selector)

    return location

def getHarvardLaw(soup):

    location_selector = 'div.tribe-events-single-section.tribe-events-event-meta.primary.tribe-clearfix > div.tribe-events-meta-group.tribe-events-meta-group-venue > dl > dd'

    location = getTagsContentFromSoup(soup, location_selector)
    return location

def getUSGBC(soup):
    pass


def getTagsContentFromSoup(soup, selector):
    # def getEventURLS0(cal_url, cal_html, selector):
    #     soup = DataFilter.removeBadThings(cal_html)
    # a_tags = soup.select(selector)
    # event_urls = []
    # for a_tag in a_tags:
    #     href = a_tag['href']
    #     link = URLFilter.convertToAbsolute(cal_url, href)
    #     event_urls.append(link)
    # return event_urls

    tags = soup.select(selector)
    contents = []
    for tag in tags:
        tag_content = cleanhtml(str(tag))
        contents.append(tag_content)
    return ' '.join(contents)


def getName(source, samples):
    for node_id, tag in samples:
        if tag.name == 'h1':
            return 1, cleanhtml(str(tag))

def cleanhtml(raw_html):
    cleanr = re.compile('<[^<]+?>')
    cleantext = re.sub(cleanr, ' ', raw_html)
    cleantext = ' '.join(cleantext.split())
    return cleantext
import { NgModule } from '@angular/core';
import { AgnesNewsCard } from './agnes-news-card';
import { IonicPageModule } from 'ionic-angular';

@NgModule({
    declarations: [
        AgnesNewsCard
    ],
    imports: [
        IonicPageModule.forChild(AgnesNewsCard)
    ],
    exports: [
        AgnesNewsCard
    ],
})

export class AgnesNewsCardModule { }

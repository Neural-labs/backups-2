import logging
import robotparser
import urlparse

import tldextract
from bs4 import BeautifulSoup

robotParser = robotparser.RobotFileParser()
#disable tldextract stderr spam
tldlogger = logging.getLogger('tldextract')
tldlogger.setLevel('WARNING')

global domain

def getPageLinks(currentURL,HTML, source):
    global domain
    domain = getdomain(source)

    links = []
    if HTML == '':
        return links
    soup = BeautifulSoup(HTML,"lxml")

    for aTag in soup.findAll("a"):

        url = aTag.get('href')
        url = convertToAbsolute(currentURL,url)

        if invalidURL(url):
            continue

        # url = removeQueries(url)

        links.append(url)

    return set(links)

def removeQueries(url):
    parsed_url = urlparse.urlparse(url)
    return parsed_url.scheme + "://" +  parsed_url.netloc + parsed_url.path

def convertToAbsolute(baseURL, url):
    if not url:
        return url
    if url[:1] == '//':
        url = url[1:]
    if not (bool(urlparse.urlparse(url).netloc)):
        parsed_currentURL = urlparse.urlparse(baseURL)
        return parsed_currentURL.scheme + "://" + parsed_currentURL.netloc + url
    else:
        return url

def getdomain(url):
    ext = tldextract.extract(url)
    return ext.domain

def linkInDomain(link):
    global domain
    link_domain = getdomain(link)
    return link_domain == domain

# INVALID DOE
def invalidURL(url):

    if not url:
        return True

    if url == '#':
        return True

    if 'mailto' in url:
        return True

    if badExtension(url):
        return True

    if not linkInDomain(url):
        return True

    return False

def badExtension(link):
    badExtensions = [
        '.ics',
        '.pdf',
        '.cfm',
        '.jpg',
        '.jpeg',
        '.png',
        '.tiff',
        '.gif',
        '.mp3',
        '.mp4',
        '.aif',
        '.wav',
        '.7z',
        '.pkg',
        '.tar.gz',
        '.rar',
        '.z',
        '.zip',
        '.dmg',
        '.bin',
        '.vcd',
        '.iso',
        '.csv',
        '.dat',
        '.log',
        '.sql',
        '.tar',
        '.exe',
        '.xml',
        '.jar',
        '.fnt',
        '.ai',
        '.bmp',
        '.ico',
        '.ps',
        '.tif',
        '.svg'
    ]
    for ext in badExtensions:
        if ext in link:
            return True
    return False
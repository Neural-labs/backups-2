import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';

import { GroupListPopup } from './group-list-popup';
import { ComponentsModule } from '../../../components/components.module';

@NgModule({
    declarations: [
        GroupListPopup
    ],
    imports: [
        IonicPageModule.forChild(GroupListPopup),
        ComponentsModule
    ],
    exports: [
        GroupListPopup
    ],
})

export class GroupListPopupModule { }

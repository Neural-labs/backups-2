import { Component } from '@angular/core';
import { PopoverController, Events, Platform, IonicPage, ToastController, NavController, ViewController} from 'ionic-angular';

import { MeService } from '../../../providers/me.service';
import { LoginService } from '../../../providers/login.service';
import { AnalyticsService } from "../../../providers/analytics.service";

import { PasswordPopup } from '../../popups/password-popup/password-popup';

import { Agnes } from '../../../app/app.component';


@IonicPage()
@Component({
  selector: 'settings',
  templateUrl: 'settings.html',
  providers: [MeService, LoginService, AnalyticsService]
})
export class SettingsPage {
  user: Object;
  fromFB: boolean;
  hideProfile: boolean;
  theme: boolean;

  constructor(private meService: MeService,
              private loginService: LoginService,
              private popoverCtrl: PopoverController,
              private analyticsService:AnalyticsService,
              private platform: Platform,
              private toastCtrl: ToastController,
              private events: Events,
              public viewCtrl: ViewController) {
  }

  ngOnInit() {
    this.user = JSON.parse(localStorage.getItem('agnesUser'));
    this.fromFB = this.user['email']['fbid'] != '';
    this.hideProfile = !this.user['display'] ? true : false;
    // let data ={'users_id':this.user['_id']};
    // this.meService.getUserTheme(data).then(theme => {
    //   this.theme = theme;
    // });
  }

  hideMyProfile(){
    this.hideProfile = !this.hideProfile;

    let disp = (this.hideProfile) ? false : true;

    if (!this.user['display'] == disp) {
      let data = {
        "id":this.user['_id'],
        "display": disp
      };

      this.meService.hideProfile(data).then(value => {
        if (value){
          this.user['display'] = disp;
          this.events.publish('updateUser');
        }
        else {
          this.hideProfile = disp ? false : true;
          Agnes.showError("There was a problem hiding your profile - try again!");
        }
      }).catch(() => {
        this.hideProfile = disp ? false : true;
        Agnes.showError("There was a problem hiding your profile - try again!");
      });
    }
  }

  //TODO: possible future feature
  hideMyActivity(){
  }

  // toggleTheme(){
  //   let newTheme = !this.theme;
  //   let data = {
  //     'users_id':this.user['_id'],
  //     'theme':newTheme
  //   };
  //   this.meService.setUserTheme(data).then(value => {
  //     if(value) {
  //       this.theme = !this.theme;
  //     }
  //   });
  // }

  toChangePassword(){

    document.getElementById('userSettings').style.filter="blur(3vw)";
    let changePw = this.popoverCtrl.create(
      PasswordPopup,
      {'type':'Change',
      'user':this.user},
      {'enableBackdropDismiss':true}
    );
    changePw.present(
      {
        animate: true,
        animation: 'ios-transition',
        duration: 350,
        easing: "ease-in-out",
        direction: "forward"
      }
    );
    changePw.onDidDismiss(newUserData => {
      document.getElementById('userSettings').style.filter = "none";
    });
  }

  logout(){
    this.events.publish('logout');
  }

  closeSettings(data) {
    this.viewCtrl.dismiss(data, '', {
      animate: false,
      animation: 'ios-transition',
      duration: 350,
      easing: "ease-in-out",
      direction: "back"
    });
  }

  contactAgnes(){

    //send feedback analytics
    this.analyticsService.logAnalytics({community: this.user['community'], users_id: this.user['_id']}, '/sendFeedback');

    Agnes.socialSharing.canShareViaEmail().then(() => {
      // Sharing via email is possible
      let subj = "Questions/comments/concerns about Agnes!";
      let message = '\n\n--\n' +
        'Agnes version: ' + Agnes.version + '\n' +
        'Cordova version: ' + Agnes.device.cordova +'\n' +
        'os: ' + Agnes.device.platform + ' ' + Agnes.device.version + '\n' +
        'Device Id: ' + this.user['deviceid'] + '\n' +
        'Device brand: ' + Agnes.device.manufacturer + '\n' +
        'Device model: ' + Agnes.device.model + '\n' +
        'Screen width: ' + window.innerWidth + '\n' +
        'Screen height: ' + window.innerHeight + '\n' +
        'User ID: ' + this.user['_id'] + '\n' +
        'User email: ' + this.user['email']['uid'] + '\n';
      Agnes.socialSharing.shareViaEmail(message,subj,['admin@agnes.io']).then(() => {
        // Success!
      }).catch(() => {
        Agnes.showError("Agnes can't open your email client - feel free to send your own email to admin@agnes.io!");
      });
    }).catch(() => {
      Agnes.showError("Agnes can't find an email client on this device - please try again!");
    });
  }

  inviteFriends(){
    //send Invite Friends to App analytics
    this.analyticsService.logAnalytics({community: this.user['community'], users_id: this.user['_id']}, '/inviteFriends');


    if (this.platform.is('cordova')) {

      let link = 'http://onelink.to/hrnse3';

      let message = "Hey check out this new events app!\n" + link;

      let subj = "Agnes: new events app";

      Agnes.socialSharing.share(message, subj, '', '')
        .then((val) => {
        })
        .catch((err) => {
        Agnes.showError("Couldn't share the app with friends, try again!");
        });
    }
    else {
      Agnes.showError("Please install Agnes from the App Store or Google Play store to share groups.");
    }
  }

  connectFB(){
    Agnes.facebook.getLoginStatus().then(value => {

      if(value && value.status) {

        let upd = {
          access_token: '',
          users_id: this.user['_id']
        };

        if (value.status == 'connected') {
          upd['access_token'] = value['authResponse']['accessToken'];

          this.loginService.fbUpdate(upd).then(value => {

            this.loginService.getUser({"users_id":this.user['_id']}).then(value => {
              if (value) {
                this.user = value;
                this.fromFB = this.user['email']['fbid'] != '';
                localStorage.setItem('agnesUser', JSON.stringify(this.user));
              }
            }).catch(err => {
              console.log(err);
              this.fromFB = true;
              this.events.publish('updateUser');
            });
              let fbToast = this.toastCtrl.create({
                  message: 'Successfully connected with Facebook!',
                  position:'top',
                  duration: 2500,
                  showCloseButton: true,
                  closeButtonText: ' '
              });
            fbToast.present();

          }).catch(err => {
            console.log('fb after update error',err);
            Agnes.showError('Could not connect to Facebook - please try again!');
          });
        }
        else if (value.status == 'not_authorized') {
          Agnes.showError('Please allow Agnes access to your Facebook account!');
        }
        else {
          let permissions = ['public_profile',
            'user_friends',
            'email',
            'user_birthday',
            'user_managed_groups',
            'user_likes',
            'pages_show_list',
            'user_events'];

          Agnes.facebook.login(permissions).then(value => {

            if (value && value.status == 'connected') {
              upd['access_token'] = value['authResponse']['accessToken'];

              this.loginService.fbUpdate(upd).then(value => {
                  let fbToast = this.toastCtrl.create({
                      message: 'Successfully connected with Facebook!',
                      position:'top',
                      duration: 2500,
                      closeButtonText: ' ',
                      showCloseButton: true
                  });
                fbToast.present();

                this.loginService.getUser({"users_id":this.user['_id']}).then(value => {
                  if (value) {
                    this.user = value;
                    this.fromFB = this.user['email']['fbid'] != '';
                    localStorage.setItem('agnesUser', JSON.stringify(this.user));
                  }
                }).catch(err => {
                  console.log(err);
                  this.fromFB = true;
                  this.events.publish('updateUser');
              });
              }).catch(err => {
                console.log('fb after update error 2',err);
                Agnes.showError('Could not connect to Facebook - please try again!');
              });
            }
            else {
              Agnes.showError('Could not connect to Facebook - please try again!');
            }
          }).catch(error => {
            console.log('Facebook.login error', error);
            Agnes.showError('Could not connect to Facebook - please try again!');
          });
        }
      }
    }).catch(error => {Agnes.showError('Could not connect to Facebook - please try again!')});
  }

  readPrivacy() {
    //send Read Privacy analytics
    this.analyticsService.logAnalytics({community: this.user['community'], users_id: this.user['_id']}, '/readPrivacy');

    window.open("https://www.iubenda.com/privacy-policy/7883920");
  }

  openTermsOfUse(){
    //send terms of use analytics
    this.analyticsService.logAnalytics({community: this.user['community'], users_id: this.user['_id']}, '/termOfUse');

    window.open("http://agnes.io/terms");
  }
}

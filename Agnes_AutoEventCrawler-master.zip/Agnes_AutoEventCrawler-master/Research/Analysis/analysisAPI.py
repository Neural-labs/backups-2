from extractionAnalysis import ExtractionTraining, ExtractionTesting
from detectionAnalysis import DetectionTraining, DetectionTesting
from clusteringAnalysis import Clustering

def train_id_classifier():
    DetectionTraining.runClassificationTraining()

def test_id_classifier():
    DetectionTesting.testClassifier()

def train_ext_classifier(model_type):
    ExtractionTraining.runExtractionTraining(model_type)

def test_ext_classifier():
    ExtractionTesting.testExtraction()

def test_clustering(detect):
    Clustering.runClustering(detect=detect)
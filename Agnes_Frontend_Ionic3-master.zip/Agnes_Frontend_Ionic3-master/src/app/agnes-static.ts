// import { Injectable } from '@angular/core';
// import { PopoverController, ToastController, ModalController, Platform } from 'ionic-angular';
// import { EventsService } from '../providers/events.service';
// import { GroupsService } from '../providers/groups.service';
//
//
// @Injectable()
// export class AgnesStatic {
//
//     constructor(public toastCtrl: ToastController,
//                 public popoverCtrl: PopoverController,
//                 public modalCtrl: ModalController,
//                 public platform: Platform,
//                 public eventsService: EventsService){
//
//     }
//
//     static processGMT(date){
//         let x = new Date(date);
//         let d = new Date(x.toLocaleDateString()).toDateString().match(/[a-zA-Z]{3} [a-zA-Z]{3} \d\d/)[0];
//         d = d.replace(/([a-zA-Z]{3})(\s[a-zA-Z]{3}\s)(\d{2})/, "$1,$2$3");
//         d = d.replace(',','.');
//         let t = x.toLocaleTimeString().replace(/:\d\d\s/,'').replace(/\s[a-zA-Z]{3}/,'');
//         return {'date':d, 'time': t};
//     }
//
//     static showError(message, buttons?, full?){
//         let agnesAlert = this.modalCtrl.create('AgnesAlert',
//             {
//                 alertMessage: message,
//                 alertButtons: buttons,
//                 fullButtons: full
//             });
//         agnesAlert.onDidDismiss(() => {
//             this.removeFilter();
//         });
//
//         for (var e = 0; e < document.getElementsByTagName("ion-popover").length; e++){
//             document.getElementsByTagName("ion-popover")[e]["style"]["filter"]="blur(3vw)";
//         }
//         document.getElementsByTagName("ng-component")[0]["style"]["filter"]="blur(3vw)";
//         agnesAlert.present();
//     }
//
//     static removeFilter(){
//         for (var e = 0; e < document.getElementsByTagName("ion-popover").length; e++){
//             document.getElementsByTagName("ion-popover")[e]["style"]["filter"]="none";
//         }
//         document.getElementsByTagName("ng-component")[0]["style"]["filter"]="none";
//     }
//
//     static hasPlugins() {
//         return this.platform.is('cordova');
//     }
//
//     /********************************************************************************************/
//     /**************************** ATTEND EVENT FUNCTIONS ****************************************/
//     /********************************************************************************************/
//
//     static going(event, matched){
//
//         let user = JSON.parse(localStorage.getItem('agnesUser'));
//         let flaginfo = {
//             "users_id": user['_id'],
//             "events_id": event['_id'],
//             "flag": 1,
//             "matched": matched
//         };
//
//         this.loading = true;
//
//         this.eventsService.sendFlag(flaginfo)
//             .then(value => this.setAttendance(event, value, flaginfo,matched))
//             .catch( error => {
//                 this.loading = false;
//                 this.showError("Sorry, could not add " + event['evtname'] + " to your attended events list right now - try again later!");
//                 this.evts.publish('goingDone',false);
//             });
//     }
//
//     static setAttendance(event, value, flaginfo, matched){
//
//         if (value==0){
//             this.eventsService.attendEvent(flaginfo)
//                 .then(attendResult => this.goingResponse(attendResult,event,matched))
//                 .catch(error => {
//                     console.log(error);
//                     this.evts.publish('goingDone',false);});
//         }
//         else {
//             this.loading = false;
//             let template = "Sorry, could not add " + event['evtname'] + " to your attended events list right now - try again later!";
//             this.showError(template);
//             this.evts.publish('goingDone',false);
//         }
//     }
//
//     static goingResponse(attendResult,event,matched){
//
//         let user = JSON.parse(localStorage.getItem('agnesUser'));
//         this.evts.publish('updateUser');
//
//         if (attendResult.indexOf('SUCCESS')!=-1) {
//             user['evtrsvp'].push(event['_id']);
//
//             localStorage.removeItem('agnesMatchedEvents');
//             localStorage.removeItem('agnesEventsTimeout');
//
//             if (this.plt.is('cordova')) {
//                 this.addToCalendar(event, matched);
//             }
//             else {
//                 this.loading = false;
//                 let toast = this.toastCtrl.create({
//                     message: event['evtname'] + ' was successfully added to your events',
//                     position:'top',
//                     showCloseButton: true,
//                     closeButtonText: ' ',
//                     duration: 2500
//                 });
//                 toast.present();
//
//                 this.evts.publish('goingDone',event);
//             }
//         }
//         else {
//             this.loading = false;
//             let message = "Sorry, could not add " + event['evtname'] + " to your attended events list right now - please try again!";
//             this.showError(message);
//             this.evts.publish('goingDone',false);
//         }
//     }
//
//     static addToCalendar(event, matched){
//         let t = event['evtname'];
//         let title = t.replace(/\s+/g, ' ');
//         let eventloc = event['location'];
//         let eventLocation = eventloc.replace(/\s+/g, ' ');
//         let n = event['evtdesc'];
//         let notes = n.replace(/\s+/g, ' ').substring(0,2000);
//
//         let startDate = new Date(event['starttime'].replace(/[-\+]\d\d\d\d/,'Z'));
//         let endDate = new Date(event['endtime'].replace(/[-\+]\d\d\d\d/,'Z'));
//
//         this.calendar.findEvent(title,'','',startDate,endDate).then(message => {
//             if (message['length'] == 0){
//                 //event is not in calendar - add
//                 this.calendar.createEvent(title,eventLocation,notes,startDate,endDate).then(msg => {
//                     this.loading = false;
//
//                     //make sure user is updated
//                     let user = JSON.parse(localStorage.getItem('agnesUser'));
//                     if(user['evtrsvp'].indexOf(event['_id']) == -1) {
//                         user['evtrsvp'].push(event['_id']);
//                         localStorage.setItem('agnesUser',JSON.stringify(user));
//                     }
//
//                     this.evts.publish('goingDone',event);
//
//                     let toast = this.toastCtrl.create({
//                         message: event['evtname'] + ' was successfully added to your calendar',
//                         position:'top',
//                         showCloseButton: true,
//                         closeButtonText: ' ',
//                         duration: 2500
//                     });
//                     toast.present();
//
//                     let inFive = new Date(new Date().getTime() + 5000);
//
//                     // Schedule local notification for rating
//                     // this.localNotifications.schedule({
//                     //   text: '',
//                     //   at: inFive,
//                     //   data: event
//                     // });
//
//                 }).catch(err => {
//                     this.loading = false;
//                     Agnes.showError("This event was successfully added to your list of events but there was a problem adding " +
//                         "it to your calendar - please try again!");
//                 });
//             }
//             else {
//                 //event is already in calendar - just show event add success message
//                 this.loading = false;
//                 let toast = this.toastCtrl.create({
//                     message: event['evtname'] + ' was successfully added to your events',
//                     position:'top',
//                     showCloseButton: true,
//                     closeButtonText: ' ',
//                     duration: 2500
//                 });
//                 toast.present();
//
//                 //make sure user is updated
//                 let user = JSON.parse(localStorage.getItem('agnesUser'));
//                 if(user['evtrsvp'].indexOf(event['_id']) == -1) {
//                     user['evtrsvp'].push(event['_id']);
//                     localStorage.setItem('agnesUser',JSON.stringify(user));
//                 }
//
//                 this.evts.publish('goingDone',event);
//             }
//         }).catch(err => {
//             Agnes.showError("This event was successfully added to your list of events but " +
//                 "there was a problem adding it to your calendar - make sure Agnes has calendar access and try again!");
//             this.loading = false;
//             this.evts.publish('goingDone',false);
//         });
//     }
//
//     /*****************************************************************************************************/
//     /**************************** UNATTEND/REMOVE EVENT FUNCTIONS ****************************************/
//     /*****************************************************************************************************/
//
//     static notGoing(event, matched){
//         let user = JSON.parse(localStorage.getItem('agnesUser'));
//         let eventFlag = (user["evtrsvp"].indexOf(event['_id']) != -1) ? 0 : -1;
//
//         //send flag that user is not attending
//         //flag is -1 if user has not indicated he/she wants to attend (delete event from events list)
//         //flag is 0 if user did want to attend but has changed his/her mind (leave event in events list, remove 'going' indicator)
//         let flagInfo = {
//             "users_id": user["_id"],
//             "events_id": event['_id'],
//             "flag": eventFlag,
//             "matched": matched
//         };
//
//         this.eventsService.sendFlag(flagInfo)
//             .then(value => {
//                 //user was previously going to attend event, so set unattendance
//                 if (flagInfo.flag == 0) {
//                     this.setUnattend(value, flagInfo,event, matched);
//                 }
//                 //user was never going to attend, skip setting unattendance
//                 else {
//                     this.nopeResponse('SUCCESS', flagInfo.flag, event, matched);
//                 }
//             })
//             .catch(error => {
//                 console.log(error);
//                 Agnes.showError("Sorry, could not remove " + event['evtname'] + " from your attended events list right now " +
//                     "- try again later!");
//             });
//     }
//
//     static setUnattend(value, flagInfo, event, matched) {
//         if (value == 0) {
//             this.eventsService.unattendEvent(flagInfo)
//                 .then(attendResult => this.nopeResponse(attendResult, flagInfo['flag'], event, matched))
//                 .catch(error => {
//                     console.log(error)
//                 });
//         }
//         else {
//             let template = "There was a problem removing this event, so you may still see it on your events list in the " +
//                 "future. Try removing it later if you do!";
//             Agnes.showError(template);
//         }
//     }
//
//     static nopeResponse(attendResult, eventFlag, event, matched) {
//         let user = JSON.parse(localStorage.getItem('agnesUser'));
//
//         if (attendResult.indexOf('SUCCESS') != -1) {
//
//             let ind = user['evtrsvp'].indexOf(event["_id"]);
//
//             //remove event from user's evtrsvp if user was previously going to attend event
//             if (ind != -1) {
//                 user['evtrsvp'].splice(ind, 1);
//                 localStorage.setItem('agnesUser',JSON.stringify(user));
//                 this.evts.publish('updateUser');
//             }
//
//             //remove event from user's displayed matched events
//             this.evts.publish('removeFromMatched', event);
//
//             if (this.plt.is('cordova') && eventFlag == 0) {
//                 this.removeFromCalendar(event, eventFlag, matched);
//             }
//             else {
//                 this.evts.publish('notGoingDone',event);
//                 let toast = this.toastCtrl.create({
//                     message: event['evtname'] + ' was successfully removed from your events',
//                     position: 'top',
//                     showCloseButton: true,
//                     closeButtonText: ' ',
//                     duration: 2500
//                 });
//                 toast.present();
//             }
//         }
//         else {
//             let template = "There was a problem removing this event, so you may still see it on your events list in the " +
//                 "future. Try removing it later if you do!";
//             Agnes.showError(template);
//         }
//     }
//
//     static removeFromCalendar(event, eventFlag, matched) {
//
//         let title = event.evtname.replace(/\s+/g, ' ');
//
//         let startDate = new Date(event['starttime'].replace(/[-\+]\d\d\d\d/, 'Z'));
//         let endDate = new Date(event['endtime'].replace(/[-\+]\d\d\d\d/, 'Z'));
//         endDate.setDate(endDate.getDate() + 1);
//
//         this.calendar.deleteEvent(title, '', '', startDate, endDate).then(message => {
//             let popupMessage = event.evtname + " was removed from your " + (message ? "calendar" : "event list") + "!";
//
//             this.evts.publish('notGoingDone',event);
//
//             let toast = this.toastCtrl.create({
//                 message: popupMessage,
//                 position: 'top',
//                 showCloseButton: true,
//                 closeButtonText: ' ',
//                 duration: 2500
//             });
//             toast.present();
//         }).catch(err => {
//             Agnes.showError(event['evtname'] +
//                 " was removed from your event list but there was a problem deleting it from your calendar.");
//         });
//     }
//
//     static undoNope(event, eventFlag, matched) {
//         let user = JSON.parse(localStorage.getItem('agnesUser'));
//
//         //user was undecided about event, reset event flag to 0
//         if (eventFlag == -1) {
//             let flaginfo = {
//                 "users_id": user['_id'],
//                 "events_id": event['_id'],
//                 "flag": 0,
//                 "matched": true
//             };
//
//             this.eventsService.sendFlag(flaginfo)
//                 .then(value => {
//                     this.evts.publish('pushEvent', event);
//                 })
//                 .catch(error => {
//                     console.log(error);
//                     Agnes.showError("Sorry, could not add " + event['evtname'] +
//                         " back into your events list right now - please try again!");
//                 });
//         }
//         //user was going to attend event, add event back into user's rsvp list and update event attendance count
//         else {
//             this.going(event, matched);
//         }
//     }
// }
import time
import logging
import string
import numpy as np
import re
from Utility_Modules import DateExtraction, LocationExtraction, DataFilter
from bs4 import BeautifulSoup
from collections import Counter

def extractFeaturesManual(text):

    features = []

    features += manualGeneral(text)

    features += manualLocation(text)

    date_start = time.time()
    features += manualDate(text)
    date_end = time.time()
    datetime = date_end-date_start
    if datetime > 1:
        logging.info(('Date',datetime))

    return features

def manualGeneral(text):
    html_text = removeRealContent(text)
    content_text = cleanhtml(text)

    lower_html = html_text.lower()
    lower_html_nohref = removeHref(lower_html)
    lower_content = content_text.lower()
    length = len(lower_content)

    keywords = ['title', 'description', 'desc', 'location', 'locat','name', 'date', 'summary', 'event', 'content', 'field', 'address',
                'venue', 'time', 'when', 'where', 'start', 'end', 'map', 'calendar', 'cal', 'from', 'to', 'building', 'hall', 'auditorium',
                'room', 'clock', 'street', 'locality', 'theatre', 'theater']

    content_length = len(content_text)  # int
    html_length = len(lower_html_nohref)  # int
    num_content_words = len(removePunctuation(lower_content))  # int
    num_html_words = len(removePunctuation(lower_html_nohref))  # int
    capital_ratio = float(sum(1 for c in content_text if c.isupper())) / float(length)  # float

    avg_content_word_len = getAvgWordLength(lower_content)  # float
    avg_content_sen_len = getAvgSentenceLength(lower_content)  # float

    punc_counts = getKeywordCount(string.punctuation, lower_content)  # list
    content_keywords = getKeywordCount(keywords, lower_content)  # list
    html_keywords = getKeywordCount(keywords, lower_html_nohref)  # list
    tag_counts = getTagCount(lower_html) # list

    features = [content_length, html_length, num_content_words, num_html_words, capital_ratio, avg_content_word_len,
                avg_content_sen_len]

    features += punc_counts
    features += content_keywords
    features += html_keywords
    features += tag_counts

    return features

# def manualNameDesc(text):
#
#     # punctuation = ',.:!?\''
#     # keywords = ['title', 'description']
#     # content = cleanhtml(text).lower()
#
#     # length = len(text)
#     # keyword_count = len([item for item in text.lower().split() if item in keywords])
#     # capital_ratio = float(sum(1 for c in content if c.isupper())) / float(length)
#     # punc_count = len([content.count(punc) for punc in punctuation])
#
#     # features = [length, keyword_count, capital_ratio, punc_count]
#
#     return features

def manualLocation(text):

    text = cleanhtml(text)
    text = cleanString(text)

    usaddr_location_fields = LocationExtraction.getUSAddressFields()
    postal_location_fields = LocationExtraction.getPostalFields()
    features = []

    us_addr = LocationExtraction.getRawUSAddress(text)
    postal_addr = LocationExtraction.getRawPostalAddress(text)

    for field in usaddr_location_fields:
        features.append(len([item for item in us_addr if item[1] == field]))

    for field in postal_location_fields:
        features.append(len([item for item in postal_addr if item[1]==field]))
    # locations = len(LocationExtraction.getLocations(text))

    return features

def manualDate(text):
    text = cleanhtml(text)
    dates = len(DateExtraction.getDates(text))

    return [dates]

def extractFeaturesContent(embedding_model, text):
    tokens = tokenizeW2V(text)

    vectors = [embedding_model.wv[token] for token in tokens if token in embedding_model.wv]

    if not vectors:
        return None

    feature_vector = np.mean(np.vstack(vectors).astype(np.float16), axis=0)

    return feature_vector


def extractFeaturesHTML(embedding_model, text):
    tokens = tokenizeH2V_W(text)

    if not tokens:
        return None

    vectors = [embedding_model.wv[token] for token in tokens if token in embedding_model.wv]

    if not vectors:
        return None

    feature_vector = np.mean(np.vstack(vectors).astype(np.float16), axis=0)

    return feature_vector

def tokenizeW2V(content):
    content = cleanhtml(content)
    content = removePunctuation(content)
    return [word for word in content.split() if word]

def tokenizeH2V_W(content):
    content = content.replace('\n','')
    html_content = removeRealContent(content)
    html_soup = BeautifulSoup(html_content, 'lxml')
    body = html_soup.find('body')
    if not body:
        logging.info('Sample has wrong html, removing...')
        return None
    tags = body.findChildren()
    h2v_string = ''
    for tag in tags:
        if hasattr(tag,'attrs') and hasattr(tag,'name'):
            h2v_string += tag.name + ' '
            for attr in tag.attrs:
                value = tag[attr]
                if isinstance(value, list):
                    for val in value:
                        h2v_string += val+' '
                else:
                    h2v_string += value+' '
    return [word for word in ' '.join(h2v_string.split()).split() if word]

def getTagCount(html):
    html = cleanString(html)

    pattern = re.compile('(<)([\w]*?)[ >]')
    tags = Counter([item[1] for item in re.findall(pattern, html)])

    valid_tags = DataFilter.ValidTags

    if not tags:
        return [0]*len(valid_tags)

    tag_counts = []
    for tag in valid_tags:
        if tag in tags:
            tag_counts.append(tags[tag])
        else:
            tag_counts.append(0)

    return tag_counts

def getKeywordCount(keyword_list, content):
    counts = []
    for item in keyword_list:
        counts.append(content.count(item))
    return counts

def getAvgWordLength(content):
    content = removePunctuation(content)
    avg_word_len = np.mean([len(word) for word in content.split()])
    return avg_word_len

def getAvgSentenceLength(content):
    avg_sen_len = np.mean([len(sen) for sen in content.split('.')])
    return avg_sen_len

def cleanString(content):
    content = content.replace('\n','')
    content = content.replace('\t','')
    content = ' '.join(content.split())
    return content

def removePunctuation(content):
    for char in string.punctuation:
        content = content.replace(char, ' ')
    return ' '.join(content.split())

def removeHref(raw_html):
    pattern = re.compile('href=".*?"')
    html_sans_href = re.sub(pattern, '', raw_html)
    return html_sans_href

def cleanhtml(raw_html):
    cleanr = re.compile('<[^<]+?>')
    cleantext = re.sub(cleanr, ' ', raw_html)
    cleantext = ' '.join(cleantext.split())
    return cleantext

def removeRealContent(content):
    pattern = re.compile('>.+?<')
    cleancontent = re.sub(pattern, '><', content)
    cleancontent = ' '.join(cleancontent)
    return cleancontent
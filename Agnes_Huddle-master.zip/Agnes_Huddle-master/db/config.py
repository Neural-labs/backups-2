from pymongo import MongoClient
conn = MongoClient("mongodb://arpit:groupten123!@agnesdatabase-shard-00-00-1mhnx.mongodb.net:27017,agnesdatabase-shard-00-01-1mhnx.mongodb.net:27017,agnesdatabase-shard-00-02-1mhnx.mongodb.net:27017/<DATABASE>?ssl=true&replicaSet=AgnesDatabase-shard-0&authSource=admin", connect=False)


def getNewConn():
    return MongoClient("mongodb://arpit:groupten123!@agnesdatabase-shard-00-00-1mhnx.mongodb.net:27017,agnesdatabase-shard-00-01-1mhnx.mongodb.net:27017,agnesdatabase-shard-00-02-1mhnx.mongodb.net:27017/<DATABASE>?ssl=true&replicaSet=AgnesDatabase-shard-0&authSource=admin")
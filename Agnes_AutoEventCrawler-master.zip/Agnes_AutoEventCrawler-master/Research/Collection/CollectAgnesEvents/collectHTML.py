"""
Module to collect HTML for newly inputted events from other crawlers

"""
import os
import socket
import urlparse
import requests
import urllib3
from Utilities import DataFilter, EventTree
import pickle
from config import db_config
import logging
import gc
from bson.objectid import ObjectId
from multiprocessing import cpu_count, JoinableQueue, Pool
from bson import Binary

dbConn = db_config.getDBConn('dev')
Agnes = dbConn.Agnes
Event_Collection = Agnes.autocrawler_events
Events_V2_Collection = Agnes.autocrawler_events_v2

batch_size = 100

def collectHTML():
    print 'Collecting HTML for samples'
    eventsCursor = posGenerator(Event_Collection)

    master(eventsCursor)

    eventsV2Cursor = posGenerator(Events_V2_Collection)

    # eventsV2Cursor = getEventsV2()

    master(eventsV2Cursor)

# last_id = ObjectId('59b4cb65aefa5b6bea1c5ce8')
def posGenerator(collection):
    total_samples = collection.count()
    counter = 0
    last_id = ObjectId('5ae57ea1aefa5b7f521d8457')
    found = None
    while True:
        batch = getEventBatchCursor(collection, last_id)
        batch_count = batch.count(with_limit_and_skip=True)

        if not batch or not batch_count:
            print 'First Id = ',found
            print 'Finished with last_id = ', last_id
            break

        last_id = batch[batch_count-1]['_id']

        for item in batch:
            counter += 1
            if counter % 100 == 0:
                logging.info('Pos Generator - %d of %d, LastID: %s' % (counter, total_samples, str(last_id)))
            if not invalidEventObj(item):
                if not found:
                    found = item['_id']
                yield item

        del batch
        gc.collect()

def getEventBatchCursor(collection, last_id):
    if not last_id:
        return collection.find({}, no_cursor_timeout=True).limit(batch_size).sort('_id',1)
    return collection.find({'_id': {'$gt': last_id}}, no_cursor_timeout=True).limit(batch_size)

def getEventsV2():
    return Events_V2_Collection.find({}, no_cursor_timeout=True)

def master(eventsCursor):

    NUM_THREADS = cpu_count()
    # NUM_THREADS = 1
    # NUM_THREADS = 13
    print 'Spawning', NUM_THREADS, 'Workers...'

    QUEUE_MAXSIZE = 50

    queue = JoinableQueue(QUEUE_MAXSIZE)

    pool = Pool(NUM_THREADS, worker, (queue,))
    counter = 0
    for eventObj in eventsCursor:
        if not counter % 50:
            print 'Progress:',counter
        if invalidEventObj(eventObj):
            continue
        counter += 1
        queue.put((eventObj, counter), block=True)



def worker(queue):
    worker_id = os.getpid()
    worker_dbConn = db_config.getNewClientDBConn()
    events_collection = worker_dbConn.Agnes.autocrawler_events
    print worker_id, 'Alive'
    while True:
        try:
            eventObj,counter = queue.get(True)
            print 'Worker received page:',counter
            url = eventObj['weburl'][0]

            error, response = sendHTTPCall(url)

            if not error:
                print 'Worker', worker_id, ' working on counter - ', counter
                HTML = response
                eventObj['HTML'] = HTML
                eventObj['url'] = DataFilter.normalizeURL(url)
                updateEvent(events_collection, eventObj)
                print 'Success: ', eventObj['_id']
                # event_tree = EventTree.EventTree(HTML=HTML, event=eventObj)
                # if event_tree.get_event_nodes():
                #     event_tree_pkl = Binary(pickle.dumps(event_tree))
                #     eventObj['HTML'] = HTML
                #     eventObj['url'] = DataFilter.normalizeURL(url)
                #     eventObj['netx_tree_pkl'] = event_tree_pkl
                #     updateEvent(events_collection, eventObj)
                #     print 'Success: ',eventObj['_id']

            queue.task_done()

        except KeyboardInterrupt as e:
            print 'Worker', worker_id, 'stopping'
            exit()

def invalidEventObj(eventObj):
    skip_sources = ['events.citypaper.com', 'guevents.georgetown.edu', 'thebridge.cmu.edu', 'nest.cua.edu',
                    'hoyalink.georgetown.edu',
                    'howard.campuslabs.com', 'temple.campuslabs.com', 'involved.towson.edu', 'studentcentral.udel.edu',
                    'gobblerconnect.vt.edu',
                    'johnshopkins.campuslabs.com', 'dspshows.com', 'wexarts.org', 'blackcatdc.com', 'ticketmaster']
    if 'HTML' in eventObj and '<head>' in eventObj['HTML']:
        return True
    if invalidURL(eventObj):
        if eventObj['weburl']:
            print 'Skipping: ' + eventObj['weburl'][0]
        return True
    if eventObj['evtsource'] in skip_sources:
        return True
    if 'netx_tree_pkl' in eventObj:
        return True
    return False

def invalidURL(eventObj):
    if len(eventObj['weburl']) == 0 or 'agnes' in eventObj['weburl'][0]:
        return True

    url = eventObj['weburl'][0]

    parsed_url = urlparse.urlparse(url)
    if not bool(parsed_url.scheme) or len(url) == 0:
        return True
    return False

def sendHTTPCall(url):
    print 'Sending:',url
    try:
        response = requests.get(url,timeout=10)
        print 'Error?'
        return False, response.text
    except Exception as e:
        print 'Error: ',e
        return True,''

def nameInHTML(eventName,HTML):
    result = eventName in HTML
    return result

def filterHTML(events):
    for event in events:
        if 'HTML' not in event:
            removeElement(event)


def updateEvent(collection, event):
    collection.update({"_id":event['_id']},{'$set':{"HTML":event['HTML'], 'netx_tree_pkl':event['netx_tree_pkl']}},upsert=False)

def removeElement(event):
    Event_Collection.remove({'_id':event['_id']})

def setPrevCrawled(event):
    Event_Collection.find_one_and_update({"_id": event['_id']}, {'$set': {"prevCrawled": True}}, upsert=False)

def setNotPrevCrawled(event):
    Event_Collection.find_one_and_update({"_id": event['_id']}, {'$set': {"prevCrawled": False}}, upsert=False)

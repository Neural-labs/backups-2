import { Component, Input, ViewChild  } from '@angular/core';
import { App, Events, PopoverController, Platform, ActionSheetController, Content } from 'ionic-angular';
import { EventsService } from '../../providers/events.service';
import { GroupsService } from '../../providers/groups.service';
import { PeopleService } from '../../providers/people.service';
import { MeService } from '../../providers/me.service';
import { Agnes } from '../../app/app.component';
import * as Bodymovin from 'bodymovin';

/**
 * card component for feed items
 */

@Component({
    selector: 'agnes-feed-card',
    templateUrl: 'agnes-feed-card.html',
    providers: [EventsService, GroupsService, PeopleService, MeService],

})
export class AgnesFeedCardComponent {


    @Input() object: Object;
    @Input() searchTerm: string;
    @Input() parentContent: any;

    objName: string;
    objDesc: string;
    objFullImg: string;

    user: Object;
    message: string;
    trailingMessage: string;
    type: string;
    objClass: string;
    userString: string;
    reminderDate: string;
    textLimit: number;
    menuButtons: Array<Object>;

    canOpenProfile: boolean;

    //isInterested = interested or attending for events, following or member for groups
    isInterested: boolean;
    isAdmin: boolean;

    constructor(public appCtrl: App,
                private events: Events,
                private platform: Platform,
                private popoverCtrl: PopoverController,
                private actionSheetCtrl: ActionSheetController,
                private groupsService: GroupsService,
                private meService: MeService,
                private eventsService: EventsService) {
    }

    ngOnInit(){
        this.user = JSON.parse(localStorage.getItem('agnesUser'));
        this.type = this.object['type'];

        this.objName = this.type == 'Groups' ? this.object['entity']['grpname'] :
            this.type == 'Events' ? this.object['entity']['evtname'] : this.object['entity']['name'];

        this.objDesc = this.object['label'] == 'Group Update' ? this.object['entity']['status_quo']
            : this.type == 'Groups' ? this.object['entity']['grpdesc']
            : this.type == 'Events' ? this.object['entity']['evtdesc']
            : this.object['entity']['content'].filter(x => x['type'] == 'text').map(x => x['content']).join('\n\n');

        this.objFullImg = this.object['entity']['picurl'];

        this.objClass = this.object['label'].toLowerCase().replace(' ', '_')
            + (this.object['label'] == 'Recently Added' || this.object['label'] == 'Discover' || this.object['label'] == 'Featured'
                ? this.type == 'Events' ? '_event' : '_group' : '');

        this.textLimit = this.object['label'] == 'Group Update' ? this.objDesc.length : 90;

        this.object['entity']['users'] = this.object['entity']['users'] ? this.object['entity']['users'] :[];

        this.isAdmin = this.type == 'Events' || this.type == 'Groups'
            ? this.object['entity']['admin'] && this.object['entity']['admin'].indexOf(this.user['_id']) != -1 : false;
        this.isInterested = this.type == 'Events'
            ? this.user['evtinterest'].indexOf(this.object['entity']['_id']) != -1
            || this.user['evtrsvp'].indexOf(this.object['entity']['_id']) != -1
            : this.object['label'] == 'Group Update' ? false
                : this.type == 'Groups'
                    ? this.object['entity']['followers'].indexOf(this.user['_id']) != -1
                    || this.object['entity']['members'].indexOf(this.user['_id']) != -1
                    : false;

        if(this.type == 'Events'){
            let date = Agnes.processGMT(this.object['entity']['starttime']);
            this.object['month'] = date['date'].substring(5,8).toUpperCase();
            this.object['date'] = parseInt(date['date'].substring(9,11));

            this.userString = this.object['entity']['users']
                ? this.object['entity']['users'].filter((x, ind) => {
                    return ind < 2
                }).map(x => x['fname'] + ' ' + x['lname']).toString().replace(',', ', ')
                : '';

            if(this.object['label'] == 'Reminder') {
                let today = new Date().toLocaleDateString();
                this.reminderDate = new Date(this.object['entity']['starttime']).toLocaleDateString() == today
                    ? 'today' : 'tomorrow';
            }
        }

        if(this.object['action'].toLowerCase() == 'share to contacts'
            || this.object['label'].toLowerCase() == 'recently added'
            && this.type != 'News') {
            this.setMenuButtons();
        }

        this.canOpenProfile = true;

        this.getMessage();
        this.getTrailingMessage();
    }

    //set up action sheet menu buttons for sharing object to users, groups, or outside of app
    setMenuButtons(){
        this.menuButtons = [];

        // add Share to Group button if user is admin of at least one group
        if(this.user['grp'].map(a => a['admin']).indexOf(true) != -1){
            this.menuButtons.push({
                text: 'Share to Group',
                icon: 'md-contacts',
                handler: () => {this.shareToGroup();}
            });
        }

        this.menuButtons.push({
            text: 'Share to Friends',
            icon: 'md-person',
            handler: () => {this.shareToFriends();}
        });

        this.menuButtons.push({
            text: 'Share outside Agnes',
            icon: 'md-share-alt',
            handler: () => {this.shareOutside();}
        });

        this.menuButtons.push({
            text: 'Cancel',
            role: 'cancel',
            icon: 'md-close',
            handler: () => {}
        });


    }

    getMessage(){
        switch(this.object['label'].toLowerCase()) {
            case 'reminder':
                this.message = 'Don\'t forget ';
                break;
            case 'recommended':
                this.message = 'We think you\'ll like ';
                break;
            // case 'event update':
            //     this.message = (this.object['entity']['users'].length > 0
            //         ? 'and '
            //         + (this.object['entity']['users'].length > 2 ? (this.object['entity']['users'].length - 2) :
            //             (this.object['entity']['users'].length - 1)) + ' of your friends are ' : 'is ')
            //     + 'interested in ';
            //     break;
            default:
                this.message = '';
                break;
        }
    }

    getTrailingMessage() {
        let label = this.object['label'].toLowerCase();
        switch(label) {
            case 'reminder':
                this.trailingMessage = 'is ';
                break;
            case 'group update':
                this.trailingMessage = 'updated its status';
                break;
            case 'event update':
                this.trailingMessage = 'has been updated';
                break;
            default:
                this.trailingMessage = '';
                break;
        }

        if(label == 'reminder' || label == 'group update') {
            let limit = 100 - this.message.length - this.trailingMessage.length
                - (label == 'reminder' ? this.reminderDate.length : 0);

            let ell = this.objName.length >= limit ? '...' : '';

            this.objName = this.objName.substring(0, limit - ell.length) + ell;
        }
    }

    //open event, group, or news profile, depending on type of card
    openObjProfile(){
        if(this.canOpenProfile){
            this.canOpenProfile = false;
            if(this.type == 'Groups'){
                //open group profile
                this.groupsService.getGroupsFromId({'grp':[this.object['entity']['_id']]}).then(val => {
                    if(val && val[0]) {
                        let grpProfile = this.popoverCtrl.create('GroupProfile',{
                            'group':val[0]
                        }, {});

                        grpProfile.present({
                            animation: 'ios-transition',
                            duration: 350
                        });

                        grpProfile.onDidDismiss(newGrp => {
                            this.canOpenProfile = true;
                            if(newGrp){
                                //TODO: update group
                                // this.user = JSON.parse(localStorage.getItem('agnesUser'));
                                // this.object['entity'] = newGrp;
                            }
                        });
                    }
                    else {
                        Agnes.showError("Sorry, could not open this group profile - try again!");
                    }
                }).catch(err => {
                    console.log(err);
                    Agnes.showError("Sorry, could not open this group profile - try again!");
                });
            }
            else if (this.type == 'Events') {

                this.eventsService.getEventsFromId({
                    'evt':[this.object['entity']['_id']],
                    'community': this.user['community']
                }).then(val => {
                    if(val && val[0]) {
                        val[0]['picurl'] = this.object['entity']['picurl'];

                        let evtProfile = this.popoverCtrl.create('EventProfile',{
                            'event': val[0]
                        }, {});

                        evtProfile.present({
                            animation: 'ios-transition',
                            duration: 350
                        });

                        evtProfile.onDidDismiss(newEvt => {
                            this.canOpenProfile = true;
                            if(newEvt){
                                //update event
                                // this.user = JSON.parse(localStorage.getItem('agnesUser'));
                                // this.object['entity'] = newEvt;
                            }
                        });
                    }
                    else {
                        Agnes.showError("Sorry, could not open this event profile - try again!");
                    }
                }).catch(err => {
                    console.log(err);
                    Agnes.showError("Sorry, could not open this event profile - try again!");
                });
            }
            else {
                let newsProfile = this.popoverCtrl.create('NewsProfile',{
                    'newsItem': this.object['entity']
                }, {});

                newsProfile.present({
                    animation: 'ios-transition',
                    duration: 350
                });

                newsProfile.onDidDismiss(newNews => {
                    this.canOpenProfile = true;
                    if(newNews){
                        //TODO: update news item
                        // this.user = JSON.parse(localStorage.getItem('agnesUser'));
                        // this.object['entity'] = newGrp;
                    }
                });
            }
        }
    }

    //default to initials if profile pic is bad
    imgError(person){
        person['noPic'] = true;
    }

    updateInterest(){
        if(this.type == 'Events'){
            let data = {
                'users_id':this.user['_id'],
                'events_id':this.object['entity']['_id']
            };

            //event was liked, now unlike
            if(this.isInterested){
                this.eventsService.eventUninterested(data).then(value => {
                    this.isInterested = false;
                    let ind = this.user['evtinterest'].indexOf(this.object['entity']['_id']);
                    if(ind != -1){ this.user['evtinterest'].splice(ind,1);}
                    localStorage.setItem('agnesUser',JSON.stringify(this.user));

                    this.events.publish('unlikedEvent', this.object['entity']);
                }).catch(err => {
                    console.log('eBD err',err);
                    Agnes.showError('Couldn\'t like this event, please try again later!');
                })
            }
            else {
                this.eventsService.eventInterested(data).then(value => {
                    this.playAnimation('like');

                    this.isInterested = true;
                    this.user['evtinterest'].push(this.object['entity']['_id']);
                    localStorage.setItem('agnesUser',JSON.stringify(this.user));

                    this.events.publish('likedEvent', this.object['entity']);
                }).catch(err => {
                    console.log('eBD err',err);
                    Agnes.showError('Couldn\'t like this event, please try again later!');
                })
            }
        }
        else if (this.type == 'Groups') {
            let data = {
                groups_id: this.object['entity']['_id'],
                users_id: this.user['_id']
            };

            if(this.isInterested) {
                this.groupsService.unfollowGroup(data).then(val => {
                    let ind = this.object['entity']['followers'].indexOf(this.user['_id']);
                    if(ind != -1){this.object['entity']['followers'].splice(ind,1);}

                    ind = this.user['following'].map(a => {return a['groups_id']}).indexOf(this.object['entity']['_id']);
                    if(ind != -1){this.user['following'].splice(ind,1);}
                    localStorage.setItem('agnesUser',JSON.stringify(this.user));

                    //remove group from followed groups in My Groups
                    this.events.publish('leftGroup', {
                        'group': this.object['entity']['_id'],
                        'type':'follow'
                    });

                    this.isInterested = false;
                }).catch(error => {
                    console.log(error);
                    Agnes.showError('Can\'t unfollow this group right now - try again later!');
                });
            }
            else {
                this.groupsService.followGroup(data).then(val => {
                    this.playAnimation('like');

                    this.object['entity']['followers'].push(this.user['_id']);
                    this.user['following'].push({'groups_id': this.object['entity']['_id']});
                    localStorage.setItem('agnesUser',JSON.stringify(this.user));

                    this.events.publish('followGroup', this.object['entity']);
                    this.events.publish('updateUser');
                    this.isInterested = true;

                }).catch(error => {
                    console.log(error);
                    Agnes.showError('Could not add this group to your following list - try again later!');
                })
            }
        }
    }

    //open share options action sheet
    share(){
      this.shareOutside()
    }

    //TODO: share to group functionality
    shareToGroup(){

    }

    //TODO: share to friends functionality
    shareToFriends(){

    }

    shareOutside(){
      Agnes.shareOutside(this.type.toLowerCase(),this.object['entity']['_id'])
    }

    //play svg animation on button click (for event)
    playAnimation(type){

        let animation = Bodymovin.loadAnimation({
            container: document.getElementById('icon_'+this.object['entity']['_id']),
            path: 'assets/img/' + type + '.json',
            renderer: 'svg',
            loop: false, // Optional
            autoplay: true, // Optional
            name: "Heart", // Name for future reference. Optional.
        })
        animation.addEventListener('complete', function() {
          animation.destroy()
        })
    }

    //expand description text section to fit full description
    seeMore(){
        if(this.textLimit == 90) {
            this.textLimit = this.objDesc.length;
        } else {
            this.textLimit = 90;
            let yOffset = document.getElementById(this.object['entity']['_id']).offsetTop;
            this.parentContent.scrollTo(0, yOffset, 100)
        }
    }

    //replace broken thumbnail w agnes logo
    thumbnailError(){
        this.object['hasImgError'] = true;
        this.object['thumbnail'] = 'assets/img/AgnesLogo_Dark.png';
    }

    //remove full image div if img src is broken
    noFullImg(){
        this.objFullImg = null;
    }

}

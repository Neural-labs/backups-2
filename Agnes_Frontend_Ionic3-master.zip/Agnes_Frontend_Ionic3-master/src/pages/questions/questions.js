"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var core_1 = require('@angular/core');
var ionic_angular_1 = require('ionic-angular');
var questions_service_1 = require('./questions.service');
var ionic_native_1 = require('ionic-native');
var forms_1 = require('@angular/forms');
var me_service_1 = require('../me/me.service');
var login_service_1 = require('../login/login.service');
var events_1 = require('../events/events');
var login_1 = require('../login/login');
var app_component_1 = require('../../app/app.component');
var AWS = require('aws-sdk');
var S3 = require('aws-sdk/clients/s3');
var Trianglify = require('trianglify');
var QuestionsPage = (function () {
    function QuestionsPage(questionsService, meService, events, navCtrl, platform, formBuilder, navParams, appCtrl, loginService) {
        this.questionsService = questionsService;
        this.meService = meService;
        this.events = events;
        this.navCtrl = navCtrl;
        this.platform = platform;
        this.formBuilder = formBuilder;
        this.navParams = navParams;
        this.appCtrl = appCtrl;
        this.loginService = loginService;
        this.types = ['account', 'academics', 'interests/skills', 'photo'];
        this.signupForm = this.formBuilder.group({
            email: ['', [forms_1.Validators.required, forms_1.Validators.pattern('.+@.+[.].{2,3}')]],
            password: ['', [forms_1.Validators.minLength(7), forms_1.Validators.required]],
            fname: ['', forms_1.Validators.required],
            lname: ['', forms_1.Validators.required]
        });
        this.communityForm = this.formBuilder.group({
            email: ['', [forms_1.Validators.required, forms_1.Validators.pattern('.+@.+[.].{2,3}')]]
        });
    }
    QuestionsPage.prototype.ngOnInit = function () {
        var _this = this;
        ionic_native_1.GoogleAnalytics.trackView("Questions");
        this.buttonsEnabled = false;
        this.slides.lockSwipes(true);
        this.user = JSON.parse(localStorage.getItem("agnesUser"));
        this.university = {
            name: "",
            events: "",
            groups: "",
            people: ""
        };
        if (!this.user) {
            this.user = { fname: '', displayURL: '' };
        }
        else {
            this.user['displayURL'] = "url('" + this.user['picurl'] + "')";
            this.university['name'] = this.user['community'] == "gwu" ? "GWU" :
                this.user['community'].charAt(0).toUpperCase()
                    + this.user['community'].substring(1, this.user['community'].length);
        }
        this.skipAccount = this.navParams.data ? this.navParams.data.skipAccount : false;
        this.fbData = (this.navParams.data.fbData != undefined && this.navParams.data.fbData != null) ? this.navParams.data.fbData : null;
        this.data = {
            studenttype: '',
            community: this.user['community'] ? this.user['community'] : '',
            displayURL: this.user['picurl'] ? "url('" + this.user['picurl'] + "')" : '',
            majorKeywordList: [],
            questionKeywordList: [],
            skillKeywordList: [],
            majorSearch: "",
            interestSearch: "",
            majorResults: "",
            interestResults: [],
            major: [],
            interest: [],
            activeSearch: "",
            activeResults: "",
            active: [],
            postcollegeSearch: "",
            postcollegeResults: [],
            postcollege: [],
            issuesSearch: "",
            issuesResults: [],
            issues: [],
            haveskillSearch: "",
            haveskillResults: [],
            haveskill: []
        };
        this.orientation = false;
        this.counts = {
            events: 0,
            groups: 0,
            people: 0
        };
        this.currentSlide = this.navParams.data.fromLogin ? 1 : 0;
        this.sentQuestions = false;
        this.loading = false;
        this.nextText = "Next";
        this.fromLogin = this.navParams.data.fromLogin ? true : false;
        this.questionTitle = this.fromLogin ? 'Academics' : this.skipAccount ? 'Community' : 'Account';
        //handle signup success (move forward on slides)
        this.events.subscribe('signedUp', function (user) {
            _this.user = user;
            _this.events.publish('updateDeviceId', { 'id': _this.user['_id'] });
            _this.data['displayURL'] = 'url("' + _this.user['picurl'] + '")';
            _this.university['name'] = (_this.user['community'] == 'gwu') ? 'GWU'
                : _this.user['community'].charAt(0).toUpperCase() + _this.user['community'].substring(1, _this.user['community'].length);
            _this.questionTitle = "Academics";
            _this.currentSlide += 1;
            _this.slides.lockSwipes(false);
            _this.slides.slideNext();
            _this.slides.lockSwipes(true);
            _this.questionAnimation();
            _this.events.unsubscribe('signedUp');
        });
        //for sending questions - show error if data has not uploaded after 5 tries
        this.attempt = 0;
        //handle success for questions sent to database
        this.events.subscribe('sentQuestions', function (data) {
            //user has finished slides, go straight to events page
            if (_this.done) {
                _this.loading = false;
                _this.events.publish('updateUser', { 'user': _this.user, 'showChat': true });
                _this.toEvents();
            }
            else {
                _this.sentQuestions = true;
            }
        });
        this.questionAnimation();
    };
    //go back to login page from signup
    QuestionsPage.prototype.toLogin = function () {
        this.navCtrl.setRoot(login_1.LoginPage);
    };
    //submit email for signup (not the same as submitting questions and fully signing up)
    QuestionsPage.prototype.signup = function () {
        var _this = this;
        //TODO: close keyboard
        if (this.signupForm.valid) {
            for (var c in this.signupForm.controls) {
                var type = c.charAt(0).toUpperCase() + c.substring(1, c.length);
                var id = 'signup' + type + 'Error';
                document.getElementById(id).classList.remove('active');
            }
            var email_1 = this.signupForm.controls['email'].value;
            var data = { "email": email_1 };
            this.loginService.verifyCommunity(data).then(function (value) {
                //either Agnes is not at user's school or email isn't .edu
                if (value == 'community not active') {
                    if (email_1.indexOf('.edu') == -1) {
                        document.getElementById('signupEmailError').classList.add('active');
                    }
                    else {
                        document.getElementById('signupEmailError').classList.remove('active');
                        app_component_1.Agnes.showError("Agnes isn't in your community yet - check back soon!");
                    }
                }
                else {
                    // this.loginService.validateEmail(data).then(val => {
                    //   //email is invalid
                    //   if(val.body.result == 'undeliverable') {
                    //     document.getElementById('signupEmailError').classList.add('active');
                    //   }
                    //   else {
                    //
                    //   }
                    // }).catch(err => {
                    //   Agnes.showError('Please enter a valid email!');
                    // });
                    document.getElementById('signupEmailError').classList.remove('active');
                    var user = {
                        "fname": _this.signupForm.controls['fname'].value,
                        "lname": _this.signupForm.controls['lname'].value,
                        "email": _this.signupForm.controls['email'].value,
                        "password": _this.signupForm.controls['password'].value,
                        "app_version": app_component_1.Agnes.version,
                        "connection_type": ionic_native_1.Network.type
                    };
                    _this.loading = true;
                    _this.loginService.signup(user).then(function (value) {
                        _this.loading = false;
                        if (value != null && value != 2) {
                            //signup was a success, save returned user data to local storage and go to questions
                            localStorage.setItem("agnesToken", value.token);
                            localStorage.setItem("agnesUser", JSON.stringify(value));
                            //advance to next page
                            _this.events.publish('signedUp', value);
                        }
                        else {
                            var errorMessage = "";
                            if (value == 2) {
                                errorMessage = 'Agnes already has your email on file - try logging in!';
                            }
                            else {
                                if (value == null) {
                                    _this.processCornell();
                                    errorMessage = 'This is currently invite-only. Feel free to contact admin@agnes.io.';
                                }
                                else {
                                    errorMessage = 'Sign up failed - please try again!';
                                }
                            }
                            app_component_1.Agnes.showError(errorMessage);
                        }
                    })
                        .catch(function (value) {
                        _this.loading = false;
                        var err = value._body;
                        var errorMessage = "";
                        if (err == 2) {
                            errorMessage = 'Agnes already has your email on file - try logging in!';
                        }
                        else {
                            errorMessage = 'Sign up failed - please try again!';
                        }
                        app_component_1.Agnes.showError(errorMessage);
                    });
                }
            }).catch(function (err) {
                app_component_1.Agnes.showError('Agnes isn\'t in your community yet - check back soon!');
            });
        }
        else {
            for (var c in this.signupForm.controls) {
                var type = c.charAt(0).toUpperCase() + c.substring(1, c.length);
                var id = 'signup' + type + 'Error';
                if (!this.signupForm.controls[c].valid) {
                    document.getElementById(id).classList.add('active');
                    if (c == 'email') {
                        var e = this.signupForm.controls[c].value.toLowerCase();
                        if (e != '') {
                            var inCommunity = e.includes("cornell.edu") ||
                                e.includes("gwu.edu") || e.includes("usgbc.org") ||
                                e.includes("agnes.edu") || e.includes("howard.edu");
                            if (e.includes('.edu') && !inCommunity) {
                                app_component_1.Agnes.showError("Agnes isn't in your community yet - check back soon!");
                            }
                        }
                    }
                }
                else {
                    document.getElementById(id).classList.remove('active');
                }
            }
            return false;
        }
    };
    //animate all elements on question page (background blur, content fade in up
    QuestionsPage.prototype.questionAnimation = function () {
        var _this = this;
        var t = 350;
        var slide = this.currentSlide;
        var skip = this.skipAccount;
        this.buttonsEnabled = false;
        //generate new triangle image
        this.questionBackground = Trianglify({
            width: 1280,
            height: 1920,
            cell_size: 400,
            variance: 1,
            x_colors: ['#4C7C88', '#2C849B', '#0B2228', '#1A4751']
        }).png();
        //reset background blur, title, progress, and next/back buttons
        // document.querySelector('.questionsBackground').classList.remove('fadeIn');
        // document.querySelector('.questionsBackgroundBlurred').classList.remove('fadeIn');
        if (document.querySelector('.questionsProgress')) {
            document.querySelector('.questionsProgress').classList.remove('fadeInUp');
        }
        document.querySelector('.questionsTitle').classList.remove('fadeInUp');
        document.querySelector('questions .optionButtons').classList.remove('fadeInUp');
        if (slide == 3) {
            document.querySelector('.agreeTerms').classList.remove('fadeInUp');
        }
        setTimeout(function () {
            //reset form items, subtext (for going to previous slide)
            var fbis = document.getElementsByClassName('formBasicItem');
            var subs = document.getElementsByClassName('subtext');
            var results = document.getElementsByClassName('results');
            for (var f = 0; f < fbis.length; f++) {
                fbis[f].classList.remove('fadeInUp');
            }
            for (var i = 0; i < subs.length; i++) {
                subs[i].classList.remove('fadeInUp');
            }
            for (var j = 0; j < results.length; j++) {
                results[j].classList.remove('fadeInUp');
            }
        }, t);
        var showButtons = function () {
            setTimeout(function () {
                document.querySelector('questions .optionButtons').classList.add('fadeInUp');
                setTimeout(function () {
                    _this.buttonsEnabled = true;
                }, 1100);
            }, t);
        };
        setTimeout(function () {
            //fade in unblurred background
            // document.querySelector('.questionsBackground').classList.add('fadeIn');
            setTimeout(function () {
                //blur background
                // document.querySelector('.questionsBackgroundBlurred').classList.add('fadeIn');
                //animate rest of elements
                setTimeout(function () {
                    var extra = 0;
                    //bring up question progress
                    if (document.querySelector('.questionsProgress')) {
                        document.querySelector('.questionsProgress').classList.add('fadeInUp');
                        extra = t;
                    }
                    //bring up question title
                    setTimeout(function () {
                        document.querySelector('.questionsTitle').classList.add('fadeInUp');
                        if (slide == 0) {
                            document.querySelector('#toLogin').classList.add('fadeInUp');
                        }
                        //account or community slide (fade in account form items or community text and input)
                        if (slide == 0) {
                            if (!skip) {
                                setTimeout(function () {
                                    document.querySelector('#accountFname').classList.add('fadeInUp');
                                    setTimeout(function () {
                                        document.querySelector('#accountLname').classList.add('fadeInUp');
                                        setTimeout(function () {
                                            document.querySelector('#accountEmail').classList.add('fadeInUp');
                                            setTimeout(function () {
                                                document.querySelector('#accountPassword').classList.add('fadeInUp');
                                                showButtons();
                                            }, t);
                                        }, t);
                                    }, t);
                                }, t);
                            }
                            else {
                                setTimeout(function () {
                                    document.querySelector('.communityText').classList.add('fadeInUp');
                                    setTimeout(function () {
                                        document.querySelector('#commEmail').classList.add('fadeInUp');
                                        showButtons();
                                    }, t);
                                }, t);
                            }
                        }
                        else if (slide == 1) {
                            setTimeout(function () {
                                document.querySelector('#studentTypeItem').classList.add('fadeInUp');
                                setTimeout(function () {
                                    document.querySelector('#majorItem').classList.add('fadeInUp');
                                    extra = (_this.data['major'].length > 0) ? t : 0;
                                    //show results
                                    setTimeout(function () {
                                        document.querySelector('#majorFinalList').classList.add('fadeInUp');
                                    }, t);
                                    //show buttons
                                    setTimeout(function () {
                                        showButtons();
                                    }, extra);
                                }, t);
                            }, t);
                        }
                        else if (slide == 2) {
                            setTimeout(function () {
                                document.querySelector('#interestHelpText').classList.add('fadeInUp');
                                setTimeout(function () {
                                    document.querySelector('#interestItem').classList.add('fadeInUp');
                                    extra = (_this.data['interest'].length > 0) ? t * 2 : 0;
                                    //show results
                                    setTimeout(function () {
                                        document.querySelector('#interestFinalList').classList.add('fadeInUp');
                                    }, t);
                                    //show buttons
                                    setTimeout(function () {
                                        showButtons();
                                    }, extra);
                                    // setTimeout(() => {
                                    //   document.querySelector('#skillHeader').classList.add('fadeInUp');
                                    //   setTimeout(()=>{
                                    //     document.querySelector('#haveskillItem').classList.add('fadeInUp');
                                    //     extra = (this.data['haveskill'].length > 0) ? t*2 : 0;
                                    //     //show results
                                    //     setTimeout(() => {
                                    //       document.querySelector('#haveskillFinalList').classList.add('fadeInUp');
                                    //     },t);
                                    //     //show buttons
                                    //     setTimeout(() => {
                                    //       showButtons();
                                    //     }, extra);
                                    //   },t);
                                    // },t);
                                }, t);
                            }, t);
                        }
                        else if (slide == 3) {
                            setTimeout(function () {
                                document.querySelector('#photoHelpText').classList.add('fadeInUp');
                                setTimeout(function () {
                                    document.querySelector('#photoItem').classList.add('fadeInUp');
                                    setTimeout(function () {
                                        document.querySelector('.agreeTerms').classList.add('fadeInUp');
                                        showButtons();
                                    }, t);
                                }, t);
                            }, t);
                        }
                        else if (slide == 4) {
                            window.setTimeout(function () {
                                document.querySelector('#welcomeText').classList.add('fadeInUp');
                                window.setTimeout(function () {
                                    document.querySelector('#commBusy').classList.add('fadeInUp');
                                    window.setTimeout(function () {
                                        document.querySelector('#eventsBox').classList.add('fadeInUp');
                                        _this.startCount('events');
                                        window.setTimeout(function () {
                                            document.querySelector('#groupsBox').classList.add('fadeInUp');
                                            _this.startCount('groups');
                                            var btnTimeout = t;
                                            if (_this.university['people'] > 100) {
                                                btnTimeout = t * 2;
                                                window.setTimeout(function () {
                                                    document.querySelector('#peopleBox').classList.add('fadeInUp');
                                                    _this.startCount('people');
                                                }, t);
                                            }
                                            window.setTimeout(function () {
                                                document.querySelector('.tutorialText').classList.add('fadeInUp');
                                                window.setTimeout(function () {
                                                    document.querySelector('.tutorialBox').classList.add('fadeIn');
                                                    window.setTimeout(function () {
                                                        document.querySelector('.tutorialBox').classList.add('animated');
                                                        window.setTimeout(function () {
                                                            showButtons();
                                                        }, t);
                                                    }, 1000);
                                                }, t);
                                            }, btnTimeout);
                                        }, t);
                                    }, t);
                                }, t);
                            }, t);
                        }
                    }, extra);
                }, t);
            }, 750);
        }, 0);
    };
    //count up 'animation' for events/groups/users numbers in Welcome page
    QuestionsPage.prototype.startCount = function (type) {
        var _this = this;
        var limit = this.university[type];
        if (this.platform.is('android')) {
            var time = (limit == 0 || (3000 / limit) > 20) ? 20 : 3000 / limit;
            var x = 0;
            while (x < limit) {
                setTimeout(function () {
                    _this.counts[type] += 1;
                }, (x + 1) * time);
                x += 1;
            }
        }
        else {
            this.counts[type] = limit;
        }
    };
    //special function for recording Cornell signups due to invite-only nature
    QuestionsPage.prototype.processCornell = function () {
        var data = {
            'name': this.signupForm.controls['fname'].value + ' ' + this.signupForm.controls['lname'].value,
            'email': this.signupForm.controls['email'].value,
            'message': 'This email was used to try and sign up for Agnes in the Cornell community'
        };
        this.meService.contactAgnes(data).then(function (value) {
            //do nothing - user should not know this message was sent
        }).catch(function (err) {
            //do nothing
        });
    };
    //sign up with Facebook after adding community
    QuestionsPage.prototype.signupFromFB = function (fbData) {
        var _this = this;
        var email = this.communityForm.controls['email'].value;
        var data = { "email": email };
        this.loginService.verifyCommunity(data).then(function (value) {
            //either Agnes is not at user's school or email isn't .edu
            if (value == 'community not active') {
                if (email.indexOf('.edu') == -1) {
                    document.getElementById('commEmailError').classList.add('active');
                }
                else {
                    document.getElementById('commEmailError').classList.remove('active');
                    app_component_1.Agnes.showError("Agnes isn't in your community yet - check back soon!");
                }
            }
            else {
                _this.loginService.fbSignup(fbData).then(function (value) {
                    if (value) {
                        localStorage.setItem('agnesToken', value['token']);
                        var upd = {
                            access_token: fbData['providerFBData']['OAuthToken'],
                            users_id: value['_id']
                        };
                        _this.events.publish('signedUp', value);
                        _this.loginService.fbUpdate(upd).then(function (value) {
                        }).catch(function (err) {
                            console.log('fb after update error', err);
                        });
                    }
                }).catch(function (err) {
                    console.log('fb after register error', err);
                    app_component_1.Agnes.showError("Couldn't sign up through Facebook right now - try again or sign up manually!");
                });
            }
        }).catch(function (err) {
            app_component_1.Agnes.showError('Could not verify your email - make sure you are connected to the internet and try again!');
        });
    };
    //move to next slide w/ validation
    QuestionsPage.prototype.slideNext = function () {
        var _this = this;
        if (this.buttonsEnabled) {
            var next = false;
            //on background - go to academics
            if (this.currentSlide == 0) {
                if (!this.skipAccount) {
                    this.signup();
                }
                else {
                    if (this.communityForm.valid) {
                        var uid = this.communityForm.value["email"];
                        this.fbData['email']['uid'] = uid;
                        this.fbData['app_version'] = app_component_1.Agnes.version;
                        this.fbData['connection_type'] = ionic_native_1.Network.type;
                        this.signupFromFB(this.fbData);
                    }
                    else {
                        document.getElementById('commEmailError').classList.add('active');
                    }
                }
            }
            else if (this.currentSlide == 1) {
                //get number of university events, groups, and users
                var data_1 = { "users_id": this.user['_id'] };
                this.questionsService.getEventsCount(data_1).then(function (count) {
                    if (count) {
                        _this.university['events'] = count['evtLength'];
                    }
                    else {
                        _this.university['events'] = 0;
                    }
                    _this.questionsService.getGroupsCount(data_1).then(function (groups) {
                        if (groups) {
                            _this.university['groups'] = groups['grpLength'];
                        }
                        else {
                            _this.university['groups'] = 0;
                        }
                        _this.questionsService.getPeopleCount(data_1).then(function (users) {
                            if (users) {
                                _this.university['people'] = users['pplLength'];
                            }
                            else {
                                _this.university['people'] = 0;
                            }
                        });
                    });
                });
                //add major from search field in case user did not click from dropdown list or did not click the + button
                this.addFromSearch('major');
                var majorValid = this.data['major'].length > 0;
                var studenttypeValid = this.data['studenttype'] != "";
                //show or hide error based on major and studenttype validation
                this.showQuestionError('major', majorValid);
                this.showQuestionError('studentType', studenttypeValid);
                next = (majorValid && studenttypeValid);
                this.questionTitle = next ? "Interests" : this.questionTitle;
                if (next) {
                    ionic_native_1.Keyboard.disableScroll(true);
                }
            }
            else if (this.currentSlide == 2) {
                this.addFromSearch('interest');
                var interestValid = this.data['interest'].length >= 3;
                this.showQuestionError('interest', interestValid);
                next = interestValid;
                // this.questionTitle = next ? "Skills" : this.questionTitle;
                this.questionTitle = next ? "Photo" : this.questionTitle;
                this.nextText = next ? "Submit" : this.nextText;
            }
            else if (this.currentSlide == 3) {
                next = true;
                this.sendQuestionsResponse();
                this.questionTitle = "Hi " + this.user['fname'];
                this.nextText = "Let's get started!";
            }
            else {
                this.done = true;
                if (this.sentQuestions) {
                    this.toEvents();
                }
                else {
                    this.loading = true;
                    this.attempt = 0;
                    var questionParams = {
                        users_id: this.user['_id'],
                        major: this.data['major'],
                        studenttype: this.data['studenttype'],
                        keywords: this.user['keywords'],
                        question: true,
                        community: this.user['community'],
                        picurl: this.data['displayURL'],
                        gender: this.user['gender']
                    };
                    this.attemptSend(questionParams);
                }
            }
            if (next) {
                //tracking
                if (window['fabric']) {
                    if (this.currentSlide < 4) {
                        var t = this.types[this.currentSlide];
                        window['fabric'].Answers.sendCustomEvent('Questions', { type: t + ' next' });
                    }
                }
                this.currentSlide += 1;
                this.slides.lockSwipes(false);
                this.slides.slideNext();
                this.slides.lockSwipes(true);
                this.questionAnimation();
            }
        }
    };
    //go to prev slide
    QuestionsPage.prototype.slidePrev = function () {
        if (this.buttonsEnabled) {
            if (this.currentSlide == 2) {
                this.questionTitle = 'Academics';
                ionic_native_1.Keyboard.disableScroll(false);
            }
            if (this.currentSlide == 3) {
                this.questionTitle = 'Interests';
                this.nextText = 'Next';
            }
            this.currentSlide -= 1;
            this.questionAnimation();
            this.slides.lockSwipes(false);
            this.slides.slidePrev();
            this.slides.lockSwipes(true);
        }
    };
    //search keyword database
    QuestionsPage.prototype.search = function (type) {
        var _this = this;
        var matches = [];
        var searchId = type + 'Search';
        var filter = this.data[searchId].toLowerCase();
        var resultsId = type + 'Results';
        var data = { "searchTerm": filter, 'type': type };
        if (type != 'haveskill') {
            this.showQuestionError(type, true);
        }
        if (filter.trim().length < 1) {
            this.data[resultsId] = [];
        }
        else {
            if (type == 'major') {
                this.questionsService.majorAutocomplete(data).then(function (value) {
                    if (value) {
                        matches = value;
                        _this.data[resultsId] = matches.map(function (a) {
                            return a['keyword'];
                        });
                    }
                    else {
                        _this.data[resultsId] = [];
                    }
                });
            }
            else {
                this.questionsService.autocomplete(data).then(function (value) {
                    if (value) {
                        matches = value;
                        _this.data[resultsId] = matches.map(function (a) {
                            return a['keyword'];
                        });
                    }
                    else {
                        _this.data[resultsId] = [];
                    }
                });
            }
        }
    };
    //remove search result list from screen by tapping outside of it
    QuestionsPage.prototype.clearSearch = function (type) {
        this.data[type + 'Results'] = [];
    };
    //add a keyword from the search bar (not by clicking on search result list)
    QuestionsPage.prototype.addFromSearch = function (type) {
        var search = this.data[type + 'Search'];
        if (search != "") {
            var keywords = search.split(/,\s*/);
            for (var k in keywords) {
                this.clickedKeyword(keywords[k], type);
            }
        }
    };
    //add a keyword by tapping on it in the search result list
    QuestionsPage.prototype.clickedKeyword = function (keyword, type) {
        keyword = keyword.toLowerCase();
        if (type == 'major' || type == 'interest') {
            document.getElementById(type + 'Error').classList.remove('active');
        }
        if (!(keyword == "")) {
            var list = this.data[type];
            var resultsId = type + 'Results';
            var searchId = type + 'Search';
            if (list.indexOf(keyword) == -1) {
                list.push(keyword);
            }
            this.data[resultsId] = [];
            this.data[searchId] = "";
        }
        this.data[type + 'Search'] = "";
        this.data[type + 'Results'] = "";
        document.getElementById(type + 'FinalList').style.filter = 'none';
    };
    //remove a keyword from the final keyword list for a given type (i.e. interest, skill, major)
    QuestionsPage.prototype.removeKeyword = function (keyword, type) {
        var list = this.data[type];
        if (list.indexOf(keyword) != -1) {
            list.splice(list.indexOf(keyword), 1);
        }
    };
    //show validation errors below inputs
    QuestionsPage.prototype.showQuestionError = function (type, valid) {
        var id = '' + type + 'Error';
        if (valid) {
            document.getElementById(id).classList.remove('active');
        }
        else {
            document.getElementById(id).classList.add('active');
        }
    };
    //add photo from native phone camera on Photo slide
    QuestionsPage.prototype.addPhoto = function (type) {
        var _this = this;
        var source = (type == 'camera') ? ionic_native_1.Camera.PictureSourceType.CAMERA : ionic_native_1.Camera.PictureSourceType.PHOTOLIBRARY;
        var options = {
            quality: 25,
            allowEdit: false,
            cameraDirection: ionic_native_1.Camera.Direction.FRONT,
            correctOrientation: true,
            destinationType: ionic_native_1.Camera.DestinationType.DATA_URL,
            sourceType: source
        };
        ionic_native_1.Camera.getPicture(options).then(function (value) {
            if (value && typeof (value) == 'string') {
                var base64Image = 'data:image/jpeg;base64,' + value;
                _this.user['picurl'] = base64Image;
                _this.data['displayURL'] = "url('" + base64Image + "')";
                document.querySelector('.addPhotoButton p')['style']['color'] = 'transparent';
            }
            else {
                app_component_1.Agnes.showError("Couldn't process your photo - try again!");
            }
        }, function (err) {
            console.log(err);
        }).catch(function (err) {
            app_component_1.Agnes.showError("Couldn't get your photos - make sure Agnes has photo access permissions and try again!");
        });
    };
    //handle 'Enter' key press
    QuestionsPage.prototype.onEnter = function (ev, type) {
        if (ev.keyCode == 13) {
            if (type != 'signup') {
                this.addFromSearch(type);
            }
            else {
                this.signup();
            }
        }
    };
    QuestionsPage.prototype.baseToBlob = function (dataURI) {
        // convert base64/URLEncoded data component to raw binary data held in a string
        var byteString;
        if (dataURI.split(',')[0].indexOf('base64') >= 0)
            byteString = atob(dataURI.split(',')[1]);
        else
            byteString = (dataURI.split(',')[1]);
        // separate out the mime component
        // var mimeString = dataURI.split(',')[0].split(':')[1].split(';')[0];
        // write the bytes of the string to a typed array
        var ia = new Uint8Array(byteString.length);
        for (var i = 0; i < byteString.length; i++) {
            ia[i] = byteString.charCodeAt(i);
        }
        return new Blob([ia.buffer], { type: "image/jpeg" });
    };
    QuestionsPage.prototype.getOrientation = function (file, callback) {
        var reader = new FileReader();
        reader.onload = function (e) {
            var view = new DataView(e.target['result']);
            if (view.getUint16(0, false) != 0xFFD8)
                return callback(-2);
            var length = view.byteLength, offset = 2;
            while (offset < length) {
                var marker = view.getUint16(offset, false);
                offset += 2;
                if (marker == 0xFFE1) {
                    if (view.getUint32(offset += 2, false) != 0x45786966)
                        return callback(-1);
                    var little = view.getUint16(offset += 6, false) == 0x4949;
                    offset += view.getUint32(offset + 4, little);
                    var tags = view.getUint16(offset, little);
                    offset += 2;
                    for (var i = 0; i < tags; i++)
                        if (view.getUint16(offset + (i * 12), little) == 0x0112)
                            return callback(view.getUint16(offset + (i * 12) + 8, little));
                }
                else if ((marker & 0xFF00) != 0xFF00)
                    break;
                else
                    offset += view.getUint16(offset, false);
            }
            return callback(-1);
        };
        reader.readAsArrayBuffer(file.slice(0, 64 * 1024));
    };
    QuestionsPage.prototype.sendQuestionsResponse = function () {
        ionic_native_1.Keyboard.disableScroll(false);
        var ks = [];
        for (var hs in this.data['haveskill']) {
            ks.push({ name: this.data['haveskill'][hs], keytype: 'haveskill' });
        }
        for (var i in this.data['interest']) {
            ks.push({ name: this.data['interest'][i], keytype: 'interest' });
        }
        this.user['keywords'] = ks;
        var pic = this.user['picurl'];
        if (pic && pic != '') {
            if (this.user['picurl'].indexOf('base64') != -1) {
                var creds = {
                    bucket: 'agnesimages',
                    access_key: 'AKIAJYQU6AUVQQKITAPQ',
                    secret_key: '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'
                };
                var uniqueFilename = "";
                var possible = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
                for (var j = 0; j < 8; j++) {
                    uniqueFilename += possible.charAt(Math.floor(Math.random() * possible.length));
                }
                var data = this.baseToBlob(this.user['picurl']);
                AWS.config.update({ region: 'us-east-1', credentials: {
                        accessKeyId: "AKIAJYQU6AUVQQKITAPQ",
                        secretAccessKey: "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"
                    } });
                var keyname = uniqueFilename + '.jpg';
                keyname = '_' + keyname;
                //TODO if the orientation stuff came up!
                /* if(this.orientation){
                 keyname = '_' + keyname;
                 }
                 else{
                 keyname = '_' + uniqueFilename
                 }
                 */
                //Bucket Parameters
                var bucketParams = {
                    Key: keyname,
                    ContentType: ".jpg",
                    Body: data,
                    ServerSideEncryption: 'AES256',
                    Bucket: creds.bucket
                };
                //bucket to define
                var bucket = new S3({ params: { Bucket: 'agnesimages' } });
                bucket.putObject(bucketParams, function (err, data) {
                    if (err) {
                        console.log('bucket error', err);
                        return false;
                    }
                    else {
                    }
                });
                this.data['picurl'] = 'https://s3.amazonaws.com/agnesimages/' + keyname;
                pic = 'https://s3.amazonaws.com/agnesimages/' + keyname;
            }
        }
        else {
            pic = '';
        }
        var questionParams = {
            users_id: this.user['_id'],
            major: this.data['major'],
            studenttype: this.data['studenttype'],
            keywords: this.user['keywords'],
            question: true,
            community: this.user['community'],
            picurl: pic,
            gender: this.user['gender']
        };
        this.attemptSend(questionParams);
    };
    //try to send question data to server max 5 times before giving error
    QuestionsPage.prototype.attemptSend = function (data) {
        var _this = this;
        if (window['fabric']) {
            window['fabric'].Answers.sendCustomEvent('Questions', { type: 'send questions attempt ' + this.attempt });
        }
        this.questionsService.sendQuestions(data).then(function (value) {
            if (value) {
                _this.loading = false;
                _this.user = value;
                _this.events.publish('sentQuestions', true);
                _this.events.publish('updateDeviceId', { 'id': _this.user['_id'] });
            }
            else {
                _this.attempt = _this.attempt + 1;
                if (_this.attempt < 5) {
                    _this.attemptSend(data);
                }
                else {
                    _this.loading = false;
                    _this.attempt = 0;
                    app_component_1.Agnes.showError('Could not upload your question responses right now - try again!');
                }
            }
        }).catch(function (err) {
            _this.attempt = _this.attempt + 1;
            if (_this.attempt < 5) {
                var questionParams = {
                    users_id: _this.user['_id'],
                    major: _this.data['major'],
                    studenttype: _this.data['studenttype'],
                    keywords: _this.user['keywords'],
                    question: true,
                    community: _this.data['community'],
                    picurl: _this.data['displayURL'],
                    gender: _this.user['gender']
                };
                _this.attemptSend(questionParams);
            }
            else {
                app_component_1.Agnes.showError('Could not upload your question responses right now - try again!');
            }
        });
    };
    //TODO: handle deep links
    QuestionsPage.prototype.toEvents = function () {
        this.events.publish('updateUser', { 'user': this.user, 'showChat': true });
        localStorage.setItem('agnesUser', JSON.stringify(this.user));
        var url = window.localStorage.getItem("external_load");
        if (url) {
            //url will be in format http://agnes.io/TYPE/ID
            // i.e. http://agnes.io/event/eventsid123456789
            var urlArr = url.substring(8, url.length).split('/');
            var type = urlArr[0];
            var sharedId = urlArr[1];
            if (type == 'event') {
                window.localStorage.setItem('leefExternalID_event', sharedId);
            }
            else if (type == 'group') {
                window.localStorage.setItem('leefExternalID_group', sharedId);
            }
            else if (type == 'user') {
                window.localStorage.setItem('leefExternalID_user', sharedId);
            }
            else {
                this.appCtrl.getRootNav().setRoot(events_1.EventsPage);
            }
        }
        else {
            this.appCtrl.getRootNav().setRoot(events_1.EventsPage);
        }
    };
    QuestionsPage.prototype.showLoading = function () {
        if (this.sentQuestions) {
            this.toEvents();
        }
        else {
            this.loading = true;
            if (this.attempt == 5) {
                var questionParams = {
                    users_id: this.user['_id'],
                    major: this.data['major'],
                    studenttype: this.data['studenttype'],
                    keywords: this.user['keywords'],
                    question: true,
                    community: this.data['community'],
                    picurl: this.data['displayURL'],
                    gender: this.user['gender']
                };
                this.attemptSend(questionParams);
            }
        }
    };
    __decorate([
        core_1.ViewChild(ionic_angular_1.Slides)
    ], QuestionsPage.prototype, "slides", void 0);
    QuestionsPage = __decorate([
        core_1.Component({
            selector: 'questions',
            templateUrl: 'questions.html',
            providers: [questions_service_1.QuestionsService, me_service_1.MeService, login_service_1.LoginService]
        })
    ], QuestionsPage);
    return QuestionsPage;
}());
exports.QuestionsPage = QuestionsPage;

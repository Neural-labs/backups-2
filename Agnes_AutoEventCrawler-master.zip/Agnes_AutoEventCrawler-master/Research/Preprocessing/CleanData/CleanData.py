from config import db_config
import pickle
from Utilities import EventTree
from bson.binary import Binary
from Preprocessing.CollectFeatures import EmbeddingTrainer
import gc

dbConn = db_config.getDBConn('dev')
Agnes = dbConn.Agnes
AutoCrawler_Events = Agnes.autocrawler_events
ID_Data_Collection = Agnes.autocrawler_id_data
Domain_Collection = Agnes.autocrawler_domain_pages

def cleanData():

    trimIdData()
    # cleanEvents()

def trimIdData():

    last_id = 0
    counter = 0
    removedCount = 0
    total_count = ID_Data_Collection.count()
    while True:

        sample_batch = getSampleBatchCursor(last_id)
        batch_size = sample_batch.count(with_limit_and_skip=True)

        if not sample_batch or not batch_size:
            break

        last_id = sample_batch[batch_size-1]['random_id']

        for sample in sample_batch:
            counter += 1
            if not counter % 1000:
                print 'Counter',counter,'of',total_count

            if not sampleInPageCollections(sample):
                print 'Removing - ',sample['_id']
                removedCount += 1
                deleteIdSample(sample)

        del sample_batch
        gc.collect()
    print 'Removed - ',removedCount

def sampleInPageCollections(sample):
    page_id = sample['event_id']
    label = sample['label']
    if label:
        result = AutoCrawler_Events.find_one({'_id':page_id}, {'_id':1})
    else:
        result = Domain_Collection.find_one({'_id':page_id}, {'_id':1})

    return bool(result)

def deleteIdSample(sample):
    ID_Data_Collection.delete_one({'_id':sample['_id']})

def cleanEvents():
    events = getEvents()
    counter = 0

    bad_sources = ['thebridge.cmu.edu','nest.cua.edu','hoyalink.georgetown.edu', 'howard.campuslabs.com', 'temple.campuslabs.com',
                   'involved.towson.edu','studentcentral.udel.edu','gobblerconnect.vt.edu', 'johnshopkins.campuslabs.com']

    head_count = 0
    for event in events:
        if invalidEvent(event):
            continue
        counter += 1
        if counter % 1000 == 0:
            print counter,'of',events.count(),' | HeadCount = ',head_count
        if '<head>' in event['HTML']:
            tokens = EmbeddingTrainer.tokenizeH2V_W(event['HTML'], find_body=False)
            # print 'Found one'
            # print event['HTML']
            # print tokens
            # print event['_id']
            head_count += 1

        # tokens = EmbeddingTrainer.tokenizeH2V_W(event['HTML'], find_body=False)
        # if tokens and tokens[0] == 'head':
        #     print event['_id']
        #     raise ValueError('found one')


def invalidEvent(event):
    if 'netx_tree_pkl' not in event:
        return True
    if event['netx_tree_pkl'] == {}:
        return True
    if 'HTML' not in event:
        return True
    return False

def updateTree(event_tree):
    event_node = event_tree.get_event_nodes()['event']
    print 'event node',event_node
    for node_id in reversed(list(event_tree.iterate_from_node(event_node))):
        node_data = event_tree.get_node_data(node_id)
        if node_data['attr_dict']['subtree_label']['other']:
            for path_id in event_tree.node_path(event_node, node_id):
                event_tree.get_node_data(path_id)['attr_dict']['subtree_label']['other'] = 1

    return event_tree

def getEvents():
    return AutoCrawler_Events.find({}, no_cursor_timeout=True)

def updateEvent(_id, updated_tree):
    AutoCrawler_Events.update_one({
        '_id':_id
    },
        {'$set':
             {'netx_tree_pkl':updated_tree}
         }
    ,
    upsert=False
    )

def getSampleBatchCursor(last_id):
    batch_size = 100
    return_fields = {'event_id':1,'label':1,'random_id':1}
    return ID_Data_Collection.find({'random_id': {'$gt': last_id}},return_fields, no_cursor_timeout=True).limit(batch_size).sort('random_id', 1)

def setEvent(url, HTML):
    AutoCrawler_Events.update_one({'url':url},{'$set': {'HTML': HTML}}, upsert=False)

def removeEvent(event):
    AutoCrawler_Events.delete_one({'url':event['url']})
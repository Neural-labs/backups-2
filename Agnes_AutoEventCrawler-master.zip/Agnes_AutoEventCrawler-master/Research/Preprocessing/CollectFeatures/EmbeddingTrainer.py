# import modules & set up logging
from config import db_config
import re
import gensim, logging
import multiprocessing
from gensim.models import Doc2Vec
import gensim.models.doc2vec
from collections import OrderedDict
from gensim.models.doc2vec import TaggedDocument
from bs4 import BeautifulSoup
from Utilities import DataFilter
from nltk.corpus import stopwords
stop_words = set(stopwords.words('english'))

dbConn = db_config.getDBConn('dev')
Agnes = dbConn.Agnes
Data_Collection = Agnes.autocrawler_events

logging.basicConfig(format='%(asctime)s : %(levelname)s : %(message)s', level=logging.INFO)

cores = multiprocessing.cpu_count()
assert gensim.models.doc2vec.FAST_VERSION > -1, "This will be painfully slow otherwise"

# total_examples = 5000000
# total_examples = 15000000
total_examples = Data_Collection.count()

split_type = 'hw'

class TokenIterator(object):

    def __init__(self, model):
        self.model = model

    def __iter__(self):
        for item in getSentenceGenerator(self.model):
            yield item
        dbConn.close()

def runEmbeddingTrainer(model_type='w2v'):

    print 'Training Gensim with model=',model_type

    if model_type == 'w2v':

        sentences = TokenIterator(model_type)

        try:
            model = gensim.models.Word2Vec(sentences, min_count=1, workers=cores)
            fname = 'gensim_model_w2v_'+split_type
            model.save(fname)

        except Exception as e:
            print 'Exception:',e

    elif model_type == 'h2v':
        sentences = TokenIterator(model_type)
        model_type = gensim.models.Word2Vec(sentences, min_count=1, workers=cores)
        model_type.save('gensim_html2vec_model')

    elif model_type == 'c2v':
        sentences = TokenIterator(model_type)
        model_type = gensim.models.Word2Vec(sentences, min_count=1, workers=cores)
        model_type.save('gensim_char2vec_model')

def getSentenceGenerator(model_type):

    batch_index = 0
    batch_size = 100
    last_id = None

    while True:
        if last_id:
            logging.info('Fetching batch, last_id: %s , batch_index %d' % (str(last_id), batch_index))

        samplebatch = getSampleBatchCursor(last_id, batch_size)
        cursor_size = samplebatch.count(with_limit_and_skip=True)

        # if no samples retrieved
        if not samplebatch or not cursor_size:
            break
        last_id = samplebatch[cursor_size - 1]['_id']
        logging.info('Retrieved %d samples' % samplebatch.count(with_limit_and_skip=True))

        for index, sample in enumerate(samplebatch):
            if not 'HTML' in sample:
                continue
            # text = sample['text']
            text = sample['HTML']
            tokens = tokenize(text)

            if not tokens:
                continue

            if model_type == 'd2v':
                yield TaggedDocument(words=tokens, tags=[sample['_id']])

            else:
                yield tokens

        del samplebatch
        batch_index += batch_size


def tokenize(content):

    if split_type =='w':
        return tokenizeW2V(content)
    elif split_type == 'hw':
        return tokenizeH2V_W(content)
    elif split_type == 'hc':
        return tokenizeH2V_C(content)
    elif split_type == 'c':
        return tokenizeC2V(content)
    else:
        raise ValueError('split type incorrectly specified!')

def tokenizeW2V(content):
    content = DataFilter.removeHTML(content)
    content = DataFilter.removePunctuation(content)
    return [word for word in content.split() if word and word not in stop_words]

def tokenizeD2V(content): # copied from the tutorial for d2v
    content = content.lower()
    content = DataFilter.removeHTML(content)
    content = ' '.join(content.split())
    # Replace breaks with spaces
    content = content.replace('<br />', ' ')
    filters = '!"#$%&()*+,-./:;<=>?@[\\]^_`{|}~\t\n'
    for c in filters:
        content = content.replace(c,'')
    return [item for item in content.split() if item]

def tokenizeC2V(content):
    filters = ''  # if we want to remove some symbols
    for c in filters:
        content = content.replace(c, '')
    return [char for char in content if char]

def tokenizeH2V(content):
    html_content = DataFilter.removeContentInHTML(content)
    symbols = '!"#$%&()*+,-./:;<=>?@[\\]^_`{|}~\t\n'
    for char in symbols:
        content = html_content.replace(char, ' ')
    return [item for item in ' '.join(content.split()).split() if item]

def tokenizeH2V_W(html_content, find_body=True):
    html_soup = DataFilter.simpleGetSoup(html_content)
    if find_body:
        body = html_soup.find('body')

        if not body:
            logging.info('HTML has no <body> tag')
            return None
        tags = body.findChildren()
    else:
        tags = html_soup.find_all()
        if not tags:
            logging.info('HTML has no tags')
            return None
    h2v_string = ''

    for tag in tags:
        if hasattr(tag,'attrs') and hasattr(tag,'name'):
            h2v_string += tag.name + ' '
            for attr in tag.attrs:
                value = tag[attr]
                if isinstance(value, list):
                    for val in value:
                        h2v_string += val+' '
                else:
                    h2v_string += value+' '

    final_str = ' '.join(h2v_string.split())
    final_str = DataFilter.removePunctuation(final_str)
    final_str = final_str.lower()
    final_tokens = final_str.split()
    return [word for word in final_tokens if word and word not in stop_words and not isHex(word)]

def isHex(word):
    try:
        int(word, 16)
        return True
    except ValueError:
        return False

def tokenizeH2V_C(content):
    content = content.replace('\n', '')
    html_content = DataFilter.removeContentInHTML(content)
    return [item for item in ' '.join(html_content.split()).split() if item]

def getSampleBatchCursor(last_id, batch_size):
    if not last_id:
        return Data_Collection.find({}, no_cursor_timeout=True).limit(batch_size).sort('_id',1)
    return Data_Collection.find({'_id': {'$gt': last_id}}, no_cursor_timeout=True).limit(batch_size)

def getSamples():
    return Data_Collection.find({}, no_cursor_timeout=True)

def getD2VModel(fname):
    return Doc2Vec.load(fname)

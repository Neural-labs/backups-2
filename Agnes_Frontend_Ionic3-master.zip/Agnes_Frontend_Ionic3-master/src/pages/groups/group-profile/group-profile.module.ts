import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';


import { GroupProfile } from './group-profile';
import { ComponentsModule } from '../../../components/components.module';

@NgModule({
  declarations: [
    GroupProfile
  ],
  imports: [
    IonicPageModule.forChild(GroupProfile),
    ComponentsModule
  ],
  exports: [
    GroupProfile
  ]
})

export class GroupProfileModule { }

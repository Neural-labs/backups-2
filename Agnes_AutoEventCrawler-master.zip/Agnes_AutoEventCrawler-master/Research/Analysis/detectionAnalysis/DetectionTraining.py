from config import db_config
from keras.models import Sequential, model_from_json
from keras.layers import Conv1D, MaxPooling1D, LSTM, Dense, Activation, Flatten, GlobalMaxPool1D, Dropout
from keras.callbacks import ModelCheckpoint
import multiprocessing
from sklearn.metrics import recall_score, f1_score, roc_auc_score, roc_curve
import numpy as np
import pickle
import logging
from bson.objectid import ObjectId
import random
import gc

cores = multiprocessing.cpu_count()

dbConn = db_config.getDBConn('dev')
Agnes = dbConn.Agnes
Data_Collection = Agnes.autocrawler_id_data
Val_Collection = Agnes.autocrawler_id_data_val


last_random_id = 4611682702678670684
split_index = 3984055764612543499
total_samples = Data_Collection.count()
validation_size = 52000
batch_size = 100
epochs = 5

INPUT_DIM = 640
RANDOM_SEED = 42

test_community = 'gwu'

useCharEmb = False
useHTMLEmb = True
useContentEmb = True
useManual = True

def runClassificationTraining():



    # print 'Initializing Global Variables...'
    # initGlobals()

    print 'Building Model...'
    model = getModel()

    steps_per_epoch = total_samples / batch_size
    validation_steps = validation_size / batch_size

    print 'Epochs',epochs
    print 'Steps per epoch', steps_per_epoch

    logging.info('Running detection training using test community %s' % test_community)
    logging.info('Starting sample generator')
    # sample_generator = getSampleGenerator()
    sample_generator = getSampleGeneratorV2(training=True)

    logging.info('Starting validation generator')
    # validation_generator = getValidationGenerator()
    validation_generator = getSampleGeneratorV2(training=False)

    logging.info('Fitting model...')
    logging.info('Total Samples: %d, Batch Size: %d, Steps per epoch %d, Validation Steps: %d' %
                 (total_samples, batch_size, steps_per_epoch, validation_steps))
    filepath = 'identification_classifier_test_'+ test_community + '.hdf5'
    checkpoint = ModelCheckpoint(filepath, verbose=1, save_best_only=True)
    callbacks_list = [checkpoint]
    model.fit_generator(generator=sample_generator, epochs=epochs, steps_per_epoch=steps_per_epoch,
                        validation_data=validation_generator, validation_steps=validation_steps,
                        callbacks=callbacks_list, verbose=1)

    evaluateModel(model)


def evaluateModel(model):

    X, y, samples = getEvaluationData()

    preds = model.predict(X)

    # print results

    for index in range(len(samples)):
        print samples[index]
        print preds[index]
        print y[index]
        print

    print '-----------------------------'
    print 'F1 Score:',f1_score(y, preds)



def runStats(predictions, actual_values):

    print 'ROC AUC Score:', roc_auc_score(actual_values, predictions)

    tpr, fpr, thresholds = roc_curve(actual_values, predictions)


def getModel():
    kernel_size = 5
    filters = 64
    lstm_output_size = 64
    input_dim = INPUT_DIM

    model = Sequential()
    model.add(Conv1D(filters,
                     kernel_size,
                     padding='same',
                     strides=1,
                     kernel_initializer='uniform',
                     input_shape=(None, input_dim),
                     batch_input_shape=(None, 1,input_dim)
                     ))
    model.add(Activation('relu'))
    model.add(Dropout(0.25))
    model.add(MaxPooling1D(padding='same'))
    model.add(LSTM(lstm_output_size))
    model.add(Dense(64, activation='relu'))
    model.add(Dropout(0.2))
    model.add(Dense(64, activation='relu'))
    model.add(Dropout(0.2))
    model.add(Dense(1, activation='sigmoid'))
    model.compile(loss='binary_crossentropy',
                  optimizer='adam',
                  metrics=['accuracy'])
    model.summary()
    return model

def getSimpleModel():
    pass

def getSampleGenerator():

    for epoch in range(epochs):
        logging.info('Sample Generator starting epoch %d\n' % epoch)
        last_id = 0
        batch_num = 0
        while True:

            sample_batch = getSampleBatchCursor(last_id, training=True)
            batch_count = sample_batch.count(with_limit_and_skip=True)

            if not sample_batch or not batch_count:
                logging.info('Sample Generator finished epoch %d\n' % epoch)
                break

            batch_num += 1
            # logging.info('Fetched Sample Batch %d\n' % batch_num)
            last_id = sample_batch[batch_count-1]['random_id']

            shuffle_array = []

            for sample in sample_batch:
                # logging.info('evtsource valid %r' % validSample(sample, training=True))
                # logging.info(sample)
                # raise ValueError('stop')
                if not validSample(sample, training=True):
                    continue
                features = getFeatures(sample)

                label = getLabel(sample)

                if not features:
                    continue

                shuffle_array.append(features+label)

            if shuffle_array:
                shuffle_array = np.array(shuffle_array)
                np.random.shuffle(shuffle_array)

                X,y = retrieveFromShuffle(shuffle_array)
                yield X, y
                del sample_batch
                gc.collect()

def getSampleGeneratorV2(training):
    # counter = 0
    for epoch in range(epochs):
        logging.info('Generator starting epoch %d, Training=%r\n' % (epoch, training))
        last_id = 0
        batch_num = 0

        while True:

            sample_batch = getSampleBatchCursor(last_id, training=training)
            batch_count = sample_batch.count(with_limit_and_skip=True)

            if not sample_batch or not batch_count:
                logging.info('Exiting sample generator training = %r' % training)
                continue # no items returned

            batch_num += 1
            if not training:
                logging.info('Fetched Sample Batch %d, last_id = %d\n' % (batch_num, last_id))
            last_id = sample_batch[batch_count-1]['random_id']

            shuffle_array = []

            for sample in sample_batch:
                # logging.info('evtsource valid %r' % validSample(sample, training=True))
                # logging.info(sample)
                # if counter % 100 ==
                if not validSample(sample, training=training):
                    continue
                # if not training and validSample(sample, training=training):
                #     logging.info(sample['evtsource'])
                    # logging.info(sample['_id'])
                    # raise ValueError('stop!')
                features = getFeatures(sample)

                label = getLabel(sample)

                if not features:
                    continue

                shuffle_array.append(features+label)

            if shuffle_array:
                shuffle_array = np.array(shuffle_array)
                np.random.shuffle(shuffle_array)

                X,y = retrieveFromShuffle(shuffle_array)

                # pos_items = len([a for a in y if a])
                # logging.info('%d samples, %d pos' % (len(y), pos_items))


                yield X, y
                del sample_batch
                gc.collect()

def getFeatures(sample):

    url_embedding = sample['url_embedding']

    if not url_embedding:
        return None

    html_embedding = sample['html_embedding']

    if not html_embedding:
        return None

    content_embedding = sample['content_embedding']

    if not content_embedding:
        return None

    features = []
    if useCharEmb:
        features += list(pickle.loads(url_embedding))
    if useHTMLEmb:
        features += list(pickle.loads(html_embedding))
    if useContentEmb:
        features += list(pickle.loads(content_embedding))
    if useManual:
        features += sample['manual_features']

    if np.isnan(np.sum(features)):
        return None

    features = scaleFeatures(features)

    return features

def retrieveFromShuffle(shuffle_array):
    X = [a[:-1] for a in shuffle_array]
    y = [a[-1] for a in shuffle_array]
    X = np.array(X)
    # X = scale(X)
    X = X.reshape(X.shape[0], 1, X.shape[1])
    y = np.array(y)
    return X,y

def reshapeData(X):
    X = np.array(X)
    X = X.reshape(X.shape[0], 1, X.shape[1])
    return X

def getValidationGenerator():

    for epoch in range(epochs):
        logging.info('Validation Generator starting epoch %d\n' % epoch)
        id_index = 0
        batch_num = 0
        while True:

            validation_batch = getValidationBatch(id_index)
            batch_count = validation_batch.count(with_limit_and_skip=True)

            if not validation_batch or not batch_count:
                break

            batch_num += 1

            id_index = validation_batch[batch_count-1]['random_id']

            X = []
            y = []

            for sample in validation_batch:
                if not validSample(sample, training=False):
                    continue
                features = getFeatures(sample)
                labels = getLabel(sample)

                if not features:
                    continue

                X.append(features)
                y.append(labels)
            if X:
                X = np.array(X)
                # X = scale(X)
                X = X.reshape(X.shape[0], 1, X.shape[1])
                y = np.array(y)

                yield X, y

def getEvaluationData():
    eval_cursor = getEvalCursor()

    X = []
    y = []
    samples = []

    for sample in eval_cursor:
        features = getFeatures(sample)

        if not features:
            continue

        X.append(features)
        y.append(getLabel(sample))
        samples.append({
            'community':sample['community'],
            'evtsource':sample['evtsource']
        })

    return X,y,samples

def validSample(sample, training):
    if not sample['evtsource'] and sample['label']:
        return False # remove items without a valid evtsource
    sample_community = sample['community']
    if sample['evtsource'] in ['eventbrite.com(washington)','eventbrite.com']: # trim the big items to reduce bias
        return random.randint(0,9) <= 3
    if training:
        return sample_community != test_community # return valid if we want to use it for training
    else:
        return sample_community == test_community # return valid if we want to use for testing


def getLabel(sample):
    return [sample['label']]

def scaleFeatures(features):

    minScalingFeatures = []
    maxScalingFeatures = []

    if useCharEmb:
        minScalingFeatures += minFeatures[:300]
        maxScalingFeatures += minFeatures[:300]

    if useHTMLEmb:
        minScalingFeatures += minFeatures[300:400]
        maxScalingFeatures += maxFeatures[300:400]

    if useContentEmb:
        minScalingFeatures += minFeatures[400:700]
        maxScalingFeatures += maxFeatures[400:700]

    if useManual:
        minScalingFeatures += minFeatures[700:]
        maxScalingFeatures += maxFeatures[700:]

    features = list(features)
    for index in range(len(features)):
        denominator = float(maxScalingFeatures[index] - minScalingFeatures[index])
        if not denominator:
            continue
        features[index] = features[index] / denominator

    return features

def getSampleBatchCursor(last_id, training):

    if training:
        query = {'random_id': {'$gt': last_id}}
    else:
        query = {'random_id': {'$gt': last_id}, 'community':test_community}

    return Data_Collection.find(query, no_cursor_timeout=True).limit(batch_size).sort('random_id', 1)

def getValidationBatch(index_id):
    return Data_Collection.find({'random_id': {'$gt': index_id}, 'community':test_community}, no_cursor_timeout=True).limit(batch_size).sort('random_id', 1)
    # return Val_Collection.find({}, no_cursor_timeout=True).sort('random_id',1)

def getEvalCursor():
    return Val_Collection.find({}, no_cursor_timeout=True).sort('random_id', 1)

def getValBatch():
    val_batch_size = 100
    validation_index = ObjectId('5a91494d55c8574343814a60')
    return Data_Collection.find({'_id': {'$gt': validation_index}, "features_h2v_w": { '$exists': True }}, no_cursor_timeout=True).limit(val_batch_size)

minFeatures = [-0.489, -0.5723, -1.074, -0.4504, -1.024, -1.184, -0.3992, -0.6245, -0.5566, -0.5254, -0.929, -0.6924, -0.4077, -0.49, -0.9634, -0.8677, -0.5757, -0.9766, -0.6577, -0.859, -0.2568, -0.3901, -0.9043, -0.5674, -0.993, -0.6323, -0.5107, -1.255, -1.2295, -0.1995, -0.619, -0.8896, -0.3691, -0.737, -0.5127, -0.7266, -0.863, -0.5015, -0.5483, -0.3523, -0.5728, -0.316, -0.421, -0.6685, -0.612, -0.823, -0.9556, -0.6855, -0.7056, -0.3489, -0.4727, -0.7188, -0.098, -0.523, -0.6934, -0.508, -0.1393, -0.4854, -0.5347, -0.527, -0.73, -0.5903, -0.4456, -0.726, -0.5366, -0.8643, -1.193, -0.225, -0.6465, -0.9263, -0.839, -1.038, -0.69, -1.461, -0.4912, -0.7104, -0.475, -0.599, -0.5415, -0.2869, -0.9023, -0.9653, -0.212, -0.707, -0.571, -0.76, -1.011, -0.5967, -0.6846, -0.882, -0.907, -0.534, -0.7856, -0.7725, -0.869, -1.14, -0.2281, -0.673, -0.9414, -0.7007, 0.1235, -0.3274, 0.1013, -0.04214, -0.2607, 0.02415, 0.02939, -0.00144, -0.09314, -1.468, 0.34, -0.1125, -0.1638, 0.094, 0.2214, 0.007675, 0.1179, -1.173, 0.2834, 0.02626, -0.007374, 0.03824, 0.0977, -0.0437, -0.10895, -0.0625, 0.1033, -0.08704, -0.162, -0.0609, 0.10736, -0.2605, 0.0345, -0.02179, -0.255, 0.08044, -0.05188, -0.035, 0.0394, 0.1461, -0.1505, -0.2346, -0.1738, -0.00144, -0.08234, -0.11194, 0.1702, -0.1842, -0.10016, -0.00943, 0.02884, -0.02574, -0.007576, -0.09106, 0.01384, -0.07983, -0.0368, -0.02385, -0.01229, 0.0503, -0.07404, -0.0869, -0.0496, -0.509, -0.3052, 0.1436, -0.0164, -0.1392, -0.078, -0.2993, -0.06934, -0.1783, -0.2812, -0.0697, -0.09985, -0.1178, -0.1351, 0.0668, -0.0797, -0.2122, -0.0819, -0.1004, 0.0715, 0.002163, -0.03096, 0.2264, 0.4236, -0.1686, -0.3855, -0.1893, 0.068, -0.1521, 0.0186, 0.0801, -0.1224, 0.2915, -0.1344, -0.0795, -0.09186, 0.05585, -0.04135, -0.1315, 0.08453, 0.03564, -0.0429, -0.714, -0.0455, -0.227, -0.1703, -0.1223, -0.1261, 0.1663, -0.1632, 0.02464, -0.0993, 0.06168, -0.0918, -0.1274, -0.01057, -0.1826, -0.1641, -0.03784, -0.04553, 0.10004, -0.02237, -0.11725, -0.1438, -0.00603, 0.012375, -0.01553, -0.1665, -0.07935, -0.00569, 0.0263, -0.2448, -0.05878, -0.0312, -0.0405, -0.1577, 0.008255, 0.674, -0.04425, -0.266, -0.05164, -0.01296, 0.08374, 0.1017, -0.0793, -0.0932, 0.1354, -0.01127, -0.1273, -0.04837, -0.1278, 0.04117, 0.1003, 0.1378, -0.1526, 0.03854, 0.04688, -0.07294, -0.01843, -0.06323, 0.113, 0.1992, 0.144, -0.2401, 0.09717, -0.3152, -0.081, -0.001453, 0.02055, 0.1305, 0.10297, 0.10126, -0.149, -0.0681, -0.1989, -0.325, -0.077, -0.04758, -0.01567, 0.08496, 0.10803, 0.1881, -0.06665, 0.1503, -0.1453, -0.0823, -0.00891, 0.2051, -0.01872, 0.1071, -0.234, -0.05048, -0.227, 0.06976, 0.1185, 0.2003, -0.3335, -0.0855, 0.09076, 0.03342, -0.10364, -0.281, -0.12256, -0.06995, -0.00887, 0.0802, -0.0167, 0.0887, 0.08295, -0.02687, 0.2115, -0.1827, -0.2822, 0.1368, -0.1564, 0.4104, -0.0439, 0.04797, -0.1395, 0.1471, -0.2177, -0.1669, -0.2058, -0.11035, -0.2852, -0.1382, -0.338, 0.0812, -0.08295, -0.184, -0.1247, -0.0139, 0.0591, -0.0626, 0.0507, 0.11237, -0.2183, -0.0816, -0.09283, -0.1615, -0.2323, -0.1394, 0.0629, 0.06116, 0.06885, 0.3008, -0.05145, -0.09656, -0.05057, 0.00751, 0.04773, -0.11646, -0.526, -0.1328, 0.03937, -0.0616, -0.1788, -0.2023, -0.2646, -0.04755, -0.201, -0.1111, 0.1631, -0.03047, -0.1534, -0.5396, 0.05273, -0.2186, -0.07404, 0.08075, 0.2294, -0.05188, -0.01271, -0.02303, -0.1838, -0.1052, -0.3088, -0.2952, -0.2233, -0.1309, -0.0803, 0.10144, 0.0946, -0.2113, 0.1157, -0.2208, 0.03497, 0.3503, -0.1254, -0.1186, -0.00358, -0.07074, -0.04047, -0.011955, 0.1602, -0.08624, -0.1721, -0.1881, -0.2297, -0.3438, -0.3066, -0.3035, -0.1718, -0.2754, -0.3145, -0.2734, -0.2103, -0.2008, -0.255, -0.2551, -0.2773, -0.4062, -0.363, -0.11536, -0.1855, -0.2081, -0.504, -0.2212, -0.1584, -0.1864, -0.3044, -0.4336, -0.248, -0.3545, -0.0934, -0.1769, -0.4985, -0.589, -0.508, -0.3108, -0.562, -0.2225, -0.573, -0.2474, -0.4277, -0.358, -0.1494, -0.2957, -0.345, -0.3115, -0.2096, -0.1908, -0.524, -0.2583, -0.4077, -0.3403, -0.1846, -0.649, -0.2598, -0.3438, -0.3047, -0.3418, -0.3398, -0.3872, -0.2886, -0.3457, -0.2922, -0.3345, -0.2369, -0.2783, -0.275, -0.293, -0.352, -0.2832, -0.1168, -0.3623, -0.1786, -0.2155, -0.4004, -0.272, -0.473, -0.377, -0.4602, -0.0996, -0.3904, -0.2445, -0.3118, -0.1962, -0.3071, -0.1097, -0.1714, -0.2274, -0.3455, -0.205, -0.201, -0.1487, -0.3848, -0.565, -0.615, -0.291, -0.4043, -0.2588, -0.1729, -0.10565, -0.4097, -0.1953, -0.4082, -0.355, -0.27, -0.2317, -0.3242, -0.327, -0.2832, -0.5757, -0.2512, -0.255, -0.1963, -0.2373, -0.322, -0.2251, -0.3145, -0.1553, -0.2656, -0.2576, -0.2454, -0.1519, -0.3135, -0.33, -0.267, -0.731, -0.3196, -0.4104, -0.2386, -0.4536, -0.3242, -0.2461, -0.3503, -0.5947, -0.2537, -0.313, -0.2566, -0.3047, -0.3584, -0.2301, -0.226, -0.2695, -0.2354, -0.2908, -0.3691, -0.4492, -0.2427, -0.4272, -0.379, -0.2361, -0.2362, -0.2695, -0.4043, -0.2217, -0.4292, -0.457, -0.2656, -0.1888, -0.3743, -0.4492, -0.2412, -0.5586, -0.2837, -0.3357, -0.1196, -0.375, -0.2461, -0.209, -0.2793, -0.2688, -0.1621, -0.453, -0.4258, -0.463, -0.1982, -0.4746, -0.3289, -0.306, -0.2301, -0.1492, -0.3682, -0.3203, -0.582, -0.4336, -0.4004, -0.2487, -0.3809, -0.2876, -0.3567, -0.59, -0.2303, -0.155, -0.508, -0.336, -0.2842, -0.542, -0.2832, -0.377, -0.2108, -0.1582, -0.354, -0.334, -0.4924, -0.3896, -0.11487, -0.2505, -0.2025, -0.2664, -0.3008, -0.3018, -0.3203, -0.2253, -0.195, -0.269, -0.3484, -0.4563, -0.1454, -0.4246, -0.1577, -0.135, -0.1832, -0.291, -0.265, -0.3594, -0.1735, -0.3652, -0.584, -0.2903, -0.4883, -0.2583, -0.2993, -0.3066, -0.3777, -0.2695, -0.1714, -0.2222, -0.3477, -0.2168, -0.235, -0.2158, -0.2465, -0.1957, -0.289, -0.3145, -0.3047, -0.1971, -0.416, -0.1998, -0.461, -0.3062, -0.0929, -0.3352, -0.2903, -0.3616, -0.2152, -0.2922, -0.249, -0.2256, -0.2812, -0.3625, -0.2754, -0.2852, -0.3015, -0.1306, -0.2451, -0.2319, -0.3145, -0.1815, -0.1571, -0.4219, -0.377, -0.455, -0.289, -0.1647, -0.1968, -0.354, -0.2129, -0.1418, -0.3398, -0.3223, -0.3928, -0.2542, -0.1837, -0.32, -0.1422, -0.2103, -0.1436, -0.3926, -0.3027, -0.373, -0.3801, -0.1924, -0.1399, -0.3398, -0.348, -0.364, -0.1481, -0.1836, -0.3594, -0.253, -0.649, -0.3242, -0.1707, 4, 20, 4, 13, 0.0, 1.0, 4.0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]

maxFeatures = [0.9785, 0.7485, 0.493, 1.129, 0.6416, 0.3726, 0.7964, 0.637, 0.586, 0.836, 0.4363, 1.3125, 0.6123, 1.011, 0.622, 0.7573, 0.5312, 0.4324, 0.8315, 0.2076, 0.7266, 0.972, 0.4153, 1.12, 0.497, 0.4248, 0.788, 0.4229, 0.04453, 0.9917, 0.719, 0.2113, 1.124, 1.04, 0.6733, 0.6855, 0.935, 0.9487, 0.566, 0.6357, 0.814, 0.995, 0.916, 0.916, 1.021, 0.582, 0.7144, 0.6846, 0.511, 0.6333, 1.074, 0.636, 1.173, 1.161, 0.644, 0.5356, 0.9697, 1.226, 0.5903, 0.732, 0.5454, 0.881, 0.8403, 0.7627, 0.7676, 0.4739, 0.3667, 0.864, 0.4802, 1.066, 0.803, 0.4536, 0.5244, 0.3896, 0.6997, 0.725, 0.66, 0.5293, 0.672, 0.6743, 1.181, 0.2866, 1.229, 0.5303, 0.4563, 0.3262, 0.6855, 0.689, 0.856, 0.645, 0.737, 0.733, 0.4915, 0.73, 0.5317, 0.2468, 1.574, 0.8086, 0.258, 0.4758, 0.2502, -0.2037, 0.2239, 0.01906, -0.1043, 0.1261, 0.075, 0.10504, -0.02605, -1.264, 0.446, 0.01503, -0.05978, 0.2034, 0.2734, 0.0988, 0.1962, -1.064, 0.384, 0.0987, 0.0638, 0.1477, 0.2837, 0.06726, -0.03607, 0.03867, 0.1621, 0.01598, -0.09595, 0.1584, 0.1658, -0.1677, 0.1401, 0.06085, -0.1906, 0.1423, 0.03003, 0.0877, 0.1364, 0.366, -0.0596, -0.06042, -0.02428, 0.1214, -0.0231, -0.033, 0.255, -0.06354, -0.04276, 0.1498, 0.1254, 0.12067, 0.0819, 0.03107, 0.08777, -0.00818, 0.05197, 0.0332, 0.086, 0.1416, -0.004257, 0.03574, 0.03674, -0.3818, -0.1327, 0.2108, 0.05496, -0.0627, -0.004784, -0.1364, -0.008194, -0.03114, -0.0949, 0.03053, -0.0008073, 0.04956, -0.04318, 0.2095, 0.03497, -0.1299, -0.01918, -0.01037, 0.1852, 0.10614, 0.02185, 0.347, 0.6436, -0.02812, -0.3035, -0.0737, 0.1611, -0.00458, 0.0734, 0.1697, -0.0473, 0.3923, -0.0356, -0.0171, -0.006214, 0.1101, 0.02977, 0.001044, 0.1927, 0.153, 0.00892, -0.4287, 0.02847, -0.1284, -0.0989, 0.0272, -0.0352, 0.2764, -0.08624, 0.0946, -0.0351, 0.1783, -0.02664, -0.0293, 0.0648, -0.0456, -0.05554, 0.03632, 0.04837, 0.1605, 0.0659, -0.0309, -0.04898, 0.096, 0.1136, 0.1089, -0.0609, 0.01585, 0.05978, 0.1208, -0.0927, -0.002382, 0.04556, 0.0886, -0.07495, 0.0678, 0.8423, 0.0848, -0.1777, -0.000908, 0.0489, 0.159, 0.1587, -0.00391, 0.01513, 0.1937, 0.03998, 0.01083, 0.01179, 0.000839, 0.121, 0.1802, 0.277, -0.0859, 0.1499, 0.1715, 0.02574, 0.05035, 0.04947, 0.25, 0.3528, 0.2798, -0.1454, 0.1642, -0.1814, -0.014595, 0.11945, 0.1034, 0.2034, 0.174, 0.1693, -0.05307, -0.001733, -0.06396, -0.2424, 0.01747, -0.01436, 0.08673, 0.1823, 0.167, 0.2632, 0.00663, 0.2028, -0.07294, -0.004215, 0.0904, 0.2622, 0.09827, 0.1682, -0.1043, 0.063, -0.10974, 0.2108, 0.1858, 0.3096, -0.223, 0.007572, 0.202, 0.1047, -0.04486, -0.2352, -0.03677, 0.0194, 0.0949, 0.1344, 0.0562, 0.2024, 0.1902, 0.02461, 0.2961, -0.00323, -0.1936, 0.1959, -0.001793, 0.495, 0.0494, 0.1381, -0.05768, 0.2194, -0.1438, -0.08215, -0.0823, -0.01274, -0.1757, -0.0477, -0.2438, 0.1666, -0.002253, -0.03336, -0.05594, 0.079, 0.137, 0.02736, 0.11127, 0.2087, -0.1381, -0.02835, 0.007076, -0.0597, -0.0827, -0.06445, 0.1875, 0.1493, 0.1284, 0.4102, 0.02852, -0.00874, 0.0546, 0.09015, 0.1406, -0.04395, -0.4521, -0.01625, 0.1561, -0.01349, -0.08246, -0.11273, -0.171, 0.01663, -0.1532, 0.02759, 0.3118, 0.0491, -0.02954, -0.3806, 0.2246, -0.1173, 0.01381, 0.1422, 0.3147, 0.05908, 0.0402, 0.0441, -0.010704, 0.07733, -0.2281, -0.1855, -0.1661, -0.068, -0.010765, 0.2234, 0.1522, -0.1062, 0.17, -0.1627, 0.324, 0.4753, -0.0754, -0.01779, 0.075, 0.06866, 0.0633, 0.0874, 0.229, -0.0351, -0.1154, 0.3086, 0.416, 0.2214, 0.2085, 0.4902, 0.2573, 0.2346, 0.3022, 0.375, 0.3613, 0.2437, 0.4084, 0.3247, 0.2268, 0.2483, 0.2812, 0.3184, 0.3003, 0.25, 0.2151, 0.3027, 0.3584, 0.4607, 0.4062, 0.2737, 0.2734, 0.265, 0.578, 0.3594, 0.1821, 0.2236, 0.2754, 0.1589, 0.2241, 0.284, 0.1992, 0.2162, 0.3223, 0.2428, 0.4805, 0.292, 0.1731, 0.535, 0.4531, 0.2822, 0.1619, 0.1865, 0.2109, 0.1826, 0.3337, 0.3984, 0.2898, 0.2783, 0.2197, 0.2295, 0.4343, 0.207, 0.1465, 0.2913, 0.412, 0.3242, 0.2075, 0.1176, 0.254, 0.1702, 0.1289, 0.2032, 0.3188, 0.2927, 0.377, 0.2297, 0.2598, 0.3809, 0.2289, 0.208, 0.2188, 0.412, 0.1865, 0.2925, 0.4304, 0.2622, 0.3972, 0.42, 0.322, 0.657, 0.2395, 0.374, 0.414, 0.2378, 0.2666, 0.2773, 0.1776, 0.2338, 0.2917, 0.2467, 0.403, 0.6094, 0.2285, 0.3372, 0.3337, 0.3828, 0.2668, 0.2837, 0.2208, 0.187, 0.4355, 0.2109, 0.4238, 0.206, 0.254, 0.2717, 0.2002, 0.2578, 0.1611, 0.5474, 0.3906, 0.1671, 0.1578, 0.451, 0.3215, 0.2351, 0.3064, 0.1503, 0.2173, 0.2783, 0.2133, 0.1398, 0.508, 0.2637, 0.2164, 0.3809, 0.4922, 0.4785, 0.4038, 0.1926, 0.1401, 0.3945, 0.418, 0.2485, 0.3247, 0.3574, 0.2646, 0.2034, 0.2076, 0.2793, 0.2329, 0.4336, 0.3694, 0.3672, 0.1956, 0.4902, 0.2002, 0.34, 0.5547, 0.2957, 0.1548, 0.2344, 0.3774, 0.2009, 0.2617, 0.197, 0.4116, 0.3008, 0.2783, 0.3643, 0.219, 0.2983, 0.4395, 0.199, 0.2988, 0.1735, 0.241, 0.4785, 0.1699, 0.2656, 0.3906, 0.4363, 0.1606, 0.287, 0.10266, 0.0746, 0.208, 0.2336, 0.2646, 0.2905, 0.2427, 0.2219, 0.6367, 0.341, 0.2617, 0.2383, 0.2162, 0.3418, 0.2164, 0.3997, 0.2551, 0.2329, 0.1348, 0.34, 0.2607, 0.2479, 0.4043, 0.4453, 0.2266, 0.3386, 0.2727, 0.2861, 0.3027, 0.4011, 0.472, 0.1593, 0.2722, 0.1855, 0.342, 0.2615, 0.3538, 0.3477, 0.3926, 0.3242, 0.0968, 0.1792, 0.2778, 0.206, 0.344, 0.1865, 0.1646, 0.2274, 0.3477, 0.1979, 0.4114, 0.2072, 0.3613, 0.1584, 0.2524, 0.1879, 0.2025, 0.4531, 0.252, 0.334, 0.2727, 0.4114, 0.255, 0.2429, 0.1508, 0.3499, 0.2422, 0.1521, 0.63, 0.3486, 0.1562, 0.181, 0.3281, 0.1528, 0.2605, 0.2678, 0.2302, 0.2292, 0.2358, 0.2168, 0.1004, 0.634, 0.2576, 0.4387, 0.1692, 0.291, 0.3933, 0.2382, 0.1912, 0.3477, 0.1934, 0.2126, 0.3425, 0.2742, 0.2786, 0.2407, 0.183, 0.3457, 0.2668, 0.4514, 0.2986, 0.1263, 0.3438, 0.1958, 0.4136, 0.3271, 0.301, 0.2483, 0.2314, 0.3528, 0.357, 0.2256, 0.2441, 0.166, 0.3735, 0.3032, 0.133, 0.2482, 0.167, 0.2141, 0.4153, 12746347, 3402183, 12568793, 3020366, 0.7916666666666666, 41.47826086956522, 24708.0, 46527, 50029, 25004, 21494, 16514, 58114, 26761, 18505, 14591, 18511, 16813, 36161, 17753, 32386, 26651, 29162, 79250, 0, 13995, 0, 22792, 15031, 24606, 13161, 28056, 21887, 53506, 18228, 18776, 10913, 27762, 23877, 587, 12887, 971, 12889, 478, 485, 1145, 1553, 74, 615, 511, 67, 1556, 250, 161, 614, 369, 317, 490, 3190, 342, 326, 2441, 1400, 12675, 2255, 616, 44, 548, 160, 522, 23, 138, 20, 142, 106, 397, 178, 33, 12191, 1138, 1245, 1138, 11155, 11155, 4039, 12192, 1448, 3097, 1577, 4685, 12106, 1560, 156, 4233, 70, 124, 423, 846, 171, 846, 1173, 138, 5109, 808, 343, 12, 441, 47, 163, 47, 219, 78, 97, 110, 208, 1180, 37, 4, 3, 4, 3, 5, 3, 4, 10, 1, 3, 1, 1, 1928, 1, 21, 26352, 6, 2498, 362, 995, 954, 4061, 839, 389049, 394, 4088, 1583, 8, 380, 1576, 8, 574, 11466, 11339, 3, 5, 2595, 2388, 321, 4824, 2, 32, 9312, 8847, 618, 405, 18, 15, 1803, 1136, 51, 121, 1163, 30, 282, 625, 6, 367, 9, 2625254, 25244, 1900, 1405, 456, 2751, 2, 108, 2, 64, 512, 1877, 16, 0, 25216, 446, 1309, 1593, 1, 127, 124, 609, 200, 0, 456, 2849, 1405, 3372, 830, 548, 2, 1406, 2, 929, 2406, 4, 4362, 51, 24565, 4, 39, 2, 0, 5, 588, 12, 1409, 5932, 71, 36, 323, 26341, 1737, 297, 36, 179, 860, 172, 20070, 1405, 83, 11238, 630, 24128]

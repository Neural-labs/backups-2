import { Component, Input } from '@angular/core';
import { App, Events, PopoverController } from 'ionic-angular';


@Component({
    selector: 'agnes-news-card',
    templateUrl: 'agnes-news-card.html',
    providers: []
})
export class AgnesNewsCard {

    @Input() newsItem: Object;
    user: Object;

    constructor(public appCtrl: App,
                private events: Events,
                private popoverCtrl: PopoverController) {
    }

    ngOnInit(){
        this.user = JSON.parse(localStorage.getItem('agnesUser'));

        this.newsItem = {
            headline: 'Board of Trustees boosts dining dollars amid food insecurity concerns',
            picurl: 'https://assets.change.org/photos/0/ma/eu/TLMaEUVMfSSqAfp-800x450-noPad.jpg?1491094962',
            views: [1,2,3,4,5,6,7,8,9,0],
            type: {
                typename: 'University News',
                picurl: 'https://lh5.ggpht.com/li5DQn0_vCOhRfCUZMVx34W4R36wsAFHlTOQYjCC-wUeD3M8Iqw5UibRTlBfHQ3Meq-Q=w300'
            },
            newsContent: 'We already have 12 teams who have submitted bids for this year\'s Glazed Daze tourney.  I\'ve also been contacted by 3 other teams who are all finalizing their tournament schedule, these teams should be getting back to me within a week or so to submit their bid as well..' +
            'We have 6 of the top 9 teams from 2017 returning this year.  Things are really shaping up to be a very competitive and amazing tournament!  Please get those bids in quickly, you don\'t want to go on a wait list!!!' +
            'Hope to see you all in June!',
            author: {
                _id: '12334567',
                fname: 'Alice',
                lname: 'Kingsley'
            },
            last_updated: new Date(),
            event: {
                _id: '234655869',
                evtname: 'SA Meeting to Discuss Dining Dollars',
                picurl: 'https://vignette.wikia.nocookie.net/bapc/images/c/c9/Puppycat.png/revision/latest?cb=20130714012411'
            }
        };
    }

    //go to news card
    openNewsItem(){
        this.newsItem['views'].push(this.user['_id']);
        this.appCtrl.getRootNav().push(
            'NewsProfile',
            {
                'newsItem': this.newsItem
            }, {
                animation: 'ios-transition',
                duration: 350

            });
    }

}

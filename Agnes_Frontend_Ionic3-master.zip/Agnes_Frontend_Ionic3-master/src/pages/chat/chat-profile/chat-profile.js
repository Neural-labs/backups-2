"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var core_1 = require('@angular/core');
var chat_service_1 = require('../chat.service');
var events_service_1 = require('../../events/events.service');
var report_1 = require('../../popups/report/report');
var people_profile_1 = require('../../people/people-profile/people-profile');
var event_profile_1 = require('../../events/event-profile/event-profile');
var app_component_1 = require('../../../app/app.component');
var ChatProfile = (function () {
    function ChatProfile(navParams, events, viewCtrl, navCtrl, chatService, eventsService, actionSheetCtrl, popoverCtrl, platform, keyboard, badge) {
        this.navParams = navParams;
        this.events = events;
        this.viewCtrl = viewCtrl;
        this.navCtrl = navCtrl;
        this.chatService = chatService;
        this.eventsService = eventsService;
        this.actionSheetCtrl = actionSheetCtrl;
        this.popoverCtrl = popoverCtrl;
        this.platform = platform;
        this.keyboard = keyboard;
        this.badge = badge;
        this.oldHeight = 0;
        this.messages = [];
        this.tMessages = [];
    }
    ChatProfile.prototype.ngOnInit = function () {
        var _this = this;
        this.loading = true;
        this.keyboard.disableScroll(true);
        this.keyboard.hideKeyboardAccessoryBar(true);
        this.channel = this.navParams.data.channel;
        this.user = JSON.parse(localStorage.getItem("agnesUser"));
        this.messages = [];
        this.receiverInfo = {
            '_id': this.channel['_id'],
            'fname': this.channel['fname'],
            'lname': this.channel['lname'],
            'picurl': this.channel['picurl']
        };
        this.groupMembersInfo = [];
        this.membersInfo = [];
        this.groupMembersStr = '';
        this.messageText = '';
        this.shouldBlur = true;
        this.scrollDown = true;
        var ind = this.user['channels'].map(function (a) { return a['receiverId']; }).indexOf(this.channel['_id']);
        this.channel['sid'] = this.user['channels'][ind]['cid'];
        localStorage.setItem('agnesChat', this.navParams.data.channel['_id']);
        this.initMessages(this.receiverInfo['_id']);
        //handle message received push notification - display new message in chat
        this.events.subscribe('messageReceived', function (value) {
            _this.rmNotifications();
            var data = value['sender'];
            if (value.event) {
                data['sid'] = value['message']['sid'];
                if (value.event['picurl'] == '' || value.event['thumbnail'] == '') {
                    value.event['thumbnail'] = "assets/img/pattern_" + Math.floor((Math.random() * 15) + 1) + '.png';
                }
                data['body'] = {
                    'message': value['event'],
                    'igiyg': true,
                    'extra': ''
                };
                var time = app_component_1.Agnes.processGMT(value['event']['starttime']);
                data['body']['message']['date'] = time.date.substring(5, time.date.length);
                data['body']['message']['time'] = time.time;
            }
            else {
                data['body'] = JSON.parse(data['lastmessage']);
            }
            var ind = _this.messages.map(function (a) {
                return a['dateString'];
            }).indexOf('Today');
            if (ind == -1) {
                _this.messages.push({
                    dateString: 'Today',
                    messages: [data],
                });
            }
            else {
                data['showTimestamp'] =
                    (((new Date(data['date_created']).getTime() - new Date(_this.messages[ind]['messages'][(_this.messages[ind]['messages'].length - 1)]['date_created']).getTime()) / 60000)
                        > 10);
                _this.messages[ind]['messages'].push(data);
            }
            // setTimeout(() => {
            //   let elem = document.getElementById('chatRoomScroll');
            //   elem.scrollTop = elem.scrollHeight;
            //   this.chatRoom.scrollToBottom(0);
            // }, 25);
        });
        //close chat if user is trying to open another chat from a push notification
        this.events.subscribe('closeCurrentChat', function (id) {
            if (id == _this.receiverInfo['_id']) {
                _this.closeChatProfile();
            }
        });
    };
    //apply correct CSS class for chat image based on orientation
    ChatProfile.prototype.imgLoad = function (ev) {
        var img = ev.target;
        if (img.naturalWidth > img.naturalHeight) {
            this.orientation = 'landscape';
        }
        else if (img.naturalWidth < img.naturalHeight) {
            this.orientation = 'portrait';
        }
        else {
            this.orientation = 'even';
        }
    };
    ChatProfile.prototype.ngAfterViewInit = function () {
    };
    ChatProfile.prototype.callFunction = function () {
        if (this.scrollDown) {
            var elem = document.getElementById('chatRoomScroll');
            elem.scrollTop = elem.scrollHeight;
            this.scrollDown = false;
        }
    };
    ChatProfile.prototype.ngOnDestroy = function () {
        this.setUnread();
        this.keyboard.disableScroll(false);
        this.keyboard.hideKeyboardAccessoryBar(false);
        this.events.unsubscribe('messageReceived');
        localStorage.removeItem('agnesChat');
    };
    ChatProfile.prototype.setUnread = function () {
        var _this = this;
        var usData = {
            'user1': this.user['_id'],
            'user2': this.receiverInfo['_id'],
            'status': true
        };
        this.chatService.unreadStatus(usData).then(function (value) {
            if (value['success'] == false && value['message'] == 'Failed to authenticate token.') {
                app_component_1.Agnes.showError('Your login token has expired, please sign in again!');
                _this.events.publish('logout');
            }
        }).catch(function (err) {
            _this.setUnread();
        });
    };
    ChatProfile.prototype.initMessages = function (receiverId) {
        var _this = this;
        this.events.publish('readChat', this.receiverInfo['_id']);
        this.rmNotifications();
        var data = {
            'users_id': this.user['_id'],
            'deviceId': this.user['deviceid'],
            'community': this.user['community']
        };
        this.chatService.twilioToken(data).then(function (val) {
            var chatClient = new window['Twilio'].Chat.Client(val['token']);
            chatClient.initialize()
                .then(function () {
                chatClient.getChannelBySid(_this.channel['sid']).then(function (channel) {
                    channel.getMessages(50).then(function (messages) {
                        _this.getAllMessages(messages);
                    });
                });
            });
        }).catch(function (err) {
            console.log(err);
        });
    };
    ChatProfile.prototype.getAllMessages = function (paginator) {
        var _this = this;
        var ms = paginator.items.map(function (a) {
            return {
                'body': JSON.parse(a.body),
                'from': a.author,
                'date_created': new Date(a.dateUpdated),
                'sid': a.sid
            };
        });
        this.tMessages = ms.concat(this.tMessages);
        if (paginator.hasPrevPage) {
            paginator.prevPage().then(function (val) {
                paginator.prevPage().then(function (val) {
                    _this.getAllMessages(val);
                });
            });
        }
        else {
            this.processMessages(this.tMessages, false);
        }
    };
    ChatProfile.prototype.rmNotifications = function () {
        var _this = this;
        //remove background notification if applicable (chat or sent IGIYG)
        var nts = JSON.parse(localStorage.getItem('agnesNotifications'));
        if (nts) {
            var nts2 = nts.filter(function (a) {
                return ((a.additionalData.category != 'chat' && a.additionalData.category != 'IYGIG_sent') ||
                    ((a.additionalData.category == 'chat' || a.additionalData.category == 'IYGIG_sent')
                        && a.additionalData.sender['_id'] != _this.receiverInfo['_id']));
            });
            if (nts2.length < nts.length) {
                this.badge.set(nts2.length);
                var rms = [];
                for (var n = 0; n < nts2.length; n++) {
                    if ((nts2[n].additionalData.category == 'chat' || nts2[n].additionalData.category == 'IYGIG_sent')
                        && nts2[n].additionalData.sender['_id'] == this.receiverInfo['_id']) {
                        rms.push(n);
                    }
                }
                for (var r in rms) {
                    nts2.splice(rms[r], 1);
                }
                localStorage.setItem('agnesNotifications', JSON.stringify(nts2));
            }
        }
    };
    ChatProfile.prototype.closeChatProfile = function () {
        var data = null;
        if (this.messages.length > 0) {
            var lastMs = this.messages[this.messages.length - 1].messages;
            var last = lastMs[lastMs.length - 1];
            data = {
                lastmessage: last['body'],
                time: last.date_created,
                _id: this.receiverInfo['_id'],
                lname: this.receiverInfo['lname'],
                fname: this.receiverInfo['fname'],
                status: true,
                picurl: this.receiverInfo['picurl'],
                from: last['from']
            };
        }
        this.viewCtrl.dismiss(data, {}, {
            animate: false
        });
    };
    ChatProfile.prototype.openChatMenu = function () {
        var _this = this;
        var btns = [
            {
                text: 'Report',
                icon: 'md-flag',
                handler: function () { _this.reportUser(); }
            }, {
                text: 'Cancel',
                role: 'cancel',
                icon: 'md-close',
                handler: function () { }
            }
        ];
        var actionSheet = this.actionSheetCtrl.create({
            title: '',
            buttons: btns
        });
        actionSheet.present();
    };
    ChatProfile.prototype.processMessages = function (ms, more) {
        var today = new Date().toLocaleDateString();
        var date = null;
        var dateString = '';
        var ind = null;
        for (var m = 0; m < ms.length; m++) {
            if (ms[m].from === this.user['_id'] && ms[m]['body']['igiyg']) {
                ms.splice(m, 1);
                m = m - 1;
            }
            else {
                date = new Date(ms[m]['date_created']);
                dateString = (date.toLocaleDateString() == today) ? 'Today' : date.toLocaleDateString();
                ms[m]['timestamp'] = date.toLocaleTimeString().replace(/:\d\d\s/, '');
                //message is an IGIYG invite
                if (ms[m]['body']['igiyg']) {
                    if (ms[m]['body']['message']['picurl'] == '' || ms[m]['body']['message']['thumbnail'] == '') {
                        ms[m]['body']['message']['thumbnail'] = "assets/img/pattern_" + Math.floor((Math.random() * 15) + 1) + '.png';
                    }
                    var time = app_component_1.Agnes.processGMT(ms[m]['body']['message']['starttime']);
                    ms[m]['body']['message']['date'] = time.date.substring(5, time.date.length);
                    ms[m]['body']['message']['time'] = time.time;
                }
                ms[m]['showTimestamp'] = m > 0
                    ? ((date.getTime() - new Date(ms[m - 1]['date_created']).getTime()) / 60000 > 10) : true;
                ind = this.messages.map(function (a) { return a['dateString']; }).indexOf(dateString);
                if (ind == -1) {
                    var item = {
                        'dateString': dateString,
                        messages: [ms[m]]
                    };
                    if (more) {
                        this.messages = [item].concat(this.messages);
                    }
                    else {
                        this.messages.push(item);
                    }
                }
                else {
                    if (more) {
                        this.messages[ind]['messages'] = [ms[m]].concat(this.messages[ind]['messages']);
                    }
                    else {
                        this.messages[ind]['messages'].push(ms[m]);
                    }
                }
            }
        }
        this.messages.sort(function (a, b) {
            var aDate = +new Date(a['dateString']);
            var bDate = +new Date(b['dateString']);
            return aDate - bDate;
        });
        this.loading = false;
        this.scrollBottom();
    };
    ChatProfile.prototype.scrollBottom = function () {
        var elem = document.getElementById('chatRoomScroll');
        var newPos = elem.scrollHeight - this.oldHeight;
        elem.scrollTop = newPos;
        this.oldHeight = elem.scrollHeight - elem.scrollTop;
    };
    //TODO
    ChatProfile.prototype.muteChat = function () {
    };
    //TODO
    ChatProfile.prototype.reportUser = function () {
        //tracking
        if (window['fabric']) {
            window['fabric'].Answers.sendCustomEvent('Chat Profile', { type: 'report' });
        }
        var reportPage = this.popoverCtrl.create(report_1.ReportPage, {
            'entityID': this.receiverInfo['_id'],
            'entityName': this.receiverInfo['fname'] + ' ' + this.receiverInfo['lname'],
            'user': this.user,
            'type': 'people',
            'platform': this.platform
        }, { 'enableBackdropDismiss': true });
        reportPage.present({
            animate: false
        });
    };
    //TODO
    ChatProfile.prototype.deleteChatHistory = function () {
    };
    ChatProfile.prototype.resend = function (message) {
        if (message['hasError']) {
            this.sendMessage(true, message);
        }
    };
    ChatProfile.prototype.sendMessage = function (resend, msg) {
        var _this = this;
        if (resend || (!resend && this.messageText.trim() != '')) {
            var message = resend ? msg['body'] : this.messageText;
            var messageObj = {
                "user1": this.user['_id'],
                "user2": this.receiverInfo['_id'],
                "message": message
            };
            if (this.connected) {
                var date = resend ? msg['date_created'] : new Date();
                var messageObjPush = {
                    body: {
                        'message': message,
                        'igyig': false,
                        'extra': null },
                    date_updated: 'now',
                    id: this.user['_id'],
                    picurl: this.user['picurl'],
                    date_created: date,
                    timestamp: date.toLocaleTimeString().replace(/:\d\d\s/, ''),
                    showTimestamp: true,
                    notSent: true,
                    from: this.user['_id']
                };
                if (!resend) {
                    var ind = this.messages.map(function (a) { return a['dateString']; }).indexOf('Today');
                    if (ind == -1) {
                        this.messages.push({
                            dateString: 'Today',
                            messages: [messageObjPush],
                        });
                    }
                    else {
                        messageObjPush['showTimestamp'] =
                            (((date.getTime() - new Date(this.messages[ind]['messages'][(this.messages[ind]['messages'].length - 1)]['date_created']).getTime()) / 60000)
                                > 10);
                        this.messages[ind]['messages'].push(messageObjPush);
                    }
                    this.messageText = '';
                }
                var mInd_1 = this.messages[this.messages.length - 1]['messages'].map(function (b) { return new Date(b['date_created']).toString(); })
                    .indexOf(date.toString());
                this.messages[this.messages.length - 1]['messages'][mInd_1]['hasError'] = false;
                this.chatService.sendMessage(messageObj).then(function (value) {
                    if (value['success'] == false && value['message'] == 'Failed to authenticate token.') {
                        app_component_1.Agnes.showError('Your login token has expired, please sign in again!');
                        _this.events.publish('logout');
                    }
                    else {
                        _this.scrollDown = true;
                        _this.messages[_this.messages.length - 1]['messages'][mInd_1]['notSent'] = false;
                        _this.messages[_this.messages.length - 1]['messages'][mInd_1]['hasError'] = false;
                    }
                }).catch(function (err) {
                    console.log('send error', err);
                    _this.messages[_this.messages.length - 1]['messages'][mInd_1]['hasError'] = true;
                });
            }
            else {
                this.chatService.createChannel(messageObj).then(function (value) {
                    if (value['success'] == false && value['message'] == 'Failed to authenticate token.') {
                        app_component_1.Agnes.showError('Your login token has expired, please sign in again!');
                        _this.events.publish('logout');
                    }
                    else {
                        _this.connected = true;
                        _this.sendMessage(resend, msg);
                    }
                }).catch(function (err) {
                    console.log('create channel err', err);
                });
            }
        }
    };
    ChatProfile.prototype.onEnter = function (ev) {
        if (ev.keyCode == 13) {
            this.sendMessage(false, null);
        }
    };
    ChatProfile.prototype.openPeopleProfile = function () {
        //tracking
        if (window['fabric']) {
            window['fabric'].Answers.sendCustomEvent('Chat Profile', { type: 'people profile' });
        }
        var peopleProfilePage = this.popoverCtrl.create(people_profile_1.PeopleProfile, {
            'person': this.receiverInfo,
            'user': this.user,
            'platform': this.platform
        }, { 'enableBackdropDismiss': false });
        peopleProfilePage.present({
            animate: true,
            animation: 'ios-transition',
            duration: 350,
            easing: "ease-in-out",
            direction: "forward"
        });
    };
    ChatProfile.prototype.openEventProfile = function (date, message) {
        var _this = this;
        //tracking
        if (window['fabric']) {
            window['fabric'].Answers.sendCustomEvent('Chat Profile', { type: 'igiyg event profile' });
        }
        var event = message['body']['message'];
        var data = { 'evt': [event['_id']] };
        this.eventsService.getEventsFromId(data).then(function (value) {
            if (value) {
                if (value['success'] == false && value['message'] == 'Failed to authenticate token.') {
                    app_component_1.Agnes.showError('Your login token has expired, please sign in again!');
                    _this.events.publish('logout');
                }
                else {
                    if (value['length'] > 0) {
                        var e = value[0];
                        _this.navCtrl.push(event_profile_1.EventProfile, {
                            'event': e,
                            'user': _this.user,
                            'type': 'all'
                        }, {
                            animation: 'ios-transition',
                            duration: 350
                        });
                    }
                    else {
                        app_component_1.Agnes.showError('Sorry, this event no longer exists or has already passed!');
                        _this.deleteMessage(date, message, true);
                    }
                }
            }
            else {
                app_component_1.Agnes.showError('Sorry, this event no longer exists or has already passed!');
                _this.deleteMessage(date, message, true);
            }
        }).catch(function (err) {
            //Agnes.showError('Sorry, this event no longer exists or has already passed!');
        });
    };
    ChatProfile.prototype.acceptIYG = function (date, message) {
        var _this = this;
        //tracking
        if (window['fabric']) {
            window['fabric'].Answers.sendCustomEvent('Chat Profile', { type: 'igiyg accept' });
        }
        this.events.subscribe('goingDone', function () {
            _this.events.unsubscribe('goingDone');
            var data = {
                'receiver_users_id': _this.receiverInfo['_id'],
                'sender_users_id': _this.user['_id'],
                'events_id': message['body']['message']['_id']
            };
            //send IYGIG accept back to sender
            _this.eventsService.acceptIYG(data).then(function (value) {
                if (value['success'] == false && value['message'] == 'Failed to authenticate token.') {
                    app_component_1.Agnes.showError('Your login token has expired, please sign in again!');
                    _this.events.publish('logout');
                }
                else {
                    _this.deleteMessage(date, message, false);
                }
            }).catch(function (err) {
                console.log('accept error', err);
            });
        });
        app_component_1.Agnes.going(message['body']['message'], false);
    };
    ChatProfile.prototype.deleteMessage = function (date, message, reject) {
        var _this = this;
        //tracking
        if (window['fabric'] && reject) {
            window['fabric'].Answers.sendCustomEvent('Chat Profile', { type: 'igiyg reject' });
        }
        var data = {
            'user1': this.user['_id'],
            'user2': this.receiverInfo['_id'],
            'sid': message['sid']
        };
        this.chatService.deleteMessage(data).then(function (val) {
            if (val['success'] == false && val['message'] == 'Failed to authenticate token.') {
                app_component_1.Agnes.showError('Your login token has expired, please sign in again!');
                _this.events.publish('logout');
            }
            else {
                //remove message from display
                var dInd = _this.messages.indexOf(date);
                if (dInd != -1) {
                    var mInd = _this.messages[dInd]['messages'].indexOf(message);
                    if (mInd != -1) {
                        _this.messages[dInd]['messages'].splice(mInd, 1);
                        if (_this.messages[dInd]['messages'].length == 0) {
                            _this.messages.splice(dInd, 1);
                        }
                    }
                }
            }
        }).catch(function (err) {
            console.log('delete m error', err);
            app_component_1.Agnes.showError('Couldn\'t remove this message - try again!');
            //keep trying bc idk
            //this.deleteMessage(date,message, reject);
        });
    };
    ChatProfile.prototype.keepKeyboard = function (event) {
        if (!this.shouldBlur || event.relatedTarget || this.reset) {
            event.target.focus();
            // Reset so other elements will blur the keyboard
            this.shouldBlur = true;
            this.reset = !this.reset;
        }
    };
    ChatProfile.prototype.resetBlur = function () {
        this.reset = true;
    };
    ChatProfile.prototype.flipBlur = function () {
        this.shouldBlur = false;
        this.reset = false;
    };
    __decorate([
        core_1.ViewChild('chatRoom')
    ], ChatProfile.prototype, "chatRoom", void 0);
    ChatProfile = __decorate([
        core_1.Component({
            selector: 'chat-profile',
            templateUrl: 'chat-profile.html',
            providers: [chat_service_1.ChatService, events_service_1.EventsService]
        })
    ], ChatProfile);
    return ChatProfile;
}());
exports.ChatProfile = ChatProfile;

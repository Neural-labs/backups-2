# Extracts the dates from a content string

import re
import DateExtractionRegex
import datefinder
from itertools import product
from dateutil import parser

tree_input = DateExtractionRegex.date_extraction_input

time_regex = tree_input['date']['time']['regex']
day_regex = tree_input['date']['day']['regex']
week_regex = tree_input['date']['week']['regex']
month_regex = tree_input['date']['month']['regex']
year_regex = tree_input['date']['year']['regex']
md_regex = tree_input['date']['md']['regex']
all_regex = tree_input['date']['all']['regex']

ValidYears = [2016, 2017, 2018, 2019, 2020]

def getDates(node_content):

    input_content = node_content.lower()
    # input_content = input_content.decode('utf8','ignore')
    input_content = input_content.encode('ascii','ignore')
    dates = runExtraction(input_content)

    dates = [date for date in dates if date[0].year in ValidYears]
    return dates


def runExtraction(content):
    library_output = cleanDates(generateDateFromLibrary(content))
    manual_output = generateDateFromContent(content)
    final_dates = combineOutputs(library_output,manual_output)
    return final_dates

def cleanDates(library_output):

    for index in range(len(library_output)):
        dateTuple = library_output[index]
        noTZDate = dateTuple[0].replace(tzinfo=None)
        library_output[index] = (noTZDate,dateTuple[1])
    return library_output

def generateDateFromLibrary(content):
    return list(datefinder.find_dates(content, source=True))

def allCombinations(part_list):
    part_list = [x for x in part_list if x]
    return list(product(*part_list))

def generateDateFromContent(content):
    dates = []

    allMatchDateStringParts = getAllMatchDateStrings(content)

    partialMatchDateStringParts = getPartialMatchDateStrings(content)

    if allMatchDateStringParts:

        allMatchCombos = allCombinations(allMatchDateStringParts)
        for combo in allMatchCombos:
            datestring = ' '.join([w for w in combo])
            datestring = cleanDatestring(datestring)
            dates += dateParser(datestring)
            dates += dateFinder(datestring)

    if partialMatchDateStringParts:

        partialMatchCombos = allCombinations(partialMatchDateStringParts)

        for combo in partialMatchCombos:
            datestring = ' '.join([w for w in combo])
            datestring = cleanDatestring(datestring)
            dates += dateParser(datestring)
            dates += dateFinder(datestring)

    dates = removeDups(dates)

    return dates

def cleanDatestring(datestring):
    if datestring and datestring[-1] == ':':
        datestring = datestring[:-1]
    return datestring

def dateParser(datestring):
    try:
        date = parser.parse(datestring)
        result = [(date, datestring)]
    except Exception as e:
        result = []

    return result

def dateFinder(datestring):
    return list(datefinder.find_dates(datestring,source=True))

def getAllMatchDateStrings(content):
    allMatchStrings = []
    timeMatchStrings = []
    # look for y/m/d combinations
    for regex in all_regex:
        allMatchStrings += ['/'.join(w) for w in re.findall(regex, content) if w]

    # if y | m | d found, look for time
    if allMatchStrings:
        for regex in time_regex:
            timeMatchStrings += [''.join(w).strip() for w in re.findall(regex, content) if w]
    else:
        return []

    allMatchStrings = removeDups(allMatchStrings)
    timeMatchStrings = removeDups(timeMatchStrings)
    return [allMatchStrings, timeMatchStrings]

def getPartialMatchDateStrings(content):
    year_strings = []
    month_strings = []
    week_strings = []
    day_strings = []
    md_strings = []
    time_strings = []

    # print 'running partial match'
    for regex in year_regex:
        # yearMatch = re.search(regex,content)
        year_strings += [''.join(w).strip() for w in re.findall(regex,content) if w]
    for regex in month_regex:
        month_strings += [''.join(w).strip() for w in re.findall(regex, content) if w]
    for regex in week_regex:
        week_strings += [''.join(w).strip() for w in re.findall(regex, content) if w]
    for regex in day_regex:
        day_strings += [''.join(w).strip() for w in re.findall(regex, content) if w]
    for regex in md_regex:
        md_strings += [''.join(w).strip() for w in re.findall(regex, content) if w]
    for regex in time_regex:
        time_strings += [''.join(w).strip() for w in re.findall(regex, content) if w]
        time_strings = [w for w in time_strings if w != ':']
        for i in range(len(time_strings)):
            s = time_strings[i]
            if s[0] == ':' and len(s) > 2:
                time_strings[i] = s[1:]
    # for regex in md_regex:
    #     date_part_strings += [''.join(w).strip() for w in re.findall(regex, content) if w]

    # print year_strings
    # print month_strings
    # print week_strings
    # print day_strings
    # print md_strings
    # print time_strings
    year_strings = [item for item in year_strings if int(item) in ValidYears]

    if (month_strings and (week_strings or day_strings)) or md_strings:
        # year_strings.append('2017') # manually add last year in case it was omitted (this is for tagging)
        # year_strings.append('2018')
        date_part_strings = [removeDups(week_strings)]
        if md_strings:
            date_part_strings.append(removeDups(md_strings))
        else:
            date_part_strings.append(removeDups(month_strings))
            date_part_strings.append(removeDups(day_strings))
        date_part_strings += [removeDups(year_strings),removeDups(time_strings)]

    else:
        date_part_strings = []

    return date_part_strings

def removeDups(items):
    return list(set(items))

def combineOutputs(library_output, manual_output):
    # return manual_output
    return list(set(library_output + manual_output))

def main():
    test_list = [
        # 'Ithaca Golf at Martin-Wallace Invitational (Final Round) Ithaca Golf at Martin-Wallace Invitational (Final Round) athletics.ithaca.edu/calendar.aspx?id=8689 Sunday, October 1 Cortland, NY',
        # 'Date: 2/16/2018 - 2/17/2018 Time: 2:00 PM - 4:00 PM',
        # 'Wednesday, January 10, 2018 10 A.M. to 4 P.M.',
        'Planning, Prioritizing, & Preparation for Pleasant ProgrammingApril 26th from 6pm to 7:30pmPoland LibraryDo you feel like a juggling octopus during daycare hours? During this session we will be discussing some strategies to assist in making the days activities flow smoother! OCFS Topics covered: 1 , 3Free training, $10 holding-fee, reimbursed to those who attend. Payment confirms registration.'
    ]

    for item in test_list:
        print item
        dates = getDates(item)
        for date in dates:
            print date


if __name__ =='__main__':
    main()
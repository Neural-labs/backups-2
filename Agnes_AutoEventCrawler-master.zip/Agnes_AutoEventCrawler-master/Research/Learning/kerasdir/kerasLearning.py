from config import db_config
from keras.preprocessing.text import Tokenizer
from keras.preprocessing import sequence
from keras.models import Sequential
import numpy as np
import math
from keras.layers import Dense, Dropout, Activation, Flatten, GlobalAveragePooling1D, Input
from keras.optimizers import *
from keras.utils import np_utils
from keras.layers.convolutional import Convolution1D, MaxPooling1D, ZeroPadding1D, AveragePooling1D
from keras.callbacks import EarlyStopping, ModelCheckpoint, TensorBoard
from keras.layers.normalization import BatchNormalization
from keras.layers import Embedding, Conv1D
from keras.layers.recurrent import SimpleRNN, LSTM, GRU
from keras.layers.wrappers import TimeDistributed
from keras.models import Model, load_model, model_from_json
from keras.callbacks import Callback, History
from keras import regularizers
# import matplotlib.pyplot as plt
from scipy import stats
import tensorflow as tf
# import seaborn as sns
# from pylab import rcParams
from sklearn.model_selection import train_test_split
from sklearn.decomposition import PCA
from sklearn.metrics import roc_auc_score
from imblearn.over_sampling import SMOTE
from imblearn.combine import SMOTEENN, SMOTETomek
from collections import Counter
import pickle
import random
import sys
import gc
import time

reload(sys)
sys.setdefaultencoding('utf8')

Agnes = db_config.getDBConn('dev').Agnes

Event_Collection = Agnes.autocrawler_events
Title_Collection = Agnes.autocrawler_ext_data_title

Data_Collection = Agnes.autocrawler_ext_data

RANDOM_SEED = 42

EVENT_LIMIT = 90000

MAXLEN = 40

class LossHistory(Callback):
    def on_train_begin(self, logs={}):
        self.losses = np.zeros(0)

    def on_batch_end(self, batch, logs={}):
        batch_loss = logs.get('loss')
        self.losses = np.hstack((self.losses, batch_loss))

def addRandomNoise(X, y, limit):

    length = len(X)
    count = 0

    while count < limit:

        random_ind = random.randint(0,length)
        random_sample = X[random_ind]
        random_label = y[random_ind]

        if not random_label:
            continue

        count += 1
        noise = np.random.normal(0, 1, random_sample.shape)
        new_sample = np.absolute((random_sample + noise)).astype(int)
        X = np.vstack((X, new_sample))
        y = np.append(y,random_label)

    return X,y

def printStats(y_true, scores):

    print 'ROC Score:',roc_auc_score(y_true=y_true, y_score=scores)

    posPreds = 0
    negPreds = 0
    avgPosPred = 0.0
    avgNegPred = 0.0
    for ind in range(len(scores)):
        if y_true[ind]:
            # print scores[ind]
            avgPosPred += scores[ind]
            posPreds += 1
        else:
            avgNegPred += scores[ind]
            negPreds += 1
    print 'Avg Pos Score:', avgPosPred / posPreds
    print 'Avg Neg Score:', avgNegPred / negPreds

def getPosNegCount(y):
    pos_count = 0
    neg_count = 0
    for item in y:
        if item:
            pos_count += 1
        else:
            neg_count += 1
    return pos_count, neg_count


def getTokenizer(fromfile):
    if fromfile:
        with open('tokenizer.pickle', 'rb') as handle:
            tokenizer = pickle.load(handle)

    else:
        tokenizer = Tokenizer(  # num_words=num_words,
            # filters='!"#$%&()*+,-./:;<=>?@[\\]^_`{|}~\t\n',
            filters='!#$%&()*+,-./:;?@[\\]^_`{|}~\t\n',
            lower=False,
            split=" ",
            char_level=True
        )

    return tokenizer

def writeTokenizer(tokenizer):
    with open('tokenizer.pickle', 'wb') as handle:
        pickle.dump(tokenizer, handle, protocol=pickle.HIGHEST_PROTOCOL)

def runKeras():


    # embeddings_path = "glove.840B.300d-char.txt"
    # embedding_dim = 300
    # batch_size = 128
    # nb_epoch = 2
    # use_pca = False
    # lr = 0.001
    # lr_decay = 1e-4
    # maxlen = 40
    # consume_less = 2  # 0 for cpu, 2 for gpu
    #
    # pos_input_text, pos_input_label, neg_input_text, neg_input_label = getInputTextAndLabels()
    #
    # text = ''.join(pos_input_text+neg_input_text)
    #
    # chars = sorted(list(set(text)))
    # print('total chars:', len(chars))
    #
    # char_indices = dict((c, i) for i, c in enumerate(chars))
    # # indices_char = dict((i, c) for i, c in enumerate(chars))
    #
    # # cut the text in semi-redundant sequences of maxlen characters
    #
    # step = 3
    # sentences = []
    # next_chars = []
    # for i in range(0, len(text) - maxlen, step):
    #     sentences.append(text[i: i + maxlen])
    #     next_chars.append(text[i + maxlen])
    #
    # print('nb sequences:', len(sentences))
    #
    # print('Vectorization...')
    # X = np.zeros((len(sentences), maxlen), dtype=np.int)
    # y = np.zeros((len(sentences), len(chars)), dtype=np.bool)
    # for i, sentence in enumerate(sentences):
    #     for t, char in enumerate(sentence):
    #         X[i, t] = char_indices[char]
    #
    #     y[i, char_indices[next_chars[i]]] = 1
    #
    # X_train, X_test, y_train, y_test = train_test_split(X,y, test_size=0.2)
    #
    # print('Processing pretrained character embeds...')
    # embedding_vectors = {}
    # with open(embeddings_path, 'r') as f:
    #     for line in f:
    #         line_split = line.strip().split(" ")
    #         vec = np.array(line_split[1:], dtype=float)
    #         char = line_split[0]
    #         embedding_vectors[char] = vec
    #
    # embedding_matrix = np.zeros((len(chars), 300))
    # # embedding_matrix = np.random.uniform(-1, 1, (len(chars), 300))
    # for char, i in char_indices.items():
    #     # print ("{}, {}".format(char, i))
    #     embedding_vector = embedding_vectors.get(char)
    #     if embedding_vector is not None:
    #         embedding_matrix[i] = embedding_vector
    #
    # print('Embedding Matrix (sans pca) shape:', embedding_matrix.shape)
    # # Use PCA from sklearn to reduce 300D -> 50D
    # if use_pca:
    #     pca = PCA(n_components=embedding_dim)
    #     pca.fit(embedding_matrix)
    #     embedding_matrix_pca = np.array(pca.transform(embedding_matrix))
    #     print (embedding_matrix_pca)
    #     print (embedding_matrix_pca.shape)
    #
    # print('Build model...')
    # main_input = Input(shape=(maxlen,))
    # embedding_layer = Embedding(
    #     len(chars), embedding_dim, input_length=maxlen,
    #     weights=[embedding_matrix_pca] if use_pca else [embedding_matrix])
    # # embedding_layer = Embedding(
    # #     len(chars), embedding_dim, input_length=maxlen)
    # embedded = embedding_layer(main_input)
    #
    # rnn = LSTM(256, implementation=consume_less)(embedded)
    #
    # # Hidden Layers
    # hidden_1 = Dense(512, use_bias=False)(rnn)
    # hidden_1 = BatchNormalization()(hidden_1)
    # hidden_1 = Activation('relu')(hidden_1)
    #
    # hidden_2 = Dense(256, use_bias=False)(hidden_1)
    # hidden_2 = BatchNormalization()(hidden_2)
    # hidden_2 = Activation('relu')(hidden_2)
    #
    # main_output = Dense(2)(hidden_2)
    # main_output = Activation('softmax', name='main_out')(main_output)
    #
    # model = Model(inputs=main_input, outputs=main_output)
    #
    # optimizer = Adam(lr=lr, decay=lr_decay)
    # model.compile(loss='categorical_crossentropy',
    #               optimizer=optimizer)#, loss_weights=[1., 0.2])
    # model.summary()
    #
    # history = model.fit(X_train, X_train,
    #                           epochs=nb_epoch,
    #                           batch_size=batch_size,
    #                           shuffle=True,
    #                           validation_data=(X_test, X_test),
    #                           verbose=1,).history


    ########################################################## CNN + LSTM METHOD #########################

    event_part = 'name'

    tok = getTokenizer(fromfile=True)
    tok.oov_token=None

    # embeddings_path = "glove.840B.300d-char.txt"
    # print('Processing pretrained character embeds...')
    # embedding_vectors = {}
    # with open(embeddings_path, 'r') as f:
    #     for line in f:
    #         line_split = line.strip().split(" ")
    #         vec = np.array(line_split[1:], dtype=float)
    #         char = line_split[0]
    #         embedding_vectors[char] = vec

    chars = tok.word_index

    # embedding_matrix = np.random.uniform(-1, 1, (len(tok.word_index), 300))
    # embedding_matrix = np.zeros((len(chars)+1, 300))
    #
    # for char, i in tok.word_index.items():
    #     embedding_vector = embedding_vectors.get(char)
    #     if embedding_vector is not None:
    #         embedding_matrix[i] = embedding_vector

    max_features = len(chars)+1
    # input_dim = X_train.shape[1]

    model = getModel(max_features)

    collection = getCollection()

    generator = batch_generator(collection, tok, event_part)

    counter = 0

    for data in generator:

        counter += 1
        if counter % 10 == 0:
            runTesting(model, collection, tok, event_part)

        # start = time.time()
        # X_train = data['x_train']
        # y_train = data['y_train']
        # X_test  = data['x_test']
        # y_test  = data['y_test']
        X = data['X']
        y = data['y']

        # params
        print 'Training on batch...'
        model.train_on_batch(X, y, class_weight={0:1,1:10})

        saveModel(model, event_part)

        # model.test_on_batch(X_test, y_test)



    #
    # print('Train...')
    # model.fit(X_train, y_train,
    #           batch_size=batch_size,
    #           epochs=nb_epochs,
    #           validation_data=(X_test, y_test))
    # scores = model.predict(X_test, batch_size=batch_size)
    #
    # printStats(y_test, scores)

    # encoding_dim = 14
    #
    # input_layer = Input(shape=(input_dim, ))
    #
    # encoder = Dense(encoding_dim, activation="tanh",
    #                 activity_regularizer=regularizers.l1(10e-5))(input_layer)
    #
    # encoder = Dense(int(encoding_dim / 2), activation="relu")(encoder)
    # decoder = Dense(int(encoding_dim / 2), activation='tanh')(encoder)
    # decoder = Dense(input_dim, activation='relu')(decoder)
    # autoencoder = Model(inputs=input_layer, outputs=decoder)
    #
    # nb_epoch = 100
    # batch_size = 32
    # autoencoder.compile(optimizer='adam',
    #                     loss='mean_squared_error',
    #                     metrics=['accuracy'])
    #
    # checkpointer = ModelCheckpoint(filepath="model.h5",
    #                                verbose=0,
    #                                save_best_only=True)
    # tensorboard = TensorBoard(log_dir='./logs',
    #                           histogram_freq=0,
    #                           write_graph=True,
    #                           write_images=True)
    # history = autoencoder.fit(X_train, X_train,
    #                           epochs=nb_epoch,
    #                           batch_size=batch_size,
    #                           shuffle=True,
    #                           validation_data=(X_test, X_test),
    #                           verbose=1,
    #                           callbacks=[checkpointer, tensorboard]).history

    # plt.plot(history['loss'])
    # plt.plot(history['val_loss'])
    # plt.title('model loss')
    # plt.ylabel('loss')
    # plt.xlabel('epoch')
    # plt.legend(['train', 'test'], loc='upper right');

    # ### Gets to the same format as imdb.load_data() but from the raw text
    # X_train_list = tok.texts_to_sequences(input_text[:TRAIN_INDEX])
    # X_test_list = tok.texts_to_sequences(input_text[TRAIN_INDEX:])
    # y_train = input_label[:TRAIN_INDEX]
    # y_test = input_label[TRAIN_INDEX:]

    # no bigrams - define maxlen
    # maxlen = 400
    # print('Pad sequences (samples x time)')
    # X_train = sequence.pad_sequences(X_train_list, maxlen=maxlen)
    # X_test = sequence.pad_sequences(X_test_list, maxlen=maxlen)
    # print('X_train shape:', X_train.shape)
    # print('X_test shape:', X_test.shape)
    # print('Y_train: ', len(y_train))
    # print('Y_test: ', len(y_test))


    # Train model with N-gram = 1
    # maxlen defined  above
    ngram_range = 1

    # for text in input_text:
    #     print('text',text)
    # Use different optimization methods
    # loss_optims = []
    # # for opt in ['adam', 'rmsprop', 'sgd-momentum', 'adagrad']:
    # model = fasttext_model(max_features=20000, embedding_dims=50, maxlen=maxlen, optimizer='sgd-momentum')
    # loss_history = History()
    # model.fit(X_train, y_train, batch_size=32, nb_epoch=20,
    #           validation_data=(X_test, y_test), callbacks=[loss_history])
    # loss_optims.append(loss_history.history)


def getModel(max_features):
    num_words = 256
    kernel_size = 5
    pool_size = 4
    embedding_dim = 300
    filters = 64
    max_len = 40
    lstm_output_size = 70
    consume_less = 1 # 1 for cpu, 2 for gpu

    print 'Build the model...'
    model = Sequential()
    # model.add(Input(shape=(input_dim,)))

    model.add(Embedding(
        input_dim=max_features,
        output_dim=embedding_dim,
        input_length=max_len))
        # trainable=False,
        # weights=[embedding_matrix]))
    model.add(Dropout(0.25))
    model.add(Conv1D(filters,
                     kernel_size,
                     padding='valid',
                     activation='relu',
                     strides=1))
    model.add(MaxPooling1D(pool_size=pool_size))
    model.add(LSTM(lstm_output_size, implementation=consume_less))
    model.add(Dense(1))
    model.add(Activation('sigmoid'))
    model.compile(loss='binary_crossentropy',
                  optimizer='adam',
                  metrics=['accuracy'])
    return model

def getCollection():
    return Data_Collection

def batch_generator(collection, tokenizer, event_part):

    batch_size = 7000
    batch_index = 0
    total_samples = collection.count()

    while batch_index < total_samples:
        text = []
        y = []

        print 'Fetching Batch Index', batch_index, 'of', total_samples
        raw_samples = getSampleBatch(collection, batch_index, batch_size)

        for sample in raw_samples:
            if sample['label'] == 0:
                text.append(sample['text'])
                y.append(0)
            elif sample['part'] == event_part:
                text.append(sample['text'])
                y.append(1)


        X = sequence.pad_sequences(tokenizer.texts_to_sequences(text), maxlen=MAXLEN)

        # print 'Train / Test Split'
        # X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=RANDOM_SEED)

        oversample_ratio = int(math.floor((len([x for x in y if x == 0]) * 0.1)))
        print('Oversampling / Undersampling with upsample ratio:',oversample_ratio)
        X, y = SMOTEENN(ratio={1: oversample_ratio}, random_state=RANDOM_SEED).fit_sample(X, y)

        # print 'Upsampling positive samples to'
        # X,y = SMOTE
        #
        data = {
            # 'x_train':X_train,
            # 'x_test':X_test,
            # 'y_train':y_train,
            # 'y_test':y_test
            'X':X,
            'y':y
        }
        yield data
        gc.collect()

        batch_index += batch_size


def getTestBatch(collection, tokenizer, event_part):
    print 'Fetching random batch'
    raw_samples = getRandomBatch(collection, batch_size=5000)

    text = []
    y  = []

    for sample in raw_samples:
        if sample['label'] == 0:
            text.append(sample['text'])
            y.append(0)
        elif sample['part'] == event_part:
            text.append(sample['text'])
            y.append(1)

    X = sequence.pad_sequences(tokenizer.texts_to_sequences(text), maxlen=MAXLEN)
    y = np.array(y)
    return X,y

def runTesting(model, collection, tok, event_part):
    print 'Testing on batch...'
    X_test, y_test = getTestBatch(collection, tok, event_part)
    y_preds = model.predict(X_test)
    printStats(y_true=y_test, scores=y_preds)
    loss, acc = model.evaluate(X_test, y_test)
    print 'Model loss:', loss, 'Accuracy:', acc

def getInputTextAndLabels(event_part):
    # events = getEvents()
    pos_input_text = []
    pos_input_label = []
    neg_input_text = []
    neg_input_label = []
    counter = 0
    PosNodeCount = 0.0
    NegNodeCount = 0.0
    depths = Counter()
    max_depth = 0
    batch_size = 100
    batch_index = 0
    evtsources = Counter()

    while counter < EVENT_LIMIT:

        batch_index += batch_size

        events = getEventBatch(batch_index, batch_size)

        # print 'Sending mongodb call...'
        # events = Event_Collection.aggregate([
        #     { '$sample': {'size': batch_size}}
        #     # { '$exists':  {"event_tree_pkl": True}}
        # ])

        for event in events:

            # if counter == EVENT_LIMIT:
            #     break
            print counter, 'of', EVENT_LIMIT

            if 'HTML' not in event or 'event_tree_pkl' not in event:
                print 'No HTML or event_tree pickle'
                continue

            print event['url']
            HTML = event['HTML']

            print 'Loading Tree...'
            event_tree = pickle.loads(event['event_tree_pkl'])
            print 'Finding Event Node...'
            event_node = event_tree.findEventNode()

            if not event_node:
                print 'Event Node not found'
                continue

            print 'Finding Title Node...'
            title_node = event_tree.getSubNode(eventNode=event_node, flag=event_part)

            if not title_node:
                print 'Title node not found'
                continue

            temp_pos_text = []
            temp_neg_text = []
            temp_pos_label = []
            temp_neg_label = []
            evtNode_found = False

            print 'Gathering Negative Nodes...'
            for node in event_tree.bfs_iterator():
                # if not 'tag-' in node['data']:
                #     continue
                text = str(node['data']['tag']).encode('ascii','ignore')
                if node == title_node:
                    PosNodeCount += 1
                    temp_pos_text.append(text)
                    temp_pos_label.append(1)
                    # pos_input_label.append(1)
                    # pos_input_text.append(text)
                    evtNode_found = True

                else:
                    NegNodeCount += 1
                    temp_neg_label.append(0)
                    temp_pos_text.append(text)
                    # neg_input_label.append(0)
                    # neg_input_text.append(text)

                node_depth = event_tree.depth(node)
                if node_depth > max_depth and not math.isinf(node_depth):
                    max_depth = node_depth
            if not evtNode_found:
                print 'evtnode not found...'
                continue

            counter += 1

            print 'Gathering Statistics...'
            evtsource = event['evtsource']
            evtsources[evtsource] += 1
            event_node_depth = event_tree.depth(event_node)
            depths[event_node_depth] += 1

            pos_input_label = pos_input_label + temp_pos_label
            pos_input_text = pos_input_text + temp_pos_text
            neg_input_label = neg_input_label + temp_neg_label
            neg_input_text = temp_neg_text + temp_neg_text

            print 'Finished Sample'

        events.close()
        gc.collect()


    print 'Number of Event Nodes:',PosNodeCount
    print 'Number of NonEvent Nodes:', NegNodeCount
    print 'Average Event Nodes per Page:', PosNodeCount / counter
    print 'Average NonEvent Nodes per Page:', NegNodeCount / counter
    print 'Deepest node depth:', max_depth
    for depth in depths:
        print 'Depth:',depth,'Occurrences:', depths[depth]
    for item in evtsources:
        print 'Evtsource',item,'Occ:',evtsources[item]

    return pos_input_text, pos_input_label, neg_input_text, neg_input_label

def generateTestData(X, y):

    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=RANDOM_SEED)

    return X_test, y_test

def getEvents():
    return Event_Collection.find({}, no_cursor_timeout=True)

def getEventBatch(index, batch_size):
    return Event_Collection.find({},no_cursor_timeout=True).skip(index).limit(batch_size)
    #, skip=index, batch_size=batch_size)[index:index+batch_size]

def getRandomBatch(collection, batch_size):
    return collection.aggregate([{"$sample": {'size': batch_size}}])

def getSampleBatch(collection, index, batch_size):
    return collection.find({},no_cursor_timeout=True).skip(index).limit(batch_size)

def saveModel(model, event_part):
    # local_weights = model.layers[0].get_weights()[0]
    # print type(local_weights)
    # with open('embedding_weights.h5') as f:
    #     f.write(local_weights)

    model_json = model.to_json()
    with open(event_part + "_model.json", "w") as json_file:
        json_file.write(model_json)
    # serialize weights to HDF5
    model.save_weights(event_part + "_model.h5")
    print("Saved model to disk")

def getModelFromDisk():
    # load json and create model
    json_file = open('model.json', 'r')
    loaded_model_json = json_file.read()
    json_file.close()
    loaded_model = model_from_json(loaded_model_json)
    # load weights into new model
    loaded_model.load_weights("model.h5")
    print("Loaded model from disk")
    return loaded_model
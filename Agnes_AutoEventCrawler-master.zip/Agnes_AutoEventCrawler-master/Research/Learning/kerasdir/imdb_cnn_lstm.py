'''Train a recurrent convolutional network on the IMDB sentiment
classification task.

Gets to 0.8498 test accuracy after 2 epochs. 41s/epoch on K520 GPU.
'''
from __future__ import print_function

from keras.preprocessing import sequence
from keras.models import Sequential
from keras.layers import Dense, Dropout, Activation
from keras.layers import Embedding
from keras.layers import LSTM
from keras.layers import Conv1D, MaxPooling1D
from keras.datasets import imdb
from sklearn.model_selection import train_test_split
from sklearn.metrics import roc_auc_score
from imblearn.over_sampling import SMOTE
from imblearn.combine import SMOTEENN, SMOTETomek
import math
import numpy as np
import random

def stop():
    raise ValueError('stop')

def addRandomNoise(X, y, limit):

    length = len(X)
    count = 0

    while count < limit:

        random_ind = random.randint(0,length)
        random_sample = X[random_ind]
        random_label = y[random_ind]

        if random_label:
            continue

        count += 1
        noise = np.random.normal(0, 1, random_sample.shape)
        new_sample = np.absolute((random_sample + noise)).astype(int)
        X = np.vstack((X, new_sample))
        y = np.append(y,random_label)

    return X,y

def getPosNegCounts(y):
    pos_count = 0
    neg_count = 0
    for item in y:
        if item:
            pos_count += 1
        else:
            neg_count += 1

    return pos_count, neg_count

def getData(minorityLimit, majorityLimit, doSMOTE, **kwargs):

    if 'upsample' in kwargs:
        upsample = kwargs['upsample']
    max_features = 20000
    maxlen = 100

    print('Loading data...')
    (x_train, y_train), (x_test, y_test) = imdb.load_data(num_words=max_features)

    X = np.concatenate((x_train, x_test))
    y = np.concatenate((y_train, y_test))

    X_pos = []
    y_pos = []
    X_neg = []
    y_neg = []

    for ind in range(len(X)):
        if y[ind]:
            X_pos.append(list(X[ind]))
            y_pos.append(y[ind])
        else:
            X_neg.append(list(X[ind]))
            y_neg.append(y[ind])

    X_new = X_pos[:majorityLimit] + X_neg[:minorityLimit]
    y_new = y_pos[:majorityLimit] + y_neg[:minorityLimit]

    print('Pad sequences (samples x time)')
    X_new = sequence.pad_sequences(X_new, maxlen=maxlen)
    # x_train = sequence.pad_sequences(x_train, maxlen=maxlen)
    # x_test = sequence.pad_sequences(x_test, maxlen=maxlen)

    if doSMOTE:

        pos_count, neg_count = getPosNegCounts(y_new)
        print('Inital Pos Neg Count:', pos_count, neg_count)

        smote = SMOTE({0:upsample})
        # X_new, y_new = SMOTETomek({0:upsample}, random_state=42, smote=smote).fit_sample(X_new, y_new)
        X_new, y_new = SMOTEENN({0: upsample}, random_state=42, smote=smote).fit_sample(X_new, y_new)

        pos_count,neg_count = getPosNegCounts(y_new)
        print('After SMOTEENN', pos_count, neg_count)

        # oversample_ratio = int(math.floor(neg_count * 0.5))
        # print('oversample_ratio', oversample_ratio, 'PosCount', pos_count, 'NegCount', neg_count)
        # X_new, y_new = SMOTE({1:oversample_ratio}).fit_sample(X_new, y_new)

        # pos_count, neg_count = getPosNegCounts(y_new)
        # print('After SMOTE:', pos_count, neg_count)

        random_limit = int(math.floor(int(abs(pos_count - neg_count)) * 0.2))
        print('random limit',random_limit, 'posCount', pos_count, 'negcount', neg_count)

        X_new, y_new = addRandomNoise(X_new, y_new, random_limit)

        pos_count, neg_count = getPosNegCounts(y_new)
        print('After Random', pos_count, neg_count)


    x_train, x_test, y_train, y_test = train_test_split(X_new, y_new, test_size=0.2)

    y_train = np.array(y_train)
    y_test = np.array(y_test)

    data = {
        'x_train':x_train,
        'x_test':x_test,
        'y_train':y_train,
        'y_test':y_test
    }

    return data

def trainModel(data):

    x_train = data['x_train']
    x_test  = data['x_test']
    y_train = data['y_train']
    y_test  = data['y_test']

    # Embedding
    max_features = 20000
    maxlen = 100
    embedding_size = 128

    # Convolution
    kernel_size = 5
    filters = 64
    pool_size = 4

    # LSTM
    lstm_output_size = 70

    # Training
    batch_size = 30
    epochs = 2

    print('Build model...')

    model = Sequential()
    model.add(Embedding(max_features, embedding_size, input_length=maxlen))
    model.add(Dropout(0.25))
    model.add(Conv1D(filters,
                     kernel_size,
                     padding='valid',
                     activation='relu',
                     strides=1))
    model.add(MaxPooling1D(pool_size=pool_size))
    model.add(LSTM(lstm_output_size))
    model.add(Dense(1))
    model.add(Activation('sigmoid'))

    model.compile(loss='binary_crossentropy',
                  optimizer='adam',
                  metrics=['accuracy'])

    print('Train...')
    model.fit(x_train, y_train,
              batch_size=batch_size,
              epochs=epochs,
              validation_data=(x_test, y_test))
    return model

def printStatistics(prediction, actual):

    score = roc_auc_score(actual, prediction, average='micro')

    print('ROC Score:',score)


def runKerasIMBD():


    '''
    Note:
    batch_size is highly sensitive.
    Only 2 epochs are needed as the dataset is very small.
    '''
    batch_size = 30

    print('Training Model 1')
    data1 = getData(minorityLimit=6000, majorityLimit=6000, doSMOTE=False)

    model1 = trainModel(data1)

    # data2 = getData(minorityLimit=600, doSMOTE=False)
    #
    # model2 = trainModel(data2)

    print('Training Model 3')
    data3 = getData(minorityLimit=600, majorityLimit=6000, doSMOTE=True, upsample=2000)

    model3 = trainModel(data3)

    print('Model 1, Data 1')
    x_test = np.concatenate((data1['x_train'], data1['x_test']))
    y_test = np.concatenate((data1['y_train'], data1['y_test']))
    preds = model1.predict(x_test)
    printStatistics(preds,y_test)

    print('Model 3, Data 3')
    x_test = np.concatenate((data3['x_train'], data3['x_test']))
    y_test = np.concatenate((data3['y_train'], data3['y_test']))
    preds = model3.predict(x_test)
    printStatistics(preds,y_test)

    print('Model 3, Data 1')
    x_test = np.concatenate((data1['x_train'], data1['x_test']))
    y_test = np.concatenate((data1['y_train'], data1['y_test']))
    preds = model3.predict(x_test)
    printStatistics(preds, y_test)

    print('Model 1, Data 3')
    x_test = np.concatenate((data3['x_train'], data3['x_test']))
    y_test = np.concatenate((data3['y_train'], data3['y_test']))
    preds = model1.predict(x_test)
    printStatistics(preds, y_test)
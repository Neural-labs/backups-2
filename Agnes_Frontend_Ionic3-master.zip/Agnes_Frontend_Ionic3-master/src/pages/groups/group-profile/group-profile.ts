import { Component, ViewChild } from '@angular/core';
import { Platform, ToastController, NavController, IonicPage, ViewController,
    NavParams, ModalController,  Scroll, Content, PopoverController, ActionSheetController, Events } from 'ionic-angular';

import { AnalyticsService } from "../../../providers/analytics.service";
import { GroupsService } from '../../../providers/groups.service';
import { LoginService } from '../../../providers/login.service';
import { EventsService } from '../../../providers/events.service';
import { PeopleService } from '../../../providers/people.service';

import { ReportPage } from '../../popups/report/report';
import { EventProfile } from '../../events/event-profile/event-profile';

import { Agnes } from '../../../app/app.component';

import {InviteFriends} from '../../popups/invite-friends/invite-friends';

@IonicPage()
@Component({
    selector: 'group-profile',
    templateUrl: 'group-profile.html',
    providers: [GroupsService, AnalyticsService, LoginService, EventsService, PeopleService]

})

export class GroupProfile {
    user:Object;
    group:Object;
    image:string;
    memberList: any;
    edited: boolean;
    orientation: string;
    menuButtons: any;

    sharedFriends: Array<Object>;

    currentTab: number;

    isClaimed: boolean;
    isMember: boolean;
    isAdmin: boolean;
    isFollowing: boolean;
    hasNewsFeed: boolean;
    claimSent: boolean;
    loading: boolean;

    sharedEvents: Array<Object>;
    hostedEvents: Array<Object>;

    today: string;
    tomorrow: string;
    yesterday: string;

    fb: boolean;

    invitedFriends: Array<string>;

    @ViewChild('descriptionScroll') descriptionScroll:Scroll;
    @ViewChild('profileScroll') profileScroll:Content;

    constructor(private navParams:NavParams,
                private actionSheetCtrl: ActionSheetController,
                private platform: Platform,
                private events: Events,
                private modalCtrl: ModalController,
                public navCtrl: NavController,
                private viewCtrl: ViewController,
                private groupsService:GroupsService,
                private toastCtrl:ToastController,
                private analyticsService: AnalyticsService,
                private loginService: LoginService,
                private eventsService: EventsService,
                private peopleService: PeopleService,
                private popoverCtrl:PopoverController) {
    }

    ngOnInit() {
        this.group = this.navParams.get('group');

        //filter out bad group websites
        if (this.group['weburl'].length > 0
            && this.group['weburl'][0] != ''
            && !this.group['weburl'][0].match(/orgsync|collegiate|simplicity/g)) {
            this.group['weburl'] = [];
        }

        this.sharedFriends = [];

        //filter out duplicate keywords
        this.group['keywords'] = this.getUnique(this.group['keywords']);

        //filter admins out of member array
        this.group['members'] = this.group['members'].filter(a => {return this.group['admin'].indexOf(a) == -1});

        this.user = JSON.parse(localStorage.getItem('agnesUser'));
        this.currentTab = 0;
        this.image = 'url("' + this.group["picurl"] + '")';
        this.edited = false;
        this.isMember = this.group['members'].indexOf(this.user['_id']) != -1;
        this.isAdmin = this.group['admin'].indexOf(this.user['_id']) != -1;
        this.isFollowing = this.group['followers'] && this.group['followers'].indexOf(this.user['_id']) != -1;
        this.isClaimed = this.group['admin'].length > 0;
        this.invitedFriends = [];

        //initialize member list if user is admin/member/follower or if group is public
        this.memberList = [];
        this.getMembers();

        //initalize events list
        this.sharedEvents = [];
        this.hostedEvents = [];
        if((this.group['hostedEvents'].length + this.group['sharedEvents'].length) > 0) {
            this.getGroupEvents();
        }

        let t = new Date();
        this.today = t.toDateString().match(/[a-zA-Z]{3} [a-zA-Z]{3} \d\d/)[0];
        this.today = this.today.replace(/([a-zA-Z]{3})(\s[a-zA-Z]{3}\s)(\d{2})/, "$1.$2$3");
        t.setDate(t.getDate() - 1);
        this.yesterday = t.toDateString().match(/[a-zA-Z]{3} [a-zA-Z]{3} \d\d/)[0];
        this.yesterday = this.yesterday.replace(/([a-zA-Z]{3})(\s[a-zA-Z]{3}\s)(\d{2})/, "$1.$2$3");
        t.setDate(t.getDate() + 2);
        this.tomorrow = t.toDateString().match(/[a-zA-Z]{3} [a-zA-Z]{3} \d\d/)[0];
        this.tomorrow = this.today.replace(/([a-zA-Z]{3})(\s[a-zA-Z]{3}\s)(\d{2})/, "$1.$2$3");

        //TODO: move newsfeed call here from group info
        this.hasNewsFeed = this.isMember || this.isAdmin;


        //if no group profile, default display pic as random pattern
        this.group['displayURL'] = (this.group['displayURL'] == '')
            ? "assets/img/pattern_" + Math.floor((Math.random() * 15) + 1) + '.png' : this.group['picurl'];

        localStorage.setItem('agnesCurrentGroup', this.group['_id']);
        this.setMenuButtons();

        this.fb = !this.group['other']['facebookId'] || this.group['other']['facebookId'] == '';

        this.events.subscribe('toMeProfile', () => {
           this.closeGroupProfile(null,null);
        });

        this.events.subscribe('friendsInvited', friends => {
          this.invitedFriends = this.invitedFriends.concat(friends);
        })

        //user has created an event hosted by this group
        this.events.subscribe('eventHosted', data => {
            if(this.group['_id'] == data.groupID){
                let eInd = this.group['hostedEvents'].indexOf(data.eventID);
                if(eInd == -1){
                    this.group['hostedEvents'].push(data.eventID);
                }
            }
        });

        //user has shared an event with this group
        this.events.subscribe('eventSharedToGroup', data => {
            if(data.groups.indexOf(this.group['_id']) != -1){
                let eInd = this.group['sharedEvents'].indexOf(data.eventID);
                if(eInd == -1){
                    this.group['sharedEvents'].push(data.eventID);
                }
            }
        });

        //user has updated group from group info page
        this.events.subscribe('groupInfoUpdated', group => {
            this.events.publish('groupProfileData',{'group': group, 'category': 'edit'});
        });

        //go to Create Events page from clicking Host Event on events tab
        this.events.subscribe('goToHostEvent', (group) => {
            this.closeGroupProfile(null,null);
            this.events.publish('goToHostEvent_2', group);
        });

        //close profile when notification has been clicked so user can be directed to notification screen
        this.events.subscribe('closeProfiles', () => {
            this.closeGroupProfile(null,null)
        });

        this.events.subscribe('groupEdited', group => {
            if(group['_id'] == this.group['_id']){
                this.refreshGroup(group);
            }
        });

        this.events.subscribe('groupMembersEdited', (group) => {
            if(group['_id'] == this.group['_id']){
                this.refreshGroup(group);
            }
        });

        //user has been promoted to admin within group
        this.events.subscribe('adminPromotion', (groupsID) => {
            if(this.group['_id'] == groupsID){
                if(this.group['admin'].indexOf(this.user['_id']) == -1){this.group['admin'].push(this.user['_id']);}
                this.isAdmin = true;
                this.isMember = false;
                this.isFollowing = true;
                this.hasNewsFeed = true;
                this.setMenuButtons();
            }
        });

        //user's request to join this group has been accepted, adjust to reflect member status
        this.events.subscribe('reqAcceptedNewMember', (groupsID) => {
            if(this.group['_id'] == groupsID){
                if(this.group['members'].indexOf(this.user['_id']) == -1){this.group['members'].push(this.user['_id']);}
                this.isAdmin = false;
                this.isMember = true;
                this.isFollowing = false;
                this.hasNewsFeed = true;
                this.setMenuButtons();
            }
        });

        this.events.subscribe('invitedFriends', friends => {
          this.invitedFriends = this.invitedFriends.concat(friends);
        })

        //user has promoted people to admin
        this.events.subscribe('promotedMembers', data => {
            if(data.group['_id'] == this.group['_id']) {
                this.group['admin'] = this.group['admin'].concat(data.members);
                this.group['members'] = this.group['members'].filter(a => {return data.members.indexOf(a) == -1});
            }
        });

        //user has removed members
        this.events.subscribe('removedMembers', data => {
            if(data.group['_id'] == this.group['_id']) {
                this.group['admin'] = this.group['admin'].filter(a => {return data.members.indexOf(a) == -1});
                this.group['members'] = this.group['members'].filter(a => {return data.members.indexOf(a) == -1});
            }
        });

        //user has deleted an event that the group is hosting or has been shared to group
        this.events.subscribe('eventDeleted', event => {
            let ind = this.group['sharedEvents'].indexOf(event['_id']);
            if(ind != -1){this.group['sharedEvents'].splice(ind,1);}

            ind = this.group['hostedEvents'].indexOf(event['_id']);
            if(ind != -1){this.group['hostedEvents'].splice(ind,1);}

            let sharedInd = this.sharedEvents.map(a => a['_id']).indexOf(event['_id']);
            if(sharedInd != -1){
                this.sharedEvents.splice(sharedInd, 1);
            }

            let hostedInd = this.hostedEvents.map(a => a['_id']).indexOf(event['_id']);
            if(hostedInd != -1){
                this.hostedEvents.splice(hostedInd,1);
            }
        });

        //prevent duplicate group shares to the same person
        this.events.subscribe('friendsShareSent', friends => {
            this.sharedFriends = this.sharedFriends.concat(friends);
        });

    }

    ionViewDidEnter(){
        //send group profile analytics
        let url = this.navParams.get('type') == 'notification' ? '/notificationGroup'
            : ('/check' + (this.navParams.get('type') == 'matched'
                ? 'Match'
                : this.navParams.get('type') == 'my' ? 'My' : '') + 'GroupProfile');
        this.analyticsService.logAnalytics({
            users_id: this.user['_id'],
            groups_id: this.group['_id']
        },url);
    }

  //add or edit a public group status
  editStatus(){
      let inp = this.group['status_quo'] ? this.group['status_quo'] : '';
      let agnesInput = this.modalCtrl.create('AgnesInput',
          {
              inp: inp,
              header: 'Add a public status',
              limit: 140,
              placeholder: 'What is your group up to?',
              type: 'status'
          });
      agnesInput.onDidDismiss((status) => {

          Agnes.removeFilter();

          if(status) {
              let data = {
                  'status_quo': status['agnesInput'].trim(),
                  'groups_id': this.group['_id'],
                  'send_notification': status['sendNotification'],
                  'users_id': this.user['_id']
              };

              this.groupsService.updateStatus(data).then(val => {

                  let message = 'Your status has been ' + (inp == '' ? 'added!' : 'changed!');

                  this.toastCtrl.create({
                      message: message,
                      position:'top',
                      showCloseButton: true,
                      closeButtonText: ' ',
                      duration: 2500
                  }).present();

                  this.group['status_quo'] = status['agnesInput'];
              }).catch(err => {
                 Agnes.showError('Sorry, couldn\'t update your group status right now - try again later!');
                 console.log(err);
              });
          }
      });
      for (var e = 0; e < document.getElementsByTagName("ion-popover").length; e++){
          document.getElementsByTagName("ion-popover")[e]["style"]["filter"]="blur(3vw)";
      }
      document.getElementsByTagName("ng-component")[0]["style"]["filter"]="blur(3vw)";
      agnesInput.present();
  }

    //get list of shared/hosted events that are connected to this group
    getGroupEvents(){
      this.sharedEvents = [];
      this.hostedEvents = [];

      //get hosted events
        if(this.group['hostedEvents'].length > 0){
            this.eventsService.getEventsFromId({
                'evt':this.group['hostedEvents'],
                'community': this.user['community']
            }).then(value => {
                if(value){

                    //filter out events that are already over
                    let now = new Date();
                    value = value.filter(a => {
                        return (new Date(a['endtime']) > now);
                    });

                    for(let v in value){
                        let start = Agnes.processGMT(value[v]['starttime']);
                        let date = (start.date == this.today) ? "Today" : (start.date == this.tomorrow) ? "Tomorrow" : start.date;
                        let time = (start.time == "12:01AM") ? "All Day" : start.time;
                        value[v]['time'] = date + ' - ' + time;
                        if(value[v]['evttype'] == 'public' || (this.isMember || this.isAdmin)) {
                            this.hostedEvents.push(value[v]);
                        }
                    }

                    this.hostedEvents.sort(function(a,b){
                        let x = new Date(a['starttime'].replace(/[-\+]\d\d\d\d/,'Z')).getTime();
                        let y = new Date(b['starttime'].replace(/[-\+]\d\d\d\d/,'Z')).getTime();
                        return x - y;
                    });
                }
                else {
                    Agnes.showError('Could not get this group\'s hosted events!');
                }
            }).catch(err => {
                console.log('get group events error', err);
                Agnes.showError('Could not get this group\'s hosted events!');
            });
        }

        //get shared events
        if(this.group['sharedEvents'].length > 0){
            this.eventsService.getEventsFromId({
                'evt':this.group['sharedEvents'],
                'community': this.user['community']
            }).then(value => {
                if(value){

                    //filter out events that are already over
                    let now = new Date();
                    value = value.filter(a => {
                        return (new Date(a['endtime']) > now);
                    });

                    for(let v in value){
                        let start = Agnes.processGMT(value[v]['starttime']);
                        let date = (start.date == this.today) ? "Today" : (start.date == this.tomorrow) ? "Tomorrow" : start.date;
                        let time = (start.time == "12:01AM") ? "All Day" : start.time;
                        value[v]['time'] = date + ' - ' + time;
                        if(value[v]['evttype'] == 'public' || (this.isMember || this.isAdmin)) {
                            this.sharedEvents.push(value[v]);
                        }
                    }

                    this.sharedEvents.sort(function(a,b){
                        let x = new Date(a['starttime'].replace(/[-\+]\d\d\d\d/,'Z')).getTime();
                        let y = new Date(b['starttime'].replace(/[-\+]\d\d\d\d/,'Z')).getTime();
                        return x - y;
                    });
                }
                else {
                    Agnes.showError('Could not get this group\'s shared events!');
                }
            }).catch(err => {
                console.log('get group events error', err);
                Agnes.showError('Could not get this group\'s shared events!');
            });
        }
    }

    closeGroupProfile(e, action){
        if (!e || ((e.direction == 4) && this.currentTab == 0) || e == 'backButton') {

            //back button specifically has been pressed
            if(e == 'backButton'){
                //send Back Button analytics
                this.analyticsService.logAnalytics({
                    backButtonName: 'groupProfile',
                    users_id: this.user['_id']}, '/backButton');

            }

            let data = (this.edited || action) ? {'group':this.group, 'category': (this.edited ? 'edit' : action)} : null;
            if(data){this.events.publish('groupProfileData',data);}
            localStorage.removeItem('agnesCurrentGroup');

            //if this is a notification, send notification closed event so notifications can be opened again
            this.events.publish('notificationClosed');

            this.viewCtrl.dismiss(null, '', {
                animate: true,
                animation: 'ios-transition',
                duration: 350,
                easing: "ease-in-out",
                direction: "back"
            });
        }
    }

    //set buttons on action sheet menu
    setMenuButtons(){

        this.menuButtons = [];

        //add Join button if user is not member or admin and is not yet following
        if(!this.isAdmin && !this.isMember && !this.isFollowing && !this.claimSent) {
            this.menuButtons.push({
                text: 'Join Group',
                icon: 'md-add',
                handler: () => {this.joinGroup();}
            })
        }

        //add view members button
        if(this.group['members'].length + this.group['admin'].length + this.group['followers'].length > 0) {
            this.menuButtons.push({
                text: 'View Members',
                icon: 'md-contacts',
                handler: () => {this.viewMembers();}
            });
        }

        //add Share Group button (always)
        this.menuButtons.push({
            text: 'Share Group',
            icon: 'md-share',
            handler: () => {this.shareGroup();}
        });

        //add unfollow button is user is following group
        if(this.isFollowing) {
            this.menuButtons.push({
                text: 'Unfollow Group',
                icon: 'md-log-out',
                handler: () => {this.unfollowGroup();}
            });
        }

        //add Leave button if user is admin or member
        if (this.isAdmin || this.isMember) {
            this.menuButtons.push({
                text: 'Leave Group',
                icon: 'md-log-out',
                cssClass: 'action-sheet-report',
                handler: () => {this.leaveGroup();}
            });
        }

        //add Delete Group button if user is admin of group
        if (this.isAdmin) {
            this.menuButtons.push({
                text: 'Delete Group',
                icon:'md-trash',
                cssClass: 'action-sheet-report',
                handler: () => {this.deleteGroup();}
            })
        }
        //add Report Group button if user is not part of group
        else {
            this.menuButtons.push({
                text: 'Report Group',
                icon: 'md-flag',
                cssClass: 'action-sheet-report',
                handler: () => {this.reportEntity();}
            });
        }

        //add Cancel button (always)
        this.menuButtons.push({
            text: 'Cancel',
            role: 'cancel',
            icon: 'md-close',
            handler: () => {}
        });
    }

    //open group options menu w/ toggle
    openGroupMenu(){

        let actionSheet = this.actionSheetCtrl.create({
            title: '',
            buttons: this.menuButtons
        });
        actionSheet.present();
    }

    editGroup() {

        this.popoverCtrl.create(
            'EditGroup',
            {
                'group': this.group
            },
            {'enableBackdropDismiss': true}).present({
            animation: 'ios-transition',
            duration: 350
        });
    }

    getChatFeed(){
        //send Group Feed analytics
        this.analyticsService.logAnalytics({
            users_id: this.user['_id'],
            groups_id: this.group['_id']
        },'/groupFeed');

        this.popoverCtrl.create('GroupFeedPage',
            {'group': this.group,
            'type' : 'feed'},{}).present({
            animation: 'ios-transition',
            duration: 350
        });
    }

    //get group members for display
    getMembers(){
        this.memberList = [];

        let adminProm = this.peopleService.getUsersFromIds({'users':this.group['admin'].filter(x => {return x != this.user['_id'];})});
        let memProm = this.peopleService.getUsersFromIds({'users':this.group['members'].filter(x => {return x != this.user['_id'];})});
        let followProm = this.peopleService.getUsersFromIds({'users':this.group['followers'].filter(x => {return x != this.user['_id'];})});

        Promise.all([adminProm,memProm,followProm]).then(val => {
            let admins = val[0];
            let mems = val[1];
            let followers = val[2];

            let combinedMems = admins.concat(mems);

            followers = followers.filter(f => {
              let notDup = true;
              for(let c in combinedMems) {
                if(combinedMems[c]['_id'] == f['_id']){
                  notDup = false
                }
              }
              return notDup
            })

            if(admins){
                //add admin boolean for badge, cover no thumbnail case, and sort alphabetically
                admins = admins.map(a => {
                    a['isAdmin'] = true;
                    a['thumbnail'] = a['thumbnail'] != ''
                        ? a['thumbnail'] : a['picurl'] != '' ? a['picurl'] : '';
                    return a;
                }).sort((a,b) => {
                    return (b['fname'] < a['fname'] ? 1 : -1);
                });

                this.memberList = this.memberList.concat(admins);
            }

            if(mems){
                //filter admins out of members, cover no thumbnail case, and sort alphabetically
                mems = mems.filter(a => {
                    return this.group['admin'].indexOf(a['_id']) == -1;
                }).map(a=> {
                    a['isMember'] = true;
                    a['thumbnail'] = a['thumbnail'] != ''
                        ? a['thumbnail'] : a['picurl'] != '' ? a['picurl'] : '';
                    return a;
                }).sort((a,b) => {
                        return (b['fname'] < a['fname'] ? 1 : -1);
                    });

                this.memberList = this.memberList.concat(mems);
            }

            if(followers){
                //add admin boolean for badge, cover no thumbnail case, and sort alphabetically
                followers = followers.map(a => {
                    a['thumbnail'] = a['thumbnail'] != ''
                        ? a['thumbnail'] : a['picurl'] != '' ? a['picurl'] : '';
                    return a;
                }).sort((a,b) => {
                    return (b['fname'] < a['fname'] ? 1 : -1);
                })

                this.memberList = this.memberList.concat(followers);
            }

        }).catch(err => {
            this.loading = false;
            console.log('getting admin error', err);
        });
    }

    //view members of group if admin or member
    viewMembers(){
        this.user['isAdmin'] = true;

        this.popoverCtrl.create('GroupMembers',{
            'group': this.group,
            'type': 'view',
            'memberList': [this.user].concat(this.memberList)
        }).present({
            animation: 'ios-transition',
            duration: 350
        });
    }

    //claim group
    claimGroup() {
        if(!this.isClaimed){

            this.events.subscribe('agnesAlertData', ind => {
                this.events.unsubscribe('agnesAlertData');

                if(ind == 1){
                    let data = {
                        "group_id": this.group['_id'],
                        "users_id": this.user['_id']
                    };
                    this.groupsService.claimGroup(data)
                        .then(value => {
                            if (value == 'sent') {
                                //successfully sent claim for group
                                this.claimSent = true;

                                let toast = this.toastCtrl.create({
                                    message: "You've requested to be an admin of " + this.group['grpname'] + "!",
                                    duration: 2500,
                                    position: 'top',
                                    closeButtonText: ' ',
                                    showCloseButton: true
                                });
                                toast.present();

                            }
                            else {
                                let message = "";
                                if (value == 'already exist') {
                                    //already have admin access (i.e. userID is in group.admin and userEmail is in group.grpemail)
                                    message = "You are already an admin of " + this.group['grpname'] + "!";
                                }
                                else {
                                    message = "Sorry, I couldn't process your request for admin access to " + this.group['grpname'] + ". Try again!";
                                }
                                Agnes.showError(message);
                            }
                        })
                        .catch(err => {
                            console.log(err)
                            Agnes.showError("Sorry, I couldn't process your request for admin access to " + this.group['grpname'] + ". Try again!")
                        })
                }
            });

            let message = "Would you like to claim " + this.group['grpname'] + " as a group that you're an admin of? If approved, " +
                "you will be given full administrative access to the group.";
            let buttons = ['Cancel', 'Yes'];

            Agnes.showError(message,buttons);
        }
    }

    contactGroup() {

        //send Group Contact analytics
        this.analyticsService.logAnalytics({
            users_id: this.user['_id'],
            groups_id: this.group['_id']
        },'/contactUnderGroup');

        //allow user to email only if on mobile phone
        if (this.platform.is('mobile')
            && this.platform.is('cordova') &&
            (this.platform.is('ios') || this.platform.is('android'))) {

            //if user is already member, do not add prepopulated subject line
            let subj = (this.group['members'].indexOf(this.user['_id']) == -1)
                ? "Saw \"" + this.group['grpname'] + "\" on Agnes" : '';

            this.loading = true;

            Agnes.socialSharing.shareViaEmail('',subj,this.group['grpemail']).then(() => {
                this.loading = false;
            }).catch(() => {
                this.loading = false;
                Agnes.showError("Agnes can't open your email client to contact this group - please try again!");
            });
        }
        else {
            Agnes.showError("Please install Agnes from the App Store or Google Play store to email groups.");
        }
    }

    deleteGroup(){

        let message = "Are you sure you want to delete " + this.group['grpname'] + "?";
        let buttons = ['Cancel','Yes'];

        this.events.subscribe('agnesAlertData', ind => {
            this.events.unsubscribe('agnesAlertData');
            if(ind == 1){
                let data = {'groups_id':this.group['_id']};

                this.groupsService.deleteGroup(data).then(value => {
                    if (value) {

                        let ind = this.user['grp'].map(function(a){return a['groups_id']}).indexOf(this.group['_id']);
                        if(ind != -1){
                            this.user['grp'].splice(ind,1);
                            localStorage.setItem('agnesUser',JSON.stringify(this.user));
                        }

                        this.events.publish('updateUser');
                        this.events.publish('groupDeleted',this.group['_id']);

                        let toast = this.toastCtrl.create({
                            message: "You've successfully deleted " + this.group['grpname'] + ".",
                            duration: 2500,
                            position: 'top',
                            closeButtonText: ' ',
                            showCloseButton: true
                        });
                        toast.present();

                        this.closeGroupProfile(null, 'delete');
                    }
                }).catch(error => {
                    console.log(error);
                    Agnes.showError("Sorry, something went wrong - try deleting " + this.group['grpname'] + " again!");
                });
            }
        });

        Agnes.showError(message,buttons);
    }

    // follow the group
    followGroup(){
        let data = {
            groups_id: this.group['_id'],
            users_id: this.user['_id']
        };

        this.groupsService.followGroup(data).then(val => {
            this.group['followers'].push(this.user['_id']);
            this.user['following'].push({'groups_id': this.group['_id']});
            this.isFollowing = true;
            this.setMenuButtons();
            this.events.publish('followGroup', this.group);
            this.events.publish('updateUser');

            let message = 'You are now following ' + this.group['grpname'] +'!';

            this.toastCtrl.create({
                message:  message,
                duration: 2500,
                position: 'top',
                closeButtonText: ' ',
                showCloseButton: true
            }).present();

        }).catch(error => {
            console.log(error);
            Agnes.showError('Could not add this group to your following list - try again later!');
        })
    }

    //invite friends to this group
    inviteFriends(){

        this.popoverCtrl.create(InviteFriends, {
            'user':this.user,
            'objectID': this.group['_id'],
            'type': 'group',
            'filterIDs': this.group['admin'].concat(this.group['members']),
            'sentFriends' : this.invitedFriends

        }).present({
            animation: 'ios-transition',
            duration: 350
        });
    }

    joinGroup() {

        //user is already part of this group
        if (this.isAdmin || this.isMember) {
            Agnes.showError("You're already a part of " + this.group['grpname'] + "!");
        }

        // if user has already requested to join
        else if (this.group['pendingreq'].indexOf(this.user['_id']) != -1) {
            Agnes.showError("You've already requested to join " + this.group['grpname'] + "!");
        }

        // user is not part of group and has not requested - make sure user really wants to join
        else {
            let message = "Are you sure you want to join " + this.group['grpname'] + "?";
            let buttons = ['Cancel','Yes'];

            this.events.subscribe('agnesAlertData', ind => {
                this.events.unsubscribe('agnesAlertData');

                if(ind == 1){
                    Agnes.removeFilter();
                    let data = {
                        "groups_id": this.group['_id'],
                        "users_id": this.user['_id'],
                        "community": this.user['community']
                    };

                    if(this.group['grptype'] == 'public' || this.group['grptype'] == 'open') {

                    this.groupsService.joinGroup(data).then(value => {
                        if (value) {
                            // if(this.group['grptype'] == 'public'){
                                this.group['members'].push(this.user['_id']);
                                this.group['memcount'] = this.group['memcount'] + 1;

                                this.user['grp'].push({'groups_id':this.group['_id'], 'admin': false});
                                this.events.publish('updateUser');
                                this.events.publish('addedGroup', {'group': this.group, 'type':'member'});
                                this.isMember = true;
                            // }
                            // else {
                                // this.group['pendingreq'].push(this.user['_id']);
                            // }

                            let message = (this.group['grptype'] == 'public' || this.group['grptype'] == 'open'
                                ? "You are now part of " : "Your request to join " )
                                + this.group['grpname']
                                +  (this.group['grptype'] == 'public' || this.group['grptype'] == 'open'
                                    ? "!" : " has been sent!");

                            this.toastCtrl.create({
                                message:  message,
                                duration: 2500,
                                position: 'top',
                                closeButtonText: ' ',
                                showCloseButton: true
                            }).present();

                            this.isMember = this.group['grptype'] == 'public' || this.group['grptype'] == 'open';
                            this.setMenuButtons();
                        }
                        else {
                            Agnes.showError("Sorry, something went wrong - try joining " + this.group['grpname'] + " again!");
                        }
                    }).catch(err => {
                       console.log('join group error', err);
                       Agnes.showError("Sorry, something went wrong - try joining " + this.group['grpname'] + " again!");
                    });
                  }
                    else {
                        this.groupsService.joinPrivateGroup(data).then(data => {
                          let message = (this.group['grptype'] == 'public' || this.group['grptype'] == 'open'
                              ? "You are now part of " : "Your request to join " )
                              + this.group['grpname']
                              +  (this.group['grptype'] == 'public' || this.group['grptype'] == 'open'
                                  ? "!" : " has been sent!");

                          this.toastCtrl.create({
                              message:  message,
                              duration: 2500,
                              position: 'top',
                              closeButtonText: ' ',
                              showCloseButton: true
                          }).present();
                        }).catch(err => {
                          console.log(err);
                        })
                    }
                }
            });

            Agnes.showError(message,buttons);
        }
    }

    leaveGroup(){

        let message = "Are you sure you want to leave " + this.group['grpname'] + "?";
        let buttons = ['Cancel', 'Yes'];

        this.events.subscribe('agnesAlertData', ind => {
            this.events.unsubscribe('agnesAlertData');

            if(ind == 1){
                let data = {
                    "groups_id": this.group['_id'],
                    "users_id": this.user['_id']
                };

                this.groupsService.leaveGroup(data).then(value => {
                    //leaveGroup returns 1 for success
                    if (value){
                        let aInd = this.group['admin'].indexOf(this.user['_id']);
                        let mInd = this.group['members'].indexOf(this.user['_id']);

                        if(aInd != -1) {this.group['admin'].splice(aInd,1);}
                        if(mInd != -1) {this.group['members'].splice(mInd,1);}

                        let ind = this.user['grp'].map(a => {return a['groups_id']}).indexOf(this.group['_id']);

                        if(ind != -1){
                            this.user['grp'].splice(ind,1);
                            localStorage.setItem('agnesUser',JSON.stringify(this.user));
                        }

                        this.events.publish('leftGroup', {'group': this.group['_id'], 'type': (this.isAdmin ? 'admin' : 'member')});
                        this.isMember = false;
                        let toast = this.toastCtrl.create({
                            message: "You've left " + this.group['grpname'] + "!",
                            duration: 2500,
                            position: 'top',
                            closeButtonText: ' ',
                            showCloseButton: true
                        });
                        toast.present();

                        this.setMenuButtons();
                        this.closeGroupProfile(null, 'leave');
                        // this.setMenuButtons()
                        // Agnes.showError("You've left " + this.group['grpname'] + "!", []);

                    }
                    else {
                        console.log('leave group err1', value);
                        Agnes.showError('Sorry, could not remove this group from your groups list - try again!');
                    }
                }).catch(err => {
                    console.log('leave group err2', err);
                    Agnes.showError('Sorry, could not remove this group from your groups list - try again!');
                });
            }
        });

        Agnes.showError(message, buttons);
    }

    openEventProfile(event) {
        this.navCtrl.push(
            EventProfile,
            {
                'event':event,
                'user':this.user,
                'type':this.user['evtrsvp'].indexOf(event['_id']) != -1 ? 'my' : 'all'
            }, {
                animation: 'ios-transition',
                duration: 350
            });
    }

    refreshGroup(data){
        this.group = data;
        this.image = data['picurl'];
        this.isClaimed = this.group['admin'].length > 0;
        if (this.isClaimed) {this.claimSent = false}
        this.isMember = this.group['members'].indexOf(this.user['_id']) != -1;
        this.isAdmin = this.group['admin'].indexOf(this.user['_id']) != -1;
        this.isFollowing = this.group['followers'] && this.group['followers'].indexOf(this.user['_id']) != -1;
        this.setMenuButtons();
        this.hasNewsFeed = this.isMember || this.isAdmin;


        //get Members and events
        this.getMembers();
        if((this.group['hostedEvents'].length + this.group['sharedEvents'].length) > 0) {
            this.getGroupEvents();
        }

        //if no group profile, default display pic as random pattern
        this.group['displayURL'] = (this.group['displayURL'] == '')
            ? "assets/img/pattern_" + Math.floor((Math.random() * 15) + 1) + '.png' : this.group['picurl'];
    }

    reportEntity() {

        let reportPage = this.popoverCtrl.create(
            ReportPage,
            {
                'entityID': this.group['_id'],
                'entityName': this.group['grpname'],
                'user': this.user,
                'type': 'group',
                'platform': this.platform
            },
            {'enableBackdropDismiss': true});
        reportPage.present(
            {
                animation: 'ios-transition',
                duration: 350
            }
        );
        reportPage.onDidDismiss(() => {
        });
    }

    shareGroup() {
      Agnes.shareOutside('group', this.group['_id'])
    }

    //sync group w Facebook group data
    syncWithFbGroup(){
        if(this.user['email']['fbid'] == ''){
            Agnes.showError("Your account isn't linked to Facebook!", ['Back', 'Connect'], true, true);
            this.events.subscribe('agnesAlertData', ind => {
                this.events.unsubscribe('agnesAlertData');
                if(ind){
                    Agnes.facebook.getLoginStatus().then(value => {

                        if(value && value.status) {

                            let upd = {
                                access_token: '',
                                users_id: this.user['_id']
                            };

                            if (value.status == 'connected') {
                                upd['access_token'] = value['authResponse']['accessToken'];

                                this.loginService.fbUpdate(upd).then(value => {

                                    this.loginService.getUser({"users_id":this.user['_id']}).then(value => {
                                        if (value) {
                                            this.user = value;
                                            localStorage.setItem('agnesUser', JSON.stringify(this.user));
                                        }
                                    }).catch(err => {
                                        console.log(err);
                                        this.events.publish('updateUser');
                                    });

                                    this.syncWithFbGroup();

                                }).catch(err => {
                                    console.log('fb after update error',err);
                                    Agnes.showError('Could not connect to Facebook - please try again!');
                                });
                            }
                            else if (value.status == 'not_authorized') {
                                Agnes.showError('Please allow Agnes access to your Facebook account!');
                            }
                            else {
                                let permissions = ['public_profile',
                                    'user_friends',
                                    'email',
                                    'user_birthday',
                                    'user_managed_groups',
                                    'user_likes',
                                    'pages_show_list',
                                    'user_events',];

                                Agnes.facebook.login(permissions).then(value => {

                                    if (value && value.status == 'connected') {
                                        upd['access_token'] = value['authResponse']['accessToken'];

                                        this.loginService.fbUpdate(upd).then(value => {

                                            this.loginService.getUser({"users_id":this.user['_id']}).then(value => {
                                                if (value) {
                                                    this.user = value;
                                                    localStorage.setItem('agnesUser', JSON.stringify(this.user));

                                                    this.syncWithFbGroup();
                                                }
                                            }).catch(err => {
                                                console.log(err);
                                                this.events.publish('updateUser');
                                            });
                                        }).catch(err => {
                                            console.log('fb after update error 2',err);
                                            Agnes.showError('Could not connect to Facebook - please try again!');
                                        });
                                    }
                                    else {
                                        Agnes.showError('Could not connect to Facebook - please try again!');
                                    }
                                }).catch(error => {
                                    console.log('Facebook.login error', error);
                                    Agnes.showError('Could not connect to Facebook - please try again!');
                                });
                            }
                        }
                    }).catch(error => {Agnes.showError('Could not connect to Facebook - please try again!')});
                }
            });
        }
        else {
            this.loading = true;
            let data = {
                'users_id':this.user['_id']
            };

            this.groupsService.getFBGroups(data).then(val => {

                this.loading = false;
                if (val && val.length > 0) {
                    val = val.filter(b => {return typeof(b) == 'object';}).map(a => {
                        a['_id'] = a['groups_id'];
                        a['thumbnail'] = a['picurl'];
                        return a;
                    });

                    if(val.length > 0) {
                      this.fb = false;
                        let fbgroups = this.popoverCtrl.create(
                            'GroupListPopup',
                            {
                                'groupList': val,
                                'submitText': 'Import',
                                // 'helpText': 'Which group should your group sync to?',
                                'singleTap': true
                            },
                            {'enableBackdropDismiss': false});
                        fbgroups.present(
                            {
                                animation: 'ios-transition',
                                duration: 350
                            }
                        );

                        fbgroups.onDidDismiss(group => {
                            if(group) {

                                this.loading = true;

                                let fbData = {
                                    groups_id: this.group['_id'],
                                    groups_fbid: group['groups_id'],
                                    grpname: group['grpname'],
                                    grpdesc: group['grpdesc'],
                                    picurl: group['picurl'],
                                    thumbnail: group['thumbnail'],
                                    community: this.user['community'],
                                    users_id: this.user['_id']
                                };

                                this.groupsService.syncWithFbGroup(fbData).then(val => {
                                    this.loading = false;

                                    if(val){
                                        console.log("Gettin' vals");
                                        console.log(val);
                                        //update info in group header and info tabs
                                        this.events.publish('groupEdited', val);

                                        let toast = this.toastCtrl.create({
                                            message: "Group synced!",
                                            duration: 2500,
                                            position: 'top',
                                            closeButtonText: ' ',
                                            showCloseButton: true
                                        });
                                        toast.present();


                                    }
                                    else {
                                        Agnes.showError("Sorry, could not sync your group - try again!")
                                    }
                                }).catch(err => {
                                    this.loading = false;
                                    console.log(err);
                                    Agnes.showError("Sorry, could not sync your group - try again!");
                                })
                            }
                        });
                    }
                    else {
                        Agnes.showError('Looks like you don\'t have any Facebook groups to sync with!');
                    }
                }
                else {
                    Agnes.showError('Looks like you don\'t have any Facebook groups to sync with!');
                }
            }).catch(err => {
                this.loading = false;
                console.log(err);
                Agnes.showError("Couldn't get your Facebook data - try again!");
            });
        }
    }

    unfollowGroup(){
        let data = {
            users_id: this.user['_id'],
            groups_id: this.group['_id']
        };

        this.groupsService.unfollowGroup(data).then(val => {
            let ind = this.group['followers'].indexOf(this.user['_id']);
            if(ind != -1){this.group['followers'].splice(ind,1);}

            ind = this.user['following'].map(a => {return a['groups_id']}).indexOf(this.group['_id']);
            if(ind != -1){this.user['following'].splice(ind,1);}
            localStorage.setItem('agnesUser',JSON.stringify(this.user));

            //remove group from followed groups in My Groups
            this.events.publish('leftGroup', {
                'group': this.group['_id'],
                'type':'follow'
            });

            this.isFollowing = false;
            this.setMenuButtons();
            let toast = this.toastCtrl.create({
                message: "You've unfollowed " + this.group['grpname'] + "!",
                duration: 2500,
                position:'top',
                closeButtonText: ' ',
                showCloseButton: true
            });
            toast.present();
        }).catch(error => {
            console.log(error);
            Agnes.showError('Could not unfollow this group right now - try again later!');
        })
    }

    userOpened(){
        this.closeGroupProfile(null, null);
    }

    //view group profile image fullscreen
    viewGrpImg(){
        if(!this.group['noPic'] && this.group != ''){Agnes.photoViewer.show(this.group['picurl']);}
    }

    getUnique(arr){
        let u = {}, a = [];
        for(var i = 0, l = arr.length; i < l; ++i){
            if(u.hasOwnProperty(arr[i])) {
                continue;
            }
            a.push(arr[i]);
            u[arr[i]] = 1;
        }
        return a;
    }

    imgError(person){
        person['noPic'] = true;
    }

}

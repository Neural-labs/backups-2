"""
Module for collecting features given a sample page with html

Types of features:
1. Manual Features (length, word count, etc.)
2. Word Embedding (Google Pre-trained W2V Embedding of Content)
3. HTML Embedding (Local Trained W2V Embedding of HTML Content)
4. URL Embedding (GLOVE Pre-Trained Char embedding of url characters)

"""

from config import db_config
import numpy as np
import string
from gensim.models import keyedvectors, Word2Vec
import logging
import pickle
import re
from collections import Counter
from bson.binary import Binary
from EmbeddingTrainer import tokenizeH2V_W, tokenizeC2V, tokenizeW2V
from Utilities import DateExtraction, LocationExtraction, DataFilter
from Utilities.DataFilter import removeContentInHTML, removeHref, removeHTML, removePunctuation, getKeywordCount, cleanString

Agnes = db_config.getDBConn('dev').Agnes
Parent_Event_Collection = Agnes.autocrawler_events
Parent_Control_Collection = Agnes.autocrawler_control

def getWord2VecEmbedding():
    return keyedvectors.KeyedVectors().load_word2vec_format('GoogleNews-vectors-negative300.bin', binary=True)

def getPageEmbedding():
    return Word2Vec.load('gensim_model_page_embedding')

def getPageEmbeddingV2():
    return Word2Vec.load('gensim_model_page_embedding_v2')

def getCharEmbedding():
    model = {}
    with open('glove.840B.300d-char.txt', 'r') as f:
        data = f.readlines()
        for line in data:
            char = line[0]
            char_data = line[1:]
            char_data = np.array([float(item) for item in char_data.split() if item]).astype(np.float16)
            model[char] = char_data
    return model

def extractFeaturesManual(url, html):

    html_content = removeContentInHTML(html)
    real_content = removeHTML(html)

    lower_url = url.lower()
    lower_content = real_content.lower()
    lower_html = html_content.lower()
    lower_html_nohref = removeHref(lower_html)

    keywords = ['title', 'description', 'detail', 'desc', 'location', 'locat', 'name', 'date', 'summary', 'event','events', 'content',
                'field', 'address','venue', 'time', 'when', 'where', 'start', 'end', 'map', 'calendar', 'cal', 'from', 'to', 'building',
                'hall', 'auditorium', 'room','floor','conference' ,'clock', 'street', 'locality', 'theatre', 'theater','tags', 'contact',
                'rsvp']

    URLKeywords = ['event','calendar','day','month','time','events','cal','date','id','id=','/events/','/event/']

    content_length = len(real_content)  # int
    html_length = len(lower_html_nohref)  # int
    num_content_words = len(removePunctuation(lower_content))  # int
    num_html_words = len(removePunctuation(lower_html_nohref))  # int

    if num_content_words < 1:
        capital_ratio = 0
    else:
        capital_ratio = float(sum(1 for c in real_content if c.isupper())) / float(num_content_words)  # float
#view-source:http://browse.calendar.gwu.edu/EventList.aspx?fromdate=5/3/2018&todate=6/1/2018&display=&type=public&eventidn=16068&view=EventDetails&information_id=30404
    avg_content_word_len = getAvgWordLength(lower_content)  # float
    avg_content_sen_len = getAvgSentenceLength(lower_content)  # float

    punc_counts = getKeywordCount(string.punctuation, lower_content)  # list
    content_keyword_counts = getKeywordCount(keywords, lower_content)  # list
    html_keyword_counts = getKeywordCount(keywords, lower_html_nohref)  # list
    url_keyword_counts = getKeywordCount(URLKeywords, lower_url) # list
    tag_counts = getTagCount(html_content) # list

    features = [content_length, html_length, num_content_words, num_html_words, capital_ratio, avg_content_word_len,
                avg_content_sen_len]

    features += punc_counts
    features += content_keyword_counts
    features += html_keyword_counts
    features += url_keyword_counts

    features += manualLocation(html)

    features += manualDate(html)

    features += tag_counts

    print 'content_len',content_length
    print 'html_len',html_length
    print 'num_content_words',num_content_words
    print 'num_html_words',num_html_words
    print 'capital ratio',capital_ratio
    print 'avg_content_word_len',avg_content_word_len
    print 'avg_content_sen_len',avg_content_sen_len
    print 'punc counts', zip(string.punctuation, punc_counts)
    print 'content keywords',zip(keywords, content_keyword_counts)
    print 'html_keywords',zip(keywords, html_keyword_counts)
    print 'url_keywords',zip(URLKeywords, url_keyword_counts)
    print 'tag_counts',zip(DataFilter.ValidTags, tag_counts)
    print 'Locations',manualLocation(html)
    print 'Dates',manualDate(html)

    return features

def manualLocation(text):

    text = removeHTML(text)
    text = cleanString(text)

    usaddr_location_fields = LocationExtraction.getUSAddressFields()
    postal_location_fields = LocationExtraction.getPostalFields()
    features = []

    us_addr = LocationExtraction.getRawUSAddress(text)
    postal_addr = LocationExtraction.getRawPostalAddress(text)

    for field in usaddr_location_fields:
        features.append(len([item for item in us_addr if item[1] == field]))

    for field in postal_location_fields:
        features.append(len([item for item in postal_addr if item[1]==field]))

    return features

def manualDate(text):
    text = removeHTML(text)
    dates = len(DateExtraction.getDates(text))

    return [dates]

def extractHTMLFeaturesEmbedding(embedding_model, text):

    HTML = removeHref(text)
    # html_content = removeRealContent(HTML)

    tokens = tokenizeH2V_W(HTML)

    feature_vector = getAvgEmbedding(embedding_model, tokens)

    return feature_vector

def extractContentFeaturesEmbedding(embedding_model, text):

    tokens = tokenizeW2V(text)

    feature_vector = getAvgEmbedding(embedding_model, tokens)

    return feature_vector

def extractURLFeaturesEmbedding(embedding_model, url):

    tokens = tokenizeC2V(url)

    vectors = [embedding_model[char] for char in tokens if char in embedding_model]

    if not vectors:
        return None

    feature_vector = np.mean(np.vstack(vectors).astype(np.float16), axis=0)

    feature_vector = Binary(pickle.dumps(feature_vector))

    return feature_vector

def getAvgEmbedding(embedding_model, tokens):
    if not tokens:
        return None

    vectors = [embedding_model.wv[token] for token in tokens if token in embedding_model.wv]

    if not vectors:
        return None

    feature_vector = np.mean(np.vstack(vectors).astype(np.float16), axis=0)

    feature_vector = Binary(pickle.dumps(feature_vector))

    return feature_vector

def getAvgWordLength(content):
    content = removePunctuation(content)
    avg_word_len = np.mean([len(word) for word in content.split()])
    return avg_word_len

def getAvgSentenceLength(content):
    avg_sen_len = np.mean([len(sen) for sen in content.split('.')])
    return avg_sen_len

def getTagCount(html):
    html = cleanString(html)

    pattern = re.compile('(<)([\w]*?)[ >]')
    tags = Counter([item[1] for item in re.findall(pattern, html)])

    valid_tags = DataFilter.ValidTags

    if not tags:
        return [0]*len(valid_tags)

    tag_counts = []
    for tag in valid_tags:
        if tag in tags:
            tag_counts.append(tags[tag])
        else:
            tag_counts.append(0)

    return tag_counts



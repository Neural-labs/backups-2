import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';

import { NewsProfile } from './news-profile';

@NgModule({
    declarations: [
        NewsProfile
    ],
    imports: [
        IonicPageModule.forChild(NewsProfile)
    ],
    exports: [
        NewsProfile
    ],
})

export class NewsProfileModule { }

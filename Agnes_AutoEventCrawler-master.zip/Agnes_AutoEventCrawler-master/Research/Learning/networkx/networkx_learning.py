from config import db_config
from Utilities import NetworkxTree, EventTree
import time
import pickle
from collections import Counter
import numpy as np
import re
from bs4 import BeautifulSoup

Agnes = db_config.getDBConn('dev').Agnes
Events_Collection = Agnes.autocrawler_events

def runNXLearning():


    # events = getEvents()
    events = []
    events = getEvents()

    print 'Querying events'
    # for event in cursor:
    #     events.append(event)
    # cursor.close()

    print 'examining events'

    counter = 0.0

    # url = 'https://www.usgbc.org/event/member-orientation-breakfast'
    #
    # event = getEventByUrl(url)
    dist = {}

    for event in events:

        if not validEvent(event):
            continue

        if counter == 100:
            break
        counter += 1

        print counter,'of',100
        print event['url']

        # event_tree = EventTree.EventTree(event['HTML'], event)
        event_tree = pickle.loads(event['netx_tree_pkl'])

        num_nodes = len(event_tree.get_nodes())

        if num_nodes in dist:
            dist[num_nodes].append(event['url'])
        else:
            dist[num_nodes] = [event['url']]

    for item in sorted(dist, key=lambda x: x):
        print item
        print
        for url in dist[item]:
            print url
            print


    print 'Avg Time per parsing', avg_time / counter

def validEvent(event):
    if not 'HTML' in event:
        return False
    if not 'netx_tree_pkl' in event:
        return False
    keys = ['evtname', 'evtdesc', 'location', 'starttime']
    for key in keys:
        if not event[key]:
            return False
    return True

def getTreeRatio(event_tree):

    event_subtrees = getSubTrees(event_tree)

    # target_count = 0.0
    # trash_count = 0.0
    #
    event_subtree = event_subtrees['event']

    name_subtree = event_subtrees['date']

    target_count = len([item for item in event_subtree if item in name_subtree])
    #
    # target_count = event_tree.depth(event_tree.get_event_nodes()['date'])
    #
    # max_depth = 0.0
    # event_node = event_tree.get_event_nodes()['event']
    #
    # for nodeid in event_tree.iterate_from_node(event_node):
    #
    #     node_depth = len(event_tree.node_path(event_node, nodeid))
    #     max_depth = max(node_depth, max_depth)
    #
    # target_count = max_depth

    # trash_count = len(event_subtree) - target_count
    #
    # print event_subtree
    # print name_subtree
    # print target_count
    # print trash_count
    # raise ValueError('stap')

    # print
    # for node in event_subtrees['event']:
    #     if nodeInPart(event_subtrees, node):
    #         target_count += 1
    #     else:
    #         trash_content = event_tree.get_node_data(node)['attr_dict']['totalcontent']
    #         # print trash_content
    #         trash_count += 1
    # print
    # event_tree.print_event_nodes()
    # print
    # event_tree.print_event()
    # print 'Target',target_count
    # print 'Trash',trash_count
    # print 'Ratio',target_count / (target_count+trash_count)
    # raise ValueError('stap')

    return target_count# / (target_count+trash_count)

def getSubTrees(event_tree):
    event_nodes = event_tree.get_event_nodes()
    subtrees = {}
    for part in event_nodes:
        part_node = event_nodes[part]
        subtrees[part] = [child_node for child_node in event_tree.iterate_from_node(part_node)]
        subtrees[part] += [nodeid for nodeid in event_tree.node_path(event_nodes['event'], event_nodes[part]) if not nodeid in subtrees[part]]
    return subtrees


def nodeInPart(subtrees, nodeid):

    for part in subtrees:
        if part == 'event':
            continue
        if nodeid in subtrees[part]:
            return True
    return False

def getEvents():
    # Data_Collection.aggregate([{"$sample": {'size': batch_size}}
    # return Events_Collection.find({}, no_cursor_timeout=True)
    batch_size = 1000
    return Events_Collection.aggregate([{"$sample":{'size': batch_size}}])

def getEventByUrl(page_url):
    return Events_Collection.find_one({'url':page_url})
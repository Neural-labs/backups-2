import { TestBed, ComponentFixture, async, fakeAsync } from '@angular/core/testing';
import { IonicModule } from 'ionic-angular';
import { DebugElement } from '@angular/core';
import { HttpModule } from '@angular/http';
import { By } from '@angular/platform-browser';


import { LoginPage } from '../pages/login/login';

import { FormBuilder } from '@angular/forms';
import { NavController, AlertController, PopoverController, Platform, Events, App, MenuController, IonicPage } from 'ionic-angular';

import { Agnes } from '../app/app.component';

import { LoginService }  from './login.service';
import { MeService } from './me.service';

import { AppMock } from '../mocks';

let comp: LoginPage;
let fixture: ComponentFixture<LoginPage>;
let de: DebugElement;
let el: HTMLElement;
let navCtrl: NavController;

describe('Page: Login Page', () => {

    beforeEach(async(() => {

        TestBed.configureTestingModule({

            declarations: [Agnes, LoginPage],

            providers: [
                // MeService,
                // LoginService,
                NavController,
                // AlertController,
                PopoverController,
                // Platform,
                Events,
                App
                // MenuController
            ],

            imports: [
                HttpModule,
                IonicModule.forRoot(Agnes)
            ]

        }).compileComponents();

    }));

    beforeEach(() => {

        fixture = TestBed.createComponent(LoginPage);
        comp    = fixture.componentInstance;
        navCtrl = TestBed.get(NavController);

    });

    afterEach(() => {
        fixture.destroy();
        comp = null;
    });

    it('is created', () => {

        expect(fixture).toBeTruthy();
        expect(comp).toBeTruthy();

    });

    it('signup button calls toSignup and opens questions page', fakeAsync(() => {
        spyOn(comp, 'toSignup');

        let button = fixture.debugElement.query(By.css('.agnesButton.signup'));
        fixture.detectChanges();
        button.triggerEventHandler('click', true);

        fixture.whenStable().then(() => {
            fixture.detectChanges();
            expect(comp.toSignup).toHaveBeenCalled();
        });
    }));

    it('toSignup sets root to question page', () => {
       fixture.detectChanges();
        spyOn(comp.navCtrl, 'setRoot');

        comp.toSignup(true);
        expect(comp.navCtrl.setRoot).toHaveBeenCalledWith('QuestionsPage', {}, {
            animate: true,
            animation: 'ios-transition',
            direction:'forward',
            duration: 50,
            easing: 'ease-in-right'
        });
    });

});
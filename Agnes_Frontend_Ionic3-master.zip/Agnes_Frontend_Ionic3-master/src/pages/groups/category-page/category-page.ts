import { Component, ViewChild } from '@angular/core';
import { FormControl } from '@angular/forms';
import { Events, IonicPage, App, PopoverController, NavParams, Content, ViewController } from 'ionic-angular';
import { GroupsService } from '../../../providers/groups.service';
import { MeService } from '../../../providers/me.service';
import { AnalyticsService } from '../../../providers/analytics.service';
import { Agnes } from '../../../app/app.component';

@IonicPage()
@Component({
    selector: 'category-page',
    templateUrl: 'category-page.html',
    providers: [ GroupsService, MeService, AnalyticsService ]
})

export class CategoryPage {

    user: Object;
    category: Object;

    popular: Array<Object>;
    mostActive: Array<Object>;
    allGroups: Array<Object>;
    storedAll = [];

    groupSearch: string;
    batchNum: number;
    currentPage: number;

    searchControl: FormControl;

    @ViewChild('content') content: Content;

    constructor(private groupsService: GroupsService,
                private meService: MeService,
                private analyticsService: AnalyticsService,
                private viewCtrl: ViewController,
                public appCtrl: App,
                private navParams: NavParams,
                private events: Events,
                private popoverCtrl: PopoverController){
        this.searchControl = new FormControl();
    }

    //initialize category page
    ngOnInit(){
        this.user = JSON.parse(localStorage.getItem('agnesUser'));
        this.category = this.navParams.get('category');

        this.popular = [];
        this.mostActive = [];
        this.allGroups = [];

        this.groupSearch = '';
        this.batchNum = 0;
        this.currentPage = 0;

        this.getGroups();

        this.events.subscribe('groupDeleted', (group) => {
            this.groupDeleted(group);
        });

        this.events.subscribe('groupSearch', term => {
            this.groupSearch = term;
            this.searchGroups(0);
        });

        //user has edited one of their groups
        this.events.subscribe('groupEdited', group => {
            this.refreshGroups(null);
        });

        //user shared an event to one of his/her groups, refresh group list
        this.events.subscribe('sharedEventToGroup', () => {
            this.refreshGroups(null);
        });

        //user's request to join a group has been accepted - refresh whatever list user is viewing
        this.events.subscribe('reqAcceptedNewMember', () => {
            this.refreshGroups(null);
        });

        //refresh group list when group has been deleted
        this.events.subscribe('groupDeleted',(data) => {
            this.refreshGroups(null);
        });

        //user's request to join a group has been accepted, refresh My Grousp to reflect that user is now part of new group
        this.events.subscribe('reqAcceptedNewMember', () => {
            this.refreshGroups(null);
        });

        //user has created an event hosted by one of user's groups
        this.events.subscribe('eventHosted', data => {
            this.refreshGroups(null);
        });

        this.groupSearch = '';
        //for keeping track of search batches
        this.batchNum = 0;

        //send Group Category Page view analytics
        this.analyticsService.logAnalytics({community: this.user['community'], users_id: this.user['_id']}, '/groupCategoryPageView');

    }

    getGroups(refresher?){
        this.user = JSON.parse(localStorage.getItem('agnesUser'));

        let popularProm = this.groupsService.getMostPopularGroups(
            {'community':this.user['community'], 'topic':this.category['grpname']});
        let activeProm = this.groupsService.getMostActiveGroups(
            {'community':this.user['community'], 'topic':this.category['grpname']});
        let allProm = this.groupsService.getGroupsByCategory(
            {'users_id': this.user["_id"], 'community':this.user['community'], 'topic':this.category['grpname']});

        Promise.all([popularProm,activeProm,allProm]).then(groups => {
            let popular = groups[0];
            let active = groups[1];
            let all = groups[2];

            if(refresher){refresher.complete();}

            if(popular){
                this.popular = popular.map( a => {
                    a['displayURL'] = (a['thumbnail'] == '' || !a['thumbnail'] || !this.isImage(a.thumbnail)
                    || a['thumbnail'].indexOf("'") != -1 ? "assets/img/pattern_" + Math.floor((Math.random() * 15) + 1) + '.png' : a['thumbnail']);
                    return a;
                });
            }

            if(active){
                this.mostActive = active.map( a => {
                    a['displayURL'] = (a['thumbnail'] == '' || !a['thumbnail'] || !this.isImage(a.thumbnail)
                    || a['thumbnail'].indexOf("'") != -1 ? "assets/img/pattern_" + Math.floor((Math.random() * 15) + 1) + '.png' : a['thumbnail']);
                    return a;
                });
            }

            if (all) {
                //filter out secret groups that user is not a member/admin of
                all = all.filter(a => {
                    return a['grptype'] != 'secret' || (a['grptype'] == 'secret' &&
                        (a['admin'].indexOf(this.user['_id']) != -1 ||
                        a['members'].indexOf(this.user['_id']) != -1));
                });
                this.allGroups = all;
            }

        }).catch(err => {
            console.log(err);
            Agnes.showError("Could not get your groups right now - try refreshing!");
            if(refresher){refresher.complete();}
        });
    }

    //check to see if image will load
    isImage(src) {
        let image = new Image();
        let isImage = true;
        image.src = src;
        image.onerror = function() {
            isImage = false;
        };
        image.onload = function() {
            isImage = true;
        };

        return isImage;
    }

    closeCategoryPage(){
        this.viewCtrl.dismiss(null,null,{
            animation: 'ios-transition',
            duration: 350,
            easing: "ease-in-out",
            direction: "back"
        });
    }

    /*************************************************************************************************************/
    /*************************************** main loading functions **********************************************/
    /*************************************************************************************************************/

    //refresh groups list
    refreshGroups(refresher){
        if(!Agnes.network || Agnes.network.type != 'none'){
            this.events.publish('updateUser');
            this.events.subscribe('updateDone',() => {
                this.events.unsubscribe('updateDone');
                this.user = JSON.parse(localStorage.getItem('agnesUser'));

                if(this.groupSearch != '') {
                    this.searchGroups(0, refresher);
                }
                else {
                    this.getGroups(refresher);
                }
            });
        }
        else {
            //lack of internet connection - alert
            Agnes.showError('You are offline! Try refreshing again when you reconnect.');
            refresher.complete();
        }
    }

    //load more events for All Groups list
    loadMoreGroups(infiniteScroll){
        //load more from search term
        if(this.groupSearch != ''){
            this.batchNum += 1;
            this.searchGroups(this.batchNum,infiniteScroll);
        }
        else {
            let data = {
                "community": this.user["community"],
                "users_id": this.user["_id"],
                "page": this.currentPage + 1
            };

            this.groupsService.loadMoreGroups(data).then(moreGroups =>{
                if (moreGroups){
                    if(moreGroups.length == 1){
                        infiniteScroll.enable(false);
                    }
                    else {
                        this.currentPage += 1;
                        this.allGroups = this.allGroups.concat(moreGroups);
                    }
                }
                infiniteScroll.complete();
            }).catch(error => {
                infiniteScroll.complete();
                console.log(error);
            });
        }
    }

    //get user's fb friends for displaying on group cards
    getFriends(){
        let data = {
            "users_id": this.user['_id'],
            "community": this.user['community']
        };

        this.meService.getFriends(data).then(value => {
            if(value.friends && value.friends.length > 0){
                this.user['fbfriends'] = value.friends.filter(a => {return a['_id'] != this.user['_id']}).map(b => {
                    return {['_id']: b['_id'], 'thumbnail': b['thumbnail'] != '' ? b['thumbnail'] : b['picurl']};
                });
            }
            else {
                this.user['fbfriends'] = [];
            }

            this.events.publish('sendFriendsToCard', this.user['fbfriends']);

        }).catch(err => {
            console.log(err);
        });
    }

    //search groups by title or keywords
    searchGroups(batchNum, refresher?){
        //reset search batch number for new searches
        if(batchNum == 0) {this.batchNum = 0;}

        if(this.batchNum == 0) {if(this.content && this.content._scroll){this.content.scrollToTop(0);}}
        if (this.groupSearch && this.groupSearch.trim().length > 0) {
            let data = {"searchTerm":this.groupSearch, "community":this.user["community"], "scroll": batchNum, "users_id": this.user['_id']};
            this.groupsService.searchGroups(data)
                .then(value => {
                    if(value){

                        //filter out secret groups that user is not a member/admin of
                        value = value.filter(a => {
                            return a['grptype'] != 'secret' || (a['grptype'] == 'secret' &&
                                (a['admin'].indexOf(this.user['_id']) != -1 ||
                                a['members'].indexOf(this.user['_id']) != -1));
                        });

                        let more = batchNum != 0;
                        // this.displayGroups(value,more,'search');
                        if(value.length == 0){this.batchNum = 0;}
                    }
                    else{
                        this.allGroups = this.storedAll;
                        this.batchNum = 0;
                    }

                    if(refresher){refresher.complete();}
                })
                .catch(function(error){
                    console.log(error);
                    this.batchNum = 0;
                    if(refresher){refresher.complete();}
                });
        }
        else {
            this.allGroups = this.storedAll;
            this.refreshGroups(null);
            if(this.content._scroll){this.content.scrollToTop(0);}
        }
    }


    /*************************************************************************************************************/
    /********************************** handle data from profile/editing *****************************************/
    /*************************************************************************************************************/

    //group has been edited - update group object in displayed lists to reflect changes
    updateGroup(group){
        let mInd = this.popular.map(function(a){return a['_id'];}).indexOf(group['_id']);
        let aInd = this.mostActive.map(function(a){return a['_id'];}).indexOf(group['_id']);
        let sInd = this.storedAll.map(function(a){return a['_id'];}).indexOf(group['_id']);

        this.popular[mInd] = group;
        this.mostActive[aInd] = group;
        this.storedAll[sInd] = group;
    }

    //delete group - remove from matched/all where applicable
    groupDeleted(group){
        let uInd = this.user['grp'].map(function(a){return a['groups_id']}).indexOf(group['_id']);
        let pInd = this.popular.map(function(a){return a['_id']}).indexOf(group['_id']);
        let mAInd = this.mostActive.map(function(a){return a['_id']}).indexOf(group['_id']);
        let aInd = this.allGroups.map(function(a){return a['_id']}).indexOf(group['_id']);

        if(uInd != -1){this.user['grp'].splice(uInd,1);}
        if(pInd != -1){this.popular.splice(pInd,1);}
        if(mAInd != -1){this.mostActive.splice(mAInd,1);}
        if(aInd != -1){
            this.allGroups.splice(aInd,1);
            this.storedAll = this.allGroups;
        }
    }

    imgError(group){
        group['noPic'] = true;
    }

    openGroupProfile(group){
        this.groupsService.getGroupsFromId({'grp':[group['_id']]}).then(val =>{
            if(val && val.length > 0){
                this.popoverCtrl.create('GroupProfile',{
                    'group':val[0],
                    'type': 'my'
                }, {}).present({
                    animation: 'ios-transition',
                    duration: 350
                });
            }
            else {
                Agnes.showError("Sorry, couldn't open this group profile!");
            }
        }).catch(err => {
            console.log(err);
            Agnes.showError("Sorry, couldn't open this group profile!");
        });
    }

}

from pymongo import MongoClient

def getNewClient():
    return MongoClient('mongodb://arpit:groupten123!@agnesautocrawler-shard-00-00-1mhnx.mongodb.net:27017,agnesautocrawler-shard-00-01-1mhnx.mongodb.net:27017,agnesautocrawler-shard-00-02-1mhnx.mongodb.net:27017/admin?replicaSet=AgnesAutoCrawler-shard-0&ssl=true')
// "use strict";
// var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
//     var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
//     if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
//     else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
//     return c > 3 && r && Object.defineProperty(target, key, r), r;
// };
// var core_1 = require('@angular/core');
// var ionic_angular_1 = require('ionic-angular');
// var app_component_1 = require('../../app/app.component');
// var event_profile_1 = require('./event-profile/event-profile');
// var events_service_1 = require('./events.service');
// var me_service_1 = require('../me/me.service');
// var event_details_1 = require('../popups/event-details/event-details');
// var EventsPage = (function () {
//     function EventsPage(navCtrl, eventService, platform, evts, meService, popoverCtrl) {
//         this.navCtrl = navCtrl;
//         this.eventService = eventService;
//         this.platform = platform;
//         this.evts = evts;
//         this.meService = meService;
//         this.popoverCtrl = popoverCtrl;
//         this.trendingEvents = [];
//         this.allEvents = [];
//         this.storedAll = [];
//         this.navOptions = {
//             animate: true,
//             animation: "ios-transition",
//             direction: "forward",
//             duration: 1000
//         };
//     }
//     //initialize events page
//     EventsPage.prototype.ngOnInit = function () {
//         //GoogleAnalytics.trackView("Events");
//         var _this = this;
//         this.loading = true;
//         this.trendingEvents = [];
//         this.matchedEvents = [];
//         this.allEvents = [];
//         this.eventsType = 'Matched';
//         this.searchOpen = false;
//         this.eventSearch = "";
//         this.searching = false;
//         var t = new Date();
//         this.today = t.toDateString().match(/[a-zA-Z]{3} [a-zA-Z]{3} \d\d/)[0];
//         this.today = this.today.replace(/([a-zA-Z]{3})(\s[a-zA-Z]{3}\s)(\d{2})/, "$1,$2$3");
//         t.setDate(t.getDate() + 1);
//         this.tomorrow = t.toDateString().match(/[a-zA-Z]{3} [a-zA-Z]{3} \d\d/)[0];
//         this.tomorrow = this.tomorrow.replace(/([a-zA-Z]{3})(\s[a-zA-Z]{3}\s)(\d{2})/, "$1,$2$3");
//         this.headerHeight = window.innerHeight / 5;
//         this.filters = ['none'];
//         this.filterDate = '';
//         // ask for location permissions - NOT BEING USED YET
//         // window.setTimeout(() => {
//         //   if (this.platform.is('cordova')){
//         //     Diagnostic.getLocationAuthorizationStatus().then(value => {
//         //       console.log('get auth status',value);
//         //       if (value == Diagnostic.permissionStatus.NOT_REQUESTED || value == 'not determined') {
//         //         let location = this.popoverCtrl.create(LocationServices,{},{'enableBackdropDismiss':true});
//         //         location.present(
//         //           {
//         //             animate: false
//         //           }
//         //         );
//         //       }
//         //     }).catch(err => console.log("can't get location auth status", err));
//         //   }
//         // },1000);
//         this.evts.subscribe('pushEvent', function (data) {
//             _this.pushAddedEvent(data, false);
//         });
//         this.evts.subscribe('resumeApp', function () {
//             if (localStorage.getItem('agnesUser')) {
//                 _this.getMatchedEvents(null);
//             }
//         });
//         this.evts.subscribe('goingDone', function (event) {
//             var ind = _this.user['evtrsvp'].indexOf(event['_id']);
//             if (ind == -1) {
//                 _this.user['evtrsvp'].push(event['_id']);
//             }
//         });
//         this.evts.subscribe('notGoingDone', function (event) {
//             var ind = _this.user['evtrsvp'].indexOf(event['_id']);
//             if (ind != -1) {
//                 _this.user['evtrsvp'].splice(ind, 1);
//             }
//         });
//         this.evts.subscribe('eventDeleted', function (data) {
//             _this.eventDeleted(data.event);
//         });
//         this.user = JSON.parse(localStorage.getItem("agnesUser"));
//         this.initEvents();
//     };
//     //make sure chat bubble is shown on this page
//     EventsPage.prototype.ionViewWillEnter = function () {
//         this.evts.publish('showChat', true);
//     };
//     //save matched events in local storage when exiting page
//     //in case something was changed (i.e. event attended, deleted, created, edited, etc.)
//     EventsPage.prototype.ionViewWillLeave = function () {
//         localStorage.setItem('agnesMatchedEvents', JSON.stringify(this.matchedDates));
//     };
//     //initialize events
//     EventsPage.prototype.initEvents = function () {
//         this.loading = true;
//         if (!app_component_1.Agnes.network || app_component_1.Agnes.network.type != 'none') {
//             this.noInternet = false;
//             this.getTrendingEvents();
//             this.getMatchedEvents(null);
//             this.getAllEvents(null);
//         }
//         else {
//             //lack of internet connection - show Tap to Refresh div
//             this.noInternet = true;
//             this.loading = false;
//         }
//     };
//     EventsPage.prototype.ngOnDestroy = function () {
//         this.evts.unsubscribe('pushEvent');
//     };
//     //return text version of HTML titles (i.e. &amp;Pizza --> &Pizza)
//     // getText(html): string {
//     //   console.log('in get text: html',html);
//     //   if(html){
//     //     return (new DOMParser).parseFromString(html, "text/html") .
//     //       documentElement . textContent;
//     //   }
//     //   else {
//     //     return null;
//     //   }
//     // }
//     //get trending events for user's community
//     EventsPage.prototype.getTrendingEvents = function () {
//         var _this = this;
//         this.eventService.getTrendingEvents(this.user["_id"])
//             .then(function (trending) { return _this.processTrending(trending); })
//             .catch(function (error) {
//             _this.getTrendingEvents();
//             console.log(error);
//         });
//     };
//     //process trending events (displayed differently than matched/all/searched)
//     EventsPage.prototype.processTrending = function (events) {
//         for (var v in events) {
//             if (typeof (events[v]) == 'object' && events[v] != null) {
//                 if (events[v]['picurl'] == '' || events[v]['thumbnail'] == '') {
//                     events[v]['thumbnail'] = "assets/img/pattern_" + Math.floor((Math.random() * 15) + 1) + '.png';
//                 }
//                 var eVar = {
//                     event: events[v],
//                     featuredText: (events[v]['featured'] ? 'Featured' : 'Trending Now')
//                 };
//                 this.trendingEvents.push(eVar);
//             }
//         }
//     };
//     //get user's matched events
//     EventsPage.prototype.getMatchedEvents = function (refresher) {
//         var _this = this;
//         var stored = JSON.parse(localStorage.getItem('agnesMatchedEvents'));
//         var t = new Date(JSON.parse(localStorage.getItem('agnesEventsTimeout')));
//         var timeout = new Date(t.setHours(t.getHours() + 12));
//         var now = new Date();
//         if (!stored || (now > timeout)) {
//             this.eventService.getMatchedEvents(this.user["_id"])
//                 .then(function (matched) {
//                 if (refresher) {
//                     refresher.complete();
//                 }
//                 _this.matchedEvents = matched;
//                 _this.numMatched = matched['length'];
//                 _this.processEvents(matched, false, 'matched');
//             })
//                 .catch(function (error) {
//                 _this.loading = false;
//                 if (error == 'timeout') {
//                     _this.noInternet = true;
//                 }
//                 _this.getMatchedEvents(refresher);
//                 console.log(error);
//             });
//         }
//         else {
//             this.loading = false;
//             this.matchedDates = stored;
//         }
//     };
//     //get all events in the user's community
//     EventsPage.prototype.getAllEvents = function (refresher) {
//         var _this = this;
//         this.eventService.loadAllEvents(this.user['_id'], this.user['community'])
//             .then(function (allEvents) {
//             _this.processEvents(allEvents, false, 'all');
//             if (refresher) {
//                 refresher.complete();
//             }
//         })
//             .catch(function (error) {
//             _this.loading = false;
//             console.log(error);
//             _this.getAllEvents(refresher);
//         });
//     };
//     //process all/matched/searched events for display purposes
//     EventsPage.prototype.processEvents = function (events, loadingMore, eventType) {
//         events = events.filter(function (a) { return (a != null); });
//         var type = (eventType == 'matched') ? 'matched' : 'all';
//         if (!loadingMore) {
//             this[type + 'Events'] = [];
//         }
//         for (var v in events) {
//             if (events[v] && typeof (events[v]) == 'object') {
//                 if (this[type + 'Events'].map(function (a) { return a["_id"]; }).indexOf(events[v]["_id"]) == -1) {
//                     this[type + 'Events'].push(events[v]);
//                 }
//             }
//         }
//         this.displayEvents(loadingMore, eventType);
//     };
//     //display events in respective arrays
//     EventsPage.prototype.displayEvents = function (loadingMore, eventType) {
//         var type = (eventType == 'matched') ? 'matched' : 'all';
//         if (!loadingMore) {
//             this[type + 'Dates'] = [];
//         }
//         var id = loadingMore ? this[type + 'Dates'].length : 0;
//         // let end = eventType == 'matched' ? 3 : this[type+'Events'].length;
//         //make dictionary of {date: [events]}
//         for (var ind = 0; ind < this[type + 'Events'].length; ind++) {
//             if (this[type + 'Events'][ind] != null && typeof (this[type + 'Events'][ind]) == 'object') {
//                 var event_1 = this[type + 'Events'][ind];
//                 // event["evtname"] = this.getText(event["evtname"]);
//                 event_1["starttime"] = event_1["starttime"].replace(/[-\+]\d\d\d\d/, 'Z');
//                 var start = app_component_1.Agnes.processGMT(event_1['starttime']);
//                 var date = (start.date == this.today) ? "TODAY" : (start.date == this.tomorrow) ? "TOMORROW" : start.date;
//                 var time = (start.time == "12:01AM") ? "TBA" : start.time;
//                 var dInd = this[type + 'Dates'].map(function (a) { return a["date"]; }).indexOf(date);
//                 //default to pattern defaults in assets folder if no image
//                 event_1['displayURL'] = (event_1['picurl'] == '')
//                     ? "assets/img/pattern_" + Math.floor((Math.random() * 15) + 1) + '.png' : event_1['picurl'];
//                 //date doesn't exist yet
//                 if (dInd == -1) {
//                     var item = {
//                         "id": id,
//                         "date": date,
//                         "events": [{
//                                 "time": time,
//                                 "event": event_1
//                             }],
//                         "ISOdate": event_1["starttime"]
//                     };
//                     this[type + 'Dates'].push(item);
//                     id++;
//                 }
//                 else {
//                     //date does exist but event doesn't
//                     var eInd = this[type + 'Dates'][dInd]["events"].map(function (a) { return a.event._id; }).indexOf(event_1["_id"]);
//                     if (eInd == -1) {
//                         var ev = {
//                             "time": time,
//                             "event": event_1
//                         };
//                         this[type + 'Dates'][dInd]["events"].push(ev);
//                     }
//                 }
//             }
//         }
//         this[type + 'Dates'].sort(function (a, b) {
//             var aDate = +new Date(a["ISOdate"]);
//             var bDate = +new Date(b["ISOdate"]);
//             return aDate - bDate;
//         });
//         // for (var d in this[type+'Dates']) {
//         //   this[type+'Dates'][d]["events"].sort(function(a,b){
//         //     let x = new Date(a.event.starttime.replace(/[-\+]\d\d\d\d/,'Z')).getTime();
//         //     let y = new Date(b.event.starttime.replace(/[-\+]\d\d\d\d/,'Z')).getTime();
//         //     return x - y;
//         //   });
//         // }
//         if (eventType == 'all') {
//             this.storedAll = this['allDates'];
//         }
//         else {
//             if (eventType == 'matched') {
//                 localStorage.setItem('agnesMatchedEvents', JSON.stringify(this.matchedDates));
//                 localStorage.setItem('agnesEventsTimeout', JSON.stringify(new Date()));
//             }
//             this.loading = false;
//         }
//     };
//     //open event profile (for deep linking and trending events)
//     EventsPage.prototype.openEventProfile = function (event, type) {
//         var _this = this;
//         if (window['fabric']) {
//             window['fabric'].Answers.sendCustomEvent('Events', { type: 'to ' + type + ' profile' });
//         }
//         this.evts.subscribe('eventProfileData', function (data) {
//             if (data.category == 'going') {
//                 _this.user = data.user;
//             }
//             else if (data.category == 'edit' || data.category == 'delete') {
//                 localStorage.removeItem('agnesMatchedEvents');
//                 localStorage.removeItem('agnesEventsTimeout');
//                 _this.getMatchedEvents(null);
//                 _this.getAllEvents(null);
//                 _this.getTrendingEvents();
//             }
//             _this.evts.unsubscribe('eventProfileData');
//         });
//         this.navCtrl.push(event_profile_1.EventProfile, {
//             'event': event.event,
//             'user': this.user,
//             'type': type
//         }, {
//             animation: 'ios-transition',
//             duration: 350
//         });
//     };
//     //delete event from matched list
//     EventsPage.prototype.eventDeleted = function (event) {
//         var start = app_component_1.Agnes.processGMT(event['starttime'].replace(/[-\+]\d\d\d\d/, 'Z'));
//         var date = (start.date == this.today) ? "TODAY" : (start.date == this.tomorrow) ? "TOMORROW" : start.date;
//         var dInd = this.matchedDates.map(function (a) { return a["date"]; }).indexOf(date);
//         if (dInd != -1) {
//             var events = this.matchedDates[dInd]["events"].map(function (a) { return a.event._id; });
//             var eInd = events.indexOf(event._id);
//             //remove event from date's event array
//             this.matchedDates[dInd]["events"].splice(eInd, 1);
//             //remove date from dates array if no events left
//             if (this.matchedDates[dInd]["events"].length == 0) {
//                 this.matchedDates.splice(dInd, 1);
//             }
//         }
//         // track event rejection
//         // if (this.platform.is('mobile') && (this.platform.is('ios') || this.platform.is('android') || this.platform.is('windows'))) {
//         //   if (analytics && typeof analytics !== undefined) {
//         //     var date = new Date(event.starttime);
//         //     var time = date.getHours() + ":" + date.getMinutes();
//         //     analytics.trackEvent("Event", "Event rejected time", time);
//         //     analytics.trackEvent("Event", "Event rejected", event._id + ' ' + event.evtname);
//         //   }
//         //   else {
//         //     console.log("google analytics not set");
//         //   }
//         // }
//         //reset local storage
//         localStorage.setItem('agnesMatchedEvents', JSON.stringify(this.matchedDates));
//     };
//     //load more events on infinite scroll
//     EventsPage.prototype.loadMoreEvents = function (infiniteScroll) {
//         var _this = this;
//         if (this.eventsType == 'All') {
//             if (this.allDates && this.allDates.length > 0) {
//                 var lastDate = this.allDates.length - 1;
//                 var eventLength = this.allDates[lastDate]["events"].length;
//                 var lastEvent = this.allDates[lastDate]["events"][eventLength - 1];
//                 var lastTime = lastEvent.event.starttime;
//                 var lastId = lastEvent.event._id;
//                 var data = { "starttime": lastTime, "community": this.user["community"], "_id": lastId };
//                 this.eventService.getMoreEvents(data)
//                     .then(function (moreEvents) { return _this.processInfinite(moreEvents, infiniteScroll); })
//                     .catch(function (error) { console.log(error); });
//             }
//         }
//         else {
//             if (infiniteScroll) {
//                 infiniteScroll.complete();
//             }
//         }
//     };
//     //process events from loadMoreEvents promise
//     EventsPage.prototype.processInfinite = function (moreEvents, infiniteScroll) {
//         if (infiniteScroll) {
//             infiniteScroll.complete();
//         }
//         if (moreEvents && moreEvents.length > 0) {
//             this.processEvents(moreEvents, true, 'all');
//         }
//         else {
//             if (infiniteScroll) {
//                 infiniteScroll.enable(false);
//             }
//         }
//     };
//     //open search bar
//     EventsPage.prototype.showSearch = function () {
//         var _this = this;
//         if (window['fabric']) {
//             window['fabric'].Answers.sendSearch('events');
//         }
//         this.searchOpen = true;
//         setTimeout(function () {
//             _this.eventSearchInput.setFocus();
//         }, 100);
//     };
//     //close search bar
//     EventsPage.prototype.closeSearch = function () {
//         this.searchOpen = false;
//         this.allDates = this.storedAll;
//         this.eventSearch = "";
//         this.searching = false;
//         app_component_1.Agnes.keyboard.close();
//         this.filters = ['none'];
//         this.filterDate = '';
//         this.eventsContent.scrollToTop(0);
//     };
//     //select search filters
//     EventsPage.prototype.changeFilters = function (type) {
//         var _this = this;
//         this.eventsContent.scrollToTop(0);
//         if (type == 'none') {
//             this.filters = ['none'];
//             this.filterDate = '';
//             this.allDates = this.storedAll;
//             this.eventsContent.scrollToTop(0);
//             if (this.eventSearch.trim() == '') {
//                 this.searching = false;
//             }
//         }
//         else {
//             //if any other filter, 'No Filter' should no longer be selected
//             var n = this.filters.indexOf('none');
//             if (n != -1) {
//                 this.filters.splice(n, 1);
//             }
//             var ind = this.filters.indexOf(type);
//             if (type == 'food') {
//                 if (ind == -1) {
//                     //tracking
//                     if (window['fabric']) {
//                         window['fabric'].Answers.sendCustomEvent('Events', { type: 'free food filter' });
//                     }
//                     this.searching = true;
//                     this.filters.push(type);
//                     this.eventService.searchEvents({ "searchTerm": 'freefood', "community": this.user["community"] })
//                         .then(function (value) {
//                         _this.freeFood = value;
//                         _this.processEvents(value, false, 'search');
//                     })
//                         .catch(function (error) {
//                         console.log(error);
//                     });
//                 }
//                 else {
//                     this.filters.splice(ind, 1);
//                     var date = new Date(this.filterDate);
//                     this.eventsByDate(date);
//                 }
//             }
//             else if (type == 'date') {
//                 if (ind == -1) {
//                     //tracking
//                     if (window['fabric']) {
//                         window['fabric'].Answers.sendCustomEvent('Events', { type: 'date filter' });
//                     }
//                     this.filters.push(type);
//                 }
//                 var now = new Date();
//                 var d = this.filterDate == '' ? now : this.filterDate;
//                 app_component_1.Agnes.datePicker.show({
//                     date: d,
//                     mode: 'date',
//                     minDate: now,
//                     androidTheme: app_component_1.Agnes.datePicker.ANDROID_THEMES.THEME_DEVICE_DEFAULT_DARK,
//                     allowOldDates: false
//                 }).then(function (date) {
//                     if (date) {
//                         console.log(date);
//                         // let fd = date.toLocaleDateString();
//                         _this.filterDate = '';
//                         //date is only filter selected - get events by date
//                         if (_this.filters.length == 1 && _this.eventSearch.trim() == '') {
//                             _this.eventsByDate(date);
//                         }
//                     }
//                     else {
//                         if (_this.filterDate == '') {
//                             _this.filters.splice(_this.filters.indexOf('date'), 1);
//                             if (_this.filters.length == 0) {
//                                 _this.changeFilters('none');
//                             }
//                         }
//                     }
//                 }, function (err) { return console.log('Error occurred while getting date: ', err); });
//             }
//             //if no filters have been selected, reselect 'No Filter'
//             if (this.filters.length == 0) {
//                 this.filters = ['none'];
//                 this.filterDate = '';
//             }
//         }
//     };
//     EventsPage.prototype.eventsByDate = function (date) {
//         var _this = this;
//         var data = {
//             'users_id': this.user['_id'],
//             'starttime': date.toISOString()
//         };
//         this.eventService.eventsByDate(data).then(function (value) {
//             _this.processEvents(value, false, 'search');
//         }).catch(function (err) {
//             console.log('eBD err', err);
//             app_component_1.Agnes.showError('Couldn\'t get events by date - try again!');
//         });
//     };
//     EventsPage.prototype.hasFreeFood = function (event) {
//         if (this.filters.indexOf('food') != -1) {
//             return (this.freeFood.map(function (a) { return a['_id']; }).indexOf(event['_id']) != -1);
//         }
//         else {
//             return true;
//         }
//     };
//     EventsPage.prototype.matchesDate = function (date) {
//         if (this.filterDate == '') {
//             return true;
//         }
//         else {
//             var d = new Date(date['ISOdate']).toLocaleDateString();
//             return d == this.filterDate;
//         }
//     };
//     //search events by title
//     EventsPage.prototype.searchEvents = function (refresher) {
//         var _this = this;
//         if (this.eventSearch && this.eventSearch.trim().length > 0) {
//             var data = { "searchTerm": this.eventSearch, "community": this.user["community"] };
//             this.searching = true;
//             this.eventService.searchEvents(data)
//                 .then(function (value) {
//                 if (refresher) {
//                     refresher.complete();
//                 }
//                 _this.processEvents(value, false, 'search');
//             })
//                 .catch(function (error) {
//                 console.log(error);
//                 if (refresher) {
//                     refresher.complete();
//                 }
//             });
//         }
//         else {
//             if (refresher) {
//                 refresher.complete();
//             }
//             this.allDates = this.storedAll;
//             this.searching = false;
//         }
//     };
//     //add a new event
//     EventsPage.prototype.addEvent = function () {
//         var _this = this;
//         if (window['fabric']) {
//             window['fabric'].Answers.sendCustomEvent('Events', { type: 'create event' });
//         }
//         var addEvent = this.popoverCtrl.create(event_details_1.EventDetails, {
//             'type': 'Add',
//             'user': this.user,
//             'platform': this.platform
//         }, { 'enableBackdropDismiss': true });
//         addEvent.present({
//             animate: true,
//             animation: 'ios-transition',
//             duration: 500,
//             easing: "ease-in-out",
//             direction: "right"
//         });
//         addEvent.onDidDismiss(function (event) {
//             if (event) {
//                 var addToAll = (event['evttype'] == 'public');
//                 _this.pushAddedEvent(event, addToAll);
//                 app_component_1.Agnes.addToCalendar(event, false);
//                 _this.user['evtrsvp'].push(event['_id']);
//                 _this.evts.publish('updateUser', { 'user': _this.user, 'showChat': _this.user['canChat'] });
//             }
//         });
//     };
//     //swipe right on an event
//     EventsPage.prototype.going = function (card, event, matched) {
//         if (card) {
//             card.close();
//         }
//         app_component_1.Agnes.going(event, matched);
//         //tracking
//         if (window['fabric']) {
//             window['fabric'].Answers.sendCustomEvent('Events', { type: 'add ' + (matched ? 'matched' : 'all') + ' event to cal' });
//         }
//     };
//     //add created event to matched list
//     EventsPage.prototype.pushAddedEvent = function (event, addToAll) {
//         // event["evtname"] = this.getText(event["evtname"]);
//         event["starttime"] = event["starttime"].replace(/[-\+]\d\d\d\d/, 'Z');
//         event['displayURL'] = event['picurl'] == ''
//             ? "assets/img/pattern_" + Math.floor((Math.random() * 15) + 1) + '.png' : event['picurl'];
//         var start = app_component_1.Agnes.processGMT(event['starttime']);
//         var date = (start.date == this.today) ? "TODAY" : (start.date == this.tomorrow) ? "TOMORROW" : start.date;
//         var time = start.time;
//         var dInd = this['matchedDates'].map(function (a) { return a["date"]; }).indexOf(date);
//         //date doesn't exist yet
//         if (dInd == -1) {
//             var openDate = {
//                 "date": date,
//                 "events": [{
//                         "time": time,
//                         "event": event
//                     }],
//                 "ISOdate": event["starttime"]
//             };
//             this['matchedDates'].push(openDate);
//         }
//         else {
//             //date does exist but event doesn't
//             this['matchedDates'][dInd]["events"].push({
//                 "time": time,
//                 "event": event
//             });
//         }
//         this['matchedDates'].sort(function (a, b) {
//             var aDate = +new Date(a["ISOdate"]);
//             var bDate = +new Date(b["ISOdate"]);
//             return aDate - bDate;
//         });
//         for (var d in this['matchedDates']) {
//             this['matchedDates'][d]["events"].sort(function (a, b) {
//                 var x = new Date(a.event.starttime.replace(/[-\+]\d\d\d\d/, "Z")).getTime();
//                 var y = new Date(b.event.starttime.replace(/[-\+]\d\d\d\d/, "Z")).getTime();
//                 return x - y;
//             });
//         }
//         if (addToAll) {
//             dInd = this.allDates.map(function (a) { return a["date"]; }).indexOf(date);
//             //date doesn't exist yet
//             if (dInd == -1) {
//                 this.allDates.push({
//                     "date": date,
//                     "events": [{
//                             "time": time,
//                             "event": event
//                         }],
//                     "ISOdate": event["starttime"]
//                 });
//             }
//             else {
//                 //date does exist but event doesn't
//                 this.allDates[dInd]["events"].push({
//                     "time": time,
//                     "event": event
//                 });
//             }
//             this.allDates.sort(function (a, b) {
//                 var aDate = +new Date(a["ISOdate"]);
//                 var bDate = +new Date(b["ISOdate"]);
//                 return aDate - bDate;
//             });
//             for (var d in this.allDates) {
//                 this.allDates[d]["events"].sort(function (a, b) {
//                     var x = new Date(a.event.starttime.replace(/[-\+]\d\d\d\d/, "Z")).getTime();
//                     var y = new Date(b.event.starttime.replace(/[-\+]\d\d\d\d/, "Z")).getTime();
//                     return x - y;
//                 });
//             }
//         }
//         localStorage.setItem('agnesMatchedEvents', JSON.stringify(this.matchedDates));
//         this.openEventProfile({ 'event': event }, 'matched');
//     };
//     //swipe left on Matched list
//     EventsPage.prototype.nope = function (card, event, matched) {
//         if (card) {
//             card.close();
//         }
//         app_component_1.Agnes.notGoing(event, matched);
//         //tracking
//         if (window['fabric']) {
//             var action = (this.user['evtrsvp'].indexOf(event['_id']) == -1) ? 'remove' : 'unattend';
//             window['fabric'].Answers.sendCustomEvent('Events', { type: action + ' matched event' });
//         }
//     };
//     EventsPage.prototype.refreshEvents = function (refresher) {
//         if (this.eventsType == 'Matched') {
//             localStorage.removeItem('agnesMatchedEvents');
//             localStorage.removeItem('agnesEventsTimeout');
//             this.getMatchedEvents(refresher);
//         }
//         else {
//             if (this.searching) {
//                 this.searchEvents(refresher);
//             }
//             else {
//                 this.getAllEvents(refresher);
//             }
//         }
//     };
//     EventsPage.prototype.dateForward = function (last, id) {
//         this.scrollToNextDate(id);
//     };
//     EventsPage.prototype.scrollToNextDate = function (id) {
//         var elem = document.querySelector('#allEvents' + id);
//         var h = elem.clientHeight;
//         var offset = elem.getBoundingClientRect().top;
//         this.eventsContent.scrollTo(0, this.eventsContent.scrollTop + h + offset - this.headerHeight);
//     };
//     EventsPage.prototype.dateBack = function (id) {
//         var elem = document.querySelector('#allEvents' + (id - 1));
//         var h = elem.clientHeight;
//         var offset = document.querySelector('#allEvents' + id).getBoundingClientRect().top;
//         this.eventsContent.scrollTo(0, this.eventsContent.scrollTop - h + offset - this.headerHeight);
//     };
//     EventsPage.prototype.keepKeyboard = function (event) {
//         if (!this.shouldBlur || event.relatedTarget || this.reset) {
//             event.target.focus();
//             // Reset so other elements will blur the keyboard
//             this.shouldBlur = true;
//             this.reset = !this.reset;
//         }
//         else {
//             if (this.eventSearch.trim() != '') {
//                 var data = {
//                     'users_id': this.user['_id'],
//                     'keyword': this.eventSearch.trim(),
//                     'source': 'events'
//                 };
//                 this.meService.logSearch(data).then(function (val) {
//                 }).catch(function (err) {
//                 });
//             }
//         }
//     };
//     EventsPage.prototype.resetBlur = function () {
//         this.reset = true;
//     };
//     EventsPage.prototype.flipBlur = function () {
//         this.shouldBlur = false;
//         this.reset = false;
//     };
//     EventsPage.prototype.scrollTop = function () {
//         if (window['fabric']) {
//             window['fabric'].Answers.sendCustomEvent('Events', { 'type': 'toggle to ' + this.eventsType });
//         }
//         this.eventsContent.scrollToTop(0);
//     };
//     EventsPage.prototype.toggleMenu = function () {
//         if (window['fabric']) {
//             window['fabric'].Answers.sendCustomEvent('Events', { type: 'open sidebar' });
//         }
//         this.evts.publish('refreshThumb');
//     };
//     EventsPage.prototype.continueAutoplay = function () {
//         this.trendingSlides.startAutoplay();
//     };
//     __decorate([
//         core_1.ViewChild(ionic_angular_1.Content)
//     ], EventsPage.prototype, "eventsContent", void 0);
//     __decorate([
//         core_1.ViewChild(ionic_angular_1.Segment)
//     ], EventsPage.prototype, "eventsSegment", void 0);
//     __decorate([
//         core_1.ViewChild('trendingSlides')
//     ], EventsPage.prototype, "trendingSlides", void 0);
//     __decorate([
//         core_1.ViewChild('eventSearchInput')
//     ], EventsPage.prototype, "eventSearchInput", void 0);
//     EventsPage = __decorate([
//         ionic_angular_1.IonicPage(),
//         core_1.Component({
//             selector: 'page-events',
//             templateUrl: 'events.html',
//             providers: [events_service_1.EventsService, me_service_1.MeService]
//         })
//     ], EventsPage);
//     return EventsPage;
// }());
// exports.EventsPage = EventsPage;

import { Component } from '@angular/core';
import { NavController, PopoverController, Platform, Events, IonicPage, App } from 'ionic-angular';
import { FormBuilder, Validators, FormGroup } from '@angular/forms';
import { PasswordPopup } from '../popups/password-popup/password-popup';
import { Agnes } from '../../app/app.component';
import { LoginService }  from '../../providers/login.service';

@IonicPage()
@Component({
  selector: 'login',
  templateUrl: 'login.html',
  providers: [LoginService]
})

export class LoginPage {

  loading: boolean;
  user: Object;
  platform: Platform;
  loggingIn: boolean;
  loginForm: FormGroup;
  hasError: boolean;
  credErrorText: string;

  constructor(public navCtrl: NavController,
              private loginService: LoginService,
              private popoverCtrl: PopoverController,
              private appCtrl: App,
              platform: Platform,
              private formBuilder: FormBuilder,
              public events: Events) {
    this.platform = platform;

    //initialize login form
    this.loginForm = this.formBuilder.group({
      email: ['', [Validators.required, Validators.pattern('.+@.+[.].{2,3}')]],
      password: ['', [Validators.minLength(7),Validators.required]]
    });
  }

  //initialize events page
  ionViewWillEnter() {
    this.loggingIn = false;
    this.loading = false;
    this.hasError = false;
    this.credErrorText = '';
    if(Agnes.facebook) {Agnes.facebook.browserInit(1743082792636380, "2.6");}
    this.autoLogin();
  }

  //navigate to signup page aka questions page
  toSignup(fromButton, data?){
    data = data ? data : {};

    this.navCtrl.setRoot('QuestionsPage',data,{
      animate: true,
      animation: 'ios-transition',
      direction:'forward',
      duration: 50,
      easing: 'ease-in-right'
    });
  }

  showLoginButtons(show) {
    this.loggingIn = show;
    this.hasError = false;
  }

  facebookLogin(){
    if(this.platform.is('cordova')){

      this.loading = true;
      Agnes.facebook.getLoginStatus().then(value => {

        if(value && value['status']) {
          if (value['status'] == 'not_authorized') {
            Agnes.showError('Please allow Agnes to access your Facebook account before logging in');
            this.loading = false;
          }
          else {
            let permissions = ['public_profile',
              'user_friends',
              'email',
              'user_birthday',
              'user_managed_groups',
              'user_likes',
              'pages_show_list',
              'user_events'];

            Agnes.facebook.login(permissions).then(value => {
              if (value && value['status'] == 'connected') {
                let accessToken = value['authResponse']['accessToken'];

                //if user does not exist, add new user to database
                //if user does exist, just head to events page after clicking login button

                Agnes.facebook.api('/me?fields=email,id,first_name,last_name,picture.width(800).height(800),cover.width(1200).height(1200)',[]).then(result => {
                  let fbid = result['email'];
                  let  providerid = result['id'];
                  let fname = result['first_name'];
                  let lname = result['last_name'];
                  let picture = result['picture'];
                  let cover = result['cover'];
                  let user = {
                    "fbid": fbid,
                    "access_token": accessToken
                  };

                  //check for user in database
                  this.loginService.fbLogin(user).then(value => {

                    //user exists, database has returned user object
                    if (value) {
                      this.loginFromFB(value);
                    }
                    else {
                      this.loading = false;
                      let fbDataForSignup = {
                        skipAccount:true,
                        fromFB: true,
                        fbData: {
                          email:{
                            fbid:fbid,
                            uid:''
                          },
                          fname: fname,
                          lname: lname,
                          picture: picture,
                          cover: cover,
                          providerFBData: {
                            providerId: providerid,
                            OAuthToken: accessToken
                          }
                        }
                      };

                      this.toSignup(false, fbDataForSignup)
                    }
                  }).catch(error=> {
                    localStorage.removeItem("fbAccessToken");
                    Agnes.showError('Facebook session has expired, please log in again');
                    this.loading = false;
                  });
                }).catch(error => {
                  Agnes.showError('Could not log in through Facebook - please try again');
                  this.loading = false;
                });
              }
              else {
                Agnes.showError('Could not log in through Facebook - please try again!');
                this.loading = false;
              }
            }).catch(error => {
              Agnes.showError('Could not log in through Facebook - please try again!');
              this.loading = false; });
          }
        }
      }).catch(error => {
        this.loading = false;
        Agnes.showError('Could not log in through Facebook - please try again!');
      });
    }
  }

  loginFromFB(value){
    this.loading = false;
    localStorage.setItem("agnesToken", value['token']);
    localStorage.setItem("agnesUser", JSON.stringify(value));

    //url will be in format http://agnes.io/TYPE/ID
    //i.e. http://agnes.io/event/eventsid123456789
    let url = localStorage.getItem("external_load");
    let urlArr = url ?  url.substring(8, url.length).split('/') : '';
    let type = url ? urlArr[0] : '';

    if (value['activated']) {

      // if user is logged in and has finished questions, go straight to events page
      if (value['question']) {
        this.events.publish('updateUser');
        this.events.publish('updateDeviceId',{'id':value['_id']});
        this.events.publish('loggedIn');
        this.navCtrl.setRoot('TabsPage');
      }
      //user has not finished questions - go to questions page
      else {
        if (url){
          Agnes.showError("Answer a few quick questions to finish signing up and view the " + type + " shared with you!");
        }
        this.toSignup(false, {fromFB:true});
      }
    }
    //user isn't activated, make user log in
    else {
      Agnes.showError('Please activate your account before logging in.');
      localStorage.removeItem("agnesUser");
    }
  }

  autoLogin(){
    this.loading = true;
    let user = JSON.parse(localStorage.getItem("agnesUser"));

    if (user) {
      if(!Agnes.network || Agnes.network.type != 'none'){
        //get updated user info
        this.loginService.lastLogin({"users_id":user._id}).then(user => {

          this.loading = false;
          if(user){
            localStorage.setItem('agnesToken', user['token']);

            //check to see if user has verified email
            if(user["activated"]){

              console.log(user)

              localStorage.setItem("agnesUser",JSON.stringify(user));
              // if user is logged in and has finished questions, go straight to events page

              if (user["question"] && !user["groupStatus"]){

                this.navCtrl.setRoot('TabsPage').then(val => {
                  this.events.publish('loggedIn');
                  this.events.publish('updateUser');
                  this.events.publish('updateDeviceId',{'id':user['_id']});
                  this.events.publish('loginUpdateBadge');
                  this.user = user;
                }).catch(err => {
                  console.log('cannot set root to Events', err);
                });
              }
              else if (user["groupStatus"]) {
                this.appCtrl.getRootNav().push(
                    'QuestionsPage',
                    {
                      'user' : user,
                      'currSlide' : 1
                    }, {
                      animation: 'ios-transition',
                      duration: 350
                    });
              }
          }
            else {
              Agnes.showError('Please activate your account before logging in.');
              localStorage.removeItem("agnesUser");
              this.loading = false;
            }
          }
        }).catch(err => {
          this.loading = false;
        });
      }
      else {

        //lack of internet connection - load user and go to events if user
        this.navCtrl.setRoot('TabsPage').then(()=> {
          Agnes.showError('You are offline! Some features may not be available or up to date until you reconnect.');
        }).catch(err => {
          console.log('cannot set root to Events', err);
        });
        this.events.publish('loggedIn');
        this.user = user;
      }
    }
    else {
      this.loading = false;
    }
  }

  //submit login credentials
  login(){
    if(Agnes.keyboard) {Agnes.keyboard.close();}

    let credError = document.getElementById('credentialError');

    if (this.loginForm.valid) {

      //hide error
      this.hasError = false;

      let data = {
        'email': this.loginForm.value["email"],
        'password': this.loginForm.value["password"]
      };

      this.loading = true;

      this.loginService.login(data)
          .then(value => {

            this.loading = false;
            if (value == "2" || value == "0" || value == "3"){
              // let errorMessage = "";
              if (value == "2") {
                this.credErrorText = "Your email or password is incorrect";
              }
              else if (value == "0"){
                this.credErrorText = "Agnes does not have your email on file - try signing up instead!";
              }
              else if (value == "3"){
                this.credErrorText = "Please activate your account before logging in!";
              }

              this.hasError = true;
            }
            else if (value !== null && typeof value === 'object') {
              console.log(value);
              localStorage.setItem("agnesToken", value["token"]);
              localStorage.setItem("agnesUser", JSON.stringify(value));

              //trigger push notification registration
              this.events.publish('updateDeviceId',{'id':value['_id']});

              if(value["groupStatus"]) {

                this.loginService.verifyCommunity({'email' : value['email']['uid']}).then(val => {
                  if(val['verify_community']['active']) {
                    //TODO: Need to navigate to second slide of questions
                    this.appCtrl.getRootNav().push(
                        'QuestionsPage',
                        {
                          'user' : value,
                          'currSlide' : 1
                        }, {
                          animation: 'ios-transition',
                          duration: 350
                        });

                  } else {
                  this.appCtrl.getRootNav().push(
                      'NoCommunityPage',
                      {
                        'user' : value
                      }, {
                        animation: 'ios-transition',
                        duration: 350
                      });
                  }
                }).catch(err => {
                  console.log(err)
                })

              } else if (value["question"]) {
                this.events.publish('loggedIn');
                this.events.publish('updateUser');
                this.appCtrl.getRootNav().setRoot('TabsPage');

              }
              else {
                let sharedE = localStorage.getItem('agnesSharedevent');
                let sharedG = localStorage.getItem('agnesSharedgroup');
                if (sharedE || sharedG) {
                  let type = sharedE ? 'event' : 'group';
                  credError.innerHTML = ("Answer a few quick questions to finish signing up and view the " + type + " shared with you!");
                  credError.classList.add('active');
                }
                this.toSignup(false,null);
              }
            }
            else {
              console.log('error', value);
              //some unknown response was sent back from database
              credError.innerHTML =('Something went wrong - please check your internet connection and try signing in again');
              credError.classList.add('active');
            }
          })
          .catch(error => {
            console.log('error', error);
            this.loading = false;
            credError.innerHTML =('Something went wrong - please check your internet connection and try signing in again');
            credError.classList.add('active');
          });
    }
    else {
      if (!this.loginForm.controls["email"].valid){
        this.credErrorText = 'Please enter a valid email address';
        credError.classList.add('active');
      }
      else if (!this.loginForm.controls["password"].valid){
        this.credErrorText = 'Password must be at least 7 characters long';
      }

      this.hasError = true;
    }
  }

  //open forgot password popup
  toForgotPassword(){

    this.hasError = false;

    let forgotPw = this.popoverCtrl.create(
        PasswordPopup,
        {'type':'Forgot'},
        {'enableBackdropDismiss':false}
    );
    forgotPw.present(
        {
          animate:true,
          animation: 'ios-transition',
          duration: 350,
          easing: "ease-in-out",
          direction: "forward"
        }
    );
    forgotPw.onDidDismiss(newUserData => {
      if(newUserData){this.user = newUserData;}
    });
  }

  //user has pressed Enter/Go/Return key in password field --> login
  onEnter(ev){
    if(ev.key=='Enter'){
      this.login();
    }
  }
}

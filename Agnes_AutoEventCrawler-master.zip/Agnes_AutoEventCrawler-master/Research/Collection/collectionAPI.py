from CollectAgnesEvents import collectHTML, collectPastEvents
from CollectCalendars import CollectNegative
from CollectCalendars import CollectPositive
from GraphBuilder.GraphBuilder.spiders.graphbuilder import runGraphBuilder


def CollectPastEvents():
    collectPastEvents.collectPastEvents()

def CollectHTML():
    collectHTML.collectHTML()

def CollectCalendarsPositive():
    CollectPositive.CollectPositive()

def CollectCalendarsNegative():
    CollectNegative.CollectNegative()

def RunGraphBuilder():
    runGraphBuilder()

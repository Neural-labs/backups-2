import { Component } from '@angular/core';
import { Events, App, IonicPage } from 'ionic-angular';

import { ChatService } from '../../../providers/chat.service';

import { Agnes } from '../../../app/app.component';

@IonicPage()
@Component({
    selector: 'my-chats',
    templateUrl: 'my-chats.html',
    providers: [ChatService]
})

export class MyChatsPage {

    user: Object;
    loading: boolean;
    noInternet: boolean;
    channels: Array<Object>;

    searching: boolean;
    userSearch: string;
    today: Date;

    constructor(private chatService: ChatService, private events: Events, private appCtrl: App){

    }

    ngOnInit(){
        this.user = JSON.parse(localStorage.getItem('agnesUser'));
        this.searching = false;
        this.userSearch = '';
        this.today = new Date();

        //update chat list to show last message when user has exited from chat profile
        this.events.subscribe('chatProfileData', channel => {
            let ind = this.channels.map(function(a){return a['_id']}).indexOf(channel['_id']);

            if(channel){

                let date = new Date(channel['time']);

                channel['timestamp'] = (date.toLocaleDateString() == this.today.toLocaleDateString())
                    ? date.toLocaleTimeString().replace(/:\d\d\s/,'') : date.toLocaleDateString();

                if(ind != -1){

                    this.channels[ind]['lastmessage']['message'] = ((channel['from'] == this.user['_id'])
                            ? "Me: " : '') + ((typeof(channel['lastmessage']['message']) == 'object')
                            ? "I'll go to this if you will!" : channel['lastmessage']['message']);

                    this.channels[ind]['timestamp'] = channel ['timestamp'];
                    this.channels[ind]['time'] = channel['time'];

                    this.channels.sort(function(a,b){
                        var aDate = +new Date(a["time"]);
                        var bDate = +new Date(b["time"]);
                        return bDate - aDate;
                    });
                }
                else {
                    channel['lastmessage']['message'] = ((channel['from'] == this.user['_id'])
                            ? "Me: " : '') + channel['lastmessage']['message'];
                    this.channels.unshift(channel);
                }
            }
            else {
                if(ind != -1) {
                    //all messages have been deleted, remove channel from list
                    this.channels.splice(ind,1);
                }
            }
        });

        //update chat list to show new chat from chat push notification
        this.events.subscribe('updateChatList', data => {

            let id = data.additionalData['sender']['_id'];
            let ind = this.channels.map(function(a){return a['_id']}).indexOf(id);
            let channel = this.channels[ind];

            if(data.additionalData['event']){
                channel['lastmessage'] = {
                    message: "I'll go if you go"
                }
            }
            else {
                channel['lastmessage'] = JSON.parse(data.additionalData['sender']['lastmessage']);
            }

            channel['time'] = data.additionalData['sender']['date_updated'];
            channel['status'] = false;
            let date = new Date(channel['time']);
            if (date.toLocaleDateString() == this.today.toLocaleDateString()) {
                channel['time'] = date.toLocaleTimeString().replace(/:\d\d\s/,'');
            }
            else {
                channel['time'] = date.toLocaleDateString();
            }

            //alert that channel has new message
            channel['newChat'] = true;

            this.channels.splice(ind,1);
            this.channels.unshift(channel);
        });

        this.initChat(null);
    }

    //initialize chat page
    initChat(refresher){
        this.loading = true;
        this.channels = [];

        if(!Agnes.network || Agnes.network.type != 'none'){

            this.noInternet = false;
            this.chatService.listChannel({"user1":this.user['_id']}).then(value => {
                this.loading = false;
                if (value) {
                    if(value['length'] > 0){
                        for (let c = 0; c < value['length']; c++){
                            let date = new Date(value[c]['time']);
                            value[c]['timestamp'] = (date.toLocaleDateString() == this.today.toLocaleDateString())
                                ? date.toLocaleTimeString().replace(/:\d\d\s/,'') : date.toLocaleDateString();

                            value[c]['lastmessage'] = JSON.parse(value[c]['lastmessage']);

                            value[c]['lastmessage']['message'] = ((value[c]['from'] == this.user['_id']) ? "Me: " : "")
                                + value[c]['lastmessage']['message'];
                        }
                        this.channels = value;
                    }
                }

                if(refresher){
                    refresher.complete();
                }
            }).catch(error => {
                this.loading = false;
                this.noInternet = true;
                if(error == 'timeout') {this.noInternet = true;}
                Agnes.showError("Sorry, there was a problem loading your chat history - try again!");
                if(refresher){
                    refresher.complete();
                }
            });
        }
        else {
            this.noInternet = true;
            this.loading = false;
            if(refresher){
                refresher.complete();
            }
        }
    }

    ionViewWillEnter(){
        localStorage.setItem('inChat', 'true');
    }

    ionViewDidEnter(){
        localStorage.setItem('inChat', 'true');
    }

    ionViewDidLeave(){
        localStorage.removeItem('inChat');
    }

    ionViewWillLeave(){
        localStorage.removeItem('inChat');
    }

    //last image has loaded, remove loading screen
    loaded(last){
        if(last){
            this.loading = false;
        }
    }

    //last image has been reached, remove loading screen
    loadError(last, channel){
        if(last){
            this.loading = false;
        }
        let ind = this.channels.indexOf(channel);
        this.channels[ind]['noPic'] = true;
    }

    //filter displayed users to match chat history search
    matchesSearch(channel){
        let term = this.userSearch.trim().toLowerCase();
        let len = term.length;
        if(len > 0){
            if (term.indexOf(' ') != -1){
                //user has searched a first and last name
                let ts = term.replace(/\s+/g,' ').split(' ');
                let fname = channel['fname'].toLowerCase().substring(0,ts[0].length) == ts[0];
                let lname = channel['lname'].toLowerCase().substring(0,ts[1].length) == ts[1];
                return (fname && lname);
            }
            let fname = channel['fname'].toLowerCase().substring(0,len) == term;
            let lname = channel['lname'].toLowerCase().substring(0,len) == term;
            return (fname || lname);
        }
        else {
            return true;
        }
    }

    //open chat w/ specific user
    goToChat(channel) {

        let ind = this.channels.map(function(a){return a['_id']}).indexOf(channel['_id']);
        if(ind != -1) {this.channels[ind]['status'] = true;}

        this.appCtrl.getRootNav().push(
            'ChatProfile',
            {
                'channel': channel,
                'newChat': channel['newChat']
            }, {
                animation: 'ios-transition',
                duration: 350
            });
    }

    //
    refreshChat(refresher){
        this.initChat(refresher);
    }
}
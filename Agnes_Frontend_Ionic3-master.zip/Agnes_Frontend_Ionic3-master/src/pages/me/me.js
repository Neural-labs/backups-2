"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var core_1 = require('@angular/core');
var login_service_1 = require('../login/login.service');
var groups_service_1 = require('../groups/groups.service');
var events_service_1 = require('../events/events.service');
var event_profile_1 = require('../events/event-profile/event-profile');
var ionic_native_1 = require('ionic-native');
var app_component_1 = require('../../app/app.component');
var edit_me_popup_1 = require('./edit-me-popup/edit-me-popup');
var MePage = (function () {
    function MePage(navCtrl, loginService, groupsService, eventsService, popoverCtrl, events) {
        this.navCtrl = navCtrl;
        this.loginService = loginService;
        this.groupsService = groupsService;
        this.eventsService = eventsService;
        this.popoverCtrl = popoverCtrl;
        this.events = events;
        this.interests = [];
        this.skills = [];
    }
    MePage.prototype.ngOnInit = function () {
        ionic_native_1.GoogleAnalytics.trackView("Me");
        this.initMe();
    };
    MePage.prototype.initMe = function () {
        var _this = this;
        this.loading = true;
        var user = JSON.parse(localStorage.getItem('agnesUser'));
        this.user = {
            '_id': user['_id'],
            'fname': '',
            'lname': '',
            'picurl': '',
            'aboutme': '',
        };
        this.userGroups = [];
        this.userEvents = [];
        this.skills = [];
        this.interests = [];
        //if internet is slow, show error div w/ option to reload
        setTimeout(function () {
            if (_this.loading) {
                _this.noInternet = true;
                _this.loading = false;
            }
        }, 5000);
        if (ionic_native_1.Network.type != 'none') {
            this.reload = true;
            this.loginService.getUser({ "users_id": this.user['_id'] })
                .then(function (value) {
                if (value) {
                    localStorage.setItem("agnesUser", JSON.stringify(value));
                    _this.user = value;
                }
                _this.userName = _this.user['fname'] + ' ' + _this.user['lname'];
                _this.image = (_this.user['cover'] != '') ? 'url(' + _this.user['cover'] + ')' : 'url(' + _this.user["picurl"] + ')';
                _this.interests = _this.user['keywords'].filter(function (a) { return (a['keytype'] != 'haveskill'); })
                    .map(function (b) { return b['name']; });
                _this.interests = _this.getUnique(_this.interests);
                _this.skills = _this.user['keywords'].filter(function (a) { return (a['keytype'] == 'haveskill'); })
                    .map(function (b) { return b['name']; });
                _this.skills = _this.getUnique(_this.skills);
                _this.majorString = _this.user['major'].toString().replace(/,/g, ', ');
                _this.meTab = "About";
                _this.getUserEvents();
                _this.getUserGroups();
                _this.loading = false;
            })
                .catch(function (err) {
                console.log(err);
                app_component_1.Agnes.showError("Something went wrong, sorry - try reloading the page!");
                _this.getUserEvents();
                _this.getUserGroups();
                _this.loading = false;
            });
        }
        else {
            this.noInternet = true;
            this.loading = false;
            this.user = user;
        }
    };
    MePage.prototype.imgLoad = function (ev) {
        // this.loading = false;
        this.fullscreen = true;
        var img = ev.target;
        if (img.naturalWidth > img.naturalHeight) {
            this.orientation = 'landscape';
        }
        else if (img.naturalWidth < img.naturalHeight) {
            this.orientation = 'portrait';
        }
        else {
            this.orientation = 'even';
        }
    };
    MePage.prototype.imgError = function () {
        var _this = this;
        // this.loading = false;
        this.fullscreen = false;
        if (this.reload) {
            setTimeout(function () {
                _this.user['picurl'] = _this.user['picurl'];
            }, 5000);
        }
    };
    //hide chat bubble
    MePage.prototype.ionViewDidEnter = function () {
        this.events.publish('showChat', false);
    };
    //show chat bubble
    MePage.prototype.ionViewWillLeave = function () {
        this.events.publish('showChat', true);
    };
    //get list of groups user is part of
    MePage.prototype.getUserGroups = function () {
        var _this = this;
        var data = {
            "grp": this.user['grp'].map(function (a) {
                return a['groups_id'];
            })
        };
        this.groupsService.getGroupsFromId(data).then(function (groups) {
            if (groups) {
                _this.userGroups = groups.map(function (a) {
                    _this.isImage(a);
                    a['displayURL'] = a['thumbnail'];
                    return a;
                });
            }
        }).catch(function (error) { console.log(error); });
    };
    //check to see if image will load
    MePage.prototype.isImage = function (group) {
        var _this = this;
        var image = new Image();
        image.src = group['thumbnail'];
        image.onerror = function () {
            var ind = _this.userGroups.map(function (a) { return a['_id']; }).indexOf(group['_id']);
            _this.userGroups[ind]['displayURL'] = "url(assets/img/pattern_" + Math.floor((Math.random() * 15) + 1) + '.png)';
        };
    };
    //get list of events that user is going to
    MePage.prototype.getUserEvents = function () {
        var _this = this;
        //get user events to display
        var evtdata = { "evt": this.user['evtrsvp'] };
        this.eventsService.getEventsFromId(evtdata).then(function (events) {
            if (events) {
                for (var e in events) {
                    events[e]['keywordString'] = events[e]['keywords'].toString().replace(/,/g, ', ');
                    //default pattern pic from assets folder if no event thumbnail
                    if (events[e]['thumbnail'] == '' || !events[e]['thumbnail']) {
                        events[e]['thumbnail'] = "assets/img/pattern_" + Math.floor((Math.random() * 15) + 1) + '.png';
                    }
                    var d = app_component_1.Agnes.processGMT(events[e]['starttime']);
                    events[e]['date'] = d.date;
                    events[e]['time'] = d.time;
                }
                events.sort(function (a, b) {
                    var aDate = +new Date(a["starttime"]);
                    var bDate = +new Date(b["starttime"]);
                    return aDate - bDate;
                });
                _this.userEvents = events;
            }
            else {
                app_component_1.Agnes.showError("Couldn't get your events, sorry - try reloading the page!");
            }
        }).catch(function (err) { console.log(err); app_component_1.Agnes.showError("Couldn't get your events, sorry - try reloading the page!"); });
    };
    //get list of interests that has no repeats
    MePage.prototype.getUnique = function (arr) {
        var u = {}, a = [];
        for (var i = 0, l = arr.length; i < l; ++i) {
            if (u.hasOwnProperty(arr[i])) {
                continue;
            }
            a.push(arr[i]);
            u[arr[i]] = 1;
        }
        return a;
    };
    //process edit, delete, or leave group
    MePage.prototype.gotGroupData = function (data) {
        var uInd = this.user['grp'].map(function (a) { return a['groups_id']; }).indexOf(data.group['_id']);
        var dispInd = this.userGroups.map(function (a) { return a['_id']; }).indexOf(data.group['_id']);
        if (data.category == 'leave' || data.category == 'delete') {
            //user chose to leave this group, remove group from displayed groups list and user's group list
            this.user['grp'].splice(uInd, 1);
            this.userGroups.splice(dispInd, 1);
            this.events.publish('updateUser', { 'user': this.user, 'showChat': this.user['canChat'] });
        }
        else if (data.category == 'edit') {
            this.userGroups[dispInd] = data.group;
        }
    };
    //view event profile from Events tab
    MePage.prototype.openEventProfile = function (event) {
        var _this = this;
        this.events.subscribe('eventProfileData', function (data) {
            _this.events.unsubscribe('eventProfileData');
            //if event has been deleted, remove from events list
            if (data.category == 'delete') {
                var ind = _this.userEvents.indexOf(event);
                _this.userEvents.splice(ind, 1);
                //reset matched events list
                localStorage.removeItem('agnesEventsTimeout');
                localStorage.removeItem('agnesMatchedEvents');
            }
        });
        //tracking
        if (window['fabric']) {
            window['fabric'].Answers.sendCustomEvent('Me', { type: 'event profile' });
        }
        this.navCtrl.push(event_profile_1.EventProfile, {
            'event': event,
            'user': this.user,
            'type': 'matched'
        }, {
            animation: 'ios-transition',
            duration: 350
        });
    };
    //go to events/groups page from Events or Groups tab
    MePage.prototype.goToPage = function (type) {
        this.events.publish('goToPage', type);
    };
    //view full screen pro pic
    MePage.prototype.viewProfilePic = function () {
        if (this.fullscreen && this.user['picurl'] != '') {
            ionic_native_1.PhotoViewer.show(this.user['picurl']);
        }
    };
    //edit user fields
    MePage.prototype.edit = function (type) {
        var _this = this;
        var editMe = this.popoverCtrl.create(edit_me_popup_1.EditMePopup, {
            'type': type,
            'me': this.user
        }, {
            'enableBackdropDismiss': true,
            'cssClass': 'small'
        });
        editMe.present({
            animate: false
        });
        editMe.onDidDismiss(function (data) {
            if (data) {
                _this.user = data;
                _this.userName = _this.user['fname'] + ' ' + _this.user['lname'];
                _this.image = (_this.user['cover'] != '') ? 'url(' + _this.user['cover'] + ')' : 'url(' + _this.user["picurl"] + ')';
                _this.interests = _this.user['keywords'].filter(function (a) { return (a['keytype'] != 'haveskill'); })
                    .map(function (b) { return b['name']; });
                _this.interests = _this.getUnique(_this.interests);
                _this.skills = _this.user['keywords'].filter(function (a) { return (a['keytype'] == 'haveskill'); })
                    .map(function (b) { return b['name']; });
                _this.skills = _this.getUnique(_this.skills);
                _this.majorString = _this.user['major'].toString().replace(/,/g, ', ');
                _this.events.publish('updateUser', { 'user': data, 'showChat': data['showChat'] });
            }
        });
    };
    MePage = __decorate([
        core_1.Component({
            selector: 'page-me',
            templateUrl: 'me.html',
            providers: [login_service_1.LoginService, groups_service_1.GroupsService, events_service_1.EventsService]
        })
    ], MePage);
    return MePage;
}());
exports.MePage = MePage;

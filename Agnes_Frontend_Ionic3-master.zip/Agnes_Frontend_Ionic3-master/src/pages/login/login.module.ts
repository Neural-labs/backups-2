import { NgModule } from '@angular/core';
import { LoginPage } from './login';
import { IonicPageModule } from 'ionic-angular';
import { HttpModule } from '@angular/http';
import { QuestionsPageModule } from '../questions/questions.module';

@NgModule({
  declarations: [
    LoginPage
  ],
  imports: [
    IonicPageModule.forChild(LoginPage),
    HttpModule,
    QuestionsPageModule
  ],
  exports: [
    LoginPage
  ],
})

export class LoginPageModule { }

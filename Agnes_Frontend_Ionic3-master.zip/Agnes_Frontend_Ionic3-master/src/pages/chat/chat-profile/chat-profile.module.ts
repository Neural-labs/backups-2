import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';


import { ChatProfile } from './chat-profile';
import { ComponentsModule } from '../../../components/components.module';

@NgModule({
  declarations: [
    ChatProfile
  ],
  imports: [
    IonicPageModule.forChild(ChatProfile),
    ComponentsModule
  ],
  exports: [
    ChatProfile
  ]
})

export class ChatProfileModule { }

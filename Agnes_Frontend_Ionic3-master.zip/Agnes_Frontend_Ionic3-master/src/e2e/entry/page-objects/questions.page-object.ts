import { browser, element, by, ElementFinder } from 'protractor';
import { LoginPageObject } from './login.page-object';

export class QuestionsPageObject {

    loginPage: LoginPageObject = new LoginPageObject();

    constructor(){

    }

    browseToPage(){

        browser.get('');

        this.loginPage.getSignupButton().click();

        browser.driver.sleep(500);

    }

}
import random

from config import db_config

# Config
dbconn = db_config.getDBConn('dev')

# DB
Agnes = dbconn.Agnes

# Collections
controlColl = Agnes.autocrawler_control
calendarColl = Agnes.autocrawler_calendarData


def CollectNegative():

    pageList = list(getControlPages())
    randomPages = getRandomPages(pageList)

    for page in randomPages:
        print page['url']
        # print page
        pageItem = {}
        pageItem['url'] = page['url']
        pageItem['HTML'] = page['HTML']
        pageItem['label'] = False
        insertIntoMongo(pageItem)

def getControlPages():
    return controlColl.find({})

def getRandomPages(pageList):

    randPages = []

    while len(randPages) < 181:

        randomNum = random.randint(0,len(pageList)-1)

        page = pageList[randomNum]

        if isValidPage(page['url']):
            pageList.append(page)

    return randPages

def isValidPage(pageURL):
    if 'play.google.com' in pageURL:
        return False
    if 'securelb.imodules.com' in pageURL:
        return False
    if 'www.tumblr.com' in pageURL:
        return False
    if 'docs.google.com' in pageURL:
        return False
    if 'accounts.google.com' in pageURL:
        return False
    if 'twitter.com/' in pageURL:
        return False

    return True


def insertIntoMongo(pageItem):
    calendarColl.find_one_and_update({"url":pageItem['url']},{"$set":{"HTML":pageItem['HTML'],"label":pageItem['label']}}, upsert=True)

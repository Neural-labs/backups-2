import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';

import { PebblePaused } from './pebble-paused';
import { ComponentsModule } from '../../../../components/components.module';
import { SuperTabsModule } from 'ionic2-super-tabs';
import {RoundProgressModule} from 'angular-svg-round-progressbar';

@NgModule({
  declarations: [
    PebblePaused
  ],
  imports: [
    IonicPageModule.forChild(PebblePaused),
    ComponentsModule,
    RoundProgressModule,
  ],
  exports: [
    PebblePaused
  ]
})

export class PebblePausedModule{ }

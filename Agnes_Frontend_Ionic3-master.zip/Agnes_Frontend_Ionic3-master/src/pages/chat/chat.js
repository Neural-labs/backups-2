"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var core_1 = require('@angular/core');
var chat_profile_1 = require('./chat-profile/chat-profile');
var chat_service_1 = require('./chat.service');
var chat_search_1 = require('./chat-search/chat-search');
var app_component_1 = require('../../app/app.component');
var ChatList = (function () {
    function ChatList(navCtrl, chatService, events, popoverCtrl) {
        this.navCtrl = navCtrl;
        this.chatService = chatService;
        this.events = events;
        this.popoverCtrl = popoverCtrl;
    }
    //initialize chat list page
    ChatList.prototype.ionViewWillEnter = function () {
        this.events.publish('showChat', true);
        this.user = JSON.parse(localStorage.getItem('agnesUser'));
        this.searching = false;
        this.userSearch = '';
        this.today = new Date();
        this.channels = [];
        this.initChat();
    };
    ChatList.prototype.initChat = function () {
        var _this = this;
        this.loading = true;
        if (app_component_1.Agnes.network.type != 'none') {
            this.noInternet = false;
            var d = { "user1": this.user['_id'] };
            this.chatService.listChannel({ "user1": this.user['_id'] }).then(function (value) {
                console.log('list channel', value);
                if (value) {
                    if (value['length'] > 0) {
                        for (var c = 0; c < value['length']; c++) {
                            var date = new Date(value[c]['time']);
                            value[c]['timestamp'] = (date.toLocaleDateString() == _this.today.toLocaleDateString())
                                ? date.toLocaleTimeString().replace(/:\d\d\s/, '') : date.toLocaleDateString();
                            value[c]['lastmessage'] = JSON.parse(value[c]['lastmessage']);
                            value[c]['lastmessage']['message'] = ((value[c]['from'] == _this.user['_id']) ? "Me: " : "")
                                + ((typeof (value[c]['lastmessage']['message']) == 'object')
                                    ? "I'll go to this if you will!" : value[c]['lastmessage']['message']);
                        }
                    }
                    else {
                        _this.loading = false;
                    }
                }
            }).catch(function (error) {
                _this.loading = false;
                if (error == 'timeout') {
                    _this.noInternet = true;
                }
                app_component_1.Agnes.showError("Sorry, there was a problem loading your chat history - try again!");
            });
            this.events.subscribe('updateChatList', function (data) {
                var id = data.additionalData['sender']['_id'];
                var ind = _this.channels.map(function (a) { return a['_id']; }).indexOf(id);
                var channel = _this.channels[ind];
                if (data.additionalData['event']) {
                    channel['lastmessage'] = {
                        message: "I'll go if you go"
                    };
                }
                else {
                    channel['lastmessage'] = JSON.parse(data.additionalData['sender']['lastmessage']);
                }
                channel['time'] = data.additionalData['sender']['date_updated'];
                channel['status'] = false;
                var date = new Date(channel['time']);
                if (date.toLocaleDateString() == _this.today.toLocaleDateString()) {
                    channel['time'] = date.toLocaleTimeString().replace(/:\d\d\s/, '');
                }
                else {
                    channel['time'] = date.toLocaleDateString();
                }
                _this.channels.splice(ind, 1);
                _this.channels.unshift(channel);
            });
        }
        else {
            this.noInternet = true;
            this.loading = false;
        }
    };
    //open chat w/ specific user
    ChatList.prototype.goToChat = function (channel) {
        var _this = this;
        //tracking
        if (window['fabric']) {
            window['fabric'].Answers.sendCustomEvent('Chat', { type: 'chat profile' });
        }
        var ind = this.channels.map(function (a) { return a['_id']; }).indexOf(channel['_id']);
        if (ind != -1) {
            this.channels[ind]['status'] = true;
        }
        var chatProfile = this.popoverCtrl.create(chat_profile_1.ChatProfile, {
            'channel': channel
        }, { 'enableBackdropDismiss': false });
        chatProfile.present({
            animate: true,
            animation: 'ios-transition',
            duration: 350,
            easing: "ease-in-out",
            direction: "forward"
        });
        chatProfile.onDidDismiss(function (channel) {
            if (channel) {
                var ind_1 = _this.channels.map(function (a) { return a['_id']; }).indexOf(channel['_id']);
                var date = new Date(channel['time']);
                channel['timestamp'] = (date.toLocaleDateString() == _this.today.toLocaleDateString())
                    ? date.toLocaleTimeString().replace(/:\d\d\s/, '') : date.toLocaleDateString();
                if (ind_1 != -1) {
                    _this.channels[ind_1]['lastmessage']['message'] = ((channel['from'] == _this.user['_id'])
                        ? "Me: " : '') + ((typeof (channel['lastmessage']['message']) == 'object')
                        ? "I'll go to this if you will!" : channel['lastmessage']['message']);
                    _this.channels[ind_1]['timestamp'] = channel['timestamp'];
                    _this.channels[ind_1]['time'] = channel['time'];
                    _this.channels.sort(function (a, b) {
                        var aDate = +new Date(a["time"]);
                        var bDate = +new Date(b["time"]);
                        return bDate - aDate;
                    });
                }
                else {
                    channel['lastmessage']['message'] = ((channel['from'] == _this.user['_id'])
                        ? "Me: " : '') + channel['lastmessage']['message'];
                    _this.channels.unshift(channel);
                }
            }
            else {
                //all messages have been deleted, remove channel from list
                _this.channels.splice(ind, 1);
            }
        });
    };
    //toggle 'searching' field to display Add Chat (+) bubble or Close Search (X) button
    ChatList.prototype.changeSearching = function () {
        this.searching = this.userSearch.trim().length > 0;
    };
    //clear chat history search
    ChatList.prototype.clearSearch = function () {
        this.userSearch = "";
        this.searching = false;
    };
    //last image has loaded, remove loading screen
    ChatList.prototype.loaded = function (last) {
        if (last) {
            this.loading = false;
        }
    };
    //last image has been reached, remove loading screen
    ChatList.prototype.loadError = function (last, channel) {
        if (last) {
            this.loading = false;
        }
        var ind = this.channels.indexOf(channel);
        this.channels[ind]['noPic'] = true;
    };
    //filter displayed users to match chat history search
    ChatList.prototype.matchesSearch = function (channel) {
        var term = this.userSearch.trim().toLowerCase();
        var len = term.length;
        if (len > 0) {
            if (term.indexOf(' ') != -1) {
                //user has searched a first and last name
                var ts = term.replace(/\s+/g, ' ').split(' ');
                var fname_1 = channel['fname'].toLowerCase().substring(0, ts[0].length) == ts[0];
                var lname_1 = channel['lname'].toLowerCase().substring(0, ts[1].length) == ts[1];
                return (fname_1 && lname_1);
            }
            var fname = channel['fname'].toLowerCase().substring(0, len) == term;
            var lname = channel['lname'].toLowerCase().substring(0, len) == term;
            return (fname || lname);
        }
        else {
            return true;
        }
    };
    //clicked + bubble, create new chat with a user
    ChatList.prototype.searchNewChat = function () {
        var _this = this;
        //tracking
        if (window['fabric']) {
            window['fabric'].Answers.sendCustomEvent('Chat', { type: 'new chat' });
        }
        var chatSearch = this.popoverCtrl.create(chat_search_1.ChatSearch, { user: this.user }, { 'enableBackdropDismiss': false });
        chatSearch.present({
            animate: true,
            animation: 'ios-transition',
            duration: 350,
            easing: "ease-in-out",
            direction: "forward"
        });
        chatSearch.onDidDismiss(function (data) {
            if (data) {
                //start chat with this user
                var channel = {
                    '_id': data.startChat['_id']
                };
                _this.goToChat(channel);
            }
        });
    };
    ChatList = __decorate([
        core_1.Component({
            selector: 'page-chat',
            providers: [chat_service_1.ChatService],
            templateUrl: 'chat.html',
        })
    ], ChatList);
    return ChatList;
}());
exports.ChatList = ChatList;

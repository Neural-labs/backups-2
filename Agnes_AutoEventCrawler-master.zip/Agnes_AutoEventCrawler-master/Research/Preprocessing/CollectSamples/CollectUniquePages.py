from config import db_config
from Utilities import EventTree

Agnes = db_config.getDBConn('dev').Agnes

Event_Collection = Agnes.autocrawler_events
Unique_Collection = Agnes.autocrawler_unique_sources

def ParseUniqueSources():

    unique_pages = getUnique()

    skip_sources = ['events.citypaper.com', 'guevents.georgetown.edu','thebridge.cmu.edu','nest.cua.edu','hoyalink.georgetown.edu',
                    'howard.campuslabs.com', 'temple.campuslabs.com','involved.towson.edu','studentcentral.udel.edu','gobblerconnect.vt.edu',
                    'johnshopkins.campuslabs.com','dspshows.com','wexarts.org','blackcatdc.com','ticketmaster','thehowardtheatre.com','nyu.edu'
                    ,'events.temple.edu','busboysandpoets.com','usgbcnh.org','athletics.trinitydc.edu','americanrepertorytheater.org']

    skip_sources.append('shakespearetheatre.org')
    missed = []
    counter = 0
    for event in unique_pages:
        if event['evtsource'] in skip_sources:
            continue
        counter += 1
        print 'Event:',counter
        print event['evtsource']
        print event['url']
        event_parts = EventTree.getEventParts(event)

        for part in event_parts:
            if not event_parts[part]:
                print part
                raise ValueError('no part content!')

        html = event['HTML']
        event_tree = EventTree.EventTree(html, event)

        event_nodes = event_tree.get_event_nodes()

        if not event_nodes:

            # for node_id, node_data in event_tree.get_nodes():
            #     print node_data['attr_dict']['totalcontent']

            for part in event_parts:
                print part
                print event_parts[part]
                print
            print event['evtsource']
            print event['url']
            print 'Event:', counter
            print 'Failed!'
            missed.append(event['url'])
            # raise ValueError('failed!')
        else:
            event_tree.print_labels()
            # for part in event_nodes:
            #     if part == 'event':
            #         continue
            #     print part
            #     # print 'Tree:',event_tree.get_node_data(event_nodes[part])['attr_dict']['tag'].prettify()
            #     print 'Tree:',event_tree.get_node_data(event_nodes[part])['attr_dict']['totalcontent']
            #     print
            #     print 'DB:',event_parts[part]
            #     print
            print '\nReal Values:'
            for part in event_parts:
                print part, event_parts[part]
            print '--------------------------'
            # raise ValueError('stop')
        print

    print 'Missed:'
    for item in missed:
        print item

def CollectUniqueSources():

    unique_sources = []
    events = getEvents()
    counter = 0

    for event in events:
        counter += 1
        if counter % 500 == 0:
            print counter,'of',events.count()
        if invalidEvent(event, unique_sources):
            continue

        unique_sources.append(event['evtsource'])
        insertEvent(event)

def invalidEvent(event, unique_sources):
    if 'HTML' not in event:
        return True
    if not event['evtsource']:
        return True
    if event['evtsource'] in unique_sources:
        return True
    parts = ['evtname','starttime','location','evtdesc']
    for part in parts:
        if not event[part]:
            return True
    return False

def getEvents():
    return Event_Collection.find({}, no_cursor_timeout=True)

def getUnique():
    return Unique_Collection.find({}, no_cursor_timeout=True)

def insertEvent(event):
    # Unique_Collection.replace_one({'url': event['url']}, event)
    del event['_id']
    Unique_Collection.replace_one({'evtsource':event['evtsource']},event, upsert=True)
    # else:
    #     Unique_Collection.insert_one(event)
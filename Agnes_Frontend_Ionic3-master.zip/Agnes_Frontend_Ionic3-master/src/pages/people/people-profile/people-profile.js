"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var core_1 = require('@angular/core');
var groups_service_1 = require('../../groups/groups.service');
var ionic_native_1 = require('ionic-native');
var report_1 = require('../../popups/report/report');
var invite_to_group_1 = require('../../popups/invite-to-group/invite-to-group');
var app_component_1 = require('../../../app/app.component.ts');
var chat_profile_1 = require('../../chat/chat-profile/chat-profile');
var PeopleProfile = (function () {
    function PeopleProfile(navParams, navCtrl, groupsService, popoverCtrl, events, actionSheetCtrl) {
        this.navParams = navParams;
        this.navCtrl = navCtrl;
        this.groupsService = groupsService;
        this.popoverCtrl = popoverCtrl;
        this.events = events;
        this.actionSheetCtrl = actionSheetCtrl;
        this.skills = [];
        this.interests = [];
        this.groups = [];
    }
    PeopleProfile.prototype.ngOnInit = function () {
        var _this = this;
        this.events.publish('pagePushed');
        this.person = this.navParams.data.person;
        this.user = this.navParams.data.user;
        this.image = (this.person['cover'] != '') ? 'url(' + this.person['cover'] + ')' : 'url(' + this.person["picurl"] + ')';
        this.platform = this.navParams.data.platform;
        this.loading = (this.user['picurl'] != '');
        this.userIsAdmin = this.user['grp'].filter(function (a) { return a['admin']; }).length > 0;
        this.peopleTab = "About";
        this.skills = this.person['keywords'].filter(function (a) { return a['keytype'] == 'haveskill'; }).map(function (a) { return a.name; });
        this.skills = this.getUnique(this.skills);
        this.interests = this.person['keywords'].filter(function (a) { return a['keytype'] != 'haveskill'; }).map(function (a) { return a.name; });
        this.interests = this.getUnique(this.interests);
        this.majorString = this.person['fname'] + ' is a ' +
            (this.person['studenttype'] == 'phd' ? 'PhD student ' :
                this.person['studenttype'] == 'masters' ? 'Masters student ' : this.person['studenttype']) + ' studying '
            + this.person['major'].toString().replace(/,/g, ', ');
        var lc = this.majorString.lastIndexOf(',');
        this.majorString = (lc != -1) ? this.majorString.substring(0, lc) + ' and' + this.majorString.substring(lc + 1) : this.majorString;
        this.tabsVal = ['About', 'Groups'];
        var data = {
            "grp": this.person['grp'].map(function (a) {
                return a['groups_id'];
            })
        };
        //get user's groups to display in Groups tab - if no groups, only display About tab
        this.groupsService.getGroupsFromId(data).then(function (groups) {
            if (groups && groups.length > 0) {
                _this.groups = groups.map(function (a) {
                    a['displayURL'] = ((a['thumbnail'] == '' || !a['thumbnail'])
                        ? "assets/img/pattern_" + Math.floor((Math.random() * 15) + 1) + '.png' : a['thumbnail']);
                    return a;
                });
            }
            else {
                _this.tabsVal = ['About'];
            }
        }).catch(function (error) { console.log(error); });
        //set menu buttons for action sheet
        this.setMenuButtons();
    };
    PeopleProfile.prototype.imgLoad = function (ev) {
        var img = ev.target;
        if (img.naturalWidth > img.naturalHeight) {
            this.orientation = 'landscape';
        }
        else if (img.naturalWidth < img.naturalHeight) {
            this.orientation = 'portrait';
        }
        else {
            this.orientation = 'even';
        }
        this.fullscreen = true;
        this.loading = false;
    };
    PeopleProfile.prototype.imgError = function (ev) {
        this.fullscreen = false;
        this.loading = false;
    };
    PeopleProfile.prototype.getUnique = function (arr) {
        var u = {}, a = [];
        for (var i = 0, l = arr.length; i < l; ++i) {
            if (u.hasOwnProperty(arr[i])) {
                continue;
            }
            a.push(arr[i]);
            u[arr[i]] = 1;
        }
        return a;
    };
    PeopleProfile.prototype.setMenuButtons = function () {
        var _this = this;
        this.menuButtons = [];
        if (this.userIsAdmin) {
            this.menuButtons.push({
                text: 'Invite User to Group',
                icon: 'md-add',
                cssClass: '',
                handler: function () { _this.inviteToGroup(); }
            });
        }
        var snd = [{
                text: 'Report User',
                icon: 'md-flag',
                cssClass: '',
                handler: function () { _this.reportEntity(); }
            }, {
                text: 'Cancel',
                role: 'cancel',
                cssClass: '',
                icon: 'md-close',
                handler: function () { }
            }];
        this.menuButtons = this.menuButtons.concat(snd);
    };
    PeopleProfile.prototype.openPeopleMenu = function () {
        var actionSheet = this.actionSheetCtrl.create({
            title: '',
            buttons: this.menuButtons
        });
        actionSheet.present();
    };
    PeopleProfile.prototype.closePeopleProfile = function (e) {
        if (!e || e.direction == 4) {
            this.navCtrl.pop({
                animate: true,
                animation: 'ios-transition',
                duration: 350,
                easing: "ease-in-out",
                direction: "back"
            }).then(function () {
            });
        }
    };
    PeopleProfile.prototype.inviteToGroup = function () {
        var _this = this;
        //tracking
        if (window['fabric']) {
            window['fabric'].Answers.sendCustomEvent('People Profile', { type: 'invite to group' });
        }
        var data = { "grp": this.user['grp'].filter(function (b) { return b['admin']; }).map(function (a) { return a['groups_id']; }) };
        if (data['grp'].length == 0) {
            app_component_1.Agnes.showError('You have to be an admin of at least one group to invite someone to join a group!');
        }
        else {
            this.groupsService.getGroupsFromId(data).then(function (value) {
                if (value) {
                    value = value.filter(function (a) {
                        return a['members'].indexOf(_this.person['_id']) == -1 && a['admin'].indexOf(_this.person['_id']) == -1;
                    });
                    if (value.length == 0) {
                        app_component_1.Agnes.showError('Looks like ' + _this.person['fname']
                            + ' is already part of all of that groups that you\'re an admin of!');
                    }
                    else {
                        var invitePage = _this.popoverCtrl.create(invite_to_group_1.InviteToGroup, {
                            'user': _this.user,
                            'person': _this.person,
                            'groups': value,
                            'platform': _this.platform
                        }, { 'enableBackdropDismiss': true });
                        invitePage.present();
                    }
                }
                else {
                    app_component_1.Agnes.showError("Sorry, couldn't get your groups right now - try again!");
                }
            }).catch(function () { app_component_1.Agnes.showError("Sorry, couldn't get your groups right now - try again!"); });
        }
    };
    PeopleProfile.prototype.chatWithUser = function () {
        //tracking
        if (window['fabric']) {
            window['fabric'].Answers.sendCustomEvent('People Profile', { type: 'chat' });
        }
        var channel = {
            '_id': this.person['_id'],
            'fname': this.person['fname'],
            'lname': this.person['lname'],
            'picurl': this.person['picurl']
        };
        var chatProfile = this.popoverCtrl.create(chat_profile_1.ChatProfile, {
            'channel': channel
        }, { 'enableBackdropDismiss': false });
        chatProfile.present();
    };
    PeopleProfile.prototype.reportEntity = function () {
        //tracking
        if (window['fabric']) {
            window['fabric'].Answers.sendCustomEvent('People Profile', { type: 'report' });
        }
        var reportPage = this.popoverCtrl.create(report_1.ReportPage, {
            'entityID': this.person['_id'],
            'entityName': this.person['fname'] + ' ' + this.person['lname'],
            'user': this.user,
            'type': 'people',
            'platform': this.platform
        }, { 'enableBackdropDismiss': true });
        reportPage.present({
            animate: false
        });
    };
    PeopleProfile.prototype.viewProPic = function () {
        if (this.fullscreen) {
            ionic_native_1.PhotoViewer.show(this.person['picurl']);
        }
    };
    //redisplay if a person's group has been edited or deleted by admin
    PeopleProfile.prototype.gotGroupData = function (data) {
        var group = data.group;
        var ind = this.groups.map(function (a) { return a['_id']; }).indexOf(group['_id']);
        if (data.category == 'edit') {
            this.groups[ind] = group;
        }
        else if (data.category == 'delete') {
            this.groups.splice(ind, 1);
        }
    };
    PeopleProfile = __decorate([
        core_1.Component({
            selector: 'people-profile',
            templateUrl: 'people-profile.html',
            providers: [groups_service_1.GroupsService]
        })
    ], PeopleProfile);
    return PeopleProfile;
}());
exports.PeopleProfile = PeopleProfile;

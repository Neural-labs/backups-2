import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';

import { AgnesAlert } from './agnes-alert';

@NgModule({
    declarations: [
        AgnesAlert
    ],
    imports: [
        IonicPageModule.forChild(AgnesAlert)
    ],
    exports: [
        AgnesAlert
    ]
})

export class AgnesAlertModule { }

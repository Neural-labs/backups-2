import { NgModule } from '@angular/core';
import { IonicModule } from 'ionic-angular';

import { GroupList } from './group-list/group-list';
import { SkeletonCardBlockComponent } from './skeleton-card-block/skeleton-card-block';
import { SkeletonCardListComponent } from './skeleton-card-list/skeleton-card-list';
import { AgnesScrollTopComponent } from './agnes-scroll-top/agnes-scroll-top';
import { AgnesCardComponent } from './agnes-card/agnes-card';
import { AgnesItemComponent } from './agnes-item/agnes-item';
import { AgnesCardBannerComponent } from './agnes-card-banner/agnes-card-banner';
import { AgnesFeedCardComponent } from './agnes-feed-card/agnes-feed-card';


@NgModule({
  declarations: [
    GroupList,
    SkeletonCardBlockComponent,
    SkeletonCardListComponent,
    AgnesScrollTopComponent,
    AgnesCardComponent,
    AgnesItemComponent,
    AgnesCardBannerComponent,
    AgnesFeedCardComponent
  ],
  imports: [
    IonicModule,
  ],
  exports: [
    GroupList,
    SkeletonCardBlockComponent,
    SkeletonCardListComponent,
    AgnesScrollTopComponent,
    AgnesCardComponent,
    AgnesItemComponent,
    AgnesCardBannerComponent,
    AgnesFeedCardComponent
  ]
})

export class ComponentsModule { }

# Looking at the data from an extraction point of view
import time
from collections import Counter
import re
import string
import math
from Utilities import DataFilter
from config import db_config

from config.config_data import POS_API

dbConn = db_config.getDBConn('dev')
Agnes = dbConn.Agnes
# Event_Collection = Agnes.autocrawler_events
Data_Collection = Agnes.autocrawler_ext_data

def ExamineSamples():

    target_parts = ['location']

    samples = getSamples()

    keys = ['avg_content_length', 'avg_html_length', 'punc_count', 'case_ratio', 'max_content_length', 'max_html_length',
            'avg_word_count']

    pos_stats = dict.fromkeys(keys, 0.0)
    neg_stats = dict.fromkeys(keys, 0.0)

    counter = 1
    pos_counter = 0
    neg_counter = 0

    pos_content_sizes = Counter()
    neg_content_sizes = Counter()

    outliers = []

    for sample in samples:

        if counter % 10000 == 0:
            print counter,'of',samples.count(),'\n'

            # for size, text in outliers:
            #     print 'item:'
            #     # print text
            #     print size
            #     print
            print 'Outlier count:', len(outliers), ' % = ', len(outliers) / float(pos_counter)
            printResults(pos_stats, neg_stats, pos_counter, neg_counter, pos_content_sizes, neg_content_sizes)

            print

        sample_stats = getStatistics(sample['text'])

        if not sample_stats:
            continue

        counter += 1

        length = sample_stats['word_count']

        if sample['label'] and sample['part'] in target_parts:
            # if content_len > 3000:
            #     outliers.append((content_len, cleanhtml(sample['text'])))
            # pos_content_sizes[sample_stats['content_length']] += 1

            if length > 100:
                outliers.append((length, sample_stats['word_count']))
            pos_content_sizes[sample_stats['word_count']] += 1
            pos_counter += 1
            pos_stats = updateStatistics(pos_stats, sample_stats)
        else:
            # neg_content_sizes[sample_stats['content_length']] += 1

            neg_content_sizes[sample_stats['word_count']] += 1
            neg_counter += 1
            neg_stats = updateStatistics(neg_stats, sample_stats)

    for size, text in outliers:
        print 'item:'
        print text
        print size
        print
    printResults(pos_stats, neg_stats, pos_counter, neg_counter, pos_content_sizes, neg_content_sizes)
    print 'Large pos content count:', len(outliers), ' % = ', len(outliers) / float(pos_counter)


def printResults(pos_stats, neg_stats, pos_counter, neg_counter, pos_content_sizes, neg_content_sizes):

    counter_divides = ['avg_content_length', 'avg_html_length', 'punc_count', 'case_ratio', 'avg_word_count']

    print '------------------------- Stats ------------------------------'
    print 'Pos Samples:',pos_counter
    print 'Pos ratio:', pos_counter / float(pos_counter + neg_counter)
    for key in pos_stats:
        if key in counter_divides:
            print key, pos_stats[key] / pos_counter
        else:
            print key,pos_stats[key]

    print

    print 'Neg Samples:',neg_counter
    for key in neg_stats:
        if key in counter_divides:
            print key, neg_stats[key] / neg_counter
        else:
            print key,neg_stats[key]

    print

    print 'Content Sizes:'
    print 'Pos'
    printCounter(pos_content_sizes)
    # for size in pos_content_sizes:
    #     print size, pos_content_sizes[size]
    # print
    print 'Neg'
    printCounter(neg_content_sizes)
    print
    # for size in neg_content_sizes:
    #     print size, neg_content_sizes[size]

    # print '--------------------------------------------------------------'

def printCounter(counter):

    bucket_size = 1

    buckets = makeBuckets(counter, bucket_size)

    for key in sorted(buckets.keys()):
        value = buckets[key]
        # stars = max(int(100 * value), 1)
        stars = int(100 * value)
        if not stars:
            continue
        print 'Bucket:',key*bucket_size,'-- [', '*' * stars


def makeBuckets(counter, bucket_size):

    # num_buckets = max_value / bucket_size
    buckets = Counter()
    for key in counter:
        value = counter[key]
        bucket = key/bucket_size
        buckets[bucket] += float(value)

    max_bucket_value = float(buckets.most_common()[0][1])

    for key in buckets:
        buckets[key] /= max_bucket_value

    return buckets

def getSamples():
    return Data_Collection.find({}, no_cursor_timeout=True)

def getStatistics(text):

    just_content = cleanhtml(text)
    just_html = removeAllInside(text)

    if not just_content:
        return False

    sample_stats = {}
    sample_stats['html_length'] = len(just_html)
    sample_stats['content_length'] = len(just_content)
    sample_stats['case_ratio'] = float(sum(1 for c in just_content if c.isupper())) / float(len(just_content))
    sample_stats['punc_count'] = len([c for c in just_content if c not in string.punctuation])
    sample_stats['word_count'] = getNumContentWords(text)

    return sample_stats

def cleanhtml(raw_html):
    cleanr = re.compile('<[^<]+?>')
    cleantext = re.sub(cleanr, '', raw_html)
    cleantext = ' '.join(cleantext.split())
    return cleantext

def removeRealContent(content):
    pattern = re.compile('>.+?<')
    # pattern = re.compile('>.*<')
    cleancontent = re.sub(pattern, '><', content)
    return cleancontent

def removeAllInside(content):
    # content = content.replace(' ','')
    # pattern = re.compile('>.+?<')
    pattern = re.compile('>.*<')
    cleancontent = re.sub(pattern, '><', content)
    return cleancontent

def getNumContentWords(text):
    content = cleanhtml(text)
    return len(content.split())

def updateStatistics(stats, sample_stats):

    stats['avg_content_length'] += sample_stats['content_length']
    stats['avg_html_length'] += sample_stats['html_length']
    stats['punc_count'] += sample_stats['punc_count']
    stats['case_ratio'] += sample_stats['case_ratio']
    stats['max_content_length'] = max(stats['max_content_length'], sample_stats['content_length'])
    stats['max_html_length'] = max(stats['max_html_length'], sample_stats['html_length'])
    stats['avg_word_count'] += sample_stats['word_count']

    return stats



import { Component } from '@angular/core';
import { NavController, ModalController, ToastController, Events, IonicPage, App } from 'ionic-angular';
import { GroupsService } from '../../../providers/groups.service';
import { PeopleService } from '../../../providers/people.service';
import { EventsService } from '../../../providers/events.service';
import { MeService } from '../../../providers/me.service';
import { AnalyticsService } from "../../../providers/analytics.service";

import { Agnes } from '../../../app/app.component';


@IonicPage()
@Component({
    selector: 'notifications',
    templateUrl: 'notifications.html',
    providers: [GroupsService, PeopleService,EventsService, MeService, AnalyticsService]
})

export class NotificationsPage {

    user:Object;
    loading: boolean;
    noNotifs: boolean;
    readNotifications: Array<Object>;
    unreadNotifications: Array<Object>;
    notifications: Array<Object>;
    eventTypes: Array<String>;
    buttonTypes: Array<String>;
    unreadCount: number;
    changedCount: number;
    navBarShown: boolean;

    notificationOpen: boolean;

    constructor(public navCtrl: NavController,
                private modalCtrl: ModalController,
                private events: Events,
                private analyticsService:AnalyticsService,
                private appCtrl: App,
                private groupsService: GroupsService,
                private peopleService: PeopleService,
                private meService: MeService,
                private toastCtrl: ToastController,
                private eventsService: EventsService) {

    }

    ngOnInit(){
        this.notifications = []
        this.eventTypes = ['share_event', 'send_igiyg', 'accept_igiyg', 'reject_igiyg', 'shareWithGroup'];
        this.notificationOpen = false;
        this.navBarShown = false;

        this.loading = true;
        this.noNotifs = false;
        this.user = JSON.parse(localStorage.getItem('agnesUser'));
        this.changedCount = 0;
        this.initNotifications(null);
        this.navBarShown = true;

        localStorage.setItem('notificationsPageOpen','true');

        //send Open Notifications Page analytics
        this.analyticsService.logAnalytics({community: this.user['community'], users_id: this.user['_id']}, '/notificationTab');

        this.events.subscribe('gotNewNotif', () => {
           this.refreshNotifs(null);
        });

        //allow notifications to be clicked on once a notification profile has been closed
        this.events.subscribe('notificationClosed', () => {
            this.notificationOpen = false;
        });
    }

    ionViewWillUnload() {
      this.readNotifs();
    }

    ionViewWillLeave(){
        localStorage.removeItem('notificationsPageOpen');
        this.navBarShown = false;

    }

    initNotifications(refresher){
        if(!refresher) {this.loading = true;}
        this.getNotifications(refresher);
    }

    //get all notifications - first unread then read in sep function
    getNotifications(refresher){
        this.notifications = [];
        let data = {
            'users_id': this.user['_id']
        };
        let t = new Date();
        this.meService.getNotifications(data).then(val => {
          console.log(val)
          if(val) {
            let notif = val['notifications'];
            this.unreadCount = val['unread'];
            this.sortNotifsByDate(notif);
            for(let u in notif) {
              notif[u]['timestamp'] = notif[u]['timestamp'] == null ? '' : this.getDisplayTime(notif[u]['timestamp'])
              this.notifications.push(notif[u]);
              }
              if(this.notifications.length == 0) {
                this.noNotifs = true;
              }
          }
        this.loading = false;
        if(refresher){
          refresher.complete();
        }
        }).catch(err => {
            if(refresher){
                refresher.complete();
            }
            console.log('get unread notification error', err);
            Agnes.showError('Could not retrieve your notifications - try again!');
        });
    }

    getDisplayTime(time) {
      let start = Agnes.processGMT(time.replace(/[-\+]\d\d\d\d/,'Z'));
      return(start.date + " " + start.time);
    }

    openProfile(notification) {
        if(!this.notificationOpen) {
            this.notificationOpen = true;
            let objId = notification['obj_id'];

            if(notification['deepLinkType'] == 'groupProfile' || notification['deepLinkType'] == 'groupFeed') {
                this.groupsService.getGroupsFromId({'grp':objId}).then(value => {
                    if (value && value['length'] > 0){
                        let group = value[0];
                        if(notification['deepLinkType'] == 'groupProfile') {
                            this.appCtrl.getRootNav().push(
                                'GroupProfile',
                                {
                                    'group':group,
                                    'type': 'notification'
                                }, {
                                    animation: 'ios-transition',
                                    duration: 350
                                })
                              } else {
                                this.appCtrl.getRootNav().push(
                                'GroupFeedPage',
                                {
                                    'group':group,
                                    'type': 'feed',
                                }, {
                                    animation: 'ios-transition',
                                    duration: 350
                                })
                              }
                    } else {
                        this.notificationOpen = false;
                        Agnes.showError("Couldn't open this group profile, sorry - try again!");
                    }
                }).catch(err => {
                    console.log(err);
                    Agnes.showError("Couldn't open this group profile, sorry - try again!");
                    this.notificationOpen = false;
                });
            }
            else if (notification['deepLinkType'] == 'eventProfile') {
                let evtdata = {"evt": objId, 'community': this.user['community']}
                this.eventsService.getEventsFromId(evtdata).then(value => {
                    if (value && value['length'] > 0){
                        let event = value[0];
                        this.appCtrl.getRootNav().push(
                            'EventProfile',
                            {
                                'event':event,
                                'type': 'notification'
                            }, {
                                animation: 'ios-transition',
                                duration: 350
                            });

                    } else {
                        Agnes.showError("Sorry, this event has already passed.");
                        this.notificationOpen = false;
                    }
                }).catch(err => {
                    console.log(err);
                    Agnes.showError("Couldn't open this event profile, sorry - try again!");
                    this.notificationOpen = false;
                });
            } else if(notification['deepLinkType'] == 'meProfile') {
              this.appCtrl.getRootNav().push(
                  'PeopleProfile',
                  {
                      'person':this.user,
                      'isMe': true
                  }, {
                      animation: 'ios-transition',
                      duration: 350
                  });
            } else if(notification['deepLinkType'] == 'huddle') {
              this.appCtrl.getRootNav().push(
                  'HuddlePage',
                  {}, {
                      animation: 'ios-transition',
                      duration: 350
                  });
            }
            this.readNotifs();
        }
  }

    closeNotifications() {
        //send Back Button analytics
        this.analyticsService.logAnalytics({
            backButtonName: 'notificationsPage',
            users_id: this.user['_id']}, '/backButton');


        this.appCtrl.getRootNav().pop({
          animation: 'ios-transition',
          duration: 350,
          easing: "ease-in-out",
          direction: "back"
      })
    }

    leftButton(n){
      this.loading = true;
      let notif = {'users_id':this.user['_id'],'notification_id': {'_id': n['id'], 'type': n['type'], 'response' : 0}};
      if(n['type'] == 'send_igiyg'){
        let data = {'sender_users_id' : this.user['_id'], 'receiver_users_id' : n['senderId'] , 'events_id' :  n['objId']};
        this.eventsService.acceptIYG(data).then(value => {
            this.eventsService.getEventsFromId({'evt': n['objId'], 'community': this.user['community']}).then( val => {
              if(val){
                Agnes.going(val[0], false, n['senderId']);
                this.readNotif(notif);
              } else {
                Agnes.showError("Sorry, there was a problem submitting your RSVP");
              }
            });
        }).catch(err => {
          Agnes.showError("Sorry, there was a problem sending your response - try again!");
        });
      } else if (n['type'] == 'invite') {
        //accepting invite to group as a member
        let data = {
            "groups_id": n['objId'],
            "users_id": this.user['_id'],
            "community": this.user['community'],
            "inviters_id": n['senderId']
        };
        this.groupsService.acceptInvite(data).then(resp => {
          if(resp) {
            let toast = this.toastCtrl.create({
              message: "You are now a member of " + n['objName']+ "!",
              duration: 2500,
              position: 'top',
              closeButtonText: ' ',
              showCloseButton: true
            });
            toast.present();
          }
          else {
              Agnes.showError("Sorry, something went wrong - try joining " + resp['grpname'] + " again!");
          }
          this.readNotif(notif);
          })
      } else if (n['type'] == 'joinPrivateGroup') {
        let data = {
            'users_id': this.user['_id'],
            'groups_id': n['objId'],
            'newmember': [n['senderId']],
            'newadmin': [],
            'rvmember': [],
            'rvadmin': [],
            'community' : this.user['community']
        };
        this.groupsService.editGroupMembers(data).then(resp => {
          if(resp) {
            this.readNotif(notif);
            let toast = this.toastCtrl.create({
              message: "You accepted " + n['userName'] + "'s request to join" + n['objName'],
              duration: 2500,
              position: 'top',
              closeButtonText: ' ',
              showCloseButton: true
            });
            toast.present();
          }
        }).catch(err => {
          console.log(err);
        })
      }
    }

    sortNotifsByDate(type) {
      type.sort(function(a,b){
        let aDate = +new Date(a["timestamp"]);
        let bDate = +new Date(b["timestamp"]);
        return bDate - aDate;
      });
    }

    rightButton(n) {
      this.loading = true;
      let notif = {'users_id':this.user['_id'],'notification_id': {'_id': n['id'], 'type': n['type'], 'response' : 1}};
      if(n['type'] == 'send_igiyg'){
        let data = {'sender_users_id' : this.user['_id'], 'receiver_users_id' : n['senderId'] , 'events_id' :  n['objId']};
        this.eventsService.rejectIYG(data).then(value => {
          this.readNotif(notif);
        }).catch(err => {
          Agnes.showError("Sorry, there was a problem sending your response - try again!");
        });
    } else if ((n['type'] == 'accept_igiyg') || (n['type'] == 'invite') || n['type'] == 'joinPrivateGroup') {
      this.readNotif(notif);
    }
    }

    readNotif(notif){
      this.meService.readNotification(notif).then(value=>{
        this.loading = false;
        this.refreshNotifs(null);
      }).catch(err =>{
        Agnes.showError("Sorry, there was a problem marking your notification as read.");
      });
    }

    readNotifs(){
      let notifIds = [];
      for(let u in this.notifications) {
        if(this.notifications[u]['buttonActions'].length == 0 && this.notifications[u]['read'] == false) {
          notifIds.push({'_id': this.notifications[u]['_id'], 'type': this.notifications[u]['type']});
          this.changedCount++;
        }
      }
      let data = {'users_id': this.user['_id'], 'notification_ids': notifIds};
      console.log(notifIds)
      let unread = this.unreadCount - this.changedCount;
      this.events.publish('changeInNotifCount', unread);
      if(notifIds.length > 0) {
        this.meService.readNotifications(data).then(value=>{
          console.log(value)
        }).catch(err =>{
          Agnes.showError("Sorry, there was a problem marking your notification as read.");
        });
      }
    }


    addToCal(objId) {
      this.eventsService.getEventsFromId({
          'evt': objId,
          'community': this.user['community']
      }).then(val => {
        Agnes.addToCalendar(val[0], false);
      }).catch(err => {
        console.log(err);
      });
    }

    refreshNotifs(refresher) {
      if(!Agnes.network || Agnes.network.type != 'none'){
        this.events.publish('updateUser');
        this.events.subscribe('updateDone',() => {
          this.events.unsubscribe('updateDone');
            this.readNotifs();
            this.initNotifications(refresher);
        });
      }
      else {
        //lack of internet connection - alert
        Agnes.showError('You are offline! Try refreshing again when you reconnect.');
        refresher.complete();
      }
    }

    notificationImgError(notification){
        notification['noPic'] = true;
        notification['defaultPic'] = notification['type'] == 'invite' ? 'assets/img/icons/group_icon_white.png'
            : 'assets/img/icons/events_icon_white.png';
    }

}

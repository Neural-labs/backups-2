"""
Agnes Huddle main controller

Purpose:
Read the huddle_requests collection, and update either the entire community, or a single user's huddle

"""

import logging
from db.functions import huddle_feeds, huddle_requests
from bson.objectid import ObjectId
from ProcessController import runRanking
logging.getLogger().setLevel(logging.INFO)
import time


def start():
    logging.info('Starting huddle controller')

    runRanking()

    # start = time.time()
    # cursor = huddle_feeds.find({})
    # cursor = huddle_feeds.find({})#,{'news':1})
    # item = cursor[0]
    # end = time.time()
    # print 'Time taken:', str(end-start)


if __name__ == '__main__':
    start()


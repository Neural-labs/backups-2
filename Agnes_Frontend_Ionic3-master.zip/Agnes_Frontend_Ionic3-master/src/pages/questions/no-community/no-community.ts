import { Component, ViewChild } from '@angular/core';
import { Platform, Events, NavController, NavParams, App, IonicPage, PopoverController } from 'ionic-angular';
import { MeService } from '../../../providers/me.service';

import { Agnes } from '../../../app/app.component';


@IonicPage()
@Component({
  selector: 'no-community',
  templateUrl: 'no-community.html',
  providers: [MeService]
})


export class NoCommunityPage{

  user:Object;
  referralCode: string;
  launchCount: number;

  constructor(public navCtrl:NavController,
              private navParams: NavParams,
              private platform: Platform,
              private appCtrl: App,
              private meService: MeService,
              private popoverCtrl: PopoverController) {
  }

  ngOnInit() {

    this.user = this.navParams.get('user')
    console.log(this.user)

    this.retrieveCountdown()
    this.retrieveCode()

  }

  retrieveCountdown() {
    this.meService.getCommunityCount({'users_id' : this.user['_id'], 'token' : this.user['token']}).then(val => {
      this.launchCount = 100 - val['pplLength']
    }).catch(err => {
      console.log(err)
    })
  }


  retrieveCode() {
    this.meService.getReferral({'users_id' : this.user['_id']}).then(val => {
      this.referralCode = val['referralCode'].toUpperCase()
    }).catch(err => {
      console.log(err)
    })
  }

  closeNoCommunity() {
    this.appCtrl.getRootNav().push(
        'LoginPage',
        {}, {
          animation: 'ios-transition',
          duration: 350
        });
  }

  referFriends() {
    if (this.platform.is('cordova')) {

      let link = 'http://onelink.to/hrnse3';

      let message = this.user['fname'] + " just sent you 5 pebbles on Agnes. Create an account to apply them towards a free burrito! Agnes is the best way to find and do more on campus. Use referral code: "

      let subj = "Agnes: The new events app"

      message = message.concat(this.referralCode + '. ' + link)

      Agnes.socialSharing.share(message, subj, '', '')
          .then((val) => {
          })
          .catch((err) => {
            console.log(err)
          });
    } else {
      Agnes.showError("Please install Agnes from the App Store or Google Play store to share events.");
    }
  }

}

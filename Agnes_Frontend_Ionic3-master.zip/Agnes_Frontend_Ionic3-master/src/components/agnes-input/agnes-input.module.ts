import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';

import { AgnesInput } from './agnes-input';

@NgModule({
    declarations: [
        AgnesInput
    ],
    imports: [
        IonicPageModule.forChild(AgnesInput)
    ],
    exports: [
        AgnesInput
    ]
})

export class AgnesInputModule { }

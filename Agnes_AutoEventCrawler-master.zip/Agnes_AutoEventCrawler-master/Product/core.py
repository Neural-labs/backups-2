from argparser import arg_parser
from Modules.Collection.Calendar_Collection.calendarcollector import CalendarCollector
from Modules.Detection.detector import Detector
from Modules.Extraction.extractor import Extractor

def runCrawler(mcc=None, run_modules=None, ):

    if 'collection' in run_modules:
        collector = CalendarCollector()
        collector.run_collection()
        collector.run_classification()
    if 'detection' in run_modules:
        detector = Detector()

    if 'extraction' in run_modules:
        extractor = Extractor()

if __name__ == '__main__':
    args = vars(arg_parser.parse_args())

    runCrawler(run_modules=args['run_modules']
               )


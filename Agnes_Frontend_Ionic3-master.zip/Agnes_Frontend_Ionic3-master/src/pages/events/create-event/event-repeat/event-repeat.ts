import { Component } from '@angular/core';
import { NavParams, ViewController, IonicPage } from 'ionic-angular';
import { EventsService } from '../../../../providers/events.service';
import { Agnes } from '../../../../app/app.component';

@IonicPage()
@Component({
    selector: 'event-repeat',
    templateUrl: 'event-repeat.html',
    providers: [EventsService]
})

export class EventRepeat {
    frequency: string;
    repeatDays: Array<string>;
    stopAfter: Date;
    stopAfterDisplay: string;
    days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
    frequencies = ['none','daily', 'weekly', 'monthly'];

    constructor(public navParams: NavParams,
                private eventsService: EventsService,
                public viewCtrl: ViewController) {
    }

    ngOnInit(){
        this.frequency = this.navParams.data.repeatData['frequency'] ? this.navParams.data.repeatData['frequency'] : 'none';
        this.repeatDays = this.navParams.data.repeatData['repeatDays'] ? this.navParams.data.repeatData['repeatDays'] : [];
        this.stopAfter = this.navParams.data.repeatData['stopAfter'] ? this.navParams.data.repeatData['stopAfter'] : null;
        this.stopAfterDisplay = this.stopAfter ? this.stopAfter.toLocaleString() : '';
    }

    closeEventRepeat(hasRepeat){
        if(hasRepeat){
            if(this.frequency == 'none'){
                this.viewCtrl.dismiss({
                    'none': true
                });
            }
            else {
                if((this.frequency != '' || this.repeatDays.length > 0) && this.stopAfter == null){
                    document.querySelector('.endDate').classList.add('error');
                    //TODO: remove
                    this.viewCtrl.dismiss({
                        'frequency': this.frequency,
                        'repeatDays': this.repeatDays,
                        'stopAfter': this.stopAfter
                    });
                }
                else {
                    document.querySelector('.endDate').classList.remove('error');
                    this.viewCtrl.dismiss({
                        'frequency': this.frequency,
                        'repeatDays': this.repeatDays,
                        'stopAfter': this.stopAfter
                    });
                }
            }
        }
        else {
            this.viewCtrl.dismiss(false);
        }
    }

    //choose frequency (deselect completely if a frequency has been clicked twice)
    setFreq(freq){
        this.frequency = (this.frequency == freq || freq == 'none' ? 'none' : freq);
        if(this.frequency != 'weekly'){this.repeatDays = [];}
    }

    //add or remove day from repeat days array
    toggleRepeatDay(day){
        let ind = this.repeatDays.indexOf(day);
        if(ind == -1){this.repeatDays.push(day);}
        else {this.repeatDays.splice(ind,1);}
    }

    //set end date for repeats
    openDatePicker(){
        let d = new Date();
        let current = this.stopAfter == null ? d : new Date(this.stopAfter);
        Agnes.datePicker.show({
            date: current,
            mode: 'date',
            titleText: 'Repeat ends on:',
            minDate: d,
            maxDate: new Date().setFullYear(d.getFullYear() + 1),
            androidTheme: Agnes.datePicker.ANDROID_THEMES.THEME_DEVICE_DEFAULT_DARK,
            allowOldDates: false
        }).then(
            date => {
                if(date){
                    this.stopAfter = new Date(date);
                    this.stopAfterDisplay = this.stopAfter.toLocaleDateString();
                }
            },
            err => console.log('Error occurred while getting date: ', err)
        );
    }

}

// import { browser, element, by } from 'protractor';
//
// import { LoginPageObject } from './page-objects/login.page-object';
//
// let loginPage = new LoginPageObject();
//
//
// describe('Password Popup test (from login) - basics', () => {
//
//     browser.waitForAngularEnabled(false);
//     browser.get('');
//     loginPage.getLoginButton().click();
//     browser.driver.sleep(500);
//     browser.driver.sleep(500);
//
//     let title = passwordPopup.getTitle();
//     let submit = passwordPopup.getSubmitButton();
//
//     it('bottom button reads Next', () => {
//         expect(submit.getText()).toContain('Next');
//         expect(submit.getText()).not.toContain('Submit');
//     });
//
//     it('title is Forgot Password', () => {
//         expect(title).toContain('Forgot Password');
//     });
//
//
//     it('click back button => Login Popup present, Password Popup gone', () => {
//
//         browser.driver.sleep(1000);
//         passwordPopup.getBackButton().click();
//         browser.driver.sleep(500);
//
//         expect(element(by.css('password-popup')).isPresent()).toBeFalsy();
//
//     });
//
// });
//
// describe('Password Popup test (from login) - submitting', () => {
//     browser.waitForAngularEnabled(false);
//     browser.get('');
//     loginPage.getLoginButton().click();
//     browser.driver.sleep(500);
//     browser.driver.sleep(500);
//
//
//     let email = passwordPopup.getInput('Email');
//     let confirm = passwordPopup.getInput('Confirm');
//     let newp = passwordPopup.getInput('New');
//     let verify = passwordPopup.getInput('Verify');
//
//     let submit = passwordPopup.getSubmitButton();
//
//     let emailError = passwordPopup.getError('email');
//     let passcodeError = passwordPopup.getError('passcode');
//     let passwordError = passwordPopup.getError('password');
//     let verifyError = passwordPopup.getError('verify');
//
//     it('Next: no email => email error: enter valid .edu address', () => {
//         passwordPopup.getSubmitButton().click();
//         browser.driver.sleep(500);
//         expect(emailError.getAttribute('class')).toContain('active');
//         expect(emailError.getText()).toContain('Please enter a valid .edu email address');
//         browser.driver.sleep(1000);
//     });
//
//     it('Next: wrong email format => email error: enter valid .edu address', () => {
//
//
//         passwordPopup.getSubmitButton().click();
//         browser.driver.sleep(500);
//         expect(emailError.getAttribute('class')).toContain('active');
//         expect(emailError.getText()).toContain('Please enter a valid .edu email address');
//
//     });
//
//     it('Next: right email format, bad email => email error: email not on file', () => {
//
//     });
//
//     it('Next: right email format, good email => goes to next slide', () => {
//
//     });
// });
//
//
// //
// // describe('Password Popup test (from settings)', () => {
// //
// //     browser.waitForAngularEnabled(false);
// //     browser.get('');
// //     loginPage.getLoginButton().click();
// //     browser.driver.sleep(500);
// //     loginPopup.getForgotPasswordButton().click();
// //     browser.driver.sleep(500);
// //
// //     beforeEach(() => {
// //     });
// //
// //     it('')
// //
// //
// //     it('click back button => Login Popup present, Password Popup gone', () => {
// //
// //         browser.driver.sleep(1000);
// //         loginPopup.getBackButton().click();
// //         browser.driver.sleep(500);
// //
// //         expect(element(by.css('.ion-page.show-page ion-content')) // Grab the title of the selected tab
// //             .getAttribute('id')) // Get the text content
// //             .toContain('loginPage'); // Check if it contains the text "Home"
// //
// //     });
// //
// //
// //     // it('click Signup with email button => goes to Questions page', () => {
// //     //
// //     //     browser.driver.sleep(1000);
// //     //     loginPopup.getSignupButton().click();
// //     //     browser.driver.sleep(2000);
// //     //
// //     //     expect(element(by.css('.ion-page.show-page ion-content')) // Grab the title of the selected tab
// //     //         .getAttribute('id')) // Get the text content
// //     //         .toContain('questions'); // Check if it contains the text "Home"
// //     //
// //     // });
// //     //
// //     // it('click (?) button => opens Forgot Password popup', () => {
// //     //     loginPopup.getForgotPasswordButton().click();
// //     //     browser.driver.sleep(500);
// //     //     let changePassword = element(by.css('password-popup'));
// //     //     expect(changePassword.isPresent()).toBeTruthy();
// //     // });
// //     //
// //     // it('click Login: no info => BOTH email and pw error', () => {
// //     //
// //     //     loginPopup.getLoginButton().click();
// //     //
// //     //     expect(element(by.id('loginEmailError')).getAttribute('class')).toContain('active');
// //     //     expect(element(by.id('loginPasswordError')).getAttribute('class')).toContain('active');
// //     //
// //     // });
// //     //
// //     // it('click Login: email, no pw => ONLY pw error', () => {
// //     //
// //     //
// //     //     browser.driver.actions().mouseDown(email).click().sendKeys("becca@gmail.com").perform();
// //     //     browser.driver.sleep(500);
// //     //     loginPopup.getLoginButton().click();
// //     //
// //     //     expect(element(by.id('loginEmailError')).getAttribute('class')).not.toContain('active');
// //     //     expect(element(by.id('loginPasswordError')).getAttribute('class')).toContain('active');
// //     //
// //     // });
// //     //
// //     // it('click Login: email, incorrect pw format => ONLY pw error', () => {
// //     //
// //     //
// //     //     browser.driver.actions().mouseDown(email).click().sendKeys("becca@groupten.com").perform();
// //     //     browser.driver.actions().mouseDown(password).click().sendKeys("123").perform();
// //     //
// //     //     browser.driver.sleep(500);
// //     //     loginPopup.getLoginButton().click();
// //     //
// //     //     expect(element(by.id('loginEmailError')).getAttribute('class')).not.toContain('active');
// //     //     expect(element(by.id('loginPasswordError')).getAttribute('class')).toContain('active');
// //     //
// //     // });
// //     //
// //     // it('click Login: email does not exist, correct pw format => ALERT not exist', () => {
// //     //
// //     //
// //     //     browser.driver.actions().mouseDown(email).click().sendKeys("becca@gmail.com").perform();
// //     //     browser.driver.actions().mouseDown(password).click().sendKeys("1234567").perform();
// //     //
// //     //     browser.driver.sleep(500);
// //     //     loginPopup.getLoginButton().click();
// //     //     browser.driver.sleep(500);
// //     //
// //     //     expect(loginPopup.getAlert().getText()).toContain('Agnes does not have your email on file');
// //     //
// //     // });
// //     //
// //     // it('click Login: email does exist, wrong password => ALERT incorrect password', () => {
// //     //
// //     //
// //     //     browser.driver.actions().mouseDown(email).click().sendKeys("becca@groupten.com").perform();
// //     //     browser.driver.actions().mouseDown(password).click().sendKeys("adfduakdjhf").perform();
// //     //
// //     //     browser.driver.sleep(500);
// //     //     loginPopup.getLoginButton().click();
// //     //     browser.driver.sleep(500);
// //     //
// //     //     expect(loginPopup.getAlert().getText()).toContain('Password is incorrect');
// //     //
// //     // });
// //     //
// //     // it('click Login: email does exist, correct password, account NOT activated => ALERT not active', () => {
// //     //
// //     //
// //     //     browser.driver.actions().mouseDown(email).click().sendKeys("beccatest@groupten.com").perform();
// //     //     browser.driver.actions().mouseDown(password).click().sendKeys("alalalal").perform();
// //     //
// //     //     browser.driver.sleep(500);
// //     //     loginPopup.getLoginButton().click();
// //     //     browser.driver.sleep(500);
// //     //
// //     //     expect(loginPopup.getAlert().getText()).toContain('Please activate your account');
// //     //
// //     // });
// //     //
// //     // it('click Login: email does exist, correct password, account activated => goes to events page', () => {
// //     //
// //     //
// //     //     browser.driver.actions().mouseDown(email).click().sendKeys("becca@groupten.com").perform();
// //     //     browser.driver.actions().mouseDown(password).click().sendKeys("alalalal").perform();
// //     //
// //     //     browser.driver.sleep(500);
// //     //     loginPopup.getLoginButton().click();
// //     //
// //     //     browser.driver.sleep(3000);
// //     //     expect(element(by.css('.ion-page.show-page ion-content')) // Grab the title of the selected tab
// //     //         .getAttribute('id')) // Get the text content
// //     //         .toContain('eventsContent'); // Check if it contains the text "Home"
// //     //
// //     // });
// //
// // });
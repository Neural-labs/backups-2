"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var core_1 = require('@angular/core');
var forms_1 = require('@angular/forms');
var login_service_1 = require('../../login/login.service');
var me_service_1 = require('../../me/me.service');
var PasswordPopup = (function () {
    function PasswordPopup(navCtrl, loginService, meService, viewCtrl, formBuilder, toastCtrl, navParams) {
        this.navCtrl = navCtrl;
        this.loginService = loginService;
        this.meService = meService;
        this.viewCtrl = viewCtrl;
        this.formBuilder = formBuilder;
        this.toastCtrl = toastCtrl;
        this.navParams = navParams;
        this.form = this.formBuilder.group({
            passcode: ['', [forms_1.Validators.required]],
            password: ['', [forms_1.Validators.required, forms_1.Validators.minLength(7)]],
            verify: ['', [forms_1.Validators.required, forms_1.Validators.minLength(7)]]
        });
    }
    PasswordPopup.prototype.ngOnInit = function () {
        this.slides.lockSwipes(true);
        this.email = '';
        this.loading = false;
        this.buttonText = "Next";
        this.hasEmailError = false;
        this.emailError = "Please enter a valid .edu email address";
        this.type = this.navParams.data.type;
        this.user = this.navParams.data.user;
        this.passcodeText = (this.type == 'Forgot') ? 'Passcode' : 'Password';
    };
    //make sure popover is not shifted to the left
    PasswordPopup.prototype.ngAfterViewInit = function () {
        window.setTimeout(function () {
            for (var e = 0; e < document.getElementsByClassName('popover-content').length; e++) {
                document.getElementsByClassName('popover-content')[e]['style']['left'] = '0px';
            }
        }, 0);
    };
    PasswordPopup.prototype.closePasswordPopup = function () {
        this.viewCtrl.dismiss(false, {}, {
            animate: true,
            animation: 'ios-transition',
            duration: 350,
            easing: "ease-in-out",
            direction: "back"
        });
    };
    PasswordPopup.prototype.submit = function () {
        var _this = this;
        //TODO: close keyboard
        var ind = this.slides.getActiveIndex();
        //on submitting email page
        if (ind == 0 && this.type == 'Forgot') {
            var emailValid = this.email.match(/.+@.+[.]edu\b/) || (this.email.match(/.+@.+[.].{2,3}\b/) && this.email.indexOf('groupten') != -1);
            if (!emailValid) {
                this.emailError = "Please enter a valid .edu email address";
                this.hasEmailError = true;
            }
            else {
                this.hasEmailError = false;
                var data = { "email_id": this.email };
                this.loading = true;
                this.loginService.forgotPassword(data).then(function (value) {
                    _this.loading = false;
                    if (value) {
                        _this.hasEmailError = false;
                        _this.buttonText = "Submit";
                        _this.slides.lockSwipes(false);
                        _this.slides.slideNext();
                        _this.slides.lockSwipes(true);
                    }
                    else {
                        _this.emailError = "Looks like Agnes doesn't have your email on file - try again or try signing up!";
                        _this.hasEmailError = true;
                    }
                });
            }
        }
        else {
            if (this.form.valid && (this.form.controls['verify'].value == this.form.controls['password'].value)) {
                //user forgot password
                if (this.type == 'Forgot') {
                    //tracking
                    if (window['fabric']) {
                        window['fabric'].Answers.sendCustomEvent('Forgot Password', { type: 'forgot pw submit' });
                    }
                    var data = {
                        "email_id": this.email,
                        "passcode": this.form.controls['passcode'].value,
                        "password": this.form.controls['password'].value
                    };
                    this.loginService.checkPasscode(data)
                        .then(function (value) {
                        if (value) {
                            //password reset was a success, send to events
                            _this.hasEmailError = false;
                            var user = JSON.stringify(value);
                            localStorage.setItem("agnesUser", user);
                            _this.toastCtrl.create({
                                message: 'Password successfully reset!',
                                duration: 4000,
                                position: 'bottom'
                            }).present();
                            _this.viewCtrl.dismiss(value);
                        }
                        else {
                            document.getElementById('passcodeError').classList.add('active');
                        }
                    }).catch(function (err) { document.getElementById('passcodeError').classList.add('active'); });
                }
                else {
                    //tracking
                    if (window['fabric']) {
                        window['fabric'].Answers.sendCustomEvent('Forgot Password', { type: 'change pw submit' });
                    }
                    var data = {
                        "users_id": this.user['_id'],
                        "new_password": this.form.value['password'],
                        "old_password": this.form.value['passcode']
                    };
                    this.meService.changePassword(data).then(function (value) {
                        if (value) {
                            _this.toastCtrl.create({
                                message: 'Password successfully changed!',
                                duration: 4000,
                                position: 'bottom'
                            }).present();
                            _this.viewCtrl.dismiss(value);
                        }
                        else {
                            document.getElementById('passcodeError').classList.add('active');
                        }
                    }).catch(function (err) {
                        document.getElementById('passcodeError').classList.add('active');
                    });
                }
            }
            else {
                if (!this.form.controls["password"].valid) {
                    document.getElementById('passwordError').classList.add('active');
                }
                else {
                    document.getElementById('passwordError').classList.remove('active');
                    var match = this.form.controls["verify"].valid &&
                        (this.form.controls['verify'].value == this.form.controls['password'].value);
                    if (!match) {
                        document.getElementById('verifyError').classList.add('active');
                    }
                    else {
                        document.getElementById('verifyError').classList.remove('active');
                    }
                }
                if (!this.form.controls['passcode'].valid) {
                    document.getElementById('passcodeError').classList.add('active');
                }
                else {
                    document.getElementById('passcodeError').classList.remove('active');
                }
            }
        }
    };
    __decorate([
        core_1.ViewChild('passwordPopupSlides')
    ], PasswordPopup.prototype, "slides", void 0);
    PasswordPopup = __decorate([
        core_1.Component({
            selector: 'password-popup',
            templateUrl: 'password-popup.html',
            providers: [login_service_1.LoginService, me_service_1.MeService]
        })
    ], PasswordPopup);
    return PasswordPopup;
}());
exports.PasswordPopup = PasswordPopup;

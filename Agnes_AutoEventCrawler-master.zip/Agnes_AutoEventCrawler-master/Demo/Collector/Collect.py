from Utility_Modules import URLFilter, DataFilter
from multiprocessing import JoinableQueue, cpu_count, Pool
from bs4 import BeautifulSoup
import requests
import tldextract

global event_html_list

def collect_pages(source):
    global event_html_list

    calendar_urls = getCalendarPages(source)

    event_html_list = []

    count = 0
    for cal_url in calendar_urls:
        cal_html = getHTML(cal_url)

        if not cal_html:
            print 'Invalid Calendar:',cal_url
            continue

        print 'Collecting Calendar:',cal_url,'\n'
        print 'Events Found:'
        event_links = getLinks(cal_url, cal_html, source)
        for link in event_links:
            count += 1
            # queue.put(link)
            event_html = getHTML(link)
            if event_html:
                print link
                event_html_list.append((link, event_html))
        print

    return event_html_list

def worker_main(queue):
    global event_html_list
    print 'Worker alive and ready to receive work'
    while True:
        url = queue.get(True)
        html = getHTML(url)

        if html:
            print 'Finished',url
            event_html_list.append((url,event_html_list))

        queue.task_done()

def getHTML(url):
    try:
        HTML = requests.get(url).text
    except Exception as e:
        print 'Failed to retrieve:',url
        print e
        return None
    return HTML

def getCalendarPages(source):
    if source == 'usgbc.org':
        return ['https://www.usgbc.org/events','https://www.usgbc.org/events?page=1','https://www.usgbc.org/events?page=2']
    elif source == 'peabody.harvard.edu':
        return ['https://www.peabody.harvard.edu/events']
    elif source == 'gsas.harvard.edu':
        return ['https://gsas.harvard.edu/events']
    elif source == 'linguistics.fas.harvard.edu':
        return ['https://linguistics.fas.harvard.edu/calendar/upcoming']
    elif source == 'hls.harvard.edu':
        return ['http://hls.harvard.edu/calendar/list/']
    else:
        raise ValueError('source invalid')

def getLinks(cal_url, cal_html, source):
    if source == 'usgbc.org':
        link_list = URLFilter.getPageLinks(cal_url, cal_html, source)
        return [link for link in link_list if 'https://www.usgbc.org/event/' in link]
    elif source == 'peabody.harvard.edu':
        return getPeabodyEvents(cal_url, cal_html)
    elif source == 'gsas.harvard.edu':
        return getGSASEvents(cal_url, cal_html)
    elif source == 'linguistics.fas.harvard.edu':
        return getHarvardFASLinguistics(cal_url, cal_html)
    elif source == 'hls.harvard.edu':
        return getHarvardLaw(cal_url, cal_html)
    else:
        raise ValueError('source invalid')

def getPeabodyEvents(cal_url, cal_html):
    selector = 'div > div > div.views-row > div.views-field.views-field-title > h2 > a'
    event_urls = getEventURLS0(cal_url, cal_html, selector)
    return event_urls

def getGSASEvents(cal_url , cal_html):
    selector = '#block-views-events-block > div > div > div > div.view-content > div > div > div.field.field-name-title > a'
    event_urls = getEventURLS0(cal_url, cal_html, selector)
    return event_urls

def getHarvardFASLinguistics(cal_url, cal_html):
    selector = 'div.event-content > header > h1 > a'
    event_urls = getEventURLS0(cal_url, cal_html, selector)
    return event_urls

def getHarvardLaw(cal_url, cal_html):
    selector = 'div.tribe-events-list-event-description.tribe-events-content.description.entry-summary.context-body > a'
    event_urls = getEventURLS0(cal_url, cal_html, selector)
    return event_urls

def getEventURLS0(cal_url, cal_html, selector):
    soup = DataFilter.removeBadThings(cal_html)
    a_tags = soup.select(selector)
    event_urls = []
    for a_tag in a_tags:
        href = a_tag['href']
        link = URLFilter.convertToAbsolute(cal_url, href)
        event_urls.append(link)
    return event_urls
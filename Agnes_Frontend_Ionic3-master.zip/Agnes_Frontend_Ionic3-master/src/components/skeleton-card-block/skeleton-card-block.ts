import { Component, Input } from '@angular/core';

@Component({
  selector: 'skeleton-card-block',
  templateUrl: 'skeleton-card-block.html'
})
export class SkeletonCardBlockComponent {

  @Input() type: string;

  constructor() {
  }

}

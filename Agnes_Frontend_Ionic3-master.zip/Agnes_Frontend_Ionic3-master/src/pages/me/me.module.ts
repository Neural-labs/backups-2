import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';

import { MePage } from './me';
import { ComponentsModule } from '../../components/components.module';
import { SuperTabsModule } from 'ionic2-super-tabs';

@NgModule({
  declarations: [
    MePage
  ],
  imports: [
    IonicPageModule.forChild(MePage),
    ComponentsModule,
    SuperTabsModule
  ],
  exports: [
    MePage
  ]
})

export class MePageModule { }

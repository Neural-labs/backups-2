import redis

r = redis.Redis(
    host='localhost',
    port='6379'
)

r.sadd('set1','bar')
r.srem('set1','bar')
value = r.sismember('set1','bar')
print value
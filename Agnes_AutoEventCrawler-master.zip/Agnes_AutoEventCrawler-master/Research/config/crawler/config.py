DATA_SEARCH = [
    'evt',
    'event'
]

MAX_DEPTH = 9
MAX_COUNT = 50000

HomePage = 'http://vt.edu'
Domain = 'vt'


import { Component, ViewChild } from '@angular/core';
import { Content, Platform, Events, IonicPage, App, Slides } from 'ionic-angular';
import { FormControl } from '@angular/forms';
import { EventsService } from '../../providers/events.service';
import { MeService } from '../../providers/me.service';

import { Agnes } from '../../app/app.component';

declare var google: any;

@IonicPage()
@Component({
  selector: 'page-events',
  templateUrl: 'events.html',
  providers: [EventsService, MeService]
})

export class EventsPage {

  matchedEvents: Array<Object>;
  nowEvents: Array<Object>;
  allEvents: Array<Object>;
  allDates: Array<Object>;

  searchedEvents: Array<Object>;
  searchedDates: Array<Object>;

  eventLocationReq: string;

  user: Object;
  loading: boolean;
  initializing: boolean;
  searching: boolean;
  noInternet: boolean;
  refreshEnabled: boolean;

  eventSearch: string;
  filterDate: any;
  gettingMore: boolean;
  orientation: string;
  spinner: boolean;
  noContent: boolean;

  today: string;
  tomorrow: string;

  storedAll: Array<Object>;

  searchControl: FormControl;
  batchNum: number;


  @ViewChild('discoverEventsContent') content: Content;
  @ViewChild('mapEventSlides') slides:Slides;

  constructor(private eventsService: EventsService,
              private meService: MeService,
              public appCtrl: App,
              private events: Events,
              private platform: Platform){
    this.searchControl = new FormControl();
  }

  ngOnInit(){
    this.matchedEvents = [];
    this.allDates = [];
    this.nowEvents = [];

    this.user = JSON.parse(localStorage.getItem('agnesUser'));
    this.eventSearch = '';
    this.filterDate = '';
    this.gettingMore = false;
    this.loading = true;
    this.initializing = true;
    this.eventLocationReq = "on";
    this.noContent = false;
    this.refreshEnabled = true;

    //keep track of search batches
    this.batchNum = 0;

    let t = new Date();
    this.today = t.toDateString().match(/[a-zA-Z]{3} [a-zA-Z]{3} \d\d/)[0];
    this.today = this.today.replace(/([a-zA-Z]{3})(\s[a-zA-Z]{3}\s)(\d{2})/, "$1.$2$3");
    t.setDate(t.getDate() + 1);
    this.tomorrow = t.toDateString().match(/[a-zA-Z]{3} [a-zA-Z]{3} \d\d/)[0];
    this.tomorrow = this.tomorrow.replace(/([a-zA-Z]{3})(\s[a-zA-Z]{3}\s)(\d{2})/, "$1.$2$3");

    this.initEvents()


    this.events.subscribe('resumeApp', function() {
        this.initEvents();
    })
    //search from Tabs search bar
    this.events.subscribe('eventSearch', term => {
      this.eventSearch = term;
      this.searchByInput(0);
    });

    this.events.subscribe('resumeApp', () => {
      if(localStorage.getItem('agnesUser')) {this.initEvents();}
    });

    this.events.subscribe('removeFromMatched', event => {
      this.removeFromMatched(event);
    });

    this.events.subscribe('pushEvent', (data) => {
      this.pushAddedEvent(data,false);
    });

    //if an event has been added, update user
    this.events.subscribe('goingDone', event => {
      if(event){
        //make sure user is updated
        this.user = JSON.parse(localStorage.getItem('agnesUser'));

        if(this.user['evtrsvp'].indexOf(event['_id']) == -1) {
          this.user['evtrsvp'].push(event['_id']);
          localStorage.setItem('agnesUser',JSON.stringify(this.user));
        }
        this.removeFromMatched(event);
      }
    });

    //refresh Discover if user goes to, edits, or deletes an event after opening event profile
    this.events.subscribe('eventProfileData', (data) => {
      if(data.category == 'going'){
        this.user = data.user;
      }
      else if (data.category == 'edit' || data.category == 'delete') {
        localStorage.removeItem('agnesMatchedEvents');
        localStorage.removeItem('agnesEventsTimeout');
        this.getMatchedEvents(null);
      }
    });
  }

  //save matched events in local storage when exiting page
  //in case something was changed (i.e. event attended, deleted, created, edited, etc.)
  ionViewWillLeave() {
    localStorage.setItem('agnesMatchedEvents', JSON.stringify(this.matchedEvents));
  }

  initEvents(){
    if(!Agnes.network || Agnes.network.type != 'none'){
      this.loading = true;
      this.noInternet = false;
      let searchTerm = localStorage.getItem("agnesEventSearch");
      if (searchTerm){
        this.eventSearch = searchTerm;
        this.searchByInput(0);
      }
      else {
        this.getMatchedEvents(null);
        this.getOnCampusEvents(null);
        this.getNowEvents(null);
      }
      this.getFriends();
    }
    else {
      //lack of internet connection - show Tap to Refresh div
      this.noInternet = true;
      let matched = JSON.parse(localStorage.getItem('agnesMatchedEvents'));
      this.matchedEvents = matched ? matched : [];
    }
  }

  //disable/enable pull-to-refresh depending on whether you are currently touching the sideways scroll div
  enableRefresh(enable){
    this.refreshEnabled = enable;
  }

  /*************************************************************************************************************/
  /*************************************** main loading functions **********************************************/
  /*************************************************************************************************************/


  getNowEvents(refresher) {
    let date = new Date()
    let curr = date.getTime()
    let then = date.getTime()+60000
    let data = {'users_id' : this.user['_id'], 'community' : this.user['community'], 'starttime':date.toISOString()}
    this.eventsService.eventsByDate(data).then(val => {
      if(val) {
        for(let v of val) {
        let start = new Date(v['starttime'].replace(/[-\+]\d\d\d\d/, "Z")).getTime()
        let end = new Date(v['endtime'].replace(/[-\+]\d\d\d\d/, "Z")).getTime()
        // determining if an event is within the next hour via javascript milliseconds
        if((start <= then) && (end >= curr)){
          this.nowEvents.push(v)
        }
      }
      this.processEvents(this.nowEvents, false, 'now')
    }
    }).catch(err => {
      console.log(err)
    })
  }

  //get user's matched events
  getMatchedEvents(refresher) {
    let data = {'id' : this.user['_id'], 'community' : this.user['community']}
      this.eventsService.getMatchedEvents(data)
          .then(matched => {
            if (refresher) {
              this.gettingMore = false;
              refresher.complete();
            }
            if(matched['success'] || (matched && matched.length > 0)){
              this.processEvents(matched, false, 'matched');
              this.loading = false;
              this.noInternet = false;
              localStorage.setItem('agnesMatchedArray', JSON.stringify(matched));
              localStorage.setItem('agnesMatchedEvents', JSON.stringify(this.matchedEvents));
              localStorage.setItem('agnesEventsTimeout', JSON.stringify(new Date()));
            }
            else {
              this.getMatchedEvents(refresher);
            }
          })
          .catch(error => {
            if (refresher) {
              this.gettingMore = false;
              refresher.complete();
            }
            this.loading = false;
            this.initializing = false;
            this.noInternet = true;
            console.log(error);
            // Agnes.showError('Could not get your matched events - try dragging to refresh the page');
              Agnes.showError("Uh oh. We lost connection.");
          });
  }

  //get all community events from database
  getOnCampusEvents(refresher){
    this.eventsService.onCampusEvents(this.user['_id'], this.user['community'])
        .then(allEvents => {
          if(refresher){
            this.gettingMore = false;
            refresher.complete();
          }
          this.noInternet = false;
          this.processEvents(allEvents, false, 'all');
        })
        .catch(error => {
          this.loading = false;
          this.noInternet = true;

          if(refresher){
            this.gettingMore = false;
            refresher.complete();
          }

          console.log(error);
          // Agnes.showError('Could not get events - try dragging to refresh the page');
          Agnes.showError("Uh oh. We lost connection.");
        });
  }

  getOffCampusEvents(refresher){
      this.eventsService.offCampusEvents(this.user['_id'], this.user['community'])
          .then(allEvents => {
            if(refresher){
              this.gettingMore = false;
              refresher.complete();
            }
            this.noInternet = false;
            this.processEvents(allEvents, false, 'all');
          })
          .catch(error => {
            this.loading = false;
            this.noInternet = true;
            console.log(error);
            // Agnes.showError('Could not get events - try dragging to refresh the page');
            Agnes.showError("Uh oh. We lost connection.");
          });
    }


  //process events for display
  processEvents(events, loadingMore, type){

    events = events.filter(a => {return (a != null && (a['evttype'] && a['evttype'] == 'public') || !a['evttype'])});
    if(!loadingMore){
      this[type+'Events'] = [];
    }

    for (let v in events){
      if (events[v] && typeof(events[v])=='object'){
        if (this[type+'Events'].map(function (a) {return a["_id"];}).indexOf(events[v]["_id"]) == -1){
          this[type+'Events'].push(events[v]);
        }
      }
    }

    //lets put these events in the date and display array!
    this.displayEvents(loadingMore, type);

    if(type=='matched') {
      localStorage.setItem('agnesMatchedEvents', JSON.stringify(this.matchedEvents));
      localStorage.setItem('agnesEventsTimeout', JSON.stringify(new Date()));
    }
  }

  //add events to Dates arrays and display array (only used for search and browse events)
  displayEvents(loadingMore, type){
    if (!loadingMore) {
      this[type+'Dates'] = [];
    }

    let lastDateIndex = loadingMore ? this[type+'Dates'].length : 0;

    if(type == 'searched' || type == 'all'){
      if(this[type+'Events'].length == 0)
      {
        console.log('no content here')
        this.noContent = true;
      }
    }
    else {
      this.noContent = false;
    }

    for (let e in this[type+'Events']) {
      let event = this[type+'Events'][e];
      if (this.isValidEvent(event)) {
        let eventDateTime = this.getEventTime(event)
        let displayedDate = this.getDisplayDate(eventDateTime)
        let displayedTime = this.getDisplayTime(event)
        let dateIndex = this.getDateIndex(type,displayedDate)
        if (this.isInvalidDateIndex(dateIndex)) {
          let newDate = {
            "id": lastDateIndex,
            "date":displayedDate,
            "events": [{
              "time": displayedTime,
              "event": event
            }],
            "ISOdate": eventDateTime
          }
          this.addDate(type,newDate)
          lastDateIndex++
        }
        else {
          let Date = this[type+'Dates'][dateIndex]
          if (this.eventNotInDate(Date,event)) {
            let ev = {
              "time":displayedTime,
              "event": event
            };
            this.addEventToDate(type,ev,dateIndex)
          }
        }

      }

    }
    this.sortDates(type);
    this.loading = false;
  }

  //refresh events ist
  refreshEvents(refresher) {
    if(!Agnes.network || Agnes.network.type != 'none'){
      this.events.publish('updateUser');
      this.events.subscribe('updateDone',() => {
        this.events.unsubscribe('updateDone');
        this.filterDate = '';
        this.user = JSON.parse(localStorage.getItem('agnesUser'));

        this.getFriends();

        if(this.eventSearch.trim() != ''){
          this.searchByInput(0,refresher);
        }
        else {
          if(this.eventLocationReq == "on") {
            this.getOnCampusEvents(refresher);
          } else {
            this.getOffCampusEvents(refresher);
          }
        }
      });
    }
    else {
      //lack of internet connection - alert
      Agnes.showError('You are offline! Try refreshing again when you reconnect.');
      refresher.complete();
      this.gettingMore = false;
    }
  }

  //load more events for searching or All Events list
  loadMoreEvents(infiniteScroll){

    this.gettingMore = true;

    if(this.eventSearch != ''){
      this.batchNum += 1;
      this.searchByInput(this.batchNum,infiniteScroll);
    }
    else if (this.allDates && this.allDates.length > 0) {
      let lastDate = this.allDates.length-1;
      let eventLength = this.allDates[lastDate]["events"].length;
      let lastEvent = this.allDates[lastDate]["events"][eventLength-1];
      let lastTime = lastEvent.event.starttime;
      let lastId = lastEvent.event._id;

      let data = {"starttime": lastTime, "community": this.user["community"], "_id":lastId};

      if(this.eventLocationReq == "on") {
          this.eventsService.loadMoreOnCampusEvents(data)
              .then(moreEvents => {
                if(infiniteScroll) {
                  infiniteScroll.complete();
                  this.gettingMore = false;
                }
                if (moreEvents && moreEvents.length > 0){
                  this.processEvents(moreEvents, true, 'all');
                }
                else {
                  if(infiniteScroll){
                    this.gettingMore = false;
                    infiniteScroll.enable(false);
                  }
                }
              }).catch(error => {
            console.log(error);
            infiniteScroll.complete();
            this.gettingMore = false;
            // Agnes.showError('Could not load more events - please try again');
            Agnes.showError("Uh oh. We lost connection.");
          });
      } else {
        this.eventsService.loadMoreOffCampusEvents(data)
            .then(moreEvents => {
              if(infiniteScroll) {
                infiniteScroll.complete();
                this.gettingMore = false;
              }
              if (moreEvents && moreEvents.length > 0){
                this.processEvents(moreEvents, true, 'all');
              }
              else {
                if(infiniteScroll){
                  this.gettingMore = false;
                  infiniteScroll.enable(false);
                }
              }
            }).catch(error => {
          console.log(error);
          infiniteScroll.complete();
          this.gettingMore = false;
          // Agnes.showError('Could not load more events - please try again');
          Agnes.showError("Uh oh. We lost connection.");
        });
    }
    }
  }

  //get user's fb friends for displaying on event cards
  getFriends(){
    let data = {
      "users_id": this.user['_id'],
      "community": this.user['community']
    };
    this.meService.getFriends(data).then(value => {
      this.loading = false;
      if(value.friends && value.friends.length > 0){
        this.user['fbfriends'] = value.friends.filter(a => {return a['_id'] != this.user['_id']});
      }
      else {
        this.user['fbfriends'] = [];
      }
      this.events.publish('sendFriendsToCard', this.user['fbfriends']);
    }).catch(err => {
      this.loading = false;
      console.log(err);
    });
  }


  /*************************************************************************************************************/
  /***************************************** filtering/searching ***********************************************/
  /*************************************************************************************************************/

  toggleMap() {
    this.appCtrl.getRootNav().push(
      'MapPage',
      {}, {
        animation: 'ios-transition',
        duration: 350
      });
  }

  toggleLocation() {
    if (this.eventLocationReq == "on") {
      this.eventLocationReq = "off";
      this.getOffCampusEvents(null);
    } else {
      this.eventLocationReq = "on";
      this.getOnCampusEvents(null);
    }
  }

  //filter events by date
  toggleDate(){
    if(this.filterDate != '') {
      this.filterDate = '';
      this.refreshEvents(null);
      this.content.scrollToTop(0);
    }
    else {
      let now = new Date();
      let d = this.filterDate == '' ? now : this.filterDate;
      Agnes.datePicker.show({
        date: d,
        mode: 'date',
        minDate: now,
        androidTheme: Agnes.datePicker.ANDROID_THEMES.THEME_DEVICE_DEFAULT_DARK,
        allowOldDates: false
      }).then(
          date => {
            if (date){
              if(date < new Date()){
                Agnes.showError("Sorry, you can't filter for dates before today!");
              }
              else {
                let d = Agnes.processGMT(date)['date'];
                this.filterDate = (d == this.today) ? "Today" : (d == this.tomorrow) ? "Tomorrow" : d;

                // date is not currently displayed - fetch from database
                if(this.allDates.map(a => {return new Date(a['date']['ISOdate'])}).indexOf(date) == -1) {
                  this.eventsByDate(date);
                }
              }
            }
          },
          err => console.log('Error occurred while getting date: ', err)
      );
    }
  }

  //search events by title or keywords
  searchByInput(batchNum, refresher?){

    //reset batch number for new searches
    if(batchNum == 0){this.batchNum = 0;}

    let canSearch = batchNum != this.batchNum || batchNum == 0;

    // if(this.isMatched){this.isMatched = false;}
    if (this.eventSearch && this.eventSearch.trim().length > 0 && canSearch) {

      if(this.batchNum == 0){this.searchedDates = [];}

      let data = {
        "searchTerm":this.eventSearch,
        "community":this.user["community"],
        "scroll": batchNum,
        "users_id": this.user['_id']
      };

      this.loading = true;

      this.eventsService.searchEvents(data)
          .then(value => {
            this.loading = false;

            if(value){
              let more = batchNum != 0;
              this.processEvents(value,more,'searched');
            }

            if(refresher){
              this.gettingMore = false;
              refresher.complete();
            }
          })
          .catch(error => {
            this.loading = false;
            console.log(error);
            if(refresher){
              this.gettingMore = false;
              refresher.complete();
            }
          });
    }
    else {
      this.content.scrollToTop(0);
      if(!this.eventSearch || this.eventSearch.trim() == '') {
        this.batchNum = 0;
      }
    }
  }

  /*************************************************************************************************************/
  /**************************************** Date / Event Helper Functions  *************************************/
  /*************************************************************************************************************/

  isValidEvent(event) {
    return event != null && typeof(event)=='object'
  }

  isInvalidDateIndex(dateIndex) {
    return dateIndex == -1
  }

  getEventTime(event) {
    return Agnes.processGMT(event["starttime"].replace(/[-\+]\d\d\d\d/,'Z'));
  }

  getDisplayDate(start) {
    return (start.date == this.today) ? "Today" : (start.date == this.tomorrow) ? "Tomorrow" : start.date;
  }

  getDisplayTime(event) {
    let start = Agnes.processGMT(event["starttime"].replace(/[-\+]\d\d\d\d/,'Z'));
    let end = Agnes.processGMT(event["endtime"].replace(/[-\+]\d\d\d\d/,'Z'));
    return (start.time == "12:01AM" ? "All Day" : start.time) + (start.time == '12:01AM' ? '' : ' - ' + end.time);
  }

  getDateIndex(type, displayedDate) {
    return this[type + 'Dates'].map(function (a) {return a["date"];}).indexOf(displayedDate);
  }

  addDate(type, newDate) {
    this[type + 'Dates'].push(newDate)
  }

  eventNotInDate(Date,event) {
    return Date["events"].map(function(a) {return a.event._id;}).indexOf(event["_id"]) == -1
  }

  addEventToDate(type, event, dateIndex) {
    this[type+'Dates'][dateIndex]['events'].push(event);
  }

  sortDates(type) {
    this[type+'Dates'].sort(function(a,b){
      let aDate = +new Date(a["ISOdate"]['date']);
      let bDate = +new Date(b["ISOdate"]['date']);
      return aDate - bDate;
    });
  }

  //get all events on given date
  eventsByDate(date){
    console.log("getting all events on given date", date);
    let data = {
      'users_id':this.user['_id'],
      'starttime':date.toISOString(),
      'community': this.user['community']
    };

    this.eventsService.eventsByDate(data).then(value => {
      if(value && value.length > 0) {
        this.processEvents(value,false,'all');
      }
    }).catch(err => {
      console.log('eBD err',err);
      // Agnes.showError('Couldn\'t get events by date - try again!');
      Agnes.showError("Uh oh. We lost connection.");
    })
  }

  //hide date block if it has no events listed (i.e. Free Food filter on but no events w/ free food for that date)
  hasChildren(dObj){
    // let type = this.isMatched ? 'matched' : 'all';
    let ind = this['all'+'Dates'].indexOf(dObj);
    if(ind != -1){let children = this['all'+'Dates'][ind]['events'].map(a => {return a['event']});
      return children.length != 0;
    }
  }

  /*************************************************************************************************************/
  /********************************** handle data from profile/editing *****************************************/
  /*************************************************************************************************************/

  //delete event from matched list
  removeFromMatched(event){
    let ind = this.matchedEvents.map(a => {return a['_id']}).indexOf(event['_id']);
    if(ind != -1) {
      this.matchedEvents.splice(ind,1);

      //reset local storage
      localStorage.setItem('agnesMatchedEvents',JSON.stringify(this.matchedEvents));
    }
  }

  //add created event to matched list
  pushAddedEvent(event,addToAll) {

    // event["evtname"] = this.getText(event["evtname"]);
    event["starttime"] = event["starttime"].replace(/[-\+]\d\d\d\d/, 'Z');
    event['displayurl'] = (event['displayurl'] == '')
        ? "assets/img/pattern_0.png" : event['displayurl'];

    let start = Agnes.processGMT(event['starttime']);
    let date = (start.date == this.today) ? "Today" : (start.date == this.tomorrow) ? "Tomorrow" : start.date;
    let time = start.time;

    let dInd = this['matchedDates'].map(function (a) {
      return a["date"];
    }).indexOf(date);

    //date doesn't exist yet
    if (dInd == -1) {
      let openDate = {
        "date": date,
        "events": [{
          "time": time,
          "event": event
        }],
        "ISOdate": event["starttime"]
      };

      this['matchedDates'].push(openDate);
    }
    else {
      //date does exist but event doesn't
      this['matchedDates'][dInd]["events"].push({
        "time": time,
        "event": event
      });
    }

    this['matchedDates'].sort(function (a, b) {
      var aDate = +new Date(a["ISOdate"]);
      var bDate = +new Date(b["ISOdate"]);
      return aDate - bDate;
    });

    for (var d in this['matchedDates']) {
      this['matchedDates'][d]["events"].sort(function (a, b) {
        let x = new Date(a.event.starttime.replace(/[-\+]\d\d\d\d/, "Z")).getTime();
        let y = new Date(b.event.starttime.replace(/[-\+]\d\d\d\d/, "Z")).getTime();
        return x - y;
      });
    }

    localStorage.setItem('agnesMatchedEvents', JSON.stringify(this.matchedEvents));

    this.appCtrl.getRootNav().push(
        'EventProfile',
        {
          'event': event,
          'type': 'all'
        }, {
          animation: 'ios-transition',
          duration: 350

        });
  }

}

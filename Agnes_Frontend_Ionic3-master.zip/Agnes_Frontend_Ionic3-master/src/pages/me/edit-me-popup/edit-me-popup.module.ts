import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { DirectivesModule } from '../../../directives/directives.module';

import { EditMePopup } from './edit-me-popup';

@NgModule({
    declarations: [
        EditMePopup
    ],
    imports: [
        IonicPageModule.forChild(EditMePopup),
        DirectivesModule
    ],
    exports: [
        EditMePopup
    ]
})

export class EditMePopupModule { }

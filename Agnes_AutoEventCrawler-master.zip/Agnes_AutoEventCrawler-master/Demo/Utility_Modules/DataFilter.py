# from config.crawler.config import DATA_SEARCH
import re

from bs4 import BeautifulSoup, Comment
from Utility_Modules import DateExtraction

DATA_SEARCH = [
    'event'
]

# DATA_KEYS = [
#     'link',
#     'tag',
#     'content',
#     'all'
# ]

URL_Keywords = [
    'event',

]

ValidTags = [
    'a',
    'abbr',
    'article',
    'aside',
    'b',
    'bdi',
    'blockquote',
    'body',
    'caption',
    'cite',
    'dd',
    'details',
    'dialogue',
    'div',
    'dl',
    'dt',
    'em',
    'embed',
    'fieldset',
    'figcaption',
    'figure',
    'form',
    'frame',
    'h1',
    'h2',
    'h3',
    'h4',
    'h5',
    'h6',
    'head',
    'header',
    'html',
    'i',
    'img',
    'ins',
    'label',
    'legend',
    'li',
    'main',
    'mark',
    'menu',
    'menuitem',
    'meta',
    'ol',
    'optgroup',
    'option',
    'p',
    'pre',
    'select',
    'small',
    'span',
    'strong',
    'sub',
    'summary',
    'sup',
    'table',
    'tbody',
    'td',
    'time',
    'title',
    'tr',
    'u',
    'ul'
]

ValidAttributes = [
    'class',
    'title',
    'datetime',
    'headers',
    'itemprop',
    'href',
    'content',
    'value',
    'summary',
    'id',
    'name'
]

ValidValues = [
    'event',
    'events',
    'date',
    'time',
    'details',
    'location',
    'venue',
    'description',
    'ticket',
    'map',
    'calendar',
    'headline'
    'title',
    'datetime',
    'field',
    'address',
    'locality',
    'postalcode',
]

ContentKeywords = [
    'event',
    'date',
    'location',
    'venue',
    'description',
    'ticket',
    'map',
    'calendar',
    'headline'
    'title',
    'datetime',
    'field',
    'topic',
    'calendar',
    'register',
    'registration',
    'details',
    'invite',
    'add to my cal',
    'event details',
    'category',
    'week',
    'month',
    'year'

]

NameKeywords = [
    'title',
    'name',
    'headline',
    'field',
    'event',
]

NameAttributes = [
    'class',
    'title',
    'headers',
    'href',
    'id',
    'name',
    'content'
]

badStrings = [
    'eventfulness',
    'preventability',
    'preventiveness',
    'uneventfulness',
    'eventualies',
    'preventatives',
    'preventative',
    'preventively',
    'uneventfully',
    'seventeenth',
    'seventeenth',
    'eventuality',
    'eventuating',
    'preventable',
    'preventible',
    'preventions',
    'seventieth',
    'eventually',
    'prevention',
    'preventive',
    'uneventful',
    'seventeens',
    'preventing',
    'eventuated',
    'eventuates',
    'preventers',
    'eventfully',
    'seventeen',
    'misevents',
    'prevented',
    'preventer',
    'elevenths',
    'eventless',
    'eventides',
    'prevent',
    'seventh',
    'seventy',
    'intimidate',
    'invalidate',
    'fluoridate',
    'revalidate',
    'transudate',
    'mithridate',
    'dilapidate',
    'depredated',
    'depredates',
    'fecundated',
    'fecundates',
    'elucidated',
    'elucidates',
    'candidates',
    'datelining',
    'outdatedly',
    'molybdates',
    'liquidated',
    'liquidates',
    'sedateness',
    'subcordate',
    'retardates',
    'periodates',
    'candidate',
    'elucidate',
    'liquidate',
    'molybdate',
    'depredate',
    'cuspidate',
    'periodate',
    'retardate',
    'obcordate',
    'fecundate',
    'excaudate',
    'emendated',
    'emendates',
    'foredated',
    'foredates',
    'denudated',
    'denudates',
    'chordates',
    'cordately',
    'datebooks',
    'antedated',
    'antedates',
    'lapidated',
    'lapidates',
    'inundated',
    'inundates',
    'playdates',
    'vanadates',
    'validated',
    'validates',
    'validate',
    'outdated',
    'dateline',
    'inundate',
    'datebook',
    'dateless',
    'postdate',
    'antedate',
    'backdate',
    'vanadate',
    'chordate',
    'acaudate',
    'denudate',
    'emendate',
    'exudates',
    'foredate',
    'gradated',
    'gradates',
    'ecaudate',
    'airdates',
    'caudated',
    'caudates',
    'dateable',
    'predated',
    'predates',
    'oxidated',
    'oxidates',
    'pedately',
    'playdate',
    'sedatest',
    'sedately',
    'incudate',
    'mandated',
    'mandates',
    'lapidate',
    'outdates',
    'misdated',
    'misdates',
    'updaters',
    'mandate',
    'undated',
    'predate',
    'exudate',
    'airdate',
    'caudate',
    'outdate',
    'gradate',
    'cordate',
    'misdate',
    'nidated',
    'nidates',
    'iodated',
    'iodates',
    'oxidate',
    'redatedredates',
    'sedated',
    'sedater',
    'sedates',
    'datedly',
    'updated',
    'updates',
    'updater',
    'update',
    'sedate',
    'iodate',
    'nidate',
    'pedate',
    'redate',
    'daters'
]
badTags = [
    'script',
    'style',
    'input',
    'head',
    'nav'
]

uselessTags = [
    'i',
    'b',
    'strong',
    'u',
    'br',
    'em'
]

badAttributes = [
    'style',
    'border',
    'colspan',
    'cellpadding',
    'cellspacing'
]


def getData(url,HTML):
    HTML = removeBadThings(HTML)
    soup = BeautifulSoup(HTML,"lxml")

    data = {}
    data['link'] = linkCount(url)
    data['tag'] = tagCount(soup)
    data['content'] = contentCount(soup)
    data['all'] = allCount(HTML)
    return data

def removeBadThings(HTML):

    HTML = ' '.join(HTML.split())
    for bad in badStrings:
        while bad in HTML:
            HTML = HTML.replace(bad,'')
    soup = BeautifulSoup(HTML,"lxml")
    for badContent in soup.find_all(badTags):
        badContent.extract()

    for comment in soup.findAll(text=lambda text: isinstance(text, Comment)):
        comment.extract()

    for tag in uselessTags:
        for match in soup.findAll(tag):
            match.unwrap()

    for x in soup.find_all():
        if 'name' in x and x.name == 'img':
            continue
        if len(x.text) == 0 or not [c for c in x.text if c.isalnum()]:
            x.extract()
    for tag in soup():
        for attr in tag.attrs.keys():
            if not validAttr(attr):
                del tag[attr]

    return soup

def linkCount(url):
    count = 0
    for word in DATA_SEARCH:
        count += url.lower().count(word)
    return count

def tagCount(soup):
    count = 0
    for tag in soup.find_all():
        if not validTag(tag):
            continue
        for word in DATA_SEARCH:
            if tag.name == 'meta':
                count += metaCount(tag,word)
            if 'class' in tag.attrs:
                count += classCount(tag['class'],word)
            if 'name' in tag.attrs:
                count += nameCount(tag['name'],word)
            if 'id' in tag.attrs:
                count += idCount(tag['id'],word)
            if 'href' in tag.attrs:
                count += hrefCount(tag['href'],word)
    return count

def validTag(tag):
    return tag in ValidTags

def validAttr(attr):
    return attr in ValidAttributes

def validValue(value):

    if len(DateExtraction.getDates(value)) > 0:
        return 'date'

    for keyword in ValidValues:
        if keyword in value:
            return keyword

    return False

# def getValue(value):
def validFeature((tag, attr, value)):
    if not validTag(tag):
        return False
    if not validAttr(attr):
        return False
    value = validValue(value)
    if not value:
        return False
    return (tag,attr,value)

def metaCount(meta_tag,word):
    content = meta_tag.get('content')
    if content:
        return content.lower().count(word)
    return 0

def contentCount(soup):
    count = 0
    for content in soup.stripped_strings:
        for word in DATA_SEARCH:
            count += content.lower().count(word)
    return count

def allCount(HTML):
    count = 0
    for word in DATA_SEARCH:
        count += HTML.lower().count(word)
    return count

def classCount(classes, word):
    count = 0
    for subClass in classes:
        count += int(subClass.lower().count(word))
    return count

def nameCount(name,word):
    return name.lower().count(word)

def idCount(id,word):
    return id.lower().count(word)

def hrefCount(href,word):
    return href.lower().count(word)


def invalidNode(node):
    return node.name not in ValidTags

def nodeAttrCount(node,keywords,regexes):

    count = 0
    count += nodeAttrKeywordCount(node,keywords)
    count += nodeAttrRegexCount(node,regexes)
    return count

def nodeAttrKeywordCount(node,keywords):
    count = 0
    if hasattr(node,'attrs'):
        for attr in node.attrs:
            for word in keywords:
                count += node.attrs[attr].lower().count(word)
    return count

def nodeAttrRegexCount(node,regexes):
    count = 0
    if hasattr(node,'attrs'):
        for attr in node.attrs:
            for regex in regexes:
                count += len(re.findall(regex,node.attrs[attr].lower()))
    return count

def getSingleCount(item,keywords):
    count = 0
    for word in keywords:
        count += item.lower().count(word)
    return count

def normalizeURL(url):
    url = convertToHTTP(url)
    url = removeEndSlash(url)
    return url

def convertToHTTP(url):
    if url[:5] == 'https':
        url = 'http'+url[5:]
    return url

def removeEndSlash(url):
    if url[-1] =='/':
        url = url[:-1]
    return url


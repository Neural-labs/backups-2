import { Component } from '@angular/core';
import { App, Events, PopoverController, ViewController, NavParams, IonicPage } from 'ionic-angular';
import { Agnes } from '../../../app/app.component';

import { AnalyticsService } from '../../../providers/analytics.service';

/**
 * card component for matched events and groups
 */

@IonicPage()
@Component({
    selector: 'news-profile',
    templateUrl: 'news-profile.html',
    providers: [AnalyticsService]
})
export class NewsProfile {

    user: Object;
    newsItem: Object;
    updatedOn: string;
    textLimit = 200;
    loading: boolean;
    noPic:boolean;

    constructor(public appCtrl: App,
                private events: Events,
                private viewCtrl: ViewController,
                private navParams: NavParams,
                private analyticsService: AnalyticsService,
                private popoverCtrl: PopoverController) {
    }

    ngOnInit(){
        this.user = JSON.parse(localStorage.getItem('agnesUser'));
        this.newsItem = this.navParams.get('newsItem');
        this.updatedOn = this.getUpdatedTime();
        this.loading = false;
        this.noPic = this.newsItem['picurl'] == '';

        this.setMenuButtons();

        //send News Profile view analytics
        this.analyticsService.logAnalytics({community: this.user['community'], users_id: this.user['_id']}, '/newsProfilePage');
    }

    setMenuButtons(){

    }

    closeNewsProfile(e){
        //send Back Button analytics
        this.analyticsService.logAnalytics({
            backButtonName: 'newsProfile',
            users_id: this.user['_id']}, '/backButton');

        if (!e || e.direction == 4){

            this.viewCtrl.dismiss(this.newsItem, '', {
                animation: 'ios-transition',
                duration: 350,
                easing: "ease-in-out",
                direction: "back"
            });
        }
    }

    getUpdatedTime(){
        let update = Agnes.processGMT(this.newsItem['date_published']);
        return update.date + ' at ' + update.time;
    }

    openOriginalPost(){
        window.open(this.newsItem['url']);
    }

    openNewsMenu(){

    }

    openRelatedEvent(){

    }

    readMore() {
        this.textLimit = this.textLimit == 200 ? 2000 : 200;
    }

    viewNewsPic(){
        if(!this.noPic){Agnes.photoViewer.show(this.newsItem['picurl']);}
    }

    newsPicError(){
        this.noPic = true;
    }
}

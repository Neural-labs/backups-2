from config import db_config
from Utilities import EventTree
from bson.binary import Binary
import pickle
import json
import sys
import time
import os
import gc
from multiprocessing import Pool, Queue, JoinableQueue, active_children, cpu_count
# from multiprocessing.dummy import Pool as ThreadPool
sys.setrecursionlimit(5000)

Agnes = db_config.getDBConn('dev').Agnes
Parent_Event_Collection = Agnes.autocrawler_events


def EventTreeCollection():
    print 'Starting Tree Collection...'

    NUM_THREADS = cpu_count()
    QUEUE_MAXSIZE = 50

    queue = JoinableQueue(QUEUE_MAXSIZE)

    pool = Pool(NUM_THREADS, worker_main,(queue,))

    counter = 0
    total = Parent_Event_Collection.count()
    batch_index = 0
    batch_size = 100
    last_id = None

    try:
        while batch_index < total:

            events = getEventBatch(last_id, batch_size)

            # no documents left
            if not events:
                break

            print 'Index:',batch_index,' Last_id:',last_id, 'Counter',counter

            prev_lastid = last_id

            cursor_size = events.count(with_limit_and_skip=True)

            if cursor_size == 0:
                continue
            # update last id
            last_id = events[cursor_size-1]['_id']

            if prev_lastid == last_id:
                break

            for event in events:
                if invalidEvent(event):
                    continue
                counter += 1
                if counter % 100 == 0:
                    print counter, 'of', total
                queue.put((event,counter), block=True)

            events.close()
            gc.collect()
            batch_index += batch_size

        print 'All events in queue'
        queue.join()

    except KeyboardInterrupt as e:
        print 'Keyboard interrupt'
        pool.terminate()
        pool.join()
        exit()

    print 'Finished Collecting Event Trees'

def invalidEvent(event):
    if not 'HTML' in event:
        return True
    keys = ['evtname', 'evtdesc', 'location', 'starttime']
    for key in keys:
        if not event[key]:
            return True
    return False

def worker_main(queue):
    worker_id = os.getpid()
    dbConn = db_config.getNewClientDBConn()
    Event_Collection = dbConn.Agnes.autocrawler_events
    # Data_Collection = dbConn.Agnes.autocrawler_ext_data
    print worker_id, 'Alive and connected to Mongo'
    while True:

        try:
            event,counter = queue.get(True)
            print 'Worker',worker_id,'received event',counter
        except Queue.Empty as e:
            print 'Queue Empty'
            exit()

        error,event_tree = parseEventToTree(event)

        if not error:
            try:
                binary = Binary(pickle.dumps(event_tree))

                # print 'Writing Binary Tree to Event',event['_id']
                writeBinaryTreeToEvent(Event_Collection, event, binary)
                print 'Wrote Binary Tree to Event', event['_id'],'counter -',counter
                # print worker_id, 'Gathering Samples'
                # samples = getSamples(event_tree, event)
                # print worker_id, 'Writing Samples'
                # writeSamples(Data_Collection, samples)

            except RuntimeError as e:
                print 'Could not convert page to tree', event['url']
        else:
            writeBinaryTreeToEvent(Event_Collection, event, {})

        queue.task_done()

def parseEventToTree(event):

    if 'HTML' not in event:  # or 'event_tree_pkl' in event:
        return True, None

    event_tree = EventTree.EventTree(event['HTML'], event)

    event_nodes = event_tree.get_event_nodes()

    if not event_nodes:
        print 'Failed to get event node'
        print event['url']
        return True, None

    return False, event_tree

def writeBinaryTreeToEvent(collection, event, binary):

    collection.update_one({
        '_id': event['_id']
    }, {
        '$set': {
            'netx_tree_pkl': binary
        }
    }, upsert=False)

def getSamples(event_tree, event):

    event_nodes = event_tree.get_event_nodes()

    invalidNodes = getInvalidNodes(event_tree)

    samples = []
    for node_id, node_data in event_tree.get_nodes():

        if node_id in invalidNodes:
            continue

        label, part = isPositiveSample(node_id, event_nodes)

        text = convertTagToStr(node_data['attr_dict']['tag'])

        sample = {
            'text':text,
            'event_id': event['_id'],
            'label':label,
            'part':part
                  }

        samples.append(sample)

    return samples

def getInvalidNodes(event_tree):
    event_nodes = event_tree.get_event_nodes()
    invalid_nodes = []
    valid_nodes = [event_nodes[part] for part in event_nodes if part != 'event']
    for node_id, node_data in event_tree.iterate_from_node(event_nodes['event']):
        if node_id not in valid_nodes:
            invalid_nodes.append(node_id)
    return invalid_nodes

def makeBinary(item):
    return Binary(pickle.dumps(item))

def convertTagToStr(tagobj):
    tagstr = str(tagobj)
    tagstr = tagstr.encode('ascii','ignore')
    return tagstr

def isPositiveSample(node_id, event_nodes):

    for part in event_nodes:
        if node_id == event_nodes[part]:
            return True, part
    return False, ''

def writeSamples(collection, samples):
    collection.insert_many(samples)

def getEvents():
    return Parent_Event_Collection.find({},no_cursor_timeout=True)

# def getEventBatch(index, batch_size):
#     return Parent_Event_Collection.find({},no_cursor_timeout=True).skip(index).limit(batch_size)
    #, skip=index, batch_size=batch_size)[index:index+batch_size]

def getEventBatch(last_id, batch_size):
    # db.students.find({'_id': {'$gt': last_id}}).limit(10)
    if not last_id:
        return Parent_Event_Collection.find({}, no_cursor_timeout=True).limit(batch_size).sort('_id',1)
    return Parent_Event_Collection.find({'_id': {'$gt': last_id}}, no_cursor_timeout=True).limit(batch_size)

def getEvent(url):
    return Parent_Event_Collection.find({'url':url})

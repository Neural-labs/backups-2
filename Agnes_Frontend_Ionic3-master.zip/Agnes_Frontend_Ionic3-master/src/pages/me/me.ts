import { Component, ViewChild } from '@angular/core';
import { NavController, Events, IonicPage } from 'ionic-angular';
import { SuperTabs } from 'ionic2-super-tabs';

@IonicPage({priority: 'high'})
@Component({
  selector: 'page-me',
  templateUrl: 'me.html',
  providers: []
})

export class MePage {

  @ViewChild(SuperTabs) superTabs: SuperTabs;

  profilePage = 'PeopleProfile';
  notificationsPage = 'NotificationsPage';
  settingsPage = 'SettingsPage';

  meData = {
    isMe: true
  };

  constructor(public navCtrl: NavController,
              private events: Events) {

  }

  ngOnInit(){

    this.events.publish('meInit');
  }

  ionViewWillEnter(){
    this.events.publish('meTabEnter');
  }
}

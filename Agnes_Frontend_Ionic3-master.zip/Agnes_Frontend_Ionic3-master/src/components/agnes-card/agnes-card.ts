import { Component, Input } from '@angular/core';
import { App, Events, PopoverController } from 'ionic-angular';
import { EventsService } from '../../providers/events.service';
import { GroupsService } from '../../providers/groups.service';
import { PeopleService } from '../../providers/people.service';
import { Agnes } from '../../app/app.component';
import * as Bodymovin from 'bodymovin';

/**
 * card component for matched events and groups
 */

@Component({
  selector: 'agnes-card',
  templateUrl: 'agnes-card.html',
  providers: [EventsService, GroupsService, PeopleService]
})
export class AgnesCardComponent {

  @Input() object: Object;
  @Input() type: string;
  @Input() objTime: string;
  @Input() fbfriends: Array<Object>;
  @Input() showIcons: boolean;
  @Input() objMyType: string;
  @Input() categoryCard: boolean;

  objName: string;
  objDesc: string;
  peoplePics = [];
  picErrors: boolean;
  attending: boolean;
  user: Object;
  like: boolean;
  inGroup: boolean;
  subtitle: string;
  animDone: boolean;

  constructor(public appCtrl: App,
              private events: Events,
              private popoverCtrl: PopoverController,
              private groupsService: GroupsService,
              private peopleService: PeopleService,
              private eventsService: EventsService) {
  }

  ngOnInit(){
    this.user = JSON.parse(localStorage.getItem('agnesUser'));
    this.objName = (this.type == 'group' ? this.object['grpname'] : this.object['evtname']);
    this.objDesc = (this.type == 'group' ? this.object['grpdesc'] : this.object['evtdesc']);
    this.animDone= false;
    this.picErrors = false;

    if(!this.categoryCard){
        this.attending = this.type == 'event' ? this.user['evtrsvp'].indexOf(this.object['_id']) != -1 : false;
        this.inGroup = this.type == 'group'
            ? (this.object['admin'].indexOf(this.user['_id']) != -1 || this.object['members'].indexOf(this.user['_id']) != -1)
            : false;
        this.like = this.type == 'group' ? this.object['followers'].indexOf(this.user['_id']) != -1
            : this.object['interested'].indexOf(this.user['_id']) != -1;
        this.showIcons = this.showIcons != null ? this.showIcons : true;

        this.object['peopleList'] = this.type == 'event' ? this.object['attendees'].concat(this.object['interested'])
            : this.type == 'group' ? this.object['admin'].concat(this.object['members'].filter(a => {
                    return this.object['admin'].indexOf(a) == -1;
                })) : [];

        //add attendees/members pics to cards
        if(this.object['peopleList'].length > 0) {
            this.peoplePics = this.object['peopleList'].indexOf(this.user['_id']) != -1 ? [this.user] : [];
            this.addPeoplePics();

            //replace people pics w friend pics
            this.events.subscribe('sendFriendsToCard', friends => {
                this.fbfriends = friends;
                this.object['fbfriends'] = this.fbfriends;
                this.addPeoplePics();
            });
        }

        if(this.type == 'event'){
            //fill heart icon if event has been liked
            this.events.subscribe('likedEvent', (event) => {
                this.user = JSON.parse(localStorage.getItem('agnesUser'));
                if(event['_id'] == this.object['_id']) {
                    this.like = true;
                    if(this.object['interested'].indexOf(this.user['_id']) == -1) {
                        this.object['interested'].push(this.user['_id']);
                    }
                }
            });

            //unfill heart icon if event has been unliked
            this.events.subscribe('unlikedEvent', (event) => {
                this.user = JSON.parse(localStorage.getItem('agnesUser'));
                if(event['_id'] == this.object['_id']) {
                    this.like = false;
                    let ind = this.object['interested'].indexOf(this.user['_id']);
                    if (ind != -1) {
                        this.object['interested'].splice(ind, 1);
                    }
                }
            });

            //change heart icon to calendar plus icon if going to event
            this.events.subscribe('goingDone', event => {
                this.user = JSON.parse(localStorage.getItem('agnesUser'));
                if(event && event['_id'] == this.object['_id']) {
                    this.like = false;
                    this.attending = true;
                    if(this.object['attendees'].indexOf(this.user['_id']) == -1) {
                        this.object['attendees'].push(this.user['_id']);
                        this.object['peopleList'] = this.object['attendees'];
                        this.addPeoplePics();
                    }
                }
            });

            //change heart icon to calendar plus icon if going to event
            this.events.subscribe('notGoingDone', event => {
                this.user = JSON.parse(localStorage.getItem('agnesUser'));
                if(event && event['_id'] == this.object['_id']) {
                    this.attending = false;
                    let ind = this.object['attendees'].indexOf(this.user['_id']);
                    if(this.object['attendees'].indexOf(this.user['_id']) != -1) {
                        this.object['attendees'].splice(ind,1);
                        this.object['peopleList'] = this.object['attendees'];
                        this.addPeoplePics();
                    }
                }
            });
        }

        if(this.type == 'group'){
            //change heart icon to joined group icon is now admin/member of group
            this.events.subscribe('addedGroup', data => {
                this.user = JSON.parse(localStorage.getItem('agnesUser'));
                let group = data.group;
                if(group && this.object['_id'] == group['_id']){
                    this.inGroup = true;
                    let type = data.type == 'admin' ? 'admin' : 'members';
                    if(this.object[type].indexOf(this.user['_id']) == -1){
                        this.object[type].push(this.user['_id']);
                        this.object['peopleList'] = this.object['admin'].concat(this.object['members']);
                        this.addPeoplePics();
                    }
                }
            });

            //change heart icon to joined group icon is now admin/member of group
            this.events.subscribe('leftGroup', data => {
                this.user = JSON.parse(localStorage.getItem('agnesUser'));
                let group = data.group;
                if(group && this.object['_id'] == group['_id']){
                    this.inGroup = false;
                    let type = data.type == 'admin' ? 'admin' : 'members';
                    let ind = this.object[type].indexOf(this.user['_id']);
                    if(ind == -1){
                        this.object[type].splice(ind,1);
                        this.object['peopleList'] = this.object['admin'].concat(this.object['members']);
                        this.addPeoplePics();
                    }
                }
            });

            //change heart outline to red heart when group has been followed
            this.events.subscribe('followGroup', group => {
                if(group && this.object['_id'] == group['_id']){
                    this.like = true;
                    this.user = JSON.parse(localStorage.getItem('agnesUser'));

                    if(this.object['followers'].indexOf(this.user['_id']) == -1) {
                        this.object['followers'].push(this.user['_id']);
                    }
                    if(this.user['following'].map(x => x['groups_id']).indexOf(this.object['_id']) == -1){
                        this.user['following'].push({'groups_id': this.object['_id']});
                        localStorage.setItem('agnesUser',JSON.stringify(this.user));
                    }
                }
            });

            //remove friend pics if they have been removed from group
            this.events.subscribe('removedMembers', data => {
                if(data.group['_id'] == this.object['_id']){
                    this.object['admin'] = this.object['admin'].filter(a => {return data.members.indexOf(a) == -1});
                    this.object['members'] = this.object['members'].filter(a => {return data.members.indexOf(a) == -1});
                    this.object['peopleList'] = this.object['admin'].concat(this.object['members']);
                    this.addPeoplePics();
                }
            });
        }
    }
    else {
        this.object['peopleList'] = [];
        this.subtitle = this.type == 'group' ? this.object['groupCount'] + ' Groups' : '';
    }
  }


  //open event or group profile, depending on type of card
  openObjProfile(){
      if(!this.categoryCard){
          if(this.type == 'group'){
              //open group profile

              let grpPromise;
              if(!this.object['grpemail']) {
                  grpPromise = this.groupsService.getGroupsFromId({'grp':[this.object['_id']]});
              }

              Promise.all([grpPromise]).then(val => {

                  let canOpen = true;
                  if(grpPromise && val) {

                      if(val[0] && val[0][0]) {
                          let ppl = this.object['peopleList'];
                          this.object = val[0][0];
                          this.object['peopleList'] = ppl;
                      }
                      else {
                          canOpen = false;
                          Agnes.showError("Sorry, could not open this group profile - try again!");
                      }
                  }

                  //open group profile
                  if(canOpen){
                      let grpProfile = this.popoverCtrl.create('GroupProfile',{
                          'group':this.object,
                          'type':this.objMyType
                      }, {});

                      grpProfile.present({
                          animation: 'ios-transition',
                          duration: 350
                      });

                      grpProfile.onDidDismiss(newGrp => {
                          //TODO: update group
                          // this.user = JSON.parse(localStorage.getItem('agnesUser'));
                          // this.object = newGrp;
                      });
                  }
              }).catch(err => {
                  console.log(err);
                  Agnes.showError("Sorry, could not open this group profile - try again!");
              });
          }
          else {
              let evtPromise;
              if(!this.object['weburl']) {
                  evtPromise = this.eventsService.getEventsFromId({
                      'evt':[this.object['_id']],
                      'community': this.user['community']
                  });
              }

              Promise.all([evtPromise]).then(val => {
                  let canOpen = true;
                  if(evtPromise && val) {

                      if(val[0] && val[0][0]) {
                          let ppl = this.object['peopleList'];
                          let pic = this.object['picurl'];
                          this.object = val[0][0];
                          this.object['peopleList'] = ppl;
                          this.object['picurl'] = pic;
                      }
                      else {
                          canOpen = false;
                          Agnes.showError("Sorry, could not open this event profile - try again!");
                      }
                  }

                  //open event profile
                  if(canOpen){

                      // let evtProfile = this.popoverCtrl.create('EventProfile',{
                      //     'event': this.object,
                      //     'type': this.objMyType
                      // }, {});
                      //
                      // evtProfile.present({
                      //     animation: 'shared-elements',
                      //     duration: 350
                      // });
                      //
                      // evtProfile.onDidDismiss(newEvt => {
                      //     //update event
                      //     this.user = JSON.parse(localStorage.getItem('agnesUser'));
                      //     this.object = newEvt;
                      //     this.attending = this.user['evtrsvp'].indexOf(this.object['_id']) != -1;
                      //     this.like = this.object['interested'].indexOf(this.user['_id']) != -1;
                      //
                      // });

                      this.appCtrl.getRootNav().push('EventProfile',{
                          'event':this.object,
                          'type': this.objMyType
                      },{
                          // animation: 'shared-elements',
                          animation: 'ios-transition',
                          duration: 250
                      });
                  }
              }).catch(err => {
                  console.log(err);
                  Agnes.showError("Sorry, could not open this event profile - try again!");
              });
          }
      }
  }

  //add friends' faces to event cards
  addPeoplePics(){


      this.fbfriends = this.fbfriends ? this.fbfriends : [];
      let inPeople = this.object['peopleList'].indexOf(this.user['_id']) != -1;

      if(this.fbfriends.length > 0) {

          //return 2 friends if user is part of peopleList, 3 if not
          let friends = this.fbfriends.filter(a => {
              return this.object['peopleList'].indexOf(a['_id']) != -1;
          }).slice(0,(inPeople ? 2 : 3));

          //peoplePics already initialized replace current people pics w as many friend pics as possible
          if(this.peoplePics.length > 0) {

              //if friend pics already in array, rearrange so user is first (if applicable) then friend pics then the rest
              let filteredPics = this.peoplePics.filter(a => {
                  return friends.map(x => {return x['_id']}).indexOf(a['_id']) == -1 && this.user['_id'] != a['_id']
              });
              this.peoplePics = (inPeople ? [this.user] : [])
                  .concat(friends.concat(filteredPics.slice(friends.length, inPeople ? 2 : 3)));
          }
          else {
              this.peoplePics = (inPeople ? [this.user] : []).concat(friends);
          }
      }

      //friends have already been checked over, user is not in peopleList
      if(this.peoplePics.length == 0 && this.object['peopleList'].length > 0){
          this.peopleService.getUsersFromIds({'users':this.object['peopleList'].slice(0,3)}).then(val => {
              if(val && val.length > 0){
                  this.peoplePics = val;
              }
              else {
                  this.picErrors = true;
              }
          }).catch(err => { this.picErrors = true; });
      }
  }

  //remove attended event from calendar
  removeFromCalendar() {
        Agnes.notGoing(this.object, false);
        this.events.publish('eventUnattend',this.object);
        this.attending = false;
        this.like = false;
  }

  //like event to show interest
  likeEvent(){

  // liking an event
    let data = {
      'users_id':this.user['_id'],
      'events_id':this.object['_id']
    };

    if(this.like){
      this.eventsService.eventUninterested(data).then(value => {
        this.like = false;
        let ind = this.user['evtinterest'].indexOf(this.object['_id']);
        if(ind != -1){ this.user['evtinterest'].splice(ind,1);}
        localStorage.setItem('agnesUser',JSON.stringify(this.user));

        ind = this.object['interested'].indexOf(this.user['_id']);
        if(ind != -1) {this.object['interested'].splice(ind,1);}

        this.events.publish('unlikedEvent', this.object);
      }).catch(err => {
        console.log('eBD err',err);
        Agnes.showError('Couldn\'t like this event, please try again later!');
      })
    }
    else {
      this.eventsService.eventInterested(data).then(value => {
        let animation = Bodymovin.loadAnimation({
            container: document.getElementById(this.object['_id']),
            path: 'assets/img/like.json',
            renderer: 'svg',
            loop: false, // Optional
            autoplay: true, // Optional
            name: "Heart", // Name for future reference. Optional.
        })
        animation.addEventListener('complete', function() {
          animation.destroy()
        })

        this.like = true;
        this.user['evtinterest'].push(this.object['_id']);
        localStorage.setItem('agnesUser',JSON.stringify(this.user));
        this.object['interested'].push(this.user['_id']);

        this.events.publish('likedEvent', this.object);
      }).catch(err => {
        console.log('eBD err',err);
        Agnes.showError('Couldn\'t like this event, please try again later!');
      })
    }
  }

  //press heart button to follow group
  followGroup(){
      let data = {
          groups_id: this.object['_id'],
          users_id: this.user['_id']
      };

      if(this.like) {
          this.groupsService.unfollowGroup(data).then(val => {
              let ind = this.object['followers'].indexOf(this.user['_id']);
              if(ind != -1){this.object['followers'].splice(ind,1);}

              ind = this.user['following'].map(a => {return a['groups_id']}).indexOf(this.object['_id']);
              if(ind != -1){this.user['following'].splice(ind,1);}
              localStorage.setItem('agnesUser',JSON.stringify(this.user));

              //remove group from followed groups in My Groups
              this.events.publish('leftGroup', {
                  'group': this.object['_id'],
                  'type':'follow'
              });

              this.like = false;
          }).catch(error => {
              console.log(error);
          });
      }
      else {
          this.groupsService.followGroup(data).then(val => {
              this.like = true;
              this.object['followers'].push(this.user['_id']);
              this.user['following'].push({'groups_id': this.object['_id']});
              localStorage.setItem('agnesUser',JSON.stringify(this.user));

              this.events.publish('followGroup', this.object);
              this.events.publish('updateUser');

          }).catch(error => {
              console.log(error);
              Agnes.showError('Could not add this group to your following list - try again later!');
          })
      }
    }

  //leave group you are part of
  leaveGroup(){
      let message = "Are you sure you want to leave " + this.object['grpname'] + "?";
      let buttons = ['Cancel', 'Yes'];

      this.events.subscribe('agnesAlertData', ind => {
          this.events.unsubscribe('agnesAlertData');

          if(ind == 1){
              let data = {
                  "groups_id": this.object['_id'],
                  "users_id": this.user['_id']
              };

              this.groupsService.leaveGroup(data).then(value => {
                  //leaveGroup returns 1 for success
                  if (value){
                      let aInd = this.object['admin'].indexOf(this.user['_id']);
                      let mInd = this.object['members'].indexOf(this.user['_id']);

                      if(aInd != -1) {this.object['admin'].splice(aInd,1);}
                      if(mInd != -1) {this.object['members'].splice(mInd,1);}

                      let ind = this.user['grp'].map(a => {return a['groups_id']}).indexOf(this.object['_id']);

                      if(ind != -1){
                          this.user['grp'].splice(ind,1);
                          localStorage.setItem('agnesUser',JSON.stringify(this.user));
                      }

                      this.events.publish('leftGroup', {'group': this.object['_id']});
                      this.inGroup = false;

                  }
                  else {
                      console.log('leave group err1', value);
                      Agnes.showError('Sorry, could not remove this group from your groups list - try again!');
                  }
              }).catch(err => {
                  console.log('leave group err2', err);
                  Agnes.showError('Sorry, could not remove this group from your groups list - try again!');
              });
          }
      });

      Agnes.showError(message, buttons);
  }

  //default to initials if profile pic is bad
  imgError(person){
      person['noPic'] = true;
  }

}

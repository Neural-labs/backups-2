import { NgModule, ErrorHandler } from '@angular/core';
import { IonicApp, IonicModule, IonicErrorHandler, } from 'ionic-angular';
import { FormsModule }   from '@angular/forms';
import { HttpModule }    from '@angular/http';
import { CloudSettings, CloudModule } from '@ionic/cloud-angular';
import { BrowserModule } from '@angular/platform-browser';

import { SuperTabsModule } from 'ionic2-super-tabs';

import { Agnes } from './app.component';
import { PasswordPopup } from '../pages/popups/password-popup/password-popup';
import { PebblePopup } from '../pages/popups/pebble-popup/pebble-popup'

import { MapOptions } from '../pages/events/event-profile/map-options/map-options';

import { ReportPage } from '../pages/popups/report/report';
import { InviteToGroup } from '../pages/popups/invite-to-group/invite-to-group';
import { EventDetails } from '../pages/popups/event-details/event-details';
import { InviteFriends } from '../pages/popups/invite-friends/invite-friends';

import { ComponentsModule } from '../components/components.module';
import { DirectivesModule } from '../directives/directives.module';
import { SharedElements } from '../directives/shared-element-transition/shared-element-transition';

import { Config } from 'ionic-angular/config/config';

/* native plugins */
import { ActionSheet } from '@ionic-native/action-sheet';
import { Badge } from '@ionic-native/badge';
import { Calendar } from '@ionic-native/calendar';
import { Camera } from '@ionic-native/camera';
import { DatePicker } from '@ionic-native/date-picker';
import { Deeplinks } from '@ionic-native/deeplinks';
import { Device } from '@ionic-native/device';
import { Facebook } from '@ionic-native/facebook';
import { Geolocation } from '@ionic-native/geolocation';
import { Keyboard } from '@ionic-native/keyboard';
import { LaunchNavigator } from '@ionic-native/launch-navigator';
import { LocalNotifications } from '@ionic-native/local-notifications';
import { Network } from '@ionic-native/network';
import { PhotoViewer } from '@ionic-native/photo-viewer';
import { Push } from '@ionic-native/push';
import { SocialSharing } from '@ionic-native/social-sharing';
import { SplashScreen } from '@ionic-native/splash-screen';
import { StatusBar } from '@ionic-native/status-bar';
import {RoundProgressModule} from 'angular-svg-round-progressbar';

import { ParallaxHeaderDirective } from '../directives/parallax-header/parallax-header';


const cloudSettings: CloudSettings = {
  'core': {
    'app_id': '8ca843c7'
  }
};

@NgModule({
  declarations: [
    Agnes,
    MapOptions,
    ReportPage,
    InviteToGroup,
    PasswordPopup,
    PebblePopup,
    EventDetails,
    ParallaxHeaderDirective,
    InviteFriends,
  ],
  imports: [
    IonicModule.forRoot(Agnes, {
      scrollPadding: false,
      scrollAssist: true,
      autoFocusAssist: false,
      swipeBackEnabled: true,
      preloadModules: true,
      statusbarPadding: false
    }),
    BrowserModule,
    RoundProgressModule,
    FormsModule,
    HttpModule,
    CloudModule.forRoot(cloudSettings),
      ComponentsModule,
      DirectivesModule
  ],
  bootstrap: [IonicApp],
  entryComponents: [
    Agnes,
    MapOptions,
    ReportPage,
    InviteToGroup,
    InviteFriends,
    PasswordPopup,
    PebblePopup,
    EventDetails
  ],
  providers: [
    ActionSheet,
    Badge,
    Calendar,
    Camera,
    DatePicker,
    Deeplinks,
    Device,
    Facebook,
    Geolocation,
    Keyboard,
    LaunchNavigator,
    LocalNotifications,
    Network,
    PhotoViewer,
    Push,
    SocialSharing,
    SplashScreen,
    StatusBar,
    {provide: ErrorHandler, useClass: IonicErrorHandler}
    ]
})
export class AppModule {
  constructor(private config: Config) {
    // Register custom transitions.
    this.config.setTransition('shared-elements', SharedElements);
  }

}

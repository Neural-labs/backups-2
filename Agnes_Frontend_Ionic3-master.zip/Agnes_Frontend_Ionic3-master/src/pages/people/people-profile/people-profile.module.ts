import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';


import { PeopleProfile } from './people-profile';
import { ComponentsModule } from '../../../components/components.module';
import { SuperTabsModule } from 'ionic2-super-tabs';
import { PeopleInfoModule } from '../people-profile/people-info/people-info.module';
import {RoundProgressModule} from 'angular-svg-round-progressbar';

@NgModule({
  declarations: [
    PeopleProfile
  ],
  imports: [
    IonicPageModule.forChild(PeopleProfile),
    ComponentsModule,
    RoundProgressModule,
    SuperTabsModule,
      PeopleInfoModule
  ],
  exports: [
    PeopleProfile
  ]
})

export class PeopleProfileModule { }

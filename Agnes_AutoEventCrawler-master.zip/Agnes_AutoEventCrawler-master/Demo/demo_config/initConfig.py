from db import dev, prod, new

global ENVIRONMENT
global DEBUG

def setDebugFlag(flag):
    global DEBUG
    DEBUG = flag

def getDebugFlag():
    global DEBUG
    return DEBUG

def debug(string, **kwargs):
    if DEBUG:
        print string
        for key in kwargs:
            print key,kwargs[key]
        print

def getDBConn(env):
    setEnvironment(env)
    CONFIG = getConfig()
    return CONFIG['dbConn']

def InitConfig(env,debug):
    global ENVIRONMENT
    global DEBUG

    ENVIRONMENT = env
    DEBUG = debug

# env can be dev or prod
def getConfig():
    global ENVIRONMENT
    if ENVIRONMENT == 'dev':
        config = initDevConfig()
    elif ENVIRONMENT == 'prod':
        config = initProdConfig()
    else:
        raise ValueError('No Environment Specified')

    return config

def initDevConfig():
    config = {}
    config['dbConn'] = dev.conn

    return config

def initProdConfig():
    config = {}
    config['dbConn'] = prod.conn

    return config

def setEnvironment(env):
    global ENVIRONMENT
    ENVIRONMENT = env

def getNewClientDBConn():
    global ENVIRONMENT
    ENVIRONMENT = 'dev'

    client = new.getNewClient()
    return client


"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var core_1 = require('@angular/core');
var ionic_native_1 = require('ionic-native');
var me_service_1 = require('../me/me.service');
var password_popup_1 = require('../../popups/password-popup/password-popup');
var app_component_1 = require('../../../app/app.component.ts');
var SettingsPage = (function () {
    function SettingsPage(viewCtrl, navParams, navCtrl, meService, popoverCtrl, platform, events) {
        this.viewCtrl = viewCtrl;
        this.navParams = navParams;
        this.navCtrl = navCtrl;
        this.meService = meService;
        this.popoverCtrl = popoverCtrl;
        this.platform = platform;
        this.events = events;
    }
    SettingsPage.prototype.ngOnInit = function () {
        ionic_native_1.GoogleAnalytics.trackView("Settings");
        this.user = this.navParams.data.user;
        this.fromFB = this.navParams.data.fromFB;
        this.hideProfile = !this.user['display'] ? 'On' : 'Off';
    };
    SettingsPage.prototype.closeSettings = function (e) {
        if (!e || e.direction == 2) {
            if (this.user['canChat']) {
                this.events.publish('showChat', true);
            }
            this.navCtrl.pop({
                animate: true,
                animation: 'ios-transition',
                duration: 350,
                easing: "ease-in-out",
                direction: "back"
            });
        }
    };
    SettingsPage.prototype.hideMyProfile = function () {
        var _this = this;
        //tracking
        if (window['fabric']) {
            window['fabric'].Answers.sendCustomEvent('Settings', { type: 'hide profile: ' + this.hideProfile });
        }
        var disp = (this.hideProfile == 'On') ? false : true;
        if (!this.user['display'] == disp) {
            var data = {
                "id": this.user['_id'],
                "display": disp
            };
            this.meService.hideProfile(data).then(function (value) {
                if (value) {
                    _this.user['display'] = disp;
                    _this.events.publish('updateUser', { 'user': _this.user, 'showChat': _this.user['canChat'] });
                }
                else {
                    _this.hideProfile = disp ? 'Off' : 'On';
                    app_component_1.Agnes.showError("There was a problem hiding your profile - try again!");
                }
            }).catch(function () {
                _this.hideProfile = disp ? 'Off' : 'On';
                app_component_1.Agnes.showError("There was a problem hiding your profile - try again!");
            });
        }
    };
    SettingsPage.prototype.toChangePassword = function () {
        //tracking
        if (window['fabric']) {
            window['fabric'].Answers.sendCustomEvent('Settings', { type: 'change password' });
        }
        document.getElementById('userSettings').style.filter = "blur(3vw)";
        var changePw = this.popoverCtrl.create(password_popup_1.PasswordPopup, { 'type': 'Change',
            'user': this.user }, { 'enableBackdropDismiss': true });
        changePw.present({
            animate: true,
            animation: 'ios-transition',
            duration: 350,
            easing: "ease-in-out",
            direction: "forward"
        });
        changePw.onDidDismiss(function (newUserData) {
            document.getElementById('userSettings').style.filter = "none";
        });
    };
    SettingsPage.prototype.logout = function () {
        //tracking
        if (window['fabric']) {
            window['fabric'].Answers.sendCustomEvent('Settings', { type: 'sign out' });
        }
        this.events.publish('logout');
    };
    SettingsPage.prototype.contactAgnes = function () {
        var _this = this;
        //tracking
        if (window['fabric']) {
            window['fabric'].Answers.sendCustomEvent('Settings', { type: 'feedback' });
        }
        ionic_native_1.SocialSharing.canShareViaEmail().then(function () {
            // Sharing via email is possible
            var subj = "Questions/comments/concerns about Agnes!";
            var message = '\n\n--\n' +
                'Agnes version: ' + app_component_1.Agnes.version + '\n' +
                'Cordova version: ' + ionic_native_1.Device.cordova + '\n' +
                'os: ' + ionic_native_1.Device.platform + ' ' + ionic_native_1.Device.version + '\n' +
                'Device Id: ' + _this.user['deviceid'] + '\n' +
                'Device brand: ' + ionic_native_1.Device.manufacturer + '\n' +
                'Device model: ' + ionic_native_1.Device.model + '\n' +
                'Screen width: ' + window.innerWidth + '\n' +
                'Screen height: ' + window.innerHeight + '\n' +
                'User ID: ' + _this.user['_id'] + '\n' +
                'User email: ' + _this.user['email']['uid'] + '\n';
            ionic_native_1.SocialSharing.shareViaEmail(message, subj, ['admin@agnes.io']).then(function () {
                // Success!
            }).catch(function () {
                app_component_1.Agnes.showError("Agnes can't open your email client - feel free to send your own email to admin@agnes.io!");
            });
        }).catch(function () {
            app_component_1.Agnes.showError("Agnes can't find an email client on this device - please try again!");
        });
    };
    SettingsPage.prototype.inviteFriends = function () {
        //tracking
        if (window['fabric']) {
            window['fabric'].Answers.sendCustomEvent('Settings', { type: 'invite friends' });
        }
        if (this.platform.is('cordova')) {
            var link = 'http://onelink.to/hrnse3';
            var message = "Hey check out this new events app!\n" + link;
            var subj = "Agnes: new events app";
            ionic_native_1.SocialSharing.share(message, subj, '', '')
                .then(function (val) {
            })
                .catch(function (err) {
                app_component_1.Agnes.showError("Couldn't share the app with friends, try again!");
            });
        }
        else {
            app_component_1.Agnes.showError("Please install Agnes from the App Store or Google Play store to share groups.");
        }
    };
    SettingsPage = __decorate([
        core_1.Component({
            selector: 'settings',
            templateUrl: 'settings.html',
            providers: [me_service_1.MeService]
        })
    ], SettingsPage);
    return SettingsPage;
}());
exports.SettingsPage = SettingsPage;

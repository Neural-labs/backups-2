import { Directive, Renderer } from '@angular/core';
import { DomController } from 'ionic-angular';

/**
 * auto resize textbox to grow w input text
 */

@Directive({
  selector: '[agnes-autogrow]',
  host: {
    '(input)' : 'resize($event.target)'
  }
})

export class AgnesAutoGrowDirective {

  constructor(private renderer: Renderer, private domCtrl: DomController) {

  }

  resize(textarea) {
    let newHeight;

    this.domCtrl.read(() => {
      newHeight = textarea.scrollHeight;
    });

    this.domCtrl.write(() => {
      this.renderer.setElementStyle(textarea, 'height', newHeight + 'px');
    });

  }

}
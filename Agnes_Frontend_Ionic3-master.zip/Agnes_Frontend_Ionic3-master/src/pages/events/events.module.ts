import { NgModule } from '@angular/core';
import { EventsPage } from './events';
import { IonicPageModule } from 'ionic-angular';
import { ComponentsModule } from '../../components/components.module';
import { SuperTabsModule } from 'ionic2-super-tabs';

import { AgnesNewsCardModule } from '../news/agnes-news-card/agnes-news-card.module';

@NgModule({
  declarations: [
    EventsPage
  ],
  imports: [
    IonicPageModule.forChild(EventsPage),
    SuperTabsModule,
    ComponentsModule,
      AgnesNewsCardModule
  ],
  exports: [
    EventsPage
  ],
})

export class EventsPageModule { }

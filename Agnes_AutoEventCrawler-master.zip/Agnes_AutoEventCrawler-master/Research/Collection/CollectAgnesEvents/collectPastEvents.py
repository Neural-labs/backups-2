import requests
from Utilities import EventTree
from config import db_config

Agnes = db_config.getDBConn('dev').Agnes
Real_Events_Coll = Agnes.events
Past_Events_Coll = Agnes.events_past
Crawler_Events_Coll = Agnes.autocrawler_events

# Only collect events in which we can find the event node

def collectPastEvents():

    # events = getEvents()
    #
    # counter = 0
    # for event in events:
    #     if invalid(event):
    #         continue
    #
    #     print event['weburl'][0]
    #     counter += 1
    #     print counter,'of',events.count()
    #     runCollection(event)

    counter = 0
    past_events = getPastEvents()

    for p_event in past_events:
        if invalid(p_event):
            continue

        # print p_event['weburl'][0]
        counter += 1
        print counter,'of',past_events.count()
        runCollection(p_event)

def getEvents():
    return Real_Events_Coll.find({}, no_cursor_timeout=True)

def invalid(event):

    if 'weburl' in event and not event['weburl']:
        return True
    if 'url' in event and not event['url']:
        return True
    if not 'weburl' in event and 'url' not in event:
        return True
    return False

def runCollection(event):
    error, HTML = getHTML(event)

    if error:
        print 'failed to get html'
        return

    event_tree = EventTree.EventTree(HTML, event)

    event_nodes = event_tree.get_event_nodes()

    if event_nodes:
        addEventToMongo(event)
    else:
        print 'Failed to find event parts'


def getHTML(event):

    url = event['weburl'][0]

    try:
        response = requests.get(url,timeout=10)
        HTML = response.text
        error = False
    except Exception as e:
        HTML = ''
        error = True

    HTML = HTML.replace('\n','').strip()

    return error, HTML

def getPastEvents():
    return Past_Events_Coll.find({}, no_cursor_timeout=True)

def addEventToMongo(event):
    try:
        Crawler_Events_Coll.insert_one(event)
    except Exception as e:
        # print 'updated',event['weburl'][0]
        Crawler_Events_Coll.find_one_and_update({"url":event['url']}, {"$set":{"HTML":event['HTML']}}, upsert=False)
        return

    # print 'added', event['weburl'][0]
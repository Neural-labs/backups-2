import { Component } from '@angular/core';
import { Events, App, IonicPage } from 'ionic-angular';

import { PeopleService } from '../../../providers/people.service';

import { Agnes } from '../../../app/app.component';

@IonicPage()
@Component({
    selector: 'new-chat',
    templateUrl: 'new-chat.html',
    providers: [PeopleService]
})

export class NewChatPage {

    userList: Array<Object>;
    displayed: Array<Object>;
    user: Object;
    loading: boolean;
    noInternet: boolean;
    searching: boolean;
    userSearch: string;

    constructor(private peopleService: PeopleService, private appCtrl: App){}

    //initialize New Chat page
    ngOnInit(){
        this.loading = true;
        this.user = JSON.parse(localStorage.getItem('agnesUser'));
        this.searching = false;
        this.userSearch = '';
        this.userList = [];
    }

    ionViewWillEnter(){
        if(!Agnes.network || Agnes.network.type != 'none'){
            this.noInternet = false;
            this.getUsers(null);
        }
        else {
            //lack of internet connection - show Tap to Refresh div
            this.noInternet = true;
            this.loading = false;
        }
    }

    //get list of users from this user's community
    getUsers(refresher){
        let stored = JSON.parse(localStorage.getItem('agnesPeople'));
        let t = new Date(localStorage.getItem('agnesPeopleTimeout'));
        let timeout = new Date(t.setHours(t.getHours()+ 12));
        let now = new Date();

        if(!stored || now > timeout || stored.length == 0 || refresher){
            let data = {'users_id': this.user["_id"], 'user':this.user, 'community': this.user['community']};
            this.peopleService.getPeople(data).then(value => {
                if(refresher){refresher.complete();}
                console.log(value);
                if(value){
                    this.displayPeople(value,false);
                }
                else {
                    this.loading = false;
                }
            }).catch(error => {
                if(refresher){refresher.complete();}
                this.loading = false;
                //if timeout, show connection error screen
                if(error == 'timeout') {this.noInternet = true;}
                console.log(error)});
        }
        else {
            this.loading = false;
            this.userList = stored;
            this.displayed = stored;
            if(refresher){refresher.complete();}
        }
    }

    loaded(){
        this.loading = false;
    }

    //process people array to display
    displayPeople(people, addingMore){
        let ids = this.userList.map(function(a){return a['_id'];});
        let adding = [];
        for (let p in people) {
            if ((ids.indexOf(people[p]["_id"]) == -1 && people[p]['_id'] != this.user['_id']) || this.searching){
                people[p].keywordString = people[p].keywords.map(function(a){return a.name}).toString().replace(/,/g,', ');
                adding.push(people[p]);
            }
        }

        if(adding.length == 0){
            this.loading = false;
        }
        else {
            if (!this.searching){
                if (addingMore) {
                    this.userList = this.userList.concat(adding);
                }
                else {
                    this.userList = adding;
                }

                this.displayed = this.userList;

                localStorage.setItem('agnesPeople',JSON.stringify(this.displayed));
                localStorage.setItem('agnesPeopleTimeout', new Date().toString());
            }
            else {
                this.displayed = adding;
            }
        }
    }

    //load more people
    loadMorePeople(infiniteScroll){
        let data = {
            "users_id":this.user["_id"],
            "_id": this.displayed[this.displayed.length - 1]["_id"]
        };

        this.peopleService.loadMorePeople(data).then(value => {
            if (value && value.filter(a => {return a['_id'] != this.user['_id']}).length == 0){
                infiniteScroll.enable(false);
            }
            else {
                this.displayPeople(value,true);
            }
            infiniteScroll.complete();
        }).catch(function(error){console.log(error)});
    }

    //open a new chat window w @person
    openNewChat(person){
        
        this.appCtrl.getRootNav().push(
            'ChatProfile',
            {
                'channel': person
            }, {
                animation: 'ios-transition',
                duration: 350
            });
    }

    //refresh list of people
    refreshNewChat(refresher){
        this.getUsers(refresher);
    }

}
import re
import string
from bs4 import BeautifulSoup, Comment
from Utilities import DateExtraction
from nltk.corpus import stopwords
stop_words = set(stopwords.words('english'))

def getCleanSoup(HTML):

    HTML = ' '.join(HTML.split())
    for bad in badStrings:
        while bad in HTML:
            HTML = HTML.replace(bad,'')

    soup = BeautifulSoup(HTML,"lxml")
    for badContent in soup.find_all(badTags):
        badContent.extract()

    for comment in soup.findAll(text=lambda text: isinstance(text, Comment)):
        comment.extract()

    for tag in uselessTags:
        for match in soup.findAll(tag):
            match.unwrap()

    for x in soup.find_all():
        if (len(x.text) == 0 or not [c for c in x.text if c.isalnum()]) and not 'img' in str(x):
            x.extract()

    for tag in soup():
        for attr in tag.attrs.keys():
            if not validAttr(attr):
                del tag[attr]
    return soup

def getDirtySoup(HTML):
    HTML = ' '.join(HTML.split())

    for bad in badStrings:
        while bad in HTML:
            HTML = HTML.replace(bad,'')

    soup = BeautifulSoup(HTML, "lxml")

    for badTag in soup.find_all(badTagsStrict):
        badTag.extract()

    for comment in soup.findAll(text=lambda text: isinstance(text, Comment)):
        comment.extract()

    for x in soup.find_all():
        if (len(x.text) == 0 or not [c for c in x.text if c.isalnum()]) and not 'img' in str(x):
            x.extract()

    return soup

def simpleGetSoup(HTML):
    HTML = ' '.join(HTML.split())
    soup = BeautifulSoup(HTML, "lxml")
    for badContent in soup.find_all(badTagsStrict):
        badContent.extract()
    for comment in soup.findAll(text=lambda text: isinstance(text, Comment)):
        comment.extract()
    return soup

def validTag(tag):
    return tag in ValidTags

def validAttr(attr):
    return attr in ValidAttributes

def validValue(value):

    if len(DateExtraction.getDates(value)) > 0:
        return 'date'

    for keyword in ValidValues:
        if keyword in value:
            return keyword

    return False

def invalidNode(node):
    return node.name not in ValidTags

def normalizeURL(url):
    url = convertToHTTP(url)
    url = removeEndSlash(url)
    return url

def convertToHTTP(url):
    if url[:5] == 'https':
        url = 'http'+url[5:]
    return url

def removeEndSlash(url):
    if url[-1] =='/':
        url = url[:-1]
    return url

def removeHTML(raw_html):
    cleanr = re.compile('<[^<]+?>')
    cleantext = re.sub(cleanr, ' ', raw_html)
    cleantext = ' '.join(cleantext.split())
    return cleantext

def removeHref(raw_html):
    pattern = re.compile(' href=".*?"')
    html_sans_href = re.sub(pattern, '', raw_html)
    return html_sans_href

def removeContentInHTML(raw_html):
    pattern = re.compile('>.+?<')
    cleancontent = re.sub(pattern, '><', raw_html)
    cleancontent = ' '.join(cleancontent.split())
    return cleancontent

def cleanString(content):
    content = content.replace('\n','')
    content = content.replace('\t','')
    content = ' '.join(content.split())
    return content

def removePunctuation(content):
    for char in string.punctuation:
        content = content.replace(char, ' ')
    return ' '.join(content.split())

def getKeywordCount(keyword_list, content):
    counts = []
    for item in keyword_list:
        counts.append(content.count(item))
    return counts

def removeStopWords(content):
    valid_words = []
    for word in content.split():
        if not word in stop_words:
            valid_words.append(word)
    return ' '.join(valid_words)


#######################################################
### Large lists of whitelisted or blacklisted items ###

ValidTags = [
    'a',
    'abbr',
    'article',
    'aside',
    'b',
    'bdi',
    'blockquote',
    'body',
    'caption',
    'cite',
    'dd',
    'details',
    'dialogue',
    'div',
    'dl',
    'dt',
    'em',
    'embed',
    'fieldset',
    'figcaption',
    'figure',
    'form',
    'frame',
    'h1',
    'h2',
    'h3',
    'h4',
    'h5',
    'h6',
    'head',
    'header',
    'html',
    'i',
    'img',
    'ins',
    'label',
    'legend',
    'li',
    'main',
    'mark',
    'menu',
    'menuitem',
    'meta',
    'ol',
    'optgroup',
    'option',
    'p',
    'pre',
    'select',
    'small',
    'span',
    'strong',
    'sub',
    'summary',
    'sup',
    'table',
    'tbody',
    'td',
    'time',
    'title',
    'tr',
    'u',
    'ul'
]

ValidAttributes = [
    'class',
    'title',
    'datetime',
    'headers',
    'itemprop',
    'href',
    'content',
    'value',
    'summary',
    'id',
    'name',
    'src',
    'alt'
]

ValidValues = [
    'event',
    'events',
    'date',
    'time',
    'details',
    'location',
    'venue',
    'description',
    'ticket',
    'map',
    'calendar',
    'headline'
    'title',
    'datetime',
    'field',
    'address',
    'locality',
    'postalcode',
]

ContentKeywords = [
    'event',
    'date',
    'location',
    'venue',
    'description',
    'ticket',
    'map',
    'calendar',
    'headline'
    'title',
    'datetime',
    'field',
    'topic',
    'calendar',
    'register',
    'registration',
    'details',
    'invite',
    'add to my cal',
    'event details',
    'category',
    'week',
    'month',
    'year'

]

NameKeywords = [
    'title',
    'name',
    'headline',
    'field',
    'event',
]

NameAttributes = [
    'class',
    'title',
    'headers',
    'href',
    'id',
    'name',
    'content'
]

badStrings = [
    'eventfulness',
    'preventability',
    'preventiveness',
    'uneventfulness',
    'eventualies',
    'preventatives',
    'preventative',
    'preventively',
    'uneventfully',
    'seventeenth',
    'seventeenth',
    'eventuality',
    'eventuating',
    'preventable',
    'preventible',
    'preventions',
    'seventieth',
    'eventually',
    'prevention',
    'preventive',
    'uneventful',
    'seventeens',
    'preventing',
    'eventuated',
    'eventuates',
    'preventers',
    'eventfully',
    'seventeen',
    'misevents',
    'prevented',
    'preventer',
    'elevenths',
    'eventless',
    'eventides',
    'prevent',
    'seventh',
    'seventy',
    'intimidate',
    'invalidate',
    'fluoridate',
    'revalidate',
    'transudate',
    'mithridate',
    'dilapidate',
    'depredated',
    'depredates',
    'fecundated',
    'fecundates',
    'elucidated',
    'elucidates',
    'candidates',
    'datelining',
    'outdatedly',
    'molybdates',
    'liquidated',
    'liquidates',
    'sedateness',
    'subcordate',
    'retardates',
    'periodates',
    'candidate',
    'elucidate',
    'liquidate',
    'molybdate',
    'depredate',
    'cuspidate',
    'periodate',
    'retardate',
    'obcordate',
    'fecundate',
    'excaudate',
    'emendated',
    'emendates',
    'foredated',
    'foredates',
    'denudated',
    'denudates',
    'chordates',
    'cordately',
    'datebooks',
    'antedated',
    'antedates',
    'lapidated',
    'lapidates',
    'inundated',
    'inundates',
    'playdates',
    'vanadates',
    'validated',
    'validates',
    'validate',
    'outdated',
    'dateline',
    'inundate',
    'datebook',
    'dateless',
    'postdate',
    'antedate',
    'backdate',
    'vanadate',
    'chordate',
    'acaudate',
    'denudate',
    'emendate',
    'exudates',
    'foredate',
    'gradated',
    'gradates',
    'ecaudate',
    'airdates',
    'caudated',
    'caudates',
    'dateable',
    'predated',
    'predates',
    'oxidated',
    'oxidates',
    'pedately',
    'playdate',
    'sedatest',
    'sedately',
    'incudate',
    'mandated',
    'mandates',
    'lapidate',
    'outdates',
    'misdated',
    'misdates',
    'updaters',
    'mandate',
    'undated',
    'predate',
    'exudate',
    'airdate',
    'caudate',
    'outdate',
    'gradate',
    'cordate',
    'misdate',
    'nidated',
    'nidates',
    'iodated',
    'iodates',
    'oxidate',
    'redatedredates',
    'sedated',
    'sedater',
    'sedates',
    'datedly',
    'updated',
    'updates',
    'updater',
    'update',
    'sedate',
    'iodate',
    'nidate',
    'pedate',
    'redate',
    'daters'
]

badTags = [
    'script',
    'noscript',
    'style',
    'input',
    'head',
    'nav'
]

badTagsStrict = [
    'script',
    'noscript',
    'style',
    'input',
]

uselessTags = [
    'b',
    'strong',
    'u',
    'br',
    'em'
]

badAttributes = [
    'style',
    'border',
    'colspan',
    'cellpadding',
    'cellspacing'
]
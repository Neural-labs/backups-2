from config import db_config
from gensim.models import Doc2Vec
import string
import numpy
from nltk.corpus import stopwords
stop = set(stopwords.words('english'))

PROD_DBCONN = db_config.getDBConn('prod')
db_config.setEnvironment('dev')

Agnes = PROD_DBCONN.Agnes
Data_Collection = Agnes.TestDocEmbedding


def runKazemWork():

    doc2vec_model = Doc2Vec.load('doc2vec.bin')

    samples = getSamples()

    counter = 0
    total = samples.count()
    for sample in samples:
        counter += 1
        print counter,'of',total
        # print sample['_id']
        # tokens = create_sentence_info(sample['Text'])
        tokens = preprocess(sample['Text'])

        vector_rep = doc2vec_model.infer_vector(tokens).tolist()

        # print type(vector_rep)

        writeSample(sample, vector_rep)

def create_sentence_info(sentence):
    exclude = set(string.punctuation)
    sentence_punctuation_removed = ''.join(ch for ch in sentence if ch not in exclude)
    words = [i for i in sentence_punctuation_removed.split(' ') if i not in stop]

    return words


def preprocess(text):
    words = text.split()

    return words

def getSamples():
    return Data_Collection.find({}, no_cursor_timeout=True)

def writeSample(sample, vector):
    Data_Collection.update_one( { '_id' : sample['_id'] }, { '$set' : { 'Model_Doc2Vec' : vector } })
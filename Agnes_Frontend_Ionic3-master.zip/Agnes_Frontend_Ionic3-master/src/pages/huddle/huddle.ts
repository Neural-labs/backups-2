import {Component, ViewChild} from '@angular/core';
import { Content, Events, IonicPage, App, ToastController, PopoverController } from 'ionic-angular';
import { AnalyticsService } from "../../providers/analytics.service";
import { PeopleService } from '../../providers/people.service'
import { HuddleService } from '../../providers/huddle.service';
import { Agnes } from '../../app/app.component';
import { MeService } from '../../providers/me.service'

@IonicPage()
@Component({
    selector: 'agnes-huddle',
    templateUrl: 'huddle.html',
    providers: [ AnalyticsService, PeopleService, HuddleService, MeService ]
})

export class HuddlePage {

    @ViewChild(Content) content: Content;

    user: Object;
    noInternet: boolean;
    noContent: boolean;
    timeout: Date;
    noFriends: boolean;
    streak: number;
    reward: number;
    lifetime: number;
    paused: boolean;
    streakGoal: number;
    loading: boolean;

    huddleSearch: string;

    fullscreen: boolean;
    spinner: boolean;
    orientation: string;

    topPebbler: Object;
    topPebbles: number;

    huddleData = [];

    constructor(public appCtrl: App,
                private huddleService: HuddleService,
                private peopleService: PeopleService,
                private popoverCtrl: PopoverController,
                private analyticsService: AnalyticsService,
                private meService: MeService,
                private events: Events){
    }

    //initialize huddle page
    ngOnInit(){
        this.loading = true;
        this.timeout = new Date();
        this.initHuddle();
        this.noFriends = true;
        //in case they make it to the bottom and want to see standings
        this.loadLeaderboard();
        this.loadFriends();
        this.loadTopPebbler();
        this.huddleSearch = '';

        this.events.subscribe('huddleSearch', (search) => {
            this.huddleSearch = search.trim();
        });
    }



    ionViewWillEnter() {
        if(this.timeout){
            let now = new Date();

            //update if user last looked at this 5+ minutes ago
            if(now.getTime() > this.timeout.getTime() + 30000){
                this.timeout = new Date();
                this.initHuddle();
            }
        }

        //send Huddle view analytics
        this.analyticsService.logAnalytics({community: this.user['community'], users_id: this.user['_id']}, '/huddlePageView');

    }

    initHuddle(refresher?){
        this.user = JSON.parse(localStorage.getItem('agnesUser'));

        let data = {'users_id': this.user['_id'], 'community': this.user['community']};
        this.huddleService.getHuddle(data).then(value => {
            console.log(value)
            this.huddleData = value;
            if(refresher){refresher.complete();}
        }).catch(err => {
            console.log(err);
            Agnes.showError("Couldn't get your campus huddle right now - try refreshing!");
            if(refresher){refresher.complete();}
        })
    }

    //pull to refresh huddle content
    refreshHuddle(refresher) {
        if(!Agnes.network || Agnes.network.type != 'none'){
            this.events.publish('updateUser');
            this.events.subscribe('updateDone',() => {
                this.events.unsubscribe('updateDone');
                this.initHuddle(refresher);
            });
        }
        else {
            //lack of internet connection - alert
            Agnes.showError('You are offline! Try refreshing again when you reconnect.');
            refresher.complete();
        }
    }

    imgLoad(ev){
      let img = ev.target;
      if (img.naturalWidth > img.naturalHeight) {
        this.orientation = 'landscape';
      } else if (img.naturalWidth < img.naturalHeight) {
        this.orientation = 'portrait';
      } else {
        this.orientation = 'even';
      }
      this.fullscreen = true;
      this.spinner = false;
    }

    imgError(){
        this.user['noPic'] = true;
    }

    loadFriends() {
    let data = {"users_id":this.user['_id'], "community":this.user['community']}
    // used to determine if a user has friends to display in pebble leaderboard
    this.meService.getFriends(data).then(value => {
        this.noFriends = value['Nofriends']
      })
    }

    loadLeaderboard() {
      //determine if pebbles are active now
      this.peopleService.communityPebblesStatus({'community' : this.user['community']}).then(val => {
          this.paused = !val['pebbleStatus']
          if(this.paused == false) {
            //if pebbles aren't paused, show the top pebbler
            let data = {"users_id":this.user['_id'], "community":this.user['community']}
            this.peopleService.getUserStreak(data).then(val =>{
              this.streak = val['dayStreak']
              let goalsArray = [7, 14, 21, 30, 45, 60, 75, 100]
              for(let g in goalsArray) {
                if(this.streak < goalsArray[g]) {
                  this.streakGoal = goalsArray[g];
                  break;
                }
              }
              this.peopleService.getUserRewardCountdown(data).then(val => {
                this.reward = val['untilReward']
                this.peopleService.getUserLifetimePebbles(data).then(val => {
                  this.lifetime = val['lifeTimePebble']
                  this.loading = false;
                }).catch(error=> {
                  console.log(error)
                })
              }).catch(error=> {
                console.log(error)
              })
            }).catch(error => {
              console.log(error)
            })
          } else {
            this.loading = false;
          }
      }).catch(error => {
        console.log(error)
      })
    }

    loadTopPebbler() {
      this.huddleService.getTopPebbler({'community': this.user['community']}).then( val => {
        this.topPebbler = val['userObject']
        this.topPebbles = val['lifeTimePebble']
      }).catch(err => {
        console.log(err)
      })
    }

    seeLeaderboard() {
      console.log(this.noFriends)
      this.popoverCtrl.create('PebbleProfile',
      {page : 2,
      person: this.user,
      streak: this.streak,
      streakGoal: this.streakGoal,
      lifetime: this.lifetime,
      reward: this.reward,
      noFriends: this.noFriends,
      isMe: true
      }, {}).present({
        animate:true,
        animation: 'ios-transition',
        duration: 350,
        easing: "ease-in-out",
        direction: "forward",
      })
    }

    openLeaderProf() {
      this.popoverCtrl.create('PeopleProfile',
      {
      isMe: false,
      person: this.topPebbler,
      }, {}).present({
        animate:true,
        animation: 'ios-transition',
        duration: 350,
        easing: "ease-in-out",
        direction: "forward",
      })
    }

}

import { Component, ViewChild } from '@angular/core';
import { Events, NavController, NavParams, App, IonicPage, Select, Slides, PopoverController } from 'ionic-angular';

import { FormControl } from '@angular/forms';

import { QuestionsService } from '../../providers/questions.service';
import { MeService } from '../../providers/me.service';
import { GroupsService } from '../../providers/groups.service';
import { AnalyticsService } from "../../providers/analytics.service";
import { LoginService } from '../../providers/login.service';

import { Agnes } from '../../app/app.component';

import * as AWS from 'aws-sdk';
import * as S3 from 'aws-sdk/clients/s3';

import * as Bodymovin from 'bodymovin';


@IonicPage()
@Component({
  selector: 'questions',
  templateUrl: 'questions.html',
  providers: [QuestionsService, MeService, AnalyticsService, GroupsService, LoginService]
})

export class QuestionsPage {
  @ViewChild('yearSelect') yearSelect: Select;
  @ViewChild('questionSlides') questionSlides: Slides;

  @ViewChild('memberInput') memberInput;
  @ViewChild('adminInput') adminInput;

  user:Object;
  referralCode: string;

  majorInput = '';
  majorAutofill = [];

  email: string;
  password:string;

  localPicImg: string;
  localCoverImg: string;

  adminSearchInput: string;
  adminSearchList: Array<Object>;
  adminSearchControl: any;

  memberSearchInput: string;
  memberSearchList: Array<Object>;
  memberSearchControl: any;

  groupList: Array<Object>;
  groupListError: boolean;
  popularGroups: Array<Object>

  adminGroups: Array<Object>;
  memberGroups: Array<Object>;
  interestedGroups: Array<Object>;

  inMembers = false;

  loading:boolean;
  attempt:number;
  shouldBlur: boolean;
  submitted: boolean;
  fbPic: boolean;

  currSlide: number;

  fromFB: boolean;
  fbData:Object;

  studentTypes = [
      "Freshman", "Sophomore", "Junior", "Senior", "Fifth year", "Masters", "PhD", "Alum", "Staff", "Other"
  ];

  referralInput: any;
  invalidReferral: boolean;
  validReferral: boolean;

  userRegistered: boolean;

  constructor(private questionsService:QuestionsService,
              private loginService: LoginService,
              private events:Events,
              private meService: MeService,
              public navCtrl:NavController,
              private navParams: NavParams,
              private analyticsService: AnalyticsService,
              private groupsService: GroupsService,
              private appCtrl: App,
              private popoverCtrl: PopoverController) {
    this.adminSearchControl = new FormControl();
    this.adminSearchList = [];

    this.memberSearchControl = new FormControl();
    this.memberSearchList = [];

    this.adminSearchInput = '';
    this.memberSearchInput = '';

    this.groupList = [];
    this.groupListError = false;

    this.referralInput = new FormControl('');
  }

  ngOnInit() {

    this.user = this.navParams.get('user') ? this.navParams.get('user') : {
      password: '',
      fname: '',
      lname: '',
      picurl: '',
      cover: '',
      major: [],
      community: '',
      studenttype: '',
      email: ''
    };

    this.referralCode = '';

    this.invalidReferral = false;

    this.email = '';
    this.password = '';

    this.localPicImg = '';
    this.localCoverImg = '';

    this.fromFB = !!this.navParams.get('fromFB');
    this.fbData = !!this.navParams.get('fbData') ? this.navParams.data.fbData : null;

    if(this.fbData){
      this.user['fname'] = this.fbData['fname'];
      this.user['lname'] = this.fbData['lname'];
      this.user['fullname'] = this.fbData['fname'] + " " + this.fbData['lname'];
      this.user['picurl'] = this.fbData['picture']['data']['url'] ? this.fbData['picture']['data']['url'] : '';
      this.user['cover'] = this.fbData['cover'] && this.fbData['cover']['source']
          ? this.fbData['cover']['source'] : '';
    }

    this.loading = false;
    this.submitted = false;

    //for sending questions - show error if data has not uploaded after 5 tries
    this.attempt = 0;

    //for keyboard
    this.shouldBlur = true;

    this.adminGroups = [];
    this.memberGroups = [];
    this.interestedGroups = [];

    this.userRegistered = false;

    this.events.subscribe('referralExists', code => {
      this.referralCode = code;
    })

    Agnes.getReferalCode();

    this.currSlide = this.navParams.get('currSlide') ? this.navParams.get('currSlide') : 0;

  }

  // Handle searching
  ionViewDidLoad() {

    this.adminSearchControl.valueChanges.debounceTime(350).subscribe(search => {
      if(search.trim() != ''){
        this.searchGroups('admin');
      }
      else {
        this.clearSearch();
      }
    });

    this.memberSearchControl.valueChanges.debounceTime(350).subscribe(search => {
      if(search.trim() != ''){
        this.searchGroups('member');
        this.inMembers = true;
      }
      else {
        this.clearSearch();
        this.inMembers = false;
      }
    });

    this.referralInput.valueChanges.debounceTime(350).subscribe(value => {
      if(value && value.trim() != ''){
          this.meService.validateReferralCode({'referralCode': value}).then(val => {
              this.invalidReferral = !val['referralCode'];
              this.validReferral = val['referralCode'];
          }).catch(err => {
              Agnes.showError('Couldn\'t process your referral code - try retyping it!');
          });
      }
      else {
          this.validReferral = false;
          this.invalidReferral = false;
      }
    });

    if(this.questionSlides) {
      this.questionSlides.onlyExternal = true;
    }

  }

  //go back to home page from signup
  backToHome(){
    this.navCtrl.setRoot('LoginPage');
  }

  //programatically move to next slide
  slideNext(){
    let valid = this.validate();
    if(valid){
      if(this.questionSlides.getActiveIndex() == 0){
        //error is password not at least 7 characters long
        if(this.password.length > 0 && this.password.length < 7){
          Agnes.showError("Your password must be at least 7 characters!");
        }
        else {
          if(this.invalidReferral){
            Agnes.showError('Uh oh, looks like your referral code is invalid! ' +
                'Do you want to try correcting it before submitting?', ['Skip', 'Retry']);
            this.events.subscribe('agnesAlertData', ind => {
              this.events.unsubscribe('agnesAlertData');

              if(ind == 0){
                this.submitBasics();
              }
            });
          }
          else {
            if(this.userRegistered){this.submitReferralCode();}
            else{this.submitBasics();}
          }
        }
      }
      else if(this.questionSlides.getActiveIndex() == 1){
        this.questionSlides.slideNext();
        this.getGroups(0)
      }
      else {
        this.submitGroups();
      }
    }
  }

  //programatically move to previous slide
  slidePrev() {
    if(this.questionSlides.getActiveIndex() == 0) {
      this.backToHome();
    }
    else {
      this.questionSlides.slidePrev();
    }
  }

  //validate questions fields
  validate(){
    if(this.questionSlides.getActiveIndex() == 0) {
      this.submitted = true;
      return this.user['fname'].trim() != ''
          && this.user['lname'].trim() != ''
          // && this.user['lname'].match(/\d+/g) == null
          && this.email.trim() != ''
          && this.password.length > 7
          && this.user['studenttype'] != ''
          && this.majorInput.trim() != '';
    }
    else {return true;}
  }

  //send question slide 1 info
  submitBasics() {

    Agnes.keyboard.disableScroll(false);

    if((this.user['picurl'] != '') && (this.fbPic == false)){
      if(this.user['picurl'].indexOf('base64') != -1){

        let creds = {
          bucket: 'agnesimages',
          access_key: 'AKIAJYQU6AUVQQKITAPQ',
          secret_key: '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'
        };

        let uniqueFilename = "";
        var possible = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
        for (var j = 0; j < 8; j++) {
          uniqueFilename += possible.charAt(Math.floor(Math.random() * possible.length));
        }

        let data = this.baseToBlob(this.user['picurl']);
        AWS.config.update({region: 'us-east-1',credentials: {
          accessKeyId: "AKIAJYQU6AUVQQKITAPQ",
          secretAccessKey:"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"
        }});

        let keyname = uniqueFilename + '.jpg';
        keyname = '_' + keyname;

        //TODO if the orientation stuff came up!
        /* if(this.orientation){
         keyname = '_' + keyname;
         }
         else{
         keyname = '_' + uniqueFilename
         }
         */

        //Bucket Parameters
        let bucketParams = {
          Key: keyname,
          ContentType: ".jpg",
          Body: data ,
          ServerSideEncryption: 'AES256',
          Bucket: creds.bucket
        };

        //bucket to define
        let bucket = new S3({ params: { Bucket: 'agnesimages' } });

        bucket.putObject(bucketParams, function(err, data) {
          if(err) {
            console.log('upload picurl err',err);
            return false;
          }
          else {
            // Upload Successfully Finished
            console.log('upload picurl success');
          }
        });

        this.user['picurl'] = 'https://s3.amazonaws.com/agnesimages/' + keyname;
      }
    }

    if((this.user['cover'] != '') && (this.fbPic == false)){
      if(this.user['cover'].indexOf('base64') != -1){

        let creds = {
          bucket: 'agnesimages',
          access_key: 'AKIAJYQU6AUVQQKITAPQ',
          secret_key: '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'
        };

        let uniqueFilename = "";
        var possible = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
        for (var j = 0; j < 8; j++) {
          uniqueFilename += possible.charAt(Math.floor(Math.random() * possible.length));
        }

        let data = this.baseToBlob(this.user['cover']);
        AWS.config.update({region: 'us-east-1',credentials: {
          accessKeyId: "AKIAJYQU6AUVQQKITAPQ",
          secretAccessKey:"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"
        }});

        let keyname = uniqueFilename + '.jpg';
        keyname = '_' + keyname;

        //TODO if the orientation stuff came up!
        /* if(this.orientation){
         keyname = '_' + keyname;
         }
         else{
         keyname = '_' + uniqueFilename
         }
         */

        //Bucket Parameters
        let bucketParams = {
          Key: keyname,
          ContentType: ".jpg",
          Body: data ,
          ServerSideEncryption: 'AES256',
          Bucket: creds.bucket
        };

        //bucket to define
        let bucket = new S3({ params: { Bucket: 'agnesimages' } });

        bucket.putObject(bucketParams, function(err, data) {
          if(err) {
            console.log('upload cover err',err);
            return false;
          }
          else {
            console.log('upload cover success');
          }
        });

        this.user['cover'] = 'https://s3.amazonaws.com/agnesimages/' + keyname;
      }
    }

    this.loading = true;
    let data = {... this.user};
    data['email'] = this.email;
    data['password'] = this.password;
    data['studenttype'] = this.user['studenttype'].toLowerCase();
    this.attemptSend(data);
  }

  //try to send question basics to server max 5 times before giving error
  attemptSend(data) {
    let registerProm = this.fromFB ? this.questionsService.verifyCommunity({"email": this.user['email']}) : this.questionsService.register(data);

    Promise.all([registerProm]).then(val => {
      let value = val[0];

      if (value) {
        if (!this.fromFB) {
          this.loading = false;
            if (value['verify'] == 'edu only') {
              Agnes.showError('Please enter a valid .edu email address so we can match you to your school community!');
            }
            else if (value['verify'] == 'email exists') {
              Agnes.showError('Agnes already has your email on file - try logging in instead!');
            }
            else if (value['verify'] == 'not active') {
                this.notAtSchool(value['userObject']);
            }
            else if (value['verify'] == 'active') {
              this.user = value['userObject'];
              this.userRegistered = true;

              localStorage.setItem('agnesToken', value['userObject']['token']);
              localStorage.setItem('agnesUser', JSON.stringify(value['userObject']));

              if(this.referralCode.trim() != ''){
                this.submitReferralCode();
              }
              else {
                //go to admin/member slide
                this.loading = false;
                this.questionSlides.slideTo(1);

                this.getGroups(0);
              }
            }
            else {
              this.attempt = this.attempt + 1;
              if (this.attempt < 5) {
                this.attemptSend(data);
              }
              else {
                this.loading = false;
                this.attempt = 0;
                Agnes.showError('Could not sign up right now - try again!');
              }
            }
          }
        else {
          if (value['verify'] == 'edu only') {
            Agnes.showError('Please enter a valid .edu email address so we can match you to your school community!');
          }
          else if (value['verify'] == 'email exists') {
            Agnes.showError('Agnes already has your email on file - try logging in instead!');
          }
          //either Agnes is not at user's school or email isn't .edu
          else if(value['verify'] == 'not active'){
              this.notAtSchool(this.user);
          }
          //Agnes is at user community, sign up w/ facebook
          else {
            let fbData = {
              major: this.user['major'],
              studenttype: this.user['studenttype'],
              email: {
                uid: this.user['email'],
                fbid: this.fbData['email']['fbid']
              },
              providerFBData: this.fbData['providerFBData']
            };
            let fbid = data['email']['fbid'];

            this.questionsService.fbRegister(fbData).then(val => {

              if (val['error'] == "2") {
                let fbLoginData = {fbid:fbid}

                this.loginService.fbLogin(fbLoginData)
                    .then(fbloginvalue => {

                      this.loading = false;
                      this.user = fbloginvalue;
                      localStorage.setItem('agnesToken', fbloginvalue['token']);
                      localStorage.setItem('agnesUser', JSON.stringify(fbloginvalue));

                      this.toEvents();
                    })
                    .catch(error => {
                      console.log('fbregister user already exists -> fblogin error')
                      Agnes.showError("Sorry there was an error, please try again!")
                    })
              }
              else if(val){

                this.loading = false;
                this.user = val;
                localStorage.setItem('agnesToken', val['token']);
                localStorage.setItem('agnesUser', JSON.stringify(val));

                this.toEvents();
              }
            }).catch(err => {
              console.log('fb register error',err);
              Agnes.showError('Could not connect to Facebook - check your Facebook app permissions and connection and try again!');
            });
          }
        }
      }
    }).catch(err => {
      if(this.fromFB){
        Agnes.showError('Could not verify your email - make sure you are connected to the internet and try again!');
      }
      else {
        console.log('register error', err);
        this.attempt = this.attempt + 1;
        if (this.attempt < 5) {
          this.attemptSend(data);
        }
        else {
          Agnes.showError('Could not sign up right now - try again!');
          this.loading = false;
          this.attempt = 0;
        }
      }
    });
  }

  //attempt submitting referral code
  submitReferralCode(){
    this.loading = true;
    console.log(this.referralCode)
    this.meService.submitReferralCode({referralCode: this.referralCode, users_id: this.user['_id']})
        .then(val => {
          if(val && val == 'success') {
            this.loading = false;
            this.questionSlides.slideTo(1);

            this.getGroups(0);
          }
          else {
            this.loading = false;
            Agnes.showError('Whoops, can\'t submit your referral code right now. ' +
                'Do you want to try again?', ['Skip', 'Retry']);
            this.events.subscribe('agnesAlertData', ind => {
              this.events.unsubscribe('agnesAlertData');

              if(ind == 0){
                this.submitBasics();
              }
              else {
                this.submitReferralCode();
              }
            });
          }
        })
        .catch(err =>{
          this.loading = false;
          Agnes.showError('Whoops, can\'t submit your referral code right now. ' +
              'Do you want to try again?', ['Skip', 'Retry']);
          this.events.subscribe('agnesAlertData', ind => {
            this.events.unsubscribe('agnesAlertData');

            if(ind == 0){
              this.submitBasics();
            }
            else {
              this.submitReferralCode();
            }
          });
        });
  }

  //submit groups that user is admin and member of, and wants to follow
  submitGroups(){
    let admin = this.adminGroups.map(x => x['_id']);
    let members = this.memberGroups.map(x => x['_id']);
    let follow = this.interestedGroups;

    let adminProms = [];
    if(admin.length > 0){
      for (let a in admin){
        adminProms.push(this.groupsService.claimGroup({"group_id": admin[a], "users_id": this.user['_id']}));
      }
    }

    let memberProms = [];
    if(members.length > 0){
      for (let m in members){
        memberProms.push(this.groupsService.joinGroup2({"groups_id": members[m],
          "users_id": this.user['_id'], 'community':this.user['community']}));
      }
    }

    let followProms = [];
    if(follow.length > 0){
      for (let f in follow){
        followProms.push(this.groupsService.followGroup({"groups_id": follow[f], "users_id": this.user['_id']}));
      }
      //go to user events and huddle
      this.toEvents();
    } else {
      Agnes.showError('Please choose a group to follow before moving forward!')
    }


    //wait for group promises to return
    Promise.all(adminProms.concat(memberProms.concat(followProms))).then(val => {
      this.events.publish('updateUser');
    }).catch(err => {
      console.log('not success in group joining');
      if(follow.length > 0) {
        //only show error if user actually tried to follow a group
      Agnes.showError('Oops, looks like there was a problem connecting you to all your groups. ' +
          'If you don\'t see them in your Saved tab, you can always search for them again in Groups!')
        }
    })
  }

  //go to admin/member groups slide from basics info and get groups
  getGroups(attempt){
    //start getting all groups for follow groups slide
    this.groupsService.getAllGroups({'users_id': this.user['_id'], 'community': this.user['community'] }).then(val => {
      this.groupList = val;
      this.groupListError = false;
    }).catch(err => {
      console.log(err);
      this.loading = false;
      if(attempt < 5){
        this.getGroups(attempt++);
      }
      else {
        this.groupListError = true;
      }
    })

    this.groupsService.getMostPopularGroups({'community' : this.user['community'], 'topic' : 'all'}).then(val => {
      console.log(val)
      this.popularGroups = val;
    })
  }

  //close year drop drown menu
  selectYear(year){
    this.user['studenttype'] = year;
    this.yearSelect.close();
  }

  //close results dropdowns
  clearSearch(e?){
    this.majorAutofill = [];
    this.adminSearchList = [];
    this.memberSearchList = [];
  }

  focused(){
  }

  //autofill interests or majors
  search(type) {
    let matches = [];
    let term = '';
    let majors = this.majorInput.split(/,\s/);
    term = majors[majors.length-1].trim().toLowerCase();

    let data = {"searchTerm": term, 'type': type};

    if (term.length == 0) {
      this.majorAutofill = [];
    }
    else {
      this.questionsService.majorAutocomplete(data).then(matches => {
        if (matches) {
          this.majorAutofill = matches.slice(0,4).map(function (a) {
            return a['keyword'].toLowerCase()
          });
        }
        else {
          this.majorAutofill = [];
        }
      });
    }
  }

  //add major to end of string
  addMajor(major){
    let majors = this.majorInput.split(/,\s*/);
    this.majorInput = majors.slice(0,majors.length-1).concat([major]).join(', ');
    this.majorAutofill = [];
  }

  //add photo from native phone camera on Photo slide
  addPhoto(type) {
    let buttons = [
      {name: 'Camera',
        icon:'md-camera'},
      {name: 'Upload',
        icon: 'ios-share-outline'}
    ];

    Agnes.showError('Choose a ' + (type == 'cover' ? 'cover photo ' : 'profile picture ') + 'source',
        buttons , false, false, true);

    this.events.subscribe('agnesAlertData', ind => {
      this.events.unsubscribe('agnesAlertData');

      if(ind == 0 || ind == 1){
        let source = ind == 0 ? Agnes.camera.PictureSourceType.CAMERA : Agnes.camera.PictureSourceType.PHOTOLIBRARY;
        let options = {
          quality: 25,
          allowEdit: true,
          correctOrientation: true,
          destinationType: Agnes.camera.DestinationType.DATA_URL,
          encodingType: Agnes.camera.EncodingType.JPEG,
          sourceType: source
        };

        Agnes.camera.getPicture(options).then((value) => {
          if (value && typeof(value)=='string'){
            let base64Image = 'data:image/jpeg;base64,' + value;
            this.user[type] = base64Image;
            if(type == 'cover'){this.localCoverImg = base64Image;}
            else {this.localPicImg = base64Image;}

            this.fbPic = false;
          }
          else {
            console.log('not base64', value);
            Agnes.showError("Couldn't process your photo - try again!");
          }
        }).catch(err => {
        });
      }
    });
  }

  //search groups
  searchGroups(type){
    let term = this[type+'SearchInput'];

    if (term.trim().length > 0) {

      //TODO: change to real community
      let data = {"searchTerm":term, "community":'agnes', "scroll": 0};
      this.groupsService.searchGroups(data)
          .then(value => {
            if(value && value.length > 0){
              //filter out secret groups that user is not a member/admin of
              this[type+'SearchList'] = value.filter(a => {
                return a['grptype'] != 'secret';
              });
            }
            else{
              Agnes.showError('Looks like your group might not be on Agnes yet - ' +
                  'but don\'t worry, you can create it after signing up!');
            }

          })
          .catch(function(error){
            console.log(error);
            Agnes.showError('Sorry, there was an error searching for your group - try again!');
          });
    }
    else {
      this[type+'SearchList'] = [];
      this[type+'SearchInput'] = '';
    }
  }

  addAdmin(group){
    let ind = this.adminGroups.map(x => x['_id']).indexOf(group['_id']);
    if(ind == -1){
      this.adminGroups.push(group);

      //remove person as member of group if they have selected admin
      let mInd = this.memberGroups.map(x => x['_id']).indexOf(group['_id']);
      if(mInd != -1){this.memberGroups.splice(mInd,1);}
    }
    else {this.adminGroups.splice(ind,1);}

    this.adminSearchInput = '';
    this.clearSearch();

    this.adminInput._elementRef.nativeElement.focus();
    // this.adminInput.focus();
  }

  addMember(group, e){

    let ind = this.memberGroups.map(x => x['_id']).indexOf(group['_id']);
    if(ind == -1){
      this.memberGroups.push(group);

      //remove person as member of group if they have selected admin
      let aInd = this.adminGroups.map(x => x['_id']).indexOf(group['_id']);
      if(aInd != -1){this.adminGroups.splice(aInd,1);}
    }
    else {this.memberGroups.splice(ind,1);}

    this.memberSearchInput = '';
    this.clearSearch();
  }

  focusAdmin(e){
    // console.log('difffocused', this.inMembers, e);
    // if(this.inMembers) { console.log('blurring'); e.preventDefault(); }
  }

  removeAdmin(group){
    let ind = this.adminGroups.map(x => x['_id']).indexOf(group['_id']);
    if(ind != -1) {
      this.adminGroups.splice(ind,1);
    }
  }

  removeMember(group){
    let ind = this.memberGroups.map(x => x['_id']).indexOf(group['_id']);
    if(ind != -1) {
      this.memberGroups.splice(ind,1);
    }
  }

  addInterested(group){
    let ind = this.interestedGroups.indexOf(group['_id']);
    if(ind == -1){
      this.interestedGroups.push(group['_id']);
      this.playAnimation(group['_id'])
    }
    else {this.interestedGroups.splice(ind,1);}
  }

  baseToBlob(dataURI) {
    // convert base64/URLEncoded data component to raw binary data held in a string
    var byteString;
    if (dataURI.split(',')[0].indexOf('base64') >= 0)
      byteString = atob(dataURI.split(',')[1]);
    else
      byteString = (dataURI.split(',')[1]);

    // separate out the mime component
    // var mimeString = dataURI.split(',')[0].split(':')[1].split(';')[0];

    // write the bytes of the string to a typed array
    var ia = new Uint8Array(byteString.length);
    for (var i = 0; i < byteString.length; i++) {
      ia[i] = byteString.charCodeAt(i);
    }

    return new Blob([ia.buffer], {type: "image/jpeg"});
  }

  getOrientation(file, callback) {
    var reader = new FileReader();
    reader.onload = function (e) {

      var view = new DataView(e.target['result']);
      if (view.getUint16(0, false) != 0xFFD8) return callback(-2);
      var length = view.byteLength, offset = 2;
      while (offset < length) {
        var marker = view.getUint16(offset, false);
        offset += 2;
        if (marker == 0xFFE1) {
          if (view.getUint32(offset += 2, false) != 0x45786966) return callback(-1);
          var little = view.getUint16(offset += 6, false) == 0x4949;
          offset += view.getUint32(offset + 4, little);
          var tags = view.getUint16(offset, little);
          offset += 2;
          for (var i = 0; i < tags; i++)
            if (view.getUint16(offset + (i * 12), little) == 0x0112)
              return callback(view.getUint16(offset + (i * 12) + 8, little));
        }
        else if ((marker & 0xFF00) != 0xFF00) break;
        else offset += view.getUint16(offset, false);
      }
      return callback(-1);
    };
    reader.readAsArrayBuffer(file.slice(0, 64 * 1024));
  }

  //TODO: handle deep links
  toEvents() {
    this.loading = true;
    this.events.publish('updateUser');
    this.events.publish('updateDeviceId', {'id':JSON.parse(localStorage.getItem('agnesUser'))['_id']});

    this.events.subscribe('updateDone', () => {
      this.events.unsubscribe('updateDone');
      this.loading = false;
      this.user = JSON.parse(localStorage.getItem('agnesUser'));
      this.appCtrl.getRootNav().setRoot('TabsPage');

    });
  }

  //create alert for error when Agnes is not at user's community yet
  notAtSchool(user){
  this.appCtrl.getRootNav().push(
      'NoCommunityPage',
      {
        'user' : user
      }, {
        animation: 'ios-transition',
        duration: 350
      });
  }

  //for keeping keyboard up when + button is pressed for keywords
  keepKeyboard(event){
    if(!this.shouldBlur){
      event.target.focus();
      this.shouldBlur = true;
    }
  }

  playAnimation(id){

      let animation = Bodymovin.loadAnimation({
          container: document.getElementById('icon_'+id),
          path: 'assets/img/like.json',
          renderer: 'svg',
          loop: false, // Optional
          autoplay: true, // Optional
          name: "Heart", // Name for future reference. Optional.
      })
      animation.addEventListener('complete', function() {
        animation.destroy()
      })
  }
}

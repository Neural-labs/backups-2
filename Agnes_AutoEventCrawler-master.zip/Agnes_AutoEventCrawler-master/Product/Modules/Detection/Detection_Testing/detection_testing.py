

class DetectionTester:
    model = None
    def __init__(self, model=None):
        if not model:
            raise ValueError('No model provided to test')

        self.model = model

    def do_testing(self):
        pass





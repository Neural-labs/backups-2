import { Injectable } from '@angular/core';
import { Headers, Http, RequestOptions } from '@angular/http';
import 'rxjs/add/operator/toPromise';
import { Agnes } from '../app/app.component';

@Injectable()
export class MeService {
  private headers = new Headers({'Content-Type': 'application/json'});

  constructor(private http:Http) {
  }

  hideProfile(data): Promise<any>{
    data["token"] = localStorage.getItem('agnesToken');
    data["timestamp"] = new Date()
    let addUrl = Agnes.API_URL + '/hide_my_profile';
    let options = new RequestOptions({ headers: this.headers });

    return this.http.post(addUrl, data, options)
      .toPromise()
      .then(response => response.json() as Object[])
      .catch(this.handleError);
  }

  contactAgnes(data): Promise<any>{
    data["token"] = localStorage.getItem('agnesToken');
    data["timestamp"] = new Date()
    let addUrl = Agnes.API_URL + '/contactadmin';
    let options = new RequestOptions({ headers: this.headers });

    return this.http.post(addUrl, data, options)
      .toPromise()
      .then(response => response.json() as Object[])
      .catch(this.handleError);
  }

  editMe(data): Promise<any>{
    data['token'] = localStorage.getItem('agnesToken');
    data["timestamp"] = new Date()
    data['users_id'] = data['_id'];

    let addUrl = Agnes.API_URL + '/edit_user';
    let options = new RequestOptions({ headers: this.headers });

    return this.http.post(addUrl, data, options)
      .toPromise()
      .then(response => response.json() as Object[])
      .catch(this.handleError);
  }

  changePassword(data): Promise<any>{
    data["token"] = localStorage.getItem('agnesToken');
    data["timestamp"] = new Date()
    let addUrl = Agnes.API_URL + '/changePassword';
    let options = new RequestOptions({ headers: this.headers });

    return this.http.post(addUrl, data, options)
      .toPromise()
      .then(response => response.json() as Object[])
      .catch(this.handleError);
  }

  updateDeviceToken(data): Promise<any>{
    data["token"] = localStorage.getItem('agnesToken');
    data["timestamp"] = new Date()
    let addUrl = Agnes.API_URL + '/update_deviceId';
    let options = new RequestOptions({ headers: this.headers });

    return this.http.post(addUrl, data, options)
      .toPromise()
      .then(response => response.json() as Object[])
      .catch(this.handleError);
  }

  rejectInvite(data): Promise<any>{
    data["token"] = localStorage.getItem('agnesToken');
    data["timestamp"] = new Date()
    let addUrl = Agnes.API_URL + '/reject_invite';
    let options = new RequestOptions({ headers: this.headers });

    return this.http.post(addUrl, data, options)
      .toPromise()
      .then(response => response.json() as Object[])
      .catch(this.handleError);
  }

  getFriends(data): Promise<any>{
    data["token"] = localStorage.getItem('agnesToken');
    data["timestamp"] = new Date()
    let addUrl = Agnes.API_URL + '/user_friends';
    let options = new RequestOptions({ headers: this.headers });

    return this.http.post(addUrl, data, options)
      .toPromise()
      .then(response => response.json() as Object[])
      .catch(this.handleError);
  }

  logSearch(data): Promise<any>{
    data["token"] = localStorage.getItem('agnesToken');
    data["timestamp"] = new Date()
    let addUrl = Agnes.API_URL + '/logSearch';
    let options = new RequestOptions({ headers: this.headers });

    return this.http.post(addUrl, data, options)
      .toPromise()
      .then(response => response.json() as Object[])
      .catch(this.handleError);
  }

  removeNotifications(data): Promise<any>{
    data["token"] = localStorage.getItem('agnesToken');
    data["timestamp"] = new Date()
    let addUrl = Agnes.API_URL + '/removeNotification';
    let options = new RequestOptions({ headers: this.headers });

    return this.http.post(addUrl, data, options)
        .toPromise()
        .then(response => response.json() as Object[])
        .catch(this.handleError);
  }

  readNotification(data) : Promise<any>{
    data["token"] = localStorage.getItem('agnesToken');
    data["timestamp"] = new Date()
    let addUrl = Agnes.API_URL + '/readNotification';
    let options = new RequestOptions({ headers: this.headers });

    return this.http.post(addUrl, data, options)
        .toPromise()
        .then(response => response.json() as Object[])
        .catch(this.handleError);
  }

  readNotifications(data) : Promise<any>{
    data["token"] = localStorage.getItem('agnesToken');
    data["timestamp"] = new Date()
    let addUrl = Agnes.API_URL + '/readNotifications';
    let options = new RequestOptions({ headers: this.headers });

    return this.http.post(addUrl, data, options)
        .toPromise()
        .then(response => response.json() as Object[])
        .catch(this.handleError);
  }


  getNotifications(data):Promise<any>{
    data["token"] = localStorage.getItem('agnesToken');
    data["timestamp"] = new Date()
    let addUrl = Agnes.API_URL + '/allUserNotifications';
    let options = new RequestOptions({ headers: this.headers });

    return this.http.post(addUrl, data, options)
        .timeout(5000)
        .toPromise()
        .then(response => response.json() as Object[])
        .catch(this.handleError);
  }

  getProposedGeneralWords(data): Promise<any> {
    data["token"] = localStorage.getItem('agnesToken');
    data["timestamp"] = new Date()
    let addUrl = Agnes.API_URL + '/getProposedGeneralWords';
    let options = new RequestOptions({headers:this.headers});

    return this.http.post(addUrl, data, options)
        .toPromise()
        .then(response => response.json() as Object[])
        .catch(this.handleError)
  }


  addKeyWords(data): Promise<any> {
      data["token"] = localStorage.getItem('agnesToken');
      data["timestamp"] = new Date()
      let addUrl = Agnes.API_URL + '/addKeyWords';
      let options = new RequestOptions({headers:this.headers});

      return this.http.post(addUrl, data, options)
          .toPromise()
          .then(response => response.json() as Object[])
          .catch(this.handleError)
  }

  getUserLastLogin(data): Promise<any> {
      data["token"] = localStorage.getItem('agnesToken');
      data["timestamp"] = new Date()
      let addUrl = Agnes.API_URL + '/getUserLastLogin';
      let options = new RequestOptions({headers:this.headers});

      return this.http.post(addUrl, data, options)
          .toPromise()
          .then(response => response.json() as Object[])
          .catch(this.handleError)
  }

  getReferral(data): Promise<any> {
      data["token"] = localStorage.getItem('agnesToken');
      data["timestamp"] = new Date()
      let addUrl = Agnes.API_URL + '/referralCode';
      let options = new RequestOptions({headers:this.headers});

      return this.http.post(addUrl, data, options)
          .toPromise()
          .then(response => response.json() as Object[])
          .catch(this.handleError)
  }

  submitReferralCode(data): Promise<any>{
    data["token"] = localStorage.getItem('agnesToken');
    data["timestamp"] = new Date()
    let addUrl = Agnes.API_URL + '/trackReferralCode';
    let options = new RequestOptions({ headers: this.headers });

    return this.http.post(addUrl, data, options)
        .toPromise()
        .then(response => response.json() as Object[])
        .catch(this.handleError);
  }

  validateReferralCode(data): Promise<any>{
    let addUrl = Agnes.API_URL + '/referralCodeValidation';
    let options = new RequestOptions({ headers: this.headers });
    data["timestamp"] = new Date()

    return this.http.post(addUrl, data, options)
        .toPromise()
        .then(response => response.json() as Object[])
        .catch(this.handleError);
  }

  getCommunityCount(data): Promise<any>{
    let addUrl = Agnes.API_URL + '/users_community_count';
    let options = new RequestOptions({ headers: this.headers });
    data["timestamp"] = new Date()

    return this.http.post(addUrl, data, options)
        .toPromise()
        .then(response => response.json() as Object[])
        .catch(this.handleError);
  }

  pebbleRewards(): Promise<any> {
    let addUrl = Agnes.API_URL + '/giftCardsList';
    let options = new RequestOptions({headers:this.headers});

    return this.http.post(addUrl, options)
        .toPromise()
        .then(response => response.json() as Object[])
        .catch(this.handleError)
  }

  claimReward(data): Promise<any>{
    data["token"] = localStorage.getItem('agnesToken');
    data["timestamp"] = new Date()
    let addUrl = Agnes.API_URL + '/giftAPI';
    let options = new RequestOptions({ headers: this.headers });

    return this.http.post(addUrl, data, options)
        .toPromise()
        .then(response => response.json() as Object[])
        .catch(this.handleError);
  }

  getReferralLink(data): Promise<any>{
    data["token"] = localStorage.getItem('agnesToken');
    data["timestamp"] = new Date()
    let addUrl = Agnes.API_URL + '/createSingleBranchIoLink';
    let options = new RequestOptions({ headers: this.headers });

    return this.http.post(addUrl, data, options)
        .toPromise()
        .then(response => response.json() as Object[])
        .catch(this.handleError);
  }

  createDeepLink(data): Promise<any>{
    data["token"] = localStorage.getItem('agnesToken');
    data["timestamp"] = new Date()
    let addUrl = Agnes.API_URL + '/createDeepLinkForEntity';
    let options = new RequestOptions({ headers: this.headers });

    return this.http.post(addUrl, data, options)
        .toPromise()
        .then(response => response.json() as Object[])
        .catch(this.handleError);
  }

  private handleError(error: any): Promise<any> {
    console.error('An error occurred', error);
    return Promise.reject(error.message || error);
  }
}

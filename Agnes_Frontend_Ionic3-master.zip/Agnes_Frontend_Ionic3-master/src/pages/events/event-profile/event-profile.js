"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var core_1 = require('@angular/core');
var events_service_1 = require('../events.service');
var groups_service_1 = require('../../groups/groups.service');
var ionic_native_1 = require('ionic-native');
var report_1 = require('../../popups/report/report');
var event_details_1 = require('../../popups/event-details/event-details');
var app_component_1 = require('../../../app/app.component');
var map_options_1 = require('./map-options/map-options');
var group_profile_1 = require('../../groups/group-profile/group-profile');
var invite_friends_1 = require('../../popups/invite-friends/invite-friends');
var EventProfile = (function () {
    function EventProfile(navParams, navCtrl, platform, events, popoverCtrl, eventsService, groupsService, toastCtrl, alertCtrl, actionSheetCtrl) {
        this.navParams = navParams;
        this.navCtrl = navCtrl;
        this.platform = platform;
        this.events = events;
        this.popoverCtrl = popoverCtrl;
        this.eventsService = eventsService;
        this.groupsService = groupsService;
        this.toastCtrl = toastCtrl;
        this.alertCtrl = alertCtrl;
        this.actionSheetCtrl = actionSheetCtrl;
    }
    EventProfile.prototype.ngOnInit = function () {
        var _this = this;
        this.events.publish('pagePushed');
        this.event = this.navParams.data.event;
        this.user = this.navParams.data.user;
        //generate triangle image if no picurl
        this.event['displayURL'] = (this.event['picurl'] == '')
            ? "assets/img/pattern_" + Math.floor((Math.random() * 15) + 1) + '.png'
            : this.event['picurl'];
        //create time display string
        var start = app_component_1.Agnes.processGMT(this.event["starttime"].replace(/[-\+]\d\d\d\d/, 'Z'));
        this.startDate = start.date.toUpperCase();
        var end = app_component_1.Agnes.processGMT(this.event['endtime'].replace(/[-\+]\d\d\d\d/, 'Z'));
        var endDate = (start.date == end.date) ? '' : end.date + ' ';
        this.timeString = (start.time == "12:01AM" && start.time == end.time) ? 'TBA' : start.time + ' - ' + endDate + end.time;
        //initialize other fields
        this.isMatched = (this.navParams.data.type == 'matched');
        this.mapApps = [];
        this.loading = true;
        this.host = { 'grpname': '', 'displayURL': '' };
        this.edited = false;
        //get event host, if one exists
        if (this.event['grps'].length > 0) {
            var data = { "grp": [this.event['grps'][0]] };
            this.groupsService.getGroupsFromId(data).then(function (groups) {
                _this.loading = false;
                if (groups && groups.length > 0) {
                    //should only return 1 group
                    groups[0]['displayURL'] = 'url("' + (groups[0]['picurl'] == '' || !groups[0]['picurl']
                        ? "assets/img/pattern_" + Math.floor((Math.random() * 15) + 1) + '.png' : groups[0]['picurl']) + '")';
                    _this.host = groups[0];
                }
                else {
                    _this.host = null;
                    var rg = {
                        'events_id': _this.event['_id'],
                        'groups_id': _this.event['grps'][0]['_id']
                    };
                    _this.eventsService.removeGroupFromEvent(rg).then(function (val) {
                    }).catch(function (err) {
                    });
                }
            }).catch(function (err) {
                _this.loading = false;
                _this.host = null;
            });
        }
        else {
            this.loading = false;
        }
        this.setMenuButtons();
        localStorage.setItem('agnesCurrentEvent', this.event['_id']);
    };
    EventProfile.prototype.imgLoad = function (ev) {
        var img = ev.target;
        if (img.naturalWidth > img.naturalHeight) {
            this.orientation = 'landscape';
        }
        else if (img.naturalWidth < img.naturalHeight) {
            this.orientation = 'portrait';
        }
        else {
            this.orientation = 'even';
        }
    };
    EventProfile.prototype.imgError = function () {
        this.event['displayURL'] = "assets/img/pattern_" + Math.floor((Math.random() * 15) + 1) + '.png';
    };
    EventProfile.prototype.closeEventProfile = function (e, data) {
        if (!e || e.direction == 4) {
            // pipe edited info back to groups list
            if (this.edited) {
                this.events.publish('eventProfileData', { 'event': this.event, 'category': 'edit' });
            }
            else {
                if (data) {
                    data['isMatched'] = this.isMatched;
                    this.events.publish('eventProfileData', data);
                }
            }
            localStorage.removeItem('agnesCurrentEvent');
            this.navCtrl.pop({
                animate: true,
                animation: 'ios-transition',
                duration: 350,
                easing: "ease-in-out",
                direction: "back"
            }).then(function () {
            });
        }
    };
    //set up action sheet menu buttons based on user info
    EventProfile.prototype.setMenuButtons = function () {
        var _this = this;
        //add Edit button if user is admin of this event
        this.menuButtons = (this.event['admin'].indexOf(this.user['_id']) != -1) ?
            [
                { text: 'Edit Event', icon: 'md-create', handler: function () { _this.editEvent(); } }
            ] : [];
        //add Share to Group button if user is admin of at least one group
        // if(this.user['grp'].map(function(a){return a.admin;}).indexOf(true) != -1){
        //   this.menuButtons.push({
        //     text: 'Share to Group',
        //     icon: 'md-contacts',
        //     handler: () => {this.shareToGroup();}
        //   });
        // }
        //add Share and Directions buttons
        this.menuButtons = this.menuButtons.concat([
            {
                text: 'Share Event',
                icon: 'md-share',
                handler: function () { _this.share(); }
            },
            {
                text: 'Get Directions',
                icon: 'md-pin',
                handler: function () { _this.toLocation(); }
            }]);
        //add button for event website, if there is one
        if (this.event['weburl'][0] != null && this.event['weburl'][0] != '') {
            this.menuButtons.push({
                text: 'Event Website',
                icon: 'ios-link',
                handler: function () {
                    //tracking
                    if (window['fabric']) {
                        window['fabric'].Answers.sendCustomEvent('Event Profile', { type: 'website' });
                    }
                    window.open(_this.event['weburl'][0], '_blank', 'location=yes');
                }
            });
        }
        var lastBtn = (this.event['admin'].indexOf(this.user['_id']) != -1)
            ? { text: 'Delete Event', icon: 'md-trash', handler: function () {
                    var alert = _this.alertCtrl.create({
                        title: 'Delete your event',
                        message: "Are you sure you want to delete " + _this.event['evtname'] + "?",
                        buttons: [
                            {
                                text: 'Cancel',
                                handler: function () {
                                },
                                role: 'cancel'
                            },
                            {
                                text: 'Yes',
                                handler: function () {
                                    //admin does want to delete this event
                                    _this.deleteEvent();
                                }
                            }
                        ]
                    });
                    alert.present();
                } }
            : { text: 'Report Event', icon: 'md-flag', handler: function () { _this.reportEvent(); } };
        //add standard Report and Cancel buttons
        var stnd = [
            lastBtn,
            {
                text: 'Cancel',
                role: 'cancel',
                icon: 'md-close',
                handler: function () { }
            }
        ];
        this.menuButtons = this.menuButtons.concat(stnd);
    };
    //for menu options
    EventProfile.prototype.openEventMenu = function () {
        var actionSheet = this.actionSheetCtrl.create({
            title: '',
            buttons: this.menuButtons
        });
        actionSheet.present();
    };
    //open navigation app to direct user to event
    EventProfile.prototype.toLocation = function () {
        var _this = this;
        //tracking
        if (window['fabric']) {
            window['fabric'].Answers.sendCustomEvent('Event Profile', { type: 'open maps' });
        }
        var location = this.event["location"];
        if (this.platform.is('mobile') && this.platform.is('cordova')) {
            var isAvailable = ionic_native_1.LaunchNavigator.isAppAvailable(ionic_native_1.LaunchNavigator.APP.GOOGLE_MAPS);
            if (!localStorage.getItem("agnesMaps")) {
                if (isAvailable) {
                    this.setMaps('Google Maps');
                }
                else {
                    ionic_native_1.LaunchNavigator.availableApps().then(function (results) {
                        _this.mapApps = results.map(function (a) { if (results[a])
                            return ionic_native_1.LaunchNavigator.getAppDisplayName(a); });
                        var mapOptions = _this.popoverCtrl.create(map_options_1.MapOptions, {
                            'maps': _this.mapApps
                        }, {
                            'enableBackdropDismiss': false,
                            'cssClass': 'small'
                        });
                        mapOptions.present({
                            animate: false
                        });
                        mapOptions.onDidDismiss(function (data) {
                            if (data) {
                                _this.setMaps(data);
                            }
                        });
                    }).catch(function (err) {
                        console.log('available maps err', err);
                    });
                }
            }
            else {
                ionic_native_1.LaunchNavigator.navigate(location, {
                    app: localStorage.getItem("agnesMaps")
                });
            }
        }
        else {
            window.open('https://www.google.com/maps/search/' + location);
        }
    };
    //save default navigation app in local storage
    EventProfile.prototype.setMaps = function (name) {
        if (name == "VZ Navigator") {
            name = "com.vznavigator.Generic";
        }
        else {
            name = name.toLowerCase();
            name = name.replace(' ', '_');
        }
        localStorage.setItem("agnesMaps", name);
        ionic_native_1.LaunchNavigator.navigate(this.event["location"], {
            app: name
        });
    };
    EventProfile.prototype.reportEvent = function () {
        //tracking
        if (window['fabric']) {
            window['fabric'].Answers.sendCustomEvent('Event Profile', { type: 'report' });
        }
        var reportPage = this.popoverCtrl.create(report_1.ReportPage, {
            'entityID': this.event['_id'],
            'entityName': this.event['evtname'],
            'user': this.user,
            'type': 'event',
            'platform': this.platform
        }, { 'enableBackdropDismiss': true });
        reportPage.present({
            animate: false
        });
        reportPage.onDidDismiss(function (data) {
        });
    };
    //view fullscreen event image
    EventProfile.prototype.viewEvtImg = function () {
        ionic_native_1.PhotoViewer.show(this.event['picurl']);
    };
    //open event details popup to edit event if user is event admin
    EventProfile.prototype.editEvent = function () {
        var _this = this;
        //tracking
        if (window['fabric']) {
            window['fabric'].Answers.sendCustomEvent('Event Profile', { type: 'edit' });
        }
        var editEvent = this.popoverCtrl.create(event_details_1.EventDetails, {
            'type': 'Edit',
            'user': this.user,
            'platform': this.platform,
            'event': this.event
        }, { 'enableBackdropDismiss': true });
        editEvent.present({
            animate: true,
            animation: 'ios-transition',
            duration: 500,
            easing: "ease-in-out",
            direction: "right"
        });
        editEvent.onDidDismiss(function (data) {
            if (data) {
                if (data.deleted) {
                    _this.deleteEvent();
                }
                else {
                    _this.event = data;
                    _this.edited = true;
                }
            }
        });
    };
    //remove event from database (only available if user is event admin)
    EventProfile.prototype.deleteEvent = function () {
        var _this = this;
        //tracking
        if (window['fabric']) {
            window['fabric'].Answers.sendCustomEvent('Event Profile', { type: 'delete' });
        }
        var data = {
            'event': this.event,
            'events_id': this.event['_id']
        };
        this.eventsService.deleteEvent(data).then(function (value) {
            if (value) {
                var toast = _this.toastCtrl.create({
                    message: "You've successfully deleted " + _this.event['evtname'] + ".",
                    duration: 4000,
                    position: 'bottom',
                    cssClass: 'delete',
                    showCloseButton: true,
                    closeButtonText: 'Undo'
                });
                toast.present();
                toast.onDidDismiss(function (event, role) {
                    // if(role == 'close'){
                    //   this.undoNope(eventFlag);
                    // }
                });
                var ind = _this.user['evtrsvp'].indexOf(_this.event['_id']);
                if (ind != -1) {
                    _this.user['evtrsvp'].splice(ind, 1);
                }
                _this.events.publish('updateUser', { 'user': _this.user, 'showChat': _this.user['canChat'] });
                _this.closeEventProfile(null, {
                    'category': 'delete',
                    'event': _this.event,
                    'eventFlag': -1
                });
            }
        }).catch(function (error) {
            console.log('delete event error', error);
            var errorMessage = "Sorry, something went wrong - try deleting " + _this.event['evtname'] + " again!";
            app_component_1.Agnes.showError(errorMessage);
        });
    };
    //user wants to attend event - call to static methods in Agnes class
    EventProfile.prototype.going = function (e) {
        var _this = this;
        document.querySelector('ng-component')['style']['filter'] = 'none';
        //tracking
        if (window['fabric']) {
            window['fabric'].Answers.sendCustomEvent('Event Profile', { type: 'add to cal' });
        }
        this.events.subscribe('goingDone', function (data) {
            _this.closeEventProfile(null, { 'user': _this.user, 'category': 'going' });
        });
        app_component_1.Agnes.going(this.event, this.isMatched);
    };
    //share event via email or social media
    EventProfile.prototype.share = function () {
        //tracking
        if (window['fabric']) {
            window['fabric'].Answers.sendShare('event');
        }
        // if (this.platform.is('cordova')) {
        //
        //   let message = "Hey! I think you might be interested in this event:\n\n" +
        //     this.event['evtname'] + '\n\n';
        //
        //   let subj = "Check out \"" + this.event['evtname'] + "\"";
        //
        //   SocialSharing.share(message, subj, this.event['picurl'], 'https://agnes.io/share/event/' + this.event['_id'])
        //     .then((val) => {
        //     })
        //     .catch((err) => {
        //     });
        //
        // }
        // else {
        //   Agnes.showError("Please install Agnes from the App Store or Google Play store to share events.");
        // }
        var shareEvent = this.popoverCtrl.create(invite_friends_1.InviteFriends, {
            'user': this.user,
            'objectID': this.event['_id'],
            'type': 'share',
            'event': this.event
        }, { 'enableBackdropDismiss': false });
        shareEvent.present({
            animate: false
        });
    };
    //IGYIG
    EventProfile.prototype.ifYouGo = function () {
        //tracking
        if (window['fabric']) {
            window['fabric'].Answers.sendCustomEvent('Event Profile', { type: 'igiyg' });
        }
        var iygSearch = this.popoverCtrl.create(invite_friends_1.InviteFriends, {
            'user': this.user,
            'objectID': this.event['_id'],
            'type': 'IGIYG'
        }, { 'enableBackdropDismiss': false });
        iygSearch.present({
            animate: false
        });
    };
    //share this event w/ members of a group that user is an admin of
    EventProfile.prototype.shareToGroup = function () {
    };
    //open profile of hosting group
    EventProfile.prototype.openGroupProfile = function (group) {
        var _this = this;
        //tracking
        if (window['fabric']) {
            window['fabric'].Answers.sendCustomEvent('Event Profile', { 'type': 'opening host group profile ' });
        }
        this.events.subscribe('groupProfileData', function (data) {
            if (data.category == 'edit') {
                _this.host = data.group;
            }
            else if (data.category == 'delete') {
                _this.host = null;
            }
            _this.events.unsubscribe('groupProfileData');
        });
        this.navCtrl.push(group_profile_1.GroupProfile, {
            'group': group,
            'user': this.user,
            'platform': this.platform
        }, {
            animation: 'ios-transition',
            duration: 350
        });
    };
    __decorate([
        core_1.ViewChild('descriptionScroll')
    ], EventProfile.prototype, "descriptionScroll", void 0);
    __decorate([
        core_1.ViewChild('profileScroll')
    ], EventProfile.prototype, "profileScroll", void 0);
    EventProfile = __decorate([
        core_1.Component({
            selector: 'event-profile',
            templateUrl: 'event-profile.html',
            providers: [events_service_1.EventsService, groups_service_1.GroupsService]
        })
    ], EventProfile);
    return EventProfile;
}());
exports.EventProfile = EventProfile;

import { Component } from '@angular/core';
import { NavParams, ViewController, Events, IonicPage } from 'ionic-angular';

@IonicPage()
@Component({
    selector: 'agnes-rating',
    templateUrl: 'agnes-rating.html',
    providers: []
})

export class AgnesRating {
    user: Object;
    event: Object;
    rating: number;
    stars = [1,2,3,4,5];

    constructor(public navParams: NavParams,
                public events: Events,
                public viewCtrl: ViewController) {
    }

    ngOnInit(){
        this.user = JSON.parse(localStorage.getItem('agnesUser'));
        console.log(this.navParams.data.event);
        this.event = {
            '_id':this.navParams.data.event['_id'],
            'evtname':this.navParams.data.event['evtname'],
            'thumbnail': this.navParams.data.event['thumbnail'] == '' ? this.navParams.data.event['picurl'] : this.navParams.data.event['thumbnail']
        };
        console.log(this.event);
        this.rating = 0;
    }

    closeAgnesRating(rating){
        let timeout = 0;

        if(rating != null){
            //TODO: send rating to backend
            this.rating = rating + 1;
            timeout = 250;
        }
        setTimeout(() => {
            this.viewCtrl.dismiss();
        },timeout);
    }

}

import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';

import { GroupFeedPage } from './group-feed';
import { ComponentsModule } from '../../../../components/components.module';

@NgModule({
    declarations: [
        GroupFeedPage
    ],
    imports: [
        IonicPageModule.forChild(GroupFeedPage),
        ComponentsModule
    ],
    exports: [
        GroupFeedPage
    ]
})

export class GroupFeedPageModule { }

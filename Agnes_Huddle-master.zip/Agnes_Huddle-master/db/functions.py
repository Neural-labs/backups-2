from config import conn
from pymongo import UpdateOne
from bson.objectid import ObjectId

Agnes = conn.Agnes
huddle_feeds = Agnes.huddle_feeds
huddle_requests = Agnes.huddle_requests
huddle_requests_past = Agnes.huddle_requests_past

batch_size = 100

# def readHuddleRequests(new=True):
#
#     if new:
#         return huddle_requests.find({'request_status':'new'}, no_cursor_timeout=True).limit(100)
#     else:
#         return huddle_requests.find({}, no_cursor_timeout=True)
#
# def setHuddleRequestFinished(current_requests_collection, request):
#     request['request_status'] = 'done'
#     current_requests_collection.update_one({'_id':request['_id']}, {'$set':{'request_status':'done'}})

def getHuddleCursor(query):
    return huddle_feeds.find(query, {'currentFeed':False}, no_cursor_timeout=True)

def getHuddleCursorBatch(last_id):
    if not last_id:
        return huddle_feeds.find({}, no_cursor_timeout=True).sort('_id', 1).limit(batch_size)
    return huddle_feeds.find({'_id': {'$gt': last_id}}, no_cursor_timeout=True).sort('_id', 1).limit(batch_size)

def getUserHuddle(collection, user_id):
    return collection.find_one({'users_id':user_id})

def initLiveUpdate(users_id):
    huddle_feeds.update_one({'users_id':users_id},{'$set': {'live_update':[]}})

#huddle_feed_collection, user_id, huddle, new_feed, huddle_hash
def updateHuddle(feed_collection, user_id, new_feed, huddle_hash, updateObj):
    user_id = ObjectId(user_id)
    groupUpdate = updateObj['groupUpdate']
    eventsFriends = updateObj['eventsFriends']
    recentlyAddedEvent = updateObj['recentlyAddedEvent']
    eventTrending = updateObj['eventTrending']
    eventFeatured = updateObj['eventFeatured']
    recommendedEvent = updateObj['recommendedEvent']
    discoverEvent = updateObj['discoverEvent']


    # huddle['recentlyAddedEvent'] = checkEventTimeList(huddle['recentlyAddedEvent'])
    # huddle['eventTrending'] = checkEventTimeList(huddle['eventTrending'])
    # huddle['eventsFriends'] = checkEventTimeList(huddle['eventsFriends'])
    # huddle['eventFeatured'] = checkEventTimeList(huddle['eventFeatured'])
    # huddle['recommendedEvent'] = checkEventTimeList(huddle['recommendedEvent'], debug=False)
    # huddle['discoverEvent'] = checkEventTimeList(huddle['discoverEvent'])
    # print len(groupUpdate)
    # print len(eventsFriends)
    # print len(recentlyAddedEvent)
    # print len(eventTrending)
    # print len(eventFeatured)
    # print len(recommendedEvent)
    # print len(discoverEvent)
    # raise ValueError('stop')


    result = feed_collection.update_one({'users_id':user_id},
                               {'$set':
                                    {
                                        'currentFeed':new_feed,
                                        'huddle_hash':huddle_hash,
                                        'groupUpdate':groupUpdate,
                                        'eventsFriends':eventsFriends,
                                        'recentlyAddedEvent':recentlyAddedEvent,
                                        'eventTrending':eventTrending,
                                        'eventFeatured':eventFeatured,
                                        'recommendedEvent':recommendedEvent,
                                        'discoverEvent':discoverEvent,
                                        'live_update':[]
                                    }
                               })

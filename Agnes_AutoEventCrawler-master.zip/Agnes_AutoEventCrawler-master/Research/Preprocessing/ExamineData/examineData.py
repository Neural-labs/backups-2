from collections import Counter
import pickle
from config.db_config import getDBConn
import logging
from Preprocessing.CollectFeatures import CollectExtractionFeatures, CollectIdentificationFeatures
from Utilities import EventTree, DataFilter, DateExtraction, LocationExtraction
import re
import numpy as np
import random


dbConn = getDBConn('dev')
Agnes = dbConn.Agnes
event_coll = Agnes.autocrawler_events
control_coll = Agnes.autocrawler_control
domain_coll = Agnes.autocrawler_domain_pages
ext_data_coll = Agnes.autocrawler_ext_data
id_data_coll = Agnes.autocrawler_id_data

def examineData():

    # examineUniqueEvtSources()
    # examineCommunities()
    # examineDomainPages()
    # examineExtData()
    # examineIdData()
    examineEvents()
    # examineSources()

def examineEvents():
    return_fields = {
        'HTML':1,
        'url':1,
        'evtsource':1
    }
    events = getEvents(return_fields)
    meta_count = 0

    # html_embedding_model = CollectIdentificationFeatures.getPageEmbeddingV2()
    # w2v_embedding_model = CollectIdentificationFeatures.getWord2VecEmbedding()
    # char_embedding_model = CollectIdentificationFeatures.getCharEmbedding()

    flag0 = False
    flag1 = False
    for event in events:
        if not 'url' in event or not 'HTML' in event:
            continue
        # pass
        page_url = event['url']
        page_html = event['HTML']
        #
        # manual_features = CollectIdentificationFeatures.extractFeaturesManual(page_url, page_html)
        #
        # html_features = CollectIdentificationFeatures.extractHTMLFeaturesEmbedding(html_embedding_model, page_html)
        #
        # content_features = CollectIdentificationFeatures.extractContentFeaturesEmbedding(w2v_embedding_model, page_html)
        #
        # url_features = CollectIdentificationFeatures.extractURLFeaturesEmbedding(char_embedding_model, page_url)
        #
        if event['evtsource'] == 'browse.calendar.gwu.edu':
            pass
            manual_features = CollectIdentificationFeatures.extractFeaturesManual(page_url, page_html)

            # html_features = CollectIdentificationFeatures.extractHTMLFeaturesEmbedding(html_embedding_model, page_html)
            #
            # content_features = CollectIdentificationFeatures.extractContentFeaturesEmbedding(w2v_embedding_model,
            #                                                                                  page_html)
            #
            # url_features = CollectIdentificationFeatures.extractURLFeaturesEmbedding(char_embedding_model, page_url)
            # flag0 = False
            raise ValueError('stop')
        # else:




        # else:
        #     print manual_features
        #     print
        #     print list(pickle.loads(html_features))
        #     print
        #     print list(pickle.loads(content_features))
        #     print
        #     print list(pickle.loads(url_features))
        #     print
        #
        # if 'HTML' not in event:
        #     continue
        # if '<meta' in event['HTML']:
        #     meta_count += 1

        # if 'evtsource' not in event or not event['evtsource']:
        #     continue
        # counts[event['evtsource']] += 1
        # if counter % 1000 == 0:
        #     print 'Meta Count:',meta_count,'Counter:',counter
        #     print
        # counter += 1


def examineExtData():
    data = getExtData()
    counter = 0

    min_values = []
    max_values = []

    for data_item in data:
        features = getExtFeatures(data_item)

        if not features:
            continue

        counter += 1
        min_values = updateValues(min_values, features, min)
        max_values = updateValues(max_values, features, max)

        # for index in range(len(features)):
        #     values[index] = fn(values[index], features[index])

        # if counter
        # print counter
        if counter % 10000 == 0:
            print 'Counter',counter
            print 'Min Values'
            print min_values
            print 'Max Values'
            print max_values
            print '\n'
            # raise ValueError('stop')

    print 'Min Values'
    print min_values
    print 'Max Values'
    print max_values

def examineIdData():
    return_fields = {}
    data = getIdData(return_fields)
    counter = 0

    min_values = []
    max_values = []

    for data_item in data:
        features = getIdFeatures(data_item)

        if not features:
            continue

        counter += 1
        min_values = updateValues(min_values, features, min)
        max_values = updateValues(max_values, features, max)

        if counter % 10000 == 0:
            print 'Counter', counter
            print 'Min Values'
            print min_values
            print 'Max Values'
            print max_values
            print '\n'

    print 'Min Values'
    print min_values
    print 'Max Values'
    print max_values

def getExtFeatures(sample):
    features = []
    html_features = sample['html_embedding']
    if not html_features:
        return None
    features += list(pickle.loads(html_features))
    features += sample['manual_features']
    features += sample['structure_features']

    if np.isnan(np.sum(features)):
        return None

    return features

def getIdFeatures(sample):

    html_features = sample['html_embedding']
    url_features = sample['url_embedding']
    content_features = sample['content_embedding']
    for features in [html_features, url_features, content_features]:
        if not features:
            return None

    html_features = list(pickle.loads(html_features))
    url_features = list(pickle.loads(url_features))
    content_features = list(pickle.loads(content_features))
    manual_features = sample['manual_features']

    features = html_features + url_features + content_features + manual_features

    if np.isnan(np.sum(features)):
        return None

    return features

def updateValues(values, features, fn):
    if not values:
        return list(features)
    for index in range(len(features)):
        values[index] = fn(values[index], features[index])
    return values

def examineDomainPages():
    domainCounts = {}
    pages = domain_coll.find({}, no_cursor_timeout=True)
    counter = 0
    total = pages.count()

    for page in pages:
        counter += 1
        print counter, 'of', total
        domain = page['Domain']
        if domain in domainCounts:
            domainCounts[domain] += 1
        else:
            domainCounts[domain] = 1

    for domain in domainCounts:
        print domain, domainCounts[domain]


def examineCommunities():
    pass

def examineUniqueEvtSources():

    pass

def examineSources():

    # loc_sources
    # garbage_sources
    # script_sources
    # source_counts

    legit_sources = []
    for source,count in source_counts:
        if source in loc_sources or source in garbage_sources or source in script_sources:
            continue
        legit_sources.append((source, count))

    print legit_sources
    random.shuffle(legit_sources)

    test_sources = [a for a in legit_sources[:10]]

    train_sources = [a for a in legit_sources[10:]]

    print
    print [a[0] for a in test_sources]
    print test_sources
    print
    print [a[0]for a in train_sources]
    print train_sources






def invalid(event):
    if not 'HTML' in event:
        return True
    if not 'netx_tree_pkl' in event:
        return True
    if event['netx_tree_pkl'] == {}:
        return True
    return False

def getEvents(return_fields):
    return event_coll.find({},return_fields, no_cursor_timeout=True)

def getControl():
    return control_coll.find({}, no_cursor_timeout=True)

def getExtData():
    # if not last_id:
    return ext_data_coll.find({}, no_cursor_timeout=True)
    # return ext_data_coll.find({}, no_cursor_timeout=True).sort('random_id',-1).limit(10000)
    # return ext_data_coll.find({'random_id': {'$lt': last_id}}, no_cursor_timeout=True).limit(100000).sort('random_id',-1)

def getIdData(return_fields):
    return id_data_coll.find({},return_fields, no_cursor_timeout=True)

def getExtDataBatch(min_id):
    return ext_data_coll.find({'random_id': {'$lt': min_id}}, no_cursor_timeout=True).limit(10000).sort('random_id',-1)


'''
Pos:

newschool 950
cambridge 12
marymount 635
ithacaNY 410
brown 1376
northeastern 251
washington 1632
towsonMD 281
udel 506
ithaca 142
barnard 27
colgate 517
oberlinOH 472
towson 28
groupten 127
howard 1
cornell 6008
bostonMA 307
trinitydc 3
dartmouth 190
bu 170
gmu 2
temple 185
williams 211
georgetown 2191
columbia 857
usgbc 129
goucher 142
osu 73
risd 111
baltimoreMD 120
washingtonDC 2782
udc 13
harvard 1176
newyorkNY 87
princeton 5069
upenn 1108
uri 354
gwu 1557
american 3123
cambridgeMA 39
jhu 31
trinity 1
yale 16

Control:
georgetown 2526
columbia 1241
princeton 2801
cornell 10894
upenn 1875
newschool 1028
gwu 10366
bu 5447
american 2836
harvard 1476
jhu 1096
cmu 7131

Domain:
georgetown 5304
columbia 3457
brown 2
princeton 10657
cornell 100001
upenn 5059
newschool 3411
gwu 133321
bu 32149
american 6183
harvard 4022
jhu 3514
cmu 55095
'''

pos_evtsources = [u'events.cornell.edu', u'american.edu', u'browse.calendar.gwu.edu', u'guevents.georgetown.edu', u'gwsports.com', u'orientation.dos.cornell.edu', u'georgetowndc.com', u'engineering.cornell.edu', u'washington.org', u'lisner.gwu.edu', u'aap.cornell.edu', u'math.cornell.edu', u'downtownithaca.com', u'calendar.howard.edu', u'usgbcnh.org', u'usgbclouisiana.org', u'usgbccentralohio.org', u'events.brown.edu', u'news.dartmouth.edu', u'princetonentertain.com', u'carnegieendowment.org', u'washingtondc.eventful.com', u'930.com', u'marymount.edu', u'capitalfringe.org', u'ustreetmusichall.com', u'meetup.com', u'blackcatdc.com', u'shakespearetheatre.org', u'thehowardtheatre.com', u'nationalgeographic.org', u'sixthandi.org', u'go.nbm.org', u'trinitydc.edu', u'theatrelab.org', u'brookings.edu', u'csis.org', u'atlanticcouncil.org', u'busboysandpoets.com', u'politics-prose.com', u'cato.org', u'newamerica.org', u'wilsoncenter.org', u'eventsdc.com', u'eli.org', u'dspshows.com', u'gradschool.cornell.edu', u'philosophy.fas.harvard.edu', u'harvardartmuseums.org', u'americanrepertorytheater.org', u'economics.harvard.edu', u'ces.fas.harvard.edu', u'ofa.fas.harvard.edu', u'daviscenter.fas.harvard.edu', u'hls.harvard.edu', u'psychology.fas.harvard.edu', u'philly.com', u'gsas.harvard.edu', u'penncurrent.upenn.edu', u'environment.harvard.edu', u'chemistry.harvard.edu', u'radcliffe.harvard.edu', u'dcsbdc.org', u'anthropology.fas.harvard.edu', u'memorialchurch.harvard.edu', u'green.harvard.edu', u'history.fas.harvard.edu', u'edportal.harvard.edu', u'thephillycalendar.com', u'nyc.com', u'my.arboretum.harvard.edu', u'statistics.fas.harvard.edu', u'upenn.edu', u'belfercenter.org', u'sociology.fas.harvard.edu', u'histsci.fas.harvard.edu', u'lrdudc.wrlc.org', u'peabody.harvard.edu', u'slavic.fas.harvard.edu', u'ves.fas.harvard.edu', u'artsinitiative.columbia.edu', u'cellbio.med.harvard.edu', u'artgallery.yale.edu', u'energypolicy.columbia.edu', u'barnard.edu', u'law.columbia.edu', u'linguistics.fas.harvard.edu', u'mailman.columbia.edu', u'arch.columbia.edu', u'socialwork.columbia.edu', u'millertheatre.com', u'lrc.columbia.edu', u'physics.columbia.edu', u'chem.columbia.edu', u'classics.columbia.edu', u'astro.columbia.edu', u'americanstudies.columbia.edu', u'humanrightscolumbia.org', u'jtsa.edu', u'ece.columbia.edu', u'events.goucher.edu', u'events.udel.edu', u'events.towson.edu', u'econ.columbia.edu', u'columbianeurology.org', u'iijs.columbia.edu', u'events.newschool.edu', u'calendar.colgate.edu', u'events.uri.edu', u'calendar.northeastern.edu', u'calendar.oberlin.edu', u'events.williams.edu', u'events.risd.edu', u'runwashington.com', u'harvard-yenching.org', u'thebostoncalendar.com', u'events.visitithaca.com', u'bu.edu', u'wexarts.org', u'events.citypaper.com', u'events.temple.edu', u'events.ithaca.edu', u'', u'nyu.edu', u'hub.jhu.edu', u'calendar.jhu.edu', u'cfa.gmu.edu']

loc_sources = [
    'millertheatre.com', 'theatrelab.org','thehowardtheatre.com','americanrepertorytheater.org', 'wilsoncenter.org','sixthandi.org','carnegieendowment.org','lrc.columbia.edu','blackcatdc.com','wcma.williams.edu','go.nbm.org','wexarts.org','ustreetmusichall.com'
]

garbage_sources = ['usgbccentralohio.org', 'lrdudc.wrlc.org', 'ece.columbia.edu','classics.columbia.edu','daviscenter.fas.harvard.edu',
                   'philosophy.fas.harvard.edu','linguistics.fas.harvard.edu','schottensteincenter.com','calendar.jhu.edu','theatrelab.org',
                   'usgbcla.onefireplace.org','trinitydc.edu','nyc.com','usgbcnh.org','psychology.fas.harvard.edu','americanstudies.columbia.edu',
                   'upenn.edu','athletics.trinitydc.edu','anthropology.columbia.edu','statistics.fas.harvard.edu','penncurrent.upenn.edu',
                   'eventsdc.com','columbianeurology.org','princetonentertain.com','events.risd.edu','cinema.cornell.edu','usgbclouisiana.org',
                   'cs.columbia.edu','nationalgeographic.org','arlnow.com']

script_sources = ['involved.towson.edu', 'nest.cua.edu','gobblerconnect.vt.edu','lisner.gwu.edu','studentcentral.udel.edu','thebridge.cmu.edu',
                  'johnshopkins.campuslabs.com','hoyalink.georgetown.edu','howard.campuslabs.com','temple.campuslabs.com']

source_counts = [('harvardartmuseums.org', '324'), ('37', '37'), ('history.fas.harvard.edu', '77'), ('events.goucher.edu', '260'), ('americanrepertorytheater.org', '68'), ('wilsoncenter.org', '78'), ('usgbccentralohio.org', '3'), ('lrdudc.wrlc.org', '1'), ('events.cornell.edu', '6989'), ('peabody.harvard.edu', '30'), ('artgallery.yale.edu', '281'), ('involved.towson.edu', '2'), ('nest.cua.edu', '92'), ('politics-prose.com', '563'), ('edportal.harvard.edu', '25'), ('gsas.harvard.edu', '101'), ('ece.columbia.edu', '4'), ('thebostoncalendar.com', '806'), ('classics.columbia.edu', '38'), ('daviscenter.fas.harvard.edu', '52'), ('calendar.howard.edu', '11'), ('cfa.gmu.edu', '27'), ('busboysandpoets.com', '151'), ('cellbio.med.harvard.edu', '18'), ('my.arboretum.harvard.edu', '11'), ('memorialchurch.harvard.edu', '39'), ('ves.fas.harvard.edu', '3'), ('barnard.edu', '72'), ('philosophy.fas.harvard.edu', '9'), ('nyu.edu', '64'), ('economics.harvard.edu', '98'), ('events.ithaca.edu', '977'), ('heymancenter.org', '22'), ('weai.columbia.edu', '68'), ('humanrightscolumbia.org', '29'), ('runwashington.com', '3'), ('gobblerconnect.vt.edu', '42'), ('linguistics.fas.harvard.edu', '4'), ('ces.fas.harvard.edu', '28'), ('sixthandi.org', '345'), ('carnegieendowment.org', '1'), ('ofa.fas.harvard.edu', '55'), ('green.harvard.edu', '43'), ('lisner.gwu.edu', '12'), ('radcliffe.harvard.edu', '19'), ('iijs.columbia.edu', '15'), ('lrc.columbia.edu', '43'), ('capitalfringe.org', '54'), ('events.visitithaca.com', '786'), ('brookings.edu', '151'), ('belfercenter.org', '147'), ('calendar.northeastern.edu', '809'), ('guevents.georgetown.edu', '4509'), ('washington.org', '3'), ('hls.harvard.edu', '735'), ('schottensteincenter.com', '27'), ('mailman.columbia.edu', '60'), ('ticketmaster', '2130'), ('thephillycalendar.com', '1301'), ('millertheatre.com', '77'), ('calendar.jhu.edu', '25'), ('studentcentral.udel.edu', '10'), ('gsd.harvard.edu', '7'), ('math.cornell.edu', '95'), ('theatrelab.org', '8'), ('usgbcla.onefireplace.org', '12'), ('trinitydc.edu', '22'), ('thebridge.cmu.edu', '4'), ('engineering.cornell.edu', '50'), ('slavic.fas.harvard.edu', '7'), ('thehowardtheatre.com', '167'), ('nyc.com', '50'), ('events.newschool.edu', '1805'), ('browse.calendar.gwu.edu', '1018'), ('usgbcnh.org', '2'), ('csis.org', '230'), ('histsci.fas.harvard.edu', '7'), ('events.citypaper.com', '25'), ('usgbc.org', '190'), ('washingtondc.eventful.com', '611'), ('cato.org', '63'), ('dcsbdc.org', '15'), ('psychology.fas.harvard.edu', '6'), ('americanstudies.columbia.edu', '18'), ('econ.columbia.edu', '4'), ('upenn.edu', '13'), ('athletics.trinitydc.edu', '1'), ('events.udel.edu', '1027'), ('english.columbia.edu', '14'), ('chem.columbia.edu', '15'), ('meetup.com', '725'), ('johnshopkins.campuslabs.com', '5'), ('eventbrite.com', '18642'), ('hoyalink.georgetown.edu', '34'), ('dspshows.com', '254'), ('events.uri.edu', '792'), ('marymount.edu', '158'), ('anthropology.columbia.edu', '2'), ('gradschool.cornell.edu', '12'), ('philly.com', '4'), ('jtsa.edu', '47'), ('calendar.oberlin.edu', '1074'), ('howard.campuslabs.com', '12'), ('newamerica.org', '69'), ('environment.harvard.edu', '208'), ('events.temple.edu', '283'), ('blackcatdc.com', '18'), ('events.williams.edu', '554'), ('atlanticcouncil.org', '62'), ('wcma.williams.edu', '7'), ('caps.gov.harvard.edu', '2'), ('go.nbm.org', '71'), ('temple.campuslabs.com', '13'), ('eventbrite.com(ithaca)', '351'), ('statistics.fas.harvard.edu', '9'), ('artsinitiative.columbia.edu', '1313'), ('shakespearetheatre.org', '33'), ('eli.org', '1'), ('aei.org', '1'), ('astro.columbia.edu', '20'), ('socialwork.columbia.edu', '37'), ('eventbrite.com(washington)', '30561'), ('sociology.fas.harvard.edu', '16'), ('penncurrent.upenn.edu', '119'), ('930.com', '37'), ('eventsdc.com', '6'), ('anthropology.fas.harvard.edu', '11'), ('calendar.colgate.edu', '1262'), ('events.towson.edu', '510'), ('news.dartmouth.edu', '2296'), ('columbianeurology.org', '14'), ('wexarts.org', '233'), ('princetonentertain.com', '958'), ('energypolicy.columbia.edu', '3'), ('events.risd.edu', '285'), ('cinema.cornell.edu', '376'), ('ustreetmusichall.com', '50'), ('bu.edu', '839'), ('law.columbia.edu', '78'), ('usgbclouisiana.org', '17'), ('earth.columbia.edu', '1'), ('arch.columbia.edu', '92'), ('physics.columbia.edu', '39'), ('harvard-yenching.org', '4'), ('georgetowndc.com', '53'), ('american.edu', '862'), ('chemistry.harvard.edu', '10'), ('cs.columbia.edu', '1'), ('nationalgeographic.org', '1'), ('arlnow.com', '318')]
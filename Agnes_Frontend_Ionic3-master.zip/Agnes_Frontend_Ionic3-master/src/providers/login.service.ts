import { Injectable } from '@angular/core';
import { Headers, Http, RequestOptions } from '@angular/http';
import 'rxjs/add/operator/toPromise';
import { Agnes } from '../app/app.component';

@Injectable()
export class LoginService {
  private headers = new Headers({'Content-Type': 'application/json'});

  static get parameters(){
    return [Http];
  }

  constructor(private http: Http) {
  }

  validateEmail(email): Promise<any> {
    email["token"] = localStorage.getItem('agnesToken');
    email["timestamp"] = new Date()
    let addUrl = Agnes.API_URL + '/emailVerification';
    let options = new RequestOptions({ headers: this.headers });

    return this.http.post(addUrl, email, options)
      .toPromise()
      .then(response => response.json() as Object[])
      .catch(this.handleError);

  }

  updateDeviceId(data) {
    data["token"] = localStorage.getItem('agnesToken');
    data["timestamp"] = new Date()
    let addUrl = Agnes.API_URL + '/update_deviceId';
    let options = new RequestOptions({ headers: this.headers });

    return this.http.post(addUrl, data, options)
      .toPromise()
      .then(response => response.json() as any)
      .catch(this.handleError);
  }

  login(data) {
    data["token"] = localStorage.getItem('agnesToken');
    data["timestamp"] = new Date()
    let addUrl = Agnes.API_URL + '/login';
    let options = new RequestOptions({ headers: this.headers });

    return this.http.post(addUrl, data, options)
      .toPromise()
      .then(response => response.json() as any)
      .catch(this.handleError);
  }

  lastLogin(data) {
    data["token"] = localStorage.getItem('agnesToken');
    data["timestamp"] = new Date()
    let addUrl = Agnes.API_URL + '/userlastLogin';
    let options = new RequestOptions({ headers: this.headers });

    return this.http.post(addUrl, data, options)
      .toPromise()
      .then(response => response.json() as any)
      .catch(this.handleError);
  }

  getUser(data): Promise<any> {
    data["token"] = localStorage.getItem('agnesToken');
    data["timestamp"] = new Date()
    let addUrl = Agnes.API_URL + '/singleUser';
    let options = new RequestOptions({ headers: this.headers });

    return this.http.post(addUrl, data, options)
      .toPromise()
      .then(response => response.json() as any)
      .catch(this.handleError);
  }

  fbLogin(data): Promise<any> {
    data["token"] = localStorage.getItem('agnesToken');
    data["timestamp"] = new Date()
    let addUrl = Agnes.API_URL + '/fblogin';
    let options = new RequestOptions({ headers: this.headers });

    return this.http.post(addUrl, data, options)
      .toPromise()
      .then(response => response.json() as any)
      .catch(this.handleError);
  }

  fbSignup(data): Promise<any> {
    data["token"] = localStorage.getItem('agnesToken');
    data["timestamp"] = new Date()
    let addUrl = Agnes.API_URL + '/fbregisternew';
    let options = new RequestOptions({ headers: this.headers });

    return this.http.post(addUrl, data, options)
      .toPromise()
      .then(response => response.json() as any)
      .catch(this.handleError);
  }

  fbUpdate(data): Promise<any> {
    data["token"] = localStorage.getItem('agnesToken');
    data["timestamp"] = new Date()
    let addUrl = Agnes.API_URL + '/update_fb_MLData';
    let options = new RequestOptions({ headers: this.headers });

    return this.http.post(addUrl, data, options)
      .toPromise()
      .then(response => response.json() as any)
      .catch(this.handleError);
  }

  forgotPassword(data): Promise<any> {
    data["token"] = localStorage.getItem('agnesToken');
    data["timestamp"] = new Date()
    let addUrl = Agnes.API_URL + '/forgetPassword';
    let options = new RequestOptions({ headers: this.headers });

    return this.http.post(addUrl, data, options)
      .toPromise()
      .then(response => response.json() as any)
      .catch(this.handleError);
  }

  checkPasscode(data): Promise<any> {
    data["token"] = localStorage.getItem('agnesToken');
    data["timestamp"] = new Date()
    let addUrl = Agnes.API_URL + '/checkPasscode';
    let options = new RequestOptions({ headers: this.headers });

    return this.http.post(addUrl, data, options)
      .toPromise()
      .then(response => response.json() as any)
      .catch(this.handleError);
  }

  chatAllowCheck(data): Promise<any> {
    data["token"] = localStorage.getItem('agnesToken');
    data["timestamp"] = new Date()
    let addUrl = Agnes.API_URL + '/chatAllowCheck';
    let options = new RequestOptions({ headers: this.headers });

    return this.http.post(addUrl, data, options)
      .toPromise()
      .then(response => response.json() as any)
      .catch(this.handleError);
  }

  verifyCommunity(data): Promise<any>{
    data["token"] = localStorage.getItem('agnesToken');
    data["timestamp"] = new Date()
    let addUrl = Agnes.API_URL + '/verifyCommunity_v2';
    let options = new RequestOptions({ headers: this.headers });

    return this.http.post(addUrl, data, options)
        .toPromise()
        .then(response => response.json() as Object[])
        .catch(this.handleError);
  }


  private handleError(error: any): Promise<any> {
    console.error('An error occurred', error);
    return Promise.reject(error.message || error);
  }
}

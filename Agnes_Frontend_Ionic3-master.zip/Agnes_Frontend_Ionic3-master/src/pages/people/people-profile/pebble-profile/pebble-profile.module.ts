import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';

import { PebbleProfile } from './pebble-profile';
import { ComponentsModule } from '../../../../components/components.module';
import { SuperTabsModule } from 'ionic2-super-tabs';
import {RoundProgressModule} from 'angular-svg-round-progressbar';

@NgModule({
  declarations: [
    PebbleProfile
  ],
  imports: [
    IonicPageModule.forChild(PebbleProfile),
    ComponentsModule,
    RoundProgressModule,
  ],
  exports: [
    PebbleProfile
  ]
})

export class PebbleProfileModule { }

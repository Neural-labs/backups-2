date_extraction_input = {}
date_extraction_input['date'] = {}
date_extraction_input['date']['time'] = {}
date_extraction_input['date']['day'] = {}
date_extraction_input['date']['week'] = {}
date_extraction_input['date']['month'] = {}
date_extraction_input['date']['year'] = {}
date_extraction_input['date']['all'] = {}
date_extraction_input['date']['md'] = {}


date_extraction_input['date']['all']['regex'] = [
    '([0-3]?[0-9])[ -/.]([0-1]?[0-9])[ -/.](1?[9]?[8-9][0-9]|2?[0]?[01][0-9])', # DD/MM/YY[YY]
    '([0-1]?[0-9])[ -/.]([0-3]?[0-9])[ -/.](1?[9]?[8-9][0-9]|2?[0]?[01][0-9])', # MM/DD/YY[YY]
    '(1?[9]?[8-9][0-9]|2?[0]?[01][0-9])[ -/.]([0-1]?[0-9])[ -/.]([0-3]?[0-9])' # YY[YY]/MM/DD
]

date_extraction_input['date']['md']['regex'] = [
    '\b([w]|[ \/.-])?(0?[0-9]|1[0-2])[ .\/-]([0-3]?[0-9])\b' #MM/DD
]

date_extraction_input['date']['time']['keywords'] = [
    'time'
    'minute'
    'hour'
]

date_extraction_input['date']['time']['regex'] = [
    '()([0-2]?[0-9])?(:)?([0-5]?[0-9][\W]?)(?(3)([ap]\.?[m]\.?)?|([ap]\.?[m]\.?))', # T (- from to) T
    # '[0-2]?[0-9](:)?[0-5]?[0-9]?[\W]?(?(1)[ap]?m?|[ap]m)' # 12:00, 12pm, 12:00pm
]

date_extraction_input['date']['day']['keywords'] = [
    'day'
]

date_extraction_input['date']['day']['regex'] = [
    '([ \/.-])([0-3]?[0-9])([, \/.\n-]|st|nd?|rd|th?)'
]

date_extraction_input['date']['week']['keywords'] = [

]

date_extraction_input['date']['week']['regex'] = [
    '(mon|tues|tue|wednes|wed|thurs|thur|fri|satur|sat|sun)(day)?' # mon[day]
]

date_extraction_input['date']['month']['regex'] = [
    '(jan)(uary)?|(feb)(ruary)?|(mar)(ch)?|(apr)(il)?|(may)|(jun)(e)?|(jul)(y)?|(aug)(ust)?|(sep)(tember)?|(sept)(ember)?|(oct)(ober)?|(nov)(ember)?|(dec)(ember)?'
]

date_extraction_input['date']['year']['regex'] = [
    '(1[9][9][0-9]|2[0][01][0-9])' # 1990 - 2019
]


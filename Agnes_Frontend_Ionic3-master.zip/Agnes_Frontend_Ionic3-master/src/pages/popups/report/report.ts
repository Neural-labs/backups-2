import { Component } from '@angular/core';
import { AlertController, Platform, ToastController, ViewController, NavParams, TextInput } from 'ionic-angular';

import { ReportService } from './report.service'

import { Agnes } from '../../../app/app.component';

@Component({
  selector: 'report',
  templateUrl: 'report.html',
  providers: [ReportService]

})

export class ReportPage {
  user:Object;
  entityID:any;
  entityName:string;
  type:string;
  platform:Platform;
  reportReason:string;
  shouldBlur:boolean;
  reset: boolean;
  reportText: string;

  constructor(public viewCtrl: ViewController,
              private navParams: NavParams,
              private alertCtrl: AlertController,
              private reportService: ReportService,
              private toastCtrl: ToastController) {
  }

  ngOnInit() {
    this.entityID = this.navParams.data.entityID;
    this.entityName = this.navParams.data.entityName;
    this.type = this.navParams.data.type;
    this.user = this.navParams.data.user;
    this.platform = this.navParams.data.platform;
    this.shouldBlur = true;
    this.reportReason = 'Offensive';
    this.reportText = '';
  }

  ngAfterViewInit(){
    window.setTimeout(function(){
      document.getElementsByClassName('popover-content')[0]['style']['left'] = '0px';
    },0);
  }

  closeReport(){
    this.viewCtrl.dismiss(null,null,{
      animation: 'ios-transition',
      duration: 350,
      easing: "ease-in-out",
      direction: "back"
    });
  }

  focusOther(ev: TextInput){
    ev.setFocus();
  }

  keepKeyboard(event)  {
    // if(!this.shouldBlur || event.relatedTarget || this.reset){
    //   event.target.focus();
    //
    //   // Reset so other elements will blur the keyboard
    //   this.shouldBlur = true;
    //   this.reset = !this.reset;
    // }
  }

  resetBlur() {
    this.reset = true;
  }

  flipBlur() {
    this.shouldBlur = false;
    this.reset = false;
  }

  submitReport(){
    if (!this.reportReason){
      document.getElementById('reportError').classList.add('active');
    }
    else {
      this.reportReason = (this.reportReason == 'Other') ? 'Other: ' + this.reportText : this.reportReason;
      document.getElementById('reportError').classList.remove('active');
      let data = {
        "entity_type": this.type,
        "report_reason":this.reportReason,
        "email_id":this.user['email']['uid'],
        "entity_id": this.entityID,
        "user_name": this.user['fname'] + " " + this.user['lname'],
        "user_id": this.user['_id'],
        "entity_name": this.entityName
      };

      this.reportService.report(data)
      .then(value => {
        if(value){
          this.toastCtrl.create({
            message: 'Report successfully submitted',
            duration: 2500,
            position:'top',
              closeButtonText: ' ',
              showCloseButton: true
          }).present();

          this.closeReport();
        }
        else{
          Agnes.showError("Sorry, your report couldn't be submitted right now. Try again!");
        }
      })
      .catch(function(error){Agnes.showError("Sorry, your report couldn't be submitted right now. Try again!");});
    }
  }
}

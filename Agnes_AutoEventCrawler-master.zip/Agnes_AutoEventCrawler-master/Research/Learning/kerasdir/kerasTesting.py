from keras.models import model_from_json, load_model
from Utilities import EventTree, DateExtraction, LocationExtraction
import requests
from datetime import datetime
import time
import logging
import pytz
from keras.layers import Dense, Conv1D, Activation, MaxPooling1D, Flatten, Dropout, LSTM
from keras.models import Sequential
import pickle
from keras.preprocessing import sequence
from gensim.models import Word2Vec, keyedvectors
from bson.objectid import ObjectId
from bs4 import BeautifulSoup
import numpy as np
from keras.optimizers import SGD
from sklearn.metrics import roc_curve, roc_auc_score
import re
from config import db_config
from Preprocessing.CollectFeatures.CollectExtractionFeatures import extractFeaturesManual, extractFeaturesHTML, extractFeaturesContent

def printStats(string):
    values = string.split('\n')
    values = [a.split() for a in values]
    thresholds = [float(a[0]) for a in values]
    values = [float(a[1]) for a in values]
    for ind in range(len(values)):
        print values[ind],thresholds[ind]
    values = list(np.cumsum(values))
    sum = values[-1]
    values = [a/float(sum) for a in values]
    for ind in range(len(values)):
        print values[ind],thresholds[ind]

# manual_features = extractFeaturesManual(sample)
#
# html_features = extractHTMLFeaturesEmbedding(h2v_w_embedding, sample)
#
# content_features = extractContentFeaturesEmbedding(word2vec_embedding, sample)
#
# url_features = extractURLFeaturesEmbedding(c2v_embedding, sample)

Agnes = db_config.getDBConn('dev').Agnes

AutoCrawler_Events = Agnes.autocrawler_events
Data_Collection = Agnes.autocrawler_ext_data

global content_embedding_model
global html_embedding_model

def testModel(model=None):
    global html_embedding_model
    global content_embedding_model
    html_embedding_model = Word2Vec.load('gensim_model_w2v_hw')
    content_embedding_model = keyedvectors.KeyedVectors().load_word2vec_format('GoogleNews-vectors-negative300.bin', binary=True)

    if not model:
        print 'Getting Model'
        # model = getModel()
        print 'Loading weights'
        name_model = getModel(input_dim=314)
        # description_model = getModel(input_dim=614)
        # location_model = getModel(input_dim=614)
        # date_model = getModel(input_dim=614)

        name_model.load_weights('keras_classifier_name.hdf5')
        # description_model.load_weights('keras_classifier_description_v2.hdf5')
        # location_model.load_weights('keras_classifier_location_v2.hdf5')
        # date_model.load_weights('keras_classifier_date_v2.hdf5')

    # parts = ['name','description','location','date']
    # models = []
    # part_model_list =

    # part_model_list = [('name',name_model),('date',date_model), ('location',location_model), ('description',description_model)]
    # runOnMongoData(part_model_list)
    part_model_list = [('name',name_model, 314)]
    # runOnMongoData(part_model_list)
    runOnRealData(part_model_list)


def runOnRealData(part_model_list):

    urls = []
    urls.append('http://events.cornell.edu/event/spring_garden_fair_plant_sale_3173')
    urls.append('http://events.cornell.edu/event/icgs_tough_turtle')
    urls.append('http://events.cornell.edu/event/midday_music_for_organ_131_cu_music')

    urls.append('https://www.usgbc.org/event/inspire-speakers-series-biophilia')
    urls.append('https://www.usgbc.org/event/usgbc-hampton-roads-happy-hour-3')
    urls.append('https://www.usgbc.org/event/march-lunch-and-leed')
    urls.append(
        'http://browse.calendar.gwu.edu/EventList.aspx?fromdate=3/2/2018&todate=3/31/2018&display=&type=public&eventidn=15774&view=EventDetails&information_id=29805')
    urls.append('http://browse.calendar.gwu.edu/EventList.aspx?fromdate=3/6/2018&todate=4/4/2018&display=&type=public&eventidn=15773&view=EventDetails&information_id=29803')
    urls.append('http://browse.calendar.gwu.edu/EventList.aspx?fromdate=3/6/2018&todate=4/4/2018&display=&type=public&eventidn=15499&view=EventDetails&information_id=29220')
    urls.append('https://www.bu.edu/law/news-events/events-calendar/?eid=210995')
    urls.append('https://www.bu.edu/cfa/news-events/events/?eid=209407')

    for url in urls:
        HTML = requestURL(url)
        event_tree = EventTree.EventTree(HTML)

        feature_list_all = ['html','content']
        samples, X_614 = getSamples(event_tree, feature_list_all)

        feature_list_314 = ['html']
        samples, X_314 = getSamples(event_tree, feature_list_314)


        # cursor = getMongoSamples()
        # samples, X = convertSamplesToFeatures(cursor)

        print 'Running Predictions'
        print url
        all_predictions = []
        for part, model, input_dim in part_model_list:

            if input_dim == 614:
                all_predictions.append((part,model.predict(X_614)))
            else:
                all_predictions.append((part,model.predict(X_314)))
        # name_predictions = name_model.predict(X)
        # desc_predictions = description_model.predict(X)
        # loc_predictions = model.predict(X)
        # date_predictions = date_model.predict(X)

        # all_predictions = [name_predictions, desc_predictions, loc_predictions, date_predictions]

        # all_predictions = [loc_predictions]

        printResults(all_predictions, samples, 1)
        print


def runOnMongoData(part_model_list):

    for part, model,input_dim in part_model_list:

        cursor = getMongoSamples(part)
        samples, X, y = convertSamplesToFeatures(cursor, part, input_dim)

        # all_predictions = [name_predictions, desc_predictions, loc_predictions, date_predictions]

        predictions = model.predict(X)
        print 'part:',part
        printResults(predictions, samples, 0, true_y=y)
        print

def printResults(predictions, samples, realData, true_y=None):

    if realData:
        for part,type_preds in predictions:
            print part
            sample_preds = zip(type_preds, samples)

            sorted_preds = sorted(sample_preds, key=lambda x: x[0][0])

            highest = sorted_preds[-5:]
            for item in highest:
                print item[0]
                print item[1]
            print

    else:

        thresholds, FN_values = get_thresholds(true_y, predictions)

        cum_fn_values = list(np.cumsum(FN_values))

        fn_sum = float(cum_fn_values[-1])

        cum_fn_values = [a/fn_sum for a in cum_fn_values]

        for ind in range(len(cum_fn_values)):
            print thresholds[ind],cum_fn_values[ind]

def get_thresholds(y_true, y_hat):
    thresholds = [a for a in np.arange(0,1.01,.01)]
    FNs = []
    for threshold in thresholds:
        FN = calculate_threshold(y_true, y_hat, threshold)
        FNs.append(FN)
    return thresholds, FNs

def calculate_threshold(y_true, y_hat, threshold):

    FN = 0

    for index in range(len(y_true)):
        true_v = y_true[index]
        pred_v = y_hat[index]

        if true_v and not pred_v>threshold:
            FN += 1

    return FN

def requestURL(url):
    try:
        HTML = requests.get(url).text
        return HTML
    except Exception as e:
        print 'failed to get url'

def getEventByUrl(page_url):
    return AutoCrawler_Events.find_one({'url':page_url})

def getEventById(eid):
    return AutoCrawler_Events.find_one({'_id':ObjectId(eid)})

def getMongoSamples(sample_part):
    return Data_Collection.find({'part':sample_part}).limit(15000)

def convertSamplesToFeatures(samples, sample_part, input_dim):

    X = []
    y = []
    items = []
    print 'Collecting Features'
    counter = 0
    for sample in samples:
        if invalidSample(sample):
            continue
        counter += 1
        if counter % 1000 == 0:
            print sample_part, counter
        features = []
        features += list(pickle.loads(sample['features_h2v_w']))
        features += list(pickle.loads(sample['features_w2v_pretrained']))
        features += sample['manual_v2']

        if len(features) != 614:
            continue

        y.append(checkLabel(sample, sample_part))

        items.append(sample)
        X.append(features)

    X = np.array(X)
    print X.shape
    X = X.reshape(X.shape[0],1,X.shape[1])
    return items,X,y

def invalidSample(sample):
    fields = ['features_h2v_w','features_w2v_pretrained','manual_v2']
    for field in fields:
        if not field in sample:
            return True
    return False

def checkLabel(sample, part):

    if not sample['label']:
        return False

    sample_part = sample['part']
    if sample_part == part:
        return True

    return False

def getSamples(event_tree, feature_list):
    samples = []
    X = []
    for node_id, node_data in event_tree.get_nodes():
        tag = node_data['attr_dict']['tag']

        text = convertTagToStr(tag)

        features = getFeatures(text, feature_list)

        if not features:
            continue

        samples.append(tag)
        X.append(features)

    X = np.array(X)
    X = X.reshape(X.shape[0], 1, X.shape[1])
    return samples,X

def convertTagToStr(tagobj):
    tagstr = str(tagobj)
    tagstr = tagstr.encode('ascii','ignore')
    return tagstr

def getFeatures(text, feature_list):
    global html_embedding_model
    global content_embedding_model
    features = []
    if 'html' in feature_list:
        html_features = extractFeaturesHTML(html_embedding_model, text)
        if not html_features:
            return None
        else:
            features += list(pickle.loads(html_features))

    if 'content' in feature_list:
        content_features = extractFeaturesContent(content_embedding_model, text)

        if not content_features:
            return None
        else:
            features += list(pickle.loads(content_features))

    features += extractFeaturesManual(text)

    return features

def getModel(input_dim):
    kernel_size = 5
    pool_size = 4
    filters = 64
    lstm_output_size = 64
    input_dim = input_dim
    consume_less = 1  # 1 for cpu, 2 for gpu
    model = Sequential()
    # model.add(Dense(input_dim, input_shape=(input_dim,)))
    # model.add(Embedding(
    #     input_dim=max_features,
    #     output_dim=embedding_dim,
    #     input_length=max_len))
    # trainable=False,
    # weights=[embedding_matrix]))
    # model.add(Dropout(0.25))
    # print model.summary()
    model.add(Conv1D(filters,
                     kernel_size,
                     padding='same',
                     strides=1,
                     kernel_initializer='uniform',
                     input_shape=(None, input_dim),
                     batch_input_shape=(None, 1,input_dim)
                     ))
                     # ))
                     # batch_size=batch_size,
                     # batch_input_shape=(None, input_dim)))
    # model.summary()
    model.add(Activation('relu'))
    # model.add(Flatten())
    # model.add(GlobalMaxPool1D())
    # model.add(Flatten())
    model.add(MaxPooling1D(padding='same'))
    # model.add(Dropout(0.25))
    # model.summary()
    # model.add(Flatten())
    model.add(LSTM(lstm_output_size))
    model.add(Dense(64, activation='relu'))
    model.add(Dense(64, activation='relu'))
    model.add(Dense(1, activation='sigmoid'))
    # model.add(Activation('sigmoid'))
    sgd = SGD(lr=0.01, momentum=0.0, decay=0.0, nesterov=False)
    model.compile(loss='binary_crossentropy',
                  optimizer='adam',
                  metrics=['accuracy'])
    model.summary()
    return model

def getModelFromDisk():

    model = load_model('extraction_classification_model_name_80.hdf5')

    return model
    # load json and create model
    # json_file = open(event_part+ '_model.json', 'r')
    # loaded_model_json = json_file.read()
    # json_file.close()
    # loaded_model = model_from_json(loaded_model_json)
    # # load weights into new model
    # loaded_model.load_weights(event_part+"_model.h5")
    # print("Loaded model from disk")
    # return loaded_model
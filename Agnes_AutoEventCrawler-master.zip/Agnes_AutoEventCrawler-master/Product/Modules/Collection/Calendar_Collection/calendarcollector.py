from utilities.scraper.scraper import Scraper
from db.db import get_devConn
from utilities.calendar_classifier import CalendarClassifier

class CalendarCollector:
    domain_tree = None


    def __init__(self, input_filepath=None):
        # todo: decide whether input is specified by runner or not
        # if input_filepath:
        #
        pass

    def run_collection(self):
        domain_scraper = Scraper()
        self.domain_tree = domain_scraper.run_scraper()

    def run_classification(self):
        if not self.domain_tree:
            raise ValueError('No Domain Tree to run classification on')

        Cal_Classifier = CalendarClassifier()
        Cal_Classifier.run_classifier(self.domain_tree)



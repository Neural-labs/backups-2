import { Component, ViewChild, Input } from '@angular/core';
import { NavParams, ViewController, Events, IonicPage, NavController } from 'ionic-angular';
import { Keyboard } from 'ionic-native'; //for android


@IonicPage()
@Component({
    selector: 'agnes-input',
    templateUrl: 'agnes-input.html',
    providers: []
})



export class AgnesInput {
    @ViewChild('focusInput') myInput;

    user: Object;
    agnesInput: string;
    limit: number;
    placeholder: string;
    type: string;
    height: string;
    privacyToggle: string;

    sendNotification: boolean;

    constructor(public navParams: NavParams,
                public events: Events,
                public viewCtrl: ViewController,
                private navCtrl: NavController) {
    }

    ngOnInit(){
        this.user = JSON.parse(localStorage.getItem('agnesUser'));
        this.agnesInput = this.navParams.data.inp;
        this.limit = this.navParams.data.limit;
        this.placeholder = this.navParams.data.placeholder;
        this.type = this.navParams.data.type;
        this.sendNotification = true;
        this.privacyToggle = 'public';

    }

    ionViewWillEnter() {
        setTimeout(() => {
          Keyboard.show() // for android
          this.myInput.setFocus();
        },0)
    }

    toggleNotification() {
        this.sendNotification = !this.sendNotification;
    }

    closeAgnesInput(posted){
        if(posted){
            if(this.agnesInput.trim() != '') {
                document.getElementById('agnesInputText').classList.remove('error');

                posted = {
                    'agnesInput':this.agnesInput,
                    'sendNotification': this.sendNotification
                };

                if(this.type=='feed') {
                    // posted['privacy'] = this.privacyToggle;
                    posted['privacy'] = 'private';
                }
                this.viewCtrl.dismiss(posted);
            }
            else {
                document.getElementById('agnesInputText').classList.add('error');
            }
        }
        else {
            this.viewCtrl.dismiss(posted);
        }
    }

}

import { Component, ViewChild, Renderer } from '@angular/core';
import { Content, NavParams, Events, ActionSheetController, PopoverController, NavController, App,
  Platform, IonicPage } from 'ionic-angular';

import { ChatService } from '../../../providers/chat.service';
import { EventsService } from '../../../providers/events.service';
import { PeopleService } from '../../../providers/people.service';

import { ReportPage } from '../../popups/report/report';
import { EventProfile } from '../../events/event-profile/event-profile';

import { Agnes } from '../../../app/app.component';

// import _ from 'lodash';

@IonicPage()
@Component({
  selector:'chat-profile',
  templateUrl: 'chat-profile.html',
  providers: [ChatService, EventsService, PeopleService]
})

export class ChatProfile {
  oldHeight: number = 0;
  channel: Object;
  messages = [];
  receiverInfo:Object;
  groupMembersInfo: any;
  groupMembersStr: string;
  membersInfo:any;
  user: Object;
  messageText:string;
  connected: boolean;
  shouldBlur: boolean;
  scrollDown: boolean;
  reset: boolean;
  orientation: string;
  loading: boolean;
  tMessages = [];
  hasPlugins: boolean;
  activeChannel: any;
  isTyping: boolean;
  paginator: any;
  canLoadMore: boolean;

  canOpenProfile: boolean;

  private inputElement;
  private millis = 200;
  private scrollTimeout = this.millis + 50;
  private textareaHeight;
  private scrollContentElelment: any;
  private footerElement: any;
  private initialTextAreaHeight;
  private keyboardHideSub;
  private keybaordShowSub;

  @ViewChild('chatRoom') chatRoom: Content;

  constructor(private navParams: NavParams,
              private events: Events,
              public navCtrl: NavController,
              private chatService: ChatService,
              private eventsService: EventsService,
              private peopleService: PeopleService,
              private actionSheetCtrl: ActionSheetController,
              private popoverCtrl: PopoverController,
              private appCtrl: App,
              public renderer: Renderer,
              private platform: Platform) {
  }

  ngOnInit() {
    this.loading = true;
    this.hasPlugins = Agnes.hasPlugins();

    this.oldHeight = 0;

    if(this.hasPlugins) {
      Agnes.keyboard.disableScroll(true);
      Agnes.keyboard.hideKeyboardAccessoryBar(true);
    }

    this.channel = this.navParams.data.channel;
    this.user = JSON.parse(localStorage.getItem("agnesUser"));

    this.messages = [];
    this.receiverInfo = this.channel;
    this.groupMembersInfo = [];
    this.membersInfo = [];
    this.groupMembersStr = '';
    this.messageText = '';
    this.shouldBlur = true;
    this.scrollDown = true;
    this.isTyping = false;
    this.canLoadMore = true;
    this.canOpenProfile = true;

    let ind = this.user['channels'].map(a => {return a['receiverId']}).indexOf(this.channel['_id']);
    if (ind != -1) {this.channel['sid'] = this.user['channels'][ind]['cid'];}

    localStorage.setItem('agnesChat', this.navParams.data.channel['_id']);
    if(this.navParams.get('newChat')){
      localStorage.removeItem('agnesChat'+this.receiverInfo['_id']);
    }

    //get messages in this chat
    this.initMessages(this.receiverInfo['_id']);

    //load receiver
    this.peopleService.getUsersFromIds({'users':[this.receiverInfo['_id']]}).then(val => {
      if(val && val.length > 0){
        this.receiverInfo = val[0];
      }
    }).catch(err => {
      console.log(err);
      Agnes.showError('Cannot display ' + this.receiverInfo['fname'] + '\'s profile - try again!');
    });

    //handle message received push notification - display new message in chat
    this.events.subscribe('messageReceived', (value) => {
      this.rmNotifications();

      let data = value['sender'];

      if(value.event){
        data['sid'] = value['message']['sid'];

        if(value.event['picurl'] == '' || value.event['thumbnail'] == '') {
          value.event['thumbnail'] = "assets/img/pattern_" + Math.floor((Math.random() * 15) + 1) + '.png';
        }
        data['body'] = {
          'message': value['event'],
          'igiyg': true,
          'extra':''
        };

        let time = Agnes.processGMT(value['event']['starttime']);
        data['body']['message']['date'] = time.date.substring(5,time.date.length);
        data['body']['message']['time'] = time.time;

      }
      else {
        data['body'] = JSON.parse(data['lastmessage']);
      }

      let ind = this.messages.map(function (a) {
        return a['dateString']
      }).indexOf('Today');
      if (ind == -1) {
        this.messages.push({
          dateString: 'Today',
          messages: [data],
        });
      }
      else {
        data['showTimestamp'] =
          (((new Date(data['date_created']).getTime() - new Date(this.messages[ind]['messages'][(this.messages[ind]['messages'].length - 1)]['date_created']).getTime()) / 60000)
          > 10);
        this.messages[ind]['messages'].push(data);
      }
      this.updateScroll('message received', 500);
    });

    //close chat if user is trying to open another chat from a push notification
    this.events.subscribe('closeCurrentChat', (id) => {
      if(id == this.receiverInfo['_id']) {
        this.closeChatProfile();
      }
    });

    //decrease notification badge if chat was stored in local storage notifications
    this.rmNotifications();

  }

  //scrolls to bottom whenever the page has loaded
  ionViewDidEnter(){
    // this.chatRoom.scrollToBottom(300);//300ms animation speed
  }

  ionViewDidLoad(){
      if (this.platform.is('ios')) {
        this.addKeyboardListeners();
      }

      this.scrollContentElelment = this.chatRoom.getScrollElement();

      this.footerElement = document.getElementsByTagName('chat-profile')[0].getElementsByTagName('ion-footer')[0];
      this.inputElement = document.getElementsByTagName('chat-profile')[0].getElementsByTagName('textarea')[0];

      this.footerElement.style.cssText = this.footerElement.style.cssText + "transition: all " + this.millis + "ms; -webkit-transition: all " +
          this.millis + "ms; -webkit-transition-timing-function: ease-out; transition-timing-function: ease-out;"

      this.scrollContentElelment.style.cssText = this.scrollContentElelment.style.cssText + "transition: all " + this.millis + "ms; -webkit-transition: all " +
          this.millis + "ms; -webkit-transition-timing-function: ease-out; transition-timing-function: ease-out;"

      this.textareaHeight = Number(this.inputElement.style.height.replace('px', ''));
      this.initialTextAreaHeight = this.textareaHeight;

      this.updateScroll('load', 500)
    }

  addKeyboardListeners() {

    this.keyboardHideSub = Agnes.keyboard.onKeyboardHide().subscribe(() => {
      let newHeight = this.textareaHeight - this.initialTextAreaHeight + 44;
      let marginBottom = newHeight + 'px';
      this.renderer.setElementStyle(this.scrollContentElelment, 'marginBottom', marginBottom);
      this.renderer.setElementStyle(this.footerElement, 'marginBottom', '0px')
    });

    this.keybaordShowSub = Agnes.keyboard.onKeyboardShow().subscribe((e) => {

      let newHeight = (e['keyboardHeight']) + this.textareaHeight - this.initialTextAreaHeight;
      let marginBottom = newHeight + 44 + 'px';
      this.renderer.setElementStyle(this.scrollContentElelment, 'marginBottom', marginBottom);
      this.renderer.setElementStyle(this.footerElement, 'marginBottom', e['keyboardHeight'] + 'px');
      this.updateScroll('keyboard show', this.scrollTimeout);
    });
  }

  updateScroll(from, timeout) {
    setTimeout(() => {
      this.chatRoom.scrollToBottom();
    }, timeout);
  }

  textAreaChange() {

    let newHeight = Number(this.inputElement.style.height.replace('px', ''));
    if (newHeight !== this.textareaHeight) {

      let diffHeight = newHeight - this.textareaHeight;
      this.textareaHeight = newHeight;
      let newNumber = Number(this.scrollContentElelment.style.marginBottom.replace('px', '')) + diffHeight;

      let marginBottom = newNumber + 'px';
      this.renderer.setElementStyle(this.scrollContentElelment, 'marginBottom', marginBottom);
      this.updateScroll('textAreaChange', this.scrollTimeout);
    }
  }

  removeKeyboardListeners() {
    this.keyboardHideSub.unsubscribe();
    this.keybaordShowSub.unsubscribe();
  }

  //apply correct CSS class for chat image based on orientation
  imgLoad(ev){
    let img = ev.target;
    if (img.naturalWidth > img.naturalHeight) {
      this.orientation = 'landscape';
    } else if (img.naturalWidth < img.naturalHeight) {
      this.orientation = 'portrait';
    } else {
      this.orientation = 'even';
    }
  }

  callFunction() {
    if(this.scrollDown){
      this.chatRoom.resize();
      this.chatRoom.scrollToBottom(0);
      this.chatRoom.resize();
      this.scrollDown = false;
    }
  }

  ngOnDestroy() {
    this.setUnread();
    if(this.hasPlugins) {
      Agnes.keyboard.disableScroll(false);
      Agnes.keyboard.hideKeyboardAccessoryBar(false);
    }
    this.events.unsubscribe('messageReceived');
    localStorage.removeItem('agnesChat');
  }

  setUnread(){
    let usData = {
      'user1': this.user['_id'],
      'user2': this.receiverInfo['_id'],
      'status': true
    };
    this.chatService.unreadStatus(usData).then(value => {
      if(value['success'] == false && value['message'] == 'Failed to authenticate token.') {
        Agnes.showError('Your login token has expired, please sign in again!');
        this.events.publish('logout');
      }
    }).catch(err => {
      this.setUnread();
    });
  }

  initMessages(receiverId) {
    this.events.publish('readChat', this.receiverInfo['_id']);

    let data = {
      'users_id': this.user['_id'],
      'deviceId': this.user['deviceid'],
      'community': this.user['community']
    };

    let ind = this.user['channels'].map(a => {return a['receiverId']}).indexOf(this.channel['_id']);
    if(ind != -1){
      this.connected = true;

      //check local storage for cached messages b/w user and chat recipient
      let chats = JSON.parse(localStorage.getItem('agnesChat'+this.receiverInfo['_id']));

      if(chats){
        this.messages = chats;
        this.chatRoom.scrollToBottom(300);
      }
      this.chatService.twilioToken(data).then(val => {
        let chatClient = new window['Twilio'].Chat.Client(val['token']);
        chatClient.initialize()
            .then(() => {
              chatClient.getChannelBySid(this.channel['sid']).then(channel => {
                this.activeChannel = channel;

                //get messages from beginning if no storage
                this.activeChannel.getMessages(50).then(messages => {
                  this.paginator = messages;
                  if(!chats){
                    this.getAllMessages(messages);
                  }
                });

                //set up to receive typing indicator
                this.activeChannel.on('typingStarted', member => {
                  this.isTyping = true;
                });

                //set  the listener for the typing ended Channel event
                this.activeChannel.on('typingEnded', member => {
                  this.isTyping = false;
                });
              });
            });
      }).catch(err => {
        console.log(err);
      });
    }
    else {
      this.connected = false;
      this.loading = false;
      this.tMessages = [];
    }
  }

  getAllMessages(paginator){
    let ms = paginator.items.map(a => {
      return {
        'body': JSON.parse(a.body),
        'from': a.author,
        'date_created': new Date(a.dateUpdated),
        'sid': a.sid
      }
    });
    this.tMessages = ms.concat(this.tMessages);

    this.processMessages(this.tMessages,false);
  }

  rmNotifications() {
    //remove background notification
    let nts = JSON.parse(localStorage.getItem('agnesNotifications'));
    if(nts){
      //remove notification from local storage and decrease badge
      let anInd = null;
      let x = 0;
      while (anInd == null && x < nts.length) {
        if (nts[x]['type'] == 'chat' && nts[x]['from'] == this.receiverInfo['_id']) {
          anInd = x;
        }
        else{
          x++;
        }
      }
      if(anInd != null){
        nts.splice(anInd,1);
        Agnes.badge.decrease(1);
        localStorage.setItem('agnesNotifications',JSON.stringify(nts));
      }
    }
  }

  closeChatProfile() {

    if(this.messages.length > 0){
      let lastMs = this.messages[this.messages.length-1].messages;
      let last = lastMs[lastMs.length - 1];

      let data = {
        lastmessage: last['body'],
        time: last.date_created,
        _id: this.receiverInfo['_id'],
        lname: this.receiverInfo['lname'],
        fname: this.receiverInfo['fname'],
        status: true,
        picurl: this.receiverInfo['picurl'],
        from: last['from']
      };

      this.events.publish('chatProfileData',data);

      let messages = this.messages;
      let newMs = this.storeMessages(50,messages);
      localStorage.setItem('agnesChat'+this.receiverInfo['_id'], JSON.stringify(newMs));
    }

    this.inputElement.blur();

    this.navCtrl.pop({
      animate: true,
      animation: 'ios-transition',
      duration: 350,
      easing: "ease-in-out",
      direction: "back"
    }).then(() => {
      if (this.platform.is('ios')) {
        this.removeKeyboardListeners();
      }
    });

  }

  storeMessages(limit, messages){
    let stored = [];
    let lastM = messages.length - 1;
    if(limit > 0 && lastM >= 0){
      if(messages[lastM]['messages'].length > limit){
        //store as many as limit will allow and return
        let item = {
          dateString: messages[lastM]['dateString'],
          messages: messages[lastM]['messages'].slice(messages[lastM]['messages'].length - limit, messages[lastM]['messages'].length)
        };
        return [item];
      }
      else {
        return this.storeMessages(limit - messages[lastM]['messages'].length, messages.slice(0,lastM)).concat([messages[lastM]]);
      }
    }
    else {
      return stored;
    }
  }

  openChatMenu() {
    let btns = [
      {
        text: 'Report',
        icon:'md-flag',
        handler: () => {this.reportUser();}
      },{
        text: 'Cancel',
        role: 'cancel',
        icon: 'md-close',
        handler: () => {}
      }
    ];

    let actionSheet = this.actionSheetCtrl.create({
      title: '',
      buttons: btns
    });
    actionSheet.present();
  }

  processMessages(ms, more) {
    let today = new Date().toLocaleDateString();
    let date = null;
    let dateString = '';
    let ind = null;

    for (var m = 0; m < ms.length; m++) {

      date = new Date(ms[m]['date_created']);
      dateString = (date.toLocaleDateString() == today) ? 'Today' : date.toLocaleDateString();
      ms[m]['timestamp'] = date.toLocaleTimeString().replace(/:\d\d\s/, '');
      let compDate = more ? (m == ms.length - 1 ? null : new Date(ms[m + 1]['date_created'])) :
          (m == 0 ? null : new Date(ms[m-1]['date_created']));

      ms[m]['showTimestamp'] = more ? (m == ms.length-1 ? true :
              (m == 0 ? false : ((date.getTime() - compDate.getTime()) / 60000 > 10))) :
          (m > 0 ? ((date.getTime() - compDate.getTime()) / 60000 > 10) : true);

      ind = this.messages.map(function (a) {
        return a['dateString'];
      }).indexOf(dateString);
      if (ind == -1) {
        let item = {
          'dateString': dateString,
          messages: [ms[m]]
        };
        if (more) {
          this.messages = [item].concat(this.messages);
        }
        else {
          this.messages.push(item);
        }
      }
      else {
        if (more) {
          this.messages[ind]['messages'] = [ms[m]].concat(this.messages[ind]['messages']);
        }
        else {
          this.messages[ind]['messages'].push(ms[m]);
        }
      }
    }

    this.messages.sort(function(a,b) {
      var aDate = +new Date(a['dateString']);
      var bDate = +new Date(b['dateString']);
      return aDate - bDate;
    });

    this.loading = false;

      if(!localStorage.getItem('agnesChat'+this.receiverInfo['_id'])){
          localStorage.setItem('agnesChat'+this.receiverInfo['_id'], JSON.stringify(this.messages));
      }

    if(!more){this.chatRoom.scrollToBottom(300);}
  }

  //TODO
  muteChat(){

  }

  //TODO
  reportUser(){

    let reportPage = this.popoverCtrl.create(
      ReportPage,
      {
        'entityID': this.receiverInfo['_id'],
        'entityName': this.receiverInfo['fname'] + ' ' + this.receiverInfo['lname'],
        'user': this.user,
        'type': 'people',
        'platform': this.platform
      },
      {'enableBackdropDismiss': true});
    reportPage.present(
      {
        animate: false
      }
    );
  }

  //TODO
  deleteChatHistory(){
  }

  resend(message){
    if(message['hasError']) {
      this.sendMessage(true,message);
    }
  }

  sendMessage(resend, msg) {
    if(resend || (!resend && this.messageText.trim() != '')){
      let message = resend ? msg['body'] : this.messageText;
      let messageObj=
        {
          "user1":this.user['_id'],
          "user2":this.receiverInfo['_id'],
          "message":message
        };

      if(this.connected){
        let date = resend ? msg['date_created'] : new Date();

        let messageObjPush = {
          body: {
            'message': message,
            'igyig': false,
            'extra': null},
          date_updated: 'now',
          id: this.user['_id'],
          picurl:this.user['picurl'],
          date_created: date,
          timestamp: date.toLocaleTimeString().replace(/:\d\d\s/,''),
          showTimestamp: true,
          notSent: true,
          from: this.user['_id']
        };

        if(!resend){
          let ind = this.messages.map(function(a){return a['dateString']}).indexOf('Today');
          if(ind == -1){
            this.messages.push({
              dateString: 'Today',
              messages:[messageObjPush],
            });
          }
          else {
            messageObjPush['showTimestamp'] =
              (((date.getTime() - new Date(this.messages[ind]['messages'][(this.messages[ind]['messages'].length-1)]['date_created']).getTime())/60000)
              > 10);
            this.messages[ind]['messages'].push(messageObjPush);
          }
          this.messageText = '';
        }

        let mInd = this.messages[this.messages.length-1]['messages'].map(function(b){return new Date(b['date_created']).toString()})
          .indexOf(date.toString());
        this.messages[this.messages.length-1]['messages'][mInd]['hasError'] = false;

        this.chatService.sendMessage(messageObj).then(value => {
          if(value['success'] == false && value['message'] == 'Failed to authenticate token.') {
            Agnes.showError('Your login token has expired, please sign in again!');
            this.events.publish('logout');
          }
          else {
            this.scrollDown = true;

            this.messages[this.messages.length-1]['messages'][mInd]['notSent'] = false;
            this.messages[this.messages.length-1]['messages'][mInd]['hasError'] = false;

            this.chatRoom.scrollToBottom(0);
          }
        }).catch(err => {
          console.log('send error',err);
          this.messages[this.messages.length-1]['messages'][mInd]['hasError'] = true;
        });
      }
      else {
        console.log(messageObj);

        this.chatService.createChannel(messageObj).then(value => {
          if(value['success'] == false && value['message'] == 'Failed to authenticate token.') {
            Agnes.showError('Your login token has expired, please sign in again!');
            this.events.publish('logout');
          }
          else {
            this.connected = true;
            this.sendMessage(resend,msg);

              let data = {
                  'users_id': this.user['_id'],
                  'deviceId': this.user['deviceid'],
                  'community': this.user['community']
              };

              this.chatService.twilioToken(data).then(val => {
                  let chatClient = new window['Twilio'].Chat.Client(val['token']);
                  chatClient.initialize()
                      .then(() => {
                          chatClient.getChannelBySid(value['sid']).then(channel => {
                              this.activeChannel = channel;

                              //set up to receive typing indicator
                              this.activeChannel.on('typingStarted', member => {
                                  this.isTyping = true;
                              });

                              //set  the listener for the typing ended Channel event
                              this.activeChannel.on('typingEnded', member => {
                                  this.isTyping = false;
                              });
                          });
                      });
              }).catch(err => {
                  console.log(err);
              });
          }
        }).catch(err => {
          console.log('create channel err',err);
        });
      }
    }
  }

  onEnter(ev){
    //if the RETURN/ENTER key is pressed, send the message
    if (ev.keyCode === 13) {
      this.sendMessage(false,null);
    }
    //else send the Typing Indicator signal
    else {
        if(this.activeChannel){this.activeChannel.typing();}
    }
  }

  openPeopleProfile(){
    if(this.canOpenProfile) {
      this.canOpenProfile = false;

      this.events.subscribe('peopleProfileClosed', () => {
        this.events.unsubscribe('peopleProfileClosed');
        this.canOpenProfile = true;
      });

      this.appCtrl.getRootNav().push(
          'PeopleProfile',
          {
            'person':this.receiverInfo,
            'user':this.user,
            'platform': this.platform
          }, {
            animation: 'ios-transition',
            duration: 350
          });
    }
  }

  deleteMessage(date, message, reject){
      
    let data = {
      'user1': this.user['_id'],
      'user2': this.receiverInfo['_id'],
      'sid': message['sid']
    };

    this.chatService.deleteMessage(data).then(val => {
      if(val['success'] == false && val['message'] == 'Failed to authenticate token.') {
        Agnes.showError('Your login token has expired, please sign in again!');
        this.events.publish('logout');
      }
      else {
        //remove message from display
        let dInd = this.messages.indexOf(date);

        if(dInd != -1){
          let mInd = this.messages[dInd]['messages'].indexOf(message);
          if(mInd != -1){
            this.messages[dInd]['messages'].splice(mInd,1);

            if(this.messages[dInd]['messages'].length == 0) {
              this.messages.splice(dInd,1);
            }
          }
        }
      }
    }).catch(err => {
      console.log('delete m error', err);
      Agnes.showError('Couldn\'t remove this message - try again!');
      //keep trying bc idk
      //this.deleteMessage(date,message, reject);
    });

  }

  keepKeyboard(event)  {
  if(!this.shouldBlur || event.relatedTarget || this.reset){
    event.target.focus();

    // Reset so other elements will blur the keyboard
    this.shouldBlur = true;
    this.reset = !this.reset;
  }
}

  resetBlur() {
    this.reset = true;
  }

  flipBlur() {
    this.shouldBlur = false;
    this.reset = false;
  }

  loadMoreChat(refresher){
      // this.activeChannel.getMessages(50,this.messages.map(a => {return a['messages']}).reduce(function(a, b) {
      //       return a.concat(b);}).length - 50).then(val =>{
      //   let ms = val.items.map(a => {
      //     return {
      //       'body': JSON.parse(a.body),
      //       'from': a.author,
      //       'date_created': new Date(a.dateUpdated)
      //     }
      //   });
      //   ms.reverse();
      //   this.processMessages(ms, true);
      //   refresher.complete();
      // }).catch(() => {
      //   refresher.complete();
      // });
    if(!this.paginator){
      refresher.complete();
    }
    else {
      if(this.paginator.hasPrevPage){
        this.paginator.prevPage().then(val =>{
          this.paginator = val;
          let ms = val.items.map(a => {
            return {
              'body': JSON.parse(a.body),
              'from': a.author,
              'date_created': new Date(a.dateUpdated)
            }
          });
          ms.reverse();
          this.processMessages(ms, true);
          refresher.complete();
        });
      }
      else {
        this.canLoadMore = false;
        refresher.complete();
      }
    }
  }

  footerTouchStart(event) {
    if (event.target.localName !== "textarea") {
      event.preventDefault();
    }
  }

  contentMouseDown(event) {
    this.inputElement.blur();
  }

}




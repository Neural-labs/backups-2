var SpecReporter = require('jasmine-spec-reporter').SpecReporter;

exports.config = {
    allScriptsTimeout: 99999,
    directConnect: true,
    capabilities: {
        'browserName': 'chrome'
    },
    framework: 'jasmine',
    jasmineNodeOpts: {
        showColors: true,
        defaultTimeoutInterval: 99999,
        print: function() {}
    },
    suites: {
        entry: ['./src/e2e/entry/login.e2e-spec.ts']//, './src/e2e/password-popup.e2e-spec.ts']
    },
    baseUrl: 'http://localhost:8100',
    useAllAngular2AppRoots: true,
    beforeLaunch: function() {

        require('ts-node').register({
            project: 'src/e2e'
        });

        require('connect')().use(require('serve-static')('www')).listen(8100);

    },
    onPrepare: function() {
        jasmine.getEnv().addReporter(new SpecReporter());
    }
}
import { Component} from '@angular/core';
import { NavController, ViewController } from 'ionic-angular';
import * as Bodymovin from 'bodymovin';

@Component({
  selector: 'pebble-popup',
  templateUrl: 'pebble-popup.html'
})

export class PebblePopup {

  constructor(public viewCtrl: ViewController) {}

  ionViewDidLoad(){
      this.showPebbleAnimation()
  }

  showPebbleAnimation() {
      setTimeout(() => {
        let animation = Bodymovin.loadAnimation({
            container: document.getElementById('popupBody'), // Required
            path: 'assets/img/star.json', // Required
            renderer: 'svg/canvas/html', // Required
            loop: false, // Optional
            autoplay: true, // Optional
            name: "Pebble", // Name for future reference. Optional.
        })
        this.dismissAnimation()
        }, 3000)
    }

dismissAnimation() {

    setTimeout(() => {
      this.viewCtrl.dismiss(false,'',{
        animate: false
      });
    },3000);
  }

}
